# Exact Braid Algebra and Diamond-Norm Bounds for a Phenomenological Noisy Fibonacci-Anyon Qubit

**Andrei Preece and Boris Batenin**  
Independent Researchers  
Berlin, 2026

## Research materials

This archive contains the full mathematical manuscript in PDF and LaTeX, the Lean source files accompanying its formal treatment, the numerical-checking script, and its saved results. The equations, theorem statements, mathematical proofs, bibliography, and the scope of formal verification are in the manuscript.

Start with `paper/2026_11_09_Exact_Braid_Algebra_and_Diamond_Norm_Bounds_for_a_Phenomenological_Noisy_Fibonacci_Anyon_Qubit.pdf`. The corresponding source is `paper/2026_11_09_Exact_Braid_Algebra_and_Diamond_Norm_Bounds_for_a_Phenomenological_Noisy_Fibonacci_Anyon_Qubit.tex`.

## Structure

- `paper/` — complete PDF manuscript and matching LaTeX source.
- `Fibonacci/` — Lean modules for fusion paths, braid algebra, golden-ratio specialization, quantum noise, and composition bounds.
- `Fibonacci.lean` — top-level Lean library imports.
- `lean-toolchain`, `lakefile.toml` — Lean and Mathlib environment specifications.
- `scripts/check_numeric.py` — symbolic algebra checks and numerical tests.
- `scripts/run_lean_audit_mac.zsh` — Lean compilation and axiom-audit procedure for macOS.
- `results/numerical_report.json` — saved results of symbolic and numerical checks.
- `SHA256SUMS.txt` — file-integrity checksums.

## Proof and verification scope

The paper supplies analytic mathematical proofs of the braid relation, the exact single-gate diamond-norm formulas, and the compatible-channel composition estimate. The accompanying Lean modules encode selected results and conditional theorems. In particular, the concrete physical-phase specialization and exact superoperator diamond-norm theorem have not been completed in Lean. The supplied Lean files have not been independently compiled and kernel-audited as part of this release. Consequently, their presence does not establish complete Lean certification; see the Lean-source section and the reproducibility appendix of the paper for the exact boundaries.

The numerical report records the checks performed by the supplied Python script. Numerical tests are not a substitute for analytic proof or formal kernel checking.

## Reproduction

For symbolic and numerical tests, from the extracted project root with Python dependencies NumPy, SciPy, and SymPy available:

```sh
python3 scripts/check_numeric.py
```

For Lean compilation and inspection on a configured macOS system:

```sh
zsh scripts/run_lean_audit_mac.zsh
```

The initial Lean/Mathlib installation can require internet access. Reading the PDF, LaTeX proofs, code, and saved numerical results requires no network access. A successful Lean run creates `results/lean_axioms.log`; the log is not included because no such run was completed for the supplied source.

## References

The bibliography is contained in the manuscript. No separate foundational manuscript is identified in the text as a required missing supplement to the included proofs.
