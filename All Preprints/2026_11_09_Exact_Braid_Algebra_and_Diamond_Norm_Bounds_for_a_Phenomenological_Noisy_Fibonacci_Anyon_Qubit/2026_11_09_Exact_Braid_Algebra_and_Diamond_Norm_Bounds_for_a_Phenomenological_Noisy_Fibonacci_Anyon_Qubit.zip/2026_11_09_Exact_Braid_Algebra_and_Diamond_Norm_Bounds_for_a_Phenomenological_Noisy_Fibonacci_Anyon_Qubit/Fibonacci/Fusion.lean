import Mathlib

/-!
# Fibonacci anyon fusion, with explicit path counts
This file contains executable fusion rules, not an assumed category instance.
Physical coherence (pentagon/hexagon) is a distinct further obligation.
-/
namespace Fibonacci

inductive Charge where
  | vacuum
  | tau
  deriving DecidableEq, Repr, Fintype

/-- Admissible simple charges in a binary fusion. -/
def outcomes : Charge → Charge → List Charge
  | .vacuum, x => [x]
  | .tau, .vacuum => [.tau]
  | .tau, .tau => [.vacuum, .tau]

theorem tau_fuses_tau : outcomes .tau .tau = [.vacuum, .tau] := rfl
theorem vacuum_is_left_unit (x : Charge) : outcomes .vacuum x = [x] := by
  cases x <;> rfl
theorem vacuum_is_right_unit (x : Charge) : outcomes x .vacuum = [x] := by
  cases x <;> rfl

/-- Number of fusion paths of `n` copies of τ, starting at vacuum and
    ending in the specified total charge. -/
def paths : Nat → Charge → Nat
  | 0, .vacuum => 1
  | 0, .tau => 0
  | n+1, .vacuum => paths n .tau
  | n+1, .tau => paths n .vacuum + paths n .tau

theorem paths_tau_rec (n : Nat) :
    paths (n+2) .tau = paths (n+1) .tau + paths n .tau := by
  simp only [paths]
  omega

theorem three_tau_two_paths : paths 3 .tau = 2 := by decide
theorem three_tau_one_vacuum_path : paths 3 .vacuum = 1 := by decide

/-- Two fusion labels for three τ anyons constrained to total charge τ. -/
inductive ThreeTauBasis where
  | intermediateVacuum
  | intermediateTau
  deriving DecidableEq, Repr, Fintype

/-- Explicit identification with a qubit basis. -/
def basisFin : ThreeTauBasis ≃ Fin 2 where
  toFun
    | .intermediateVacuum => 0
    | .intermediateTau => 1
  invFun := fun i =>
    if i = 0 then .intermediateVacuum else .intermediateTau
  left_inv := by
    intro x
    cases x <;> rfl
  right_inv := by
    intro x
    fin_cases x <;> rfl

end Fibonacci
