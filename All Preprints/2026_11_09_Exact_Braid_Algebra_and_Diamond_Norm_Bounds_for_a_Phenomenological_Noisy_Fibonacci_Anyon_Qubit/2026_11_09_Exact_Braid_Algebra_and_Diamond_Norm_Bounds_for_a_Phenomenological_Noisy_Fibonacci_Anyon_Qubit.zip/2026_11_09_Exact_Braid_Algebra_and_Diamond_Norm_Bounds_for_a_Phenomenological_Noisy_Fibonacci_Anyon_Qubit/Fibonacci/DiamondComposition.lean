import Mathlib

/-!
# Universal certified norm-composition estimates

The theorems below are mathematical theorems in any normed (possibly
noncommutative) ring. A fully certified diamond-norm application still
needs an actual CPTP-superoperator normed-algebra instance using the
completely bounded trace norm; that bridge is NOT in this package.
-/
namespace Fibonacci

variable {A : Type*} [NormedRing A]

/-- Two-step difference estimate. Used for completely bounded trace norm
    once channel composition is represented by ring multiplication. -/
theorem two_step_error (x y u v : A)
    (hy : ‖y‖ ≤ 1) (hu : ‖u‖ ≤ 1) :
    ‖x*y-u*v‖ ≤ ‖x-u‖+‖y-v‖ := by
  have hid : x*y-u*v=(x-u)*y+u*(y-v) := by
    simp only [sub_mul, mul_sub]
    abel
  calc
    ‖x*y-u*v‖ = ‖(x-u)*y+u*(y-v)‖ := by rw [hid]
    _ ≤ ‖(x-u)*y‖+‖u*(y-v)‖ := norm_add_le _ _
    _ ≤ ‖x-u‖*‖y‖+‖u‖*‖y-v‖ :=
      add_le_add (norm_mul_le _ _) (norm_mul_le _ _)
    _ ≤ ‖x-u‖+‖y-v‖ := by
      have h1 : ‖x-u‖*‖y‖ ≤ ‖x-u‖ := by
        calc
          _ ≤ ‖x-u‖*1 := mul_le_mul_of_nonneg_left hy (norm_nonneg _)
          _ = ‖x-u‖ := mul_one _
      have h2 : ‖u‖*‖y-v‖ ≤ ‖y-v‖ := by
        calc
          _ ≤ 1*‖y-v‖ := mul_le_mul_of_nonneg_right hu (norm_nonneg _)
          _ = ‖y-v‖ := one_mul _
      linarith

/-- Chronologically ordered product of n channel operators. -/
def word (f : ℕ → A) : ℕ → A
  | 0 => 1
  | n+1 => f n * word f n

theorem word_norm_le_one (f : ℕ → A)
    (hf : ∀ i, ‖f i‖ ≤ 1) (n : ℕ) :
    ‖word f n‖ ≤ 1 := by
  induction n with
  | zero => simp [word]
  | succ n ih =>
    change ‖f n * word f n‖ ≤ 1
    calc
      _ ≤ ‖f n‖*‖word f n‖ := norm_mul_le _ _
      _ ≤ 1*‖word f n‖ :=
        mul_le_mul_of_nonneg_right (hf n) (norm_nonneg _)
      _ ≤ 1*1 := mul_le_mul_of_nonneg_left ih (by norm_num)
      _ = 1 := by ring

/-- n-gate telescoping bound. Every assumption is explicit. -/
theorem word_error (noisy ideal : ℕ → A)
    (hn : ∀ i, ‖noisy i‖ ≤ 1)
    (hi : ∀ i, ‖ideal i‖ ≤ 1) (n : ℕ) :
    ‖word noisy n-word ideal n‖ ≤
      ∑ i ∈ Finset.range n, ‖noisy i - ideal i‖ := by
  induction n with
  | zero => simp [word]
  | succ n ih =>
    change ‖noisy n * word noisy n-ideal n * word ideal n‖ ≤ _
    have h := two_step_error (noisy n) (word noisy n)
      (ideal n) (word ideal n) (word_norm_le_one noisy hn n) (hi n)
    calc
      _ ≤ ‖noisy n-ideal n‖+‖word noisy n-word ideal n‖ := h
      _ ≤ ‖noisy n-ideal n‖ + ∑ i ∈ Finset.range n, ‖noisy i-ideal i‖ :=
        add_le_add_left ih _
      _ = ∑ i ∈ Finset.range (n+1), ‖noisy i-ideal i‖ := by
        rw [Finset.sum_range_succ]
        ring

end Fibonacci
