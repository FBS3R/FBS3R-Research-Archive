import Mathlib

/-!
# Algebraic 2×2 Fibonacci braid identity

This file deliberately avoids importing an unproved quantum-category API.
It proves a symbolic Yang–Baxter identity for explicit F/R matrices,
conditional ONLY on two displayed polynomial identities.
It does not itself certify that the physical exponential phases satisfy them.
-/
namespace Fibonacci

structure Mat2 (α : Type*) where
  a00 : α
  a01 : α
  a10 : α
  a11 : α
  deriving Repr

/-- Matrix multiplication, written out to avoid hidden normalization. -/
def mmul (A B : Mat2 ℂ) : Mat2 ℂ :=
  ⟨A.a00*B.a00+A.a01*B.a10,
   A.a00*B.a01+A.a01*B.a11,
   A.a10*B.a00+A.a11*B.a10,
   A.a10*B.a01+A.a11*B.a11⟩

def one2 : Mat2 ℂ := ⟨1, 0, 0, 1⟩

def Fmat (u v : ℂ) : Mat2 ℂ := ⟨u, v, v, -u⟩
def Rmat (a b : ℂ) : Mat2 ℂ := ⟨a, 0, 0, b⟩

def braid1 (a b : ℂ) : Mat2 ℂ := Rmat a b
def braid2 (u v a b : ℂ) : Mat2 ℂ :=
  mmul (mmul (Fmat u v) (Rmat a b)) (Fmat u v)

theorem mmul_assoc (A B C : Mat2 ℂ) :
    mmul (mmul A B) C = mmul A (mmul B C) := by
  apply Mat2.ext <;> simp only [mmul] <;> ring

theorem mmul_one (A : Mat2 ℂ) : mmul A one2 = A := by
  apply Mat2.ext <;> simp [mmul, one2]

theorem one_mmul (A : Mat2 ℂ) : mmul one2 A = A := by
  apply Mat2.ext <;> simp [mmul, one2]

/-- Orthogonal recoupling matrix, proved directly by four entry equalities. -/
theorem Fmat_square (u v : ℂ) (h : u*u+v*v = 1) :
    mmul (Fmat u v) (Fmat u v) = one2 := by
  apply Mat2.ext
  · simpa only [mmul, Fmat, one2] using h
  · simp [mmul, Fmat, one2]; ring
  · simp [mmul, Fmat, one2]; ring
  · simpa only [mmul, Fmat, one2, neg_mul, mul_neg, neg_neg] using h

/-- Symbolic braid relation. hF and hR are the explicitly exposed obligations:
    u²+v²=1 and u²(a-b)²+ab=0.
    The proof is an exact polynomial identity, not a numerical test. -/
theorem braid_relation (u v a b : ℂ)
    (hF : u*u+v*v=1)
    (hR : (a-b)^2*u^2+a*b=0) :
    mmul (mmul (braid1 a b) (braid2 u v a b)) (braid1 a b) =
      mmul (mmul (braid2 u v a b) (braid1 a b)) (braid2 u v a b) := by
  have hunit : u^2 + v^2 - 1 = 0 := by
    calc
      u^2+v^2-1 = (u*u+v*v)-1 := by ring
      _ = 0 := by rw [hF]; ring
  apply Mat2.ext
  · dsimp [mmul, braid1, braid2, Fmat, Rmat]
    linear_combination
      (a-b)*v^2*hR - a*(a^2*u^2+b^2*v^2)*hunit
  · dsimp [mmul, braid1, braid2, Fmat, Rmat]
    linear_combination
      (-u*v*(a-b))*hR - 2*a*b*u*v*(a-b)*hunit
  · dsimp [mmul, braid1, braid2, Fmat, Rmat]
    linear_combination
      (-u*v*(a-b))*hR - 2*a*b*u*v*(a-b)*hunit
  · dsimp [mmul, braid1, braid2, Fmat, Rmat]
    linear_combination
      (-(a-b)*v^2)*hR - b*(a^2*v^2+b^2*u^2)*hunit

end Fibonacci
