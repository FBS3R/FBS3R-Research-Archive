import Fibonacci.GoldenF

/-!
# Physical effective noise: logical fusion-basis dephasing + flagged leakage

The 2-dimensional code H_code is embedded into H_out = C² ⊕ C|L|.
The following Kraus maps define a completely positive map by construction.
Trace preservation holds provided 0≤q,ell≤1 and U is unitary; the
matrix-level kernel proof of that fact is NOT included in this module.
This is a phenomenological effective channel, not a microscopic anyon bath.
-/
namespace Fibonacci

abbrev LogicalMat := Matrix (Fin 2) (Fin 2) ℂ
abbrev OutputMat := Matrix (Fin 3) (Fin 3) ℂ
abbrev KrausMat := Matrix (Fin 3) (Fin 2) ℂ

/-- Embedding of the logical fusion space into code plus orthogonal flag. -/
def encode : KrausMat := !![1, 0; 0, 1; 0, 0]

/-- Logical fusion-channel phase flip. -/
def logicalZ : LogicalMat := !![1, 0; 0, -1]

/-- Leak each logical basis vector into the orthogonal erasure state. -/
def leak0 : KrausMat := !![0, 0; 0, 0; 1, 0]
def leak1 : KrausMat := !![0, 0; 0, 0; 0, 1]

/-- Convert the certified algebraic 2×2 data to the standard matrix type. -/
def toMatrix (M : Mat2 ℂ) : LogicalMat :=
  !![M.a00, M.a01; M.a10, M.a11]

/-- Explicit Kraus decomposition of a single noisy braid. -/
noncomputable def kraus0 (q ell : ℝ) (U : LogicalMat) : KrausMat :=
  ((Real.sqrt ((1-ell)*(1-q)) : ℝ) : ℂ) • (encode * U)
noncomputable def kraus1 (q ell : ℝ) (U : LogicalMat) : KrausMat :=
  ((Real.sqrt ((1-ell)*q) : ℝ) : ℂ) • (encode * logicalZ * U)
noncomputable def kraus2 (ell : ℝ) : KrausMat :=
  ((Real.sqrt ell : ℝ) : ℂ) • leak0
noncomputable def kraus3 (ell : ℝ) : KrausMat :=
  ((Real.sqrt ell : ℝ) : ℂ) • leak1

/-- Schrödinger-picture noisy map L(C²) -> L(C³). -/
noncomputable def noisyGate (q ell : ℝ) (U : LogicalMat)
    (ρ : LogicalMat) : OutputMat :=
    kraus0 q ell U * ρ * (kraus0 q ell U)ᴴ
  + kraus1 q ell U * ρ * (kraus1 q ell U)ᴴ
  + kraus2 ell * ρ * (kraus2 ell)ᴴ
  + kraus3 ell * ρ * (kraus3 ell)ᴴ

/-- The noiseless channel has the same input and output dimensions. -/
def idealGate (U : LogicalMat) (ρ : LogicalMat) : OutputMat :=
  (encode * U) * ρ * (encode * U)ᴴ

/-- Total per-gate flagged failure weight. -/
def failureWeight (q ell : ℝ) : ℝ := ell + (1-ell)*q

theorem kraus_probabilities_sum_one (q ell : ℝ) :
    (1-ell)*(1-q) + (1-ell)*q + ell = 1 := by ring

theorem failureWeight_bounds (q ell : ℝ)
    (hq0 : 0 ≤ q) (hq1 : q ≤ 1)
    (he0 : 0 ≤ ell) (he1 : ell ≤ 1) :
    0 ≤ failureWeight q ell ∧ failureWeight q ell ≤ 1 := by
  have ha : 0 ≤ (1-ell)*q :=
    mul_nonneg (sub_nonneg.mpr he1) hq0
  have hb : 0 ≤ (1-ell)*(1-q) :=
    mul_nonneg (sub_nonneg.mpr he1) (sub_nonneg.mpr hq1)
  constructor
  · unfold failureWeight
    linarith
  · unfold failureWeight
    nlinarith

end Fibonacci
