import Mathlib

/-!
# Exact norm scaling for a phase-flip mixture

Use with superoperators endowed with the actual diamond norm once an
appropriate normed-space instance has been supplied. Does NOT equate
an arbitrary norm to the diamond norm.
-/
namespace Fibonacci

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- The noisy map is the convex mixture (1-q)U+q ZU in a vector space
    of quantum superoperators. -/
def dephased (q : ℝ) (ideal phaseFlipped : E) : E :=
  (1-q) • ideal + q • phaseFlipped

theorem dephased_difference (q : ℝ) (ideal phaseFlipped : E) :
    dephased q ideal phaseFlipped - ideal = q • (phaseFlipped-ideal) := by
  unfold dephased
  rw [smul_sub]
  -- a module identity, requiring no channel-specific assumption
  module

theorem dephased_norm_exact (q : ℝ) (ideal phaseFlipped : E) :
    ‖dephased q ideal phaseFlipped - ideal‖ =
      |q| * ‖phaseFlipped - ideal‖ := by
  rw [dephased_difference, norm_smul]
  simp only [Real.norm_eq_abs]

/-- For a superoperator diamond norm this specializes to 2q only when
    the phase flip has diamond distance 2 from the identity. -/
theorem dephased_two_q (q : ℝ) (ideal phaseFlipped : E)
    (hq : 0 ≤ q) (hflip : ‖phaseFlipped-ideal‖ = 2) :
    ‖dephased q ideal phaseFlipped - ideal‖ = 2*q := by
  rw [dephased_norm_exact, hflip, abs_of_nonneg hq]
  ring

end Fibonacci
