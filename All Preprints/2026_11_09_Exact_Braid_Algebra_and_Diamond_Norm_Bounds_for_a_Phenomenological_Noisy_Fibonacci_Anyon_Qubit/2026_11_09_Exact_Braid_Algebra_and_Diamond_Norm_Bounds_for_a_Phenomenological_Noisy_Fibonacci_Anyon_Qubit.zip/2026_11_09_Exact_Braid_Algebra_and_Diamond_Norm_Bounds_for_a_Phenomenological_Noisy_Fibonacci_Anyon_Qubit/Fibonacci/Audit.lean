import Fibonacci

-- Read the full theorem statement BEFORE interpreting the axiom report.
#check Fibonacci.tau_fuses_tau
#check Fibonacci.three_tau_two_paths
#check Fibonacci.braid_relation
#check Fibonacci.goldenF_square
#check Fibonacci.physical_braid_if_phase_identity
#check Fibonacci.failureWeight_bounds
#check Fibonacci.two_step_error
#check Fibonacci.word_error
#check Fibonacci.dephased_norm_exact

-- This list must NOT include sorryAx; it is meaningful only if compilation succeeds.
#print axioms Fibonacci.tau_fuses_tau
#print axioms Fibonacci.three_tau_two_paths
#print axioms Fibonacci.braid_relation
#print axioms Fibonacci.goldenF_square
#print axioms Fibonacci.physical_braid_if_phase_identity
#print axioms Fibonacci.failureWeight_bounds
#print axioms Fibonacci.two_step_error
#print axioms Fibonacci.word_error
#print axioms Fibonacci.dephased_norm_exact
#check Fibonacci.failure_weight_equals_nonidentity
#print axioms Fibonacci.failure_weight_equals_nonidentity
