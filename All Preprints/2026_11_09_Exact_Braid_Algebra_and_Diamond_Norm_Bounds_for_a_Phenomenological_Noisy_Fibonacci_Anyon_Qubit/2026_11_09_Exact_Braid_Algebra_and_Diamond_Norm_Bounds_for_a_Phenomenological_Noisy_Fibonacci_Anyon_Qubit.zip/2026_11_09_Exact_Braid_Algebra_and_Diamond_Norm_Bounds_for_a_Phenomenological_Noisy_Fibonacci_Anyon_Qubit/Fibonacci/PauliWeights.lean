import Mathlib

/-!
# Normalization and exact failure weight for stochastic logical Pauli errors
This is algebra of the exact channel bound in the manuscript. The step
identifying these weights with a diamond norm still requires a concrete
superoperator diamond-norm model.
-/
namespace Fibonacci

structure PauliWeights where
  pI : ℝ
  pX : ℝ
  pY : ℝ
  pZ : ℝ

def normalized (p : PauliWeights) : Prop :=
  p.pI + p.pX + p.pY + p.pZ = 1

def pauliFlaggedFailure (ell : ℝ) (p : PauliWeights) : ℝ :=
  1 - (1-ell)*p.pI

theorem failure_weight_equals_nonidentity
    (ell : ℝ) (p : PauliWeights) (hp : normalized p) :
    pauliFlaggedFailure ell p =
      ell+(1-ell)*(p.pX+p.pY+p.pZ) := by
  unfold pauliFlaggedFailure
  have hs : p.pI + p.pX + p.pY + p.pZ = 1 := hp
  calc
    1 - (1-ell)*p.pI =
      (1-ell)*(p.pI+p.pX+p.pY+p.pZ)+ell-(1-ell)*p.pI := by
        rw [hs]
        ring
    _ = ell+(1-ell)*(p.pX+p.pY+p.pZ) := by ring

end Fibonacci
