#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h:h}"
cd "$ROOT"
printf '\n### TOOLCHAIN\n'
lean --version
lake --version
printf '\n### UPDATE DEPENDENCIES\n'
lake update
printf '\n### MATHLIB CACHE (if available)\n'
lake exe cache get || true
printf '\n### BUILD\n'
lake build
printf '\n### AUDIT THEOREM STATEMENTS AND AXIOMS\n'
lake env lean Fibonacci/Audit.lean 2>&1 | tee results/lean_axioms.log
if grep -Eq 'sorryAx|(^| )error:' results/lean_axioms.log; then
  echo 'VERDICT=FAIL'; exit 1
fi
printf '\nVERDICT=LEAN_BUILD_AND_AXIOM_AUDIT_PASSED\n'
printf 'Warning: this does NOT discharge any explicitly assumed hypotheses.\n'
