#!/usr/bin/env python3
"""Independent exact symbolic and high-precision physics regression checks.
This is NOT a Lean/kernel proof and NOT a complete diamond-norm SDP certificate.
"""
import json
from pathlib import Path
import numpy as np
import sympy as s
from scipy.linalg import svdvals

HERE = Path(__file__).resolve().parent.parent
u, v, a, b = s.symbols('u v a b')
F = s.Matrix([[u, v], [v, -u]])
R = s.diag(a, b)
S = F * R * F
D = (R * S * R - S * R * S).applyfunc(s.expand)
H = u**2 + v**2 - 1
Q = (a-b)**2 * u**2 + a*b
expected = s.Matrix([
    [(a-b)*v**2*Q - a*(a**2*u**2+b**2*v**2)*H,
     -u*v*(a-b)*Q-2*a*b*u*v*(a-b)*H],
    [-u*v*(a-b)*Q-2*a*b*u*v*(a-b)*H,
     -(a-b)*v**2*Q-b*(a**2*v**2+b**2*u**2)*H]
])
assert all(s.expand(D[i,j]-expected[i,j]) == 0 for i in range(2) for j in range(2))
assert (F*F-s.eye(2)).subs(v**2,1-u**2).applyfunc(s.expand) == s.zeros(2)

ug = (s.sqrt(5)-1)/2
vg = s.sqrt(ug)
assert s.simplify(ug**2 + vg**2 - 1)==0
qalg = -ug/s.Integer(2) - s.I*s.sqrt(1-ug**2/s.Integer(4))
assert s.simplify(qalg**2+ug*qalg+1)==0
assert s.simplify(ug**2*(1-qalg)**2+qalg)==0

uf, vf = float(ug), float(vg)
phase0 = np.exp(-4j*np.pi/5)
phase1 = np.exp(3j*np.pi/5)
f = np.array([[uf,vf],[vf,-uf]], dtype=complex)
r = np.diag([phase0,phase1])
b1, b2 = r, f@r@f
I = np.eye(2)
def resid(x): return float(np.linalg.norm(x,ord='fro'))
results = {
    'sympy_exact_braid_polynomial_certificate': 'PASS',
    'sympy_exact_golden_F_involution': 'PASS',
    'sympy_exact_algebraic_R_ratio': 'PASS',
    'F_unitarity_fro_error': resid(f.conj().T @ f-I),
    'B1_unitarity_fro_error': resid(b1.conj().T@b1-I),
    'B2_unitarity_fro_error': resid(b2.conj().T@b2-I),
    'yang_baxter_fro_error': resid(b1@b2@b1-b2@b1@b2),
    'phase_relation_error': float(abs((phase0-phase1)**2*uf**2 + phase0*phase1)),
    'f_matrix': [[str(x) for x in row] for row in f],
    'r_matrix': [[str(x) for x in row] for row in r],
}
assert max(results[k] for k in [
    'F_unitarity_fro_error','B1_unitarity_fro_error',
    'B2_unitarity_fro_error','yang_baxter_fro_error','phase_relation_error'
])<1e-13

# Logical dephasing and leakage are modeled on a 3-level target H_out=C^2 ⊕ span{|L>}.
# Kraus K0=sqrt((1-l)(1-q)) J U; K1=sqrt((1-l)q) J ZU;
# K2=sqrt(l)|L><0|; K3=sqrt(l)|L><1|.
J=np.array([[1,0],[0,1],[0,0]],complex)
L0=np.array([[0,0],[0,0],[1,0]],complex)
L1=np.array([[0,0],[0,0],[0,1]],complex)
Z=np.diag([1,-1]).astype(complex)
plus=np.array([1,1],complex)/np.sqrt(2)
rhoPlus=np.outer(plus,plus.conj())
checks=[]
for U in [b1,b2,b2@b1@b2]:
  for q in [0.0,0.01,0.1,0.5,1.0]:
    for leak in [0.0,0.02,0.3,1.0]:
      kraus=[np.sqrt((1-leak)*(1-q))*J@U,
             np.sqrt((1-leak)*q)*J@Z@U,
             np.sqrt(leak)*L0,
             np.sqrt(leak)*L1]
      compl=sum(K.conj().T@K for K in kraus)
      assert resid(compl-I)<1e-12
      # For leakage-free case, pick U^dagger|+> to saturate the 2q diamond bound.
      rho=U.conj().T@rhoPlus@U
      noisy=sum(K@rho@K.conj().T for K in kraus)
      ideal=J@U@rho@U.conj().T@J.conj().T
      trace_dist=float(sum(svdvals(noisy-ideal)))
      assert abs(trace_dist-2*(leak+(1-leak)*q))<2e-12
      checks.append((q,leak))
# General Pauli+erasure extension: Bell state with ancilla attains 2[1-(1-l)pI].
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
paulis=[np.eye(2,dtype=complex), X, Y, Z]
phi=np.array([1,0,0,1],complex)/np.sqrt(2)
phiD=np.outer(phi,phi.conj())
pauli_cases=0
for U in [b1,b2,b2@b1@b2]:
  for leak in [0.,0.02,0.3,1.]:
    for probs in [[1.,0.,0.,0.],[0.7,0.1,0.15,0.05],[0.25]*4,[0.,1.,0.,0.]]:
      state=np.kron(U.conj().T,I)@phiD@np.kron(U,I)
      K=[np.sqrt((1-leak)*p)*J@P@U for p,P in zip(probs,paulis)]
      K += [np.sqrt(leak)*L0, np.sqrt(leak)*L1]
      assert resid(sum(T.conj().T@T for T in K)-I)<1e-12
      out=sum(np.kron(T,I)@state@np.kron(T,I).conj().T for T in K)
      jU=np.kron(J@U,I)
      ideal=jU@state@jU.conj().T
      dist=float(sum(svdvals(out-ideal)))
      assert abs(dist-2*(1-(1-leak)*probs[0]))<2e-12
      pauli_cases+=1
results['general_Pauli_flagged_erasure_Bell_lower_bound_cases']=pauli_cases
results['general_Pauli_analytic_diamond_upper_bound']='2*(1-(1-leak)*pI)'
results['kraus_TP_tests']=len(checks)
results['single_gate_phase_flip_flagged_erasure_exact_diamond_via_matching_bounds']='PASS (analytical upper + code-state lower)'
results['analytical_upper_bound']='2*((1-leak)*q + leak) (CPTP triangle inequality)' 
results['diamond_norm_full_sdp_independent_check']='NOT_PERFORMED'
results['lean_kernel_build']='NOT_AVAILABLE_IN_EXECUTION_ENVIRONMENT'
HERE.joinpath('results').mkdir(exist_ok=True)
HERE.joinpath('results/numerical_report.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(results,indent=2,ensure_ascii=False))
