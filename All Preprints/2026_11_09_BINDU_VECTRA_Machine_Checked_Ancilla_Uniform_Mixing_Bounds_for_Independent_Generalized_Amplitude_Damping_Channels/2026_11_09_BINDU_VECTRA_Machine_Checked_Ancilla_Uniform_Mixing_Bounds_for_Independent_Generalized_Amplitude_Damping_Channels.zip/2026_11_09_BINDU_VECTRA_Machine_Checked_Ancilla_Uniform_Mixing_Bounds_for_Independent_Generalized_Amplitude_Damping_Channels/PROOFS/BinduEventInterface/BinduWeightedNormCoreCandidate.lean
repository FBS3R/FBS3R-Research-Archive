import BinduEventInterface.CPTPDiamondContractivity

/-!
Pure scalar-weighted Schatten-1 inequality. The statement is unconditional
apart from 0 ≤ r ≤ 1 and two supplied matrix norm estimates.
Source candidate: verification requires the user's pinned Lean+Mathlib.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

theorem bindu_weighted_norm_two_term
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (r : ℝ) (hr0 : 0 ≤ r) (hr1 : r ≤ 1)
    (A B : Matrix ι ι ℂ) (M : ℝ)
    (hA : schattenOneSpectralNorm A ≤ M)
    (hB : schattenOneSpectralNorm B ≤ 2 * M) :
    schattenOneSpectralNorm
      (((r * (1 - r) : ℝ) : ℂ) • A + (((r ^ 2 : ℝ) : ℂ) • B)) ≤
      (r + r ^ 2) * M := by
  have hw1 : 0 ≤ r * (1 - r) :=
    mul_nonneg hr0 (sub_nonneg.mpr hr1)
  have hw2 : 0 ≤ r ^ 2 := sq_nonneg r
  have hn1 : ‖((r * (1 - r) : ℝ) : ℂ)‖ = r * (1 - r) := by
    rw [Complex.norm_real, Real.norm_of_nonneg hw1]
  have hn2 : ‖((r ^ 2 : ℝ) : ℂ)‖ = r ^ 2 := by
    rw [Complex.norm_real, Real.norm_of_nonneg hw2]
  have ha : schattenOneSpectralNorm (((r * (1 - r) : ℝ) : ℂ) • A) ≤
      (r * (1 - r)) * M := by
    calc
      schattenOneSpectralNorm (((r * (1 - r) : ℝ) : ℂ) • A) ≤
          ‖((r * (1 - r) : ℝ) : ℂ)‖ * schattenOneSpectralNorm A :=
        schattenOne_smul_le _ _
      _ = (r * (1 - r)) * schattenOneSpectralNorm A := by rw [hn1]
      _ ≤ (r * (1 - r)) * M := mul_le_mul_of_nonneg_left hA hw1
  have hb : schattenOneSpectralNorm (((r ^ 2 : ℝ) : ℂ) • B) ≤
      (r ^ 2) * (2 * M) := by
    calc
      schattenOneSpectralNorm (((r ^ 2 : ℝ) : ℂ) • B) ≤
          ‖((r ^ 2 : ℝ) : ℂ)‖ * schattenOneSpectralNorm B :=
        schattenOne_smul_le _ _
      _ = (r ^ 2) * schattenOneSpectralNorm B := by rw [hn2]
      _ ≤ (r ^ 2) * (2 * M) := mul_le_mul_of_nonneg_left hB hw2
  calc
    schattenOneSpectralNorm
        (((r * (1 - r) : ℝ) : ℂ) • A + (((r ^ 2 : ℝ) : ℂ) • B)) ≤
        schattenOneSpectralNorm (((r * (1 - r) : ℝ) : ℂ) • A) +
          schattenOneSpectralNorm (((r ^ 2 : ℝ) : ℂ) • B) :=
      schattenOne_add_le _ _
    _ ≤ (r * (1 - r)) * M + (r ^ 2) * (2 * M) := add_le_add ha hb
    _ = (r + r ^ 2) * M := by ring

end BinduEventInterface

#print axioms BinduEventInterface.bindu_weighted_norm_two_term
