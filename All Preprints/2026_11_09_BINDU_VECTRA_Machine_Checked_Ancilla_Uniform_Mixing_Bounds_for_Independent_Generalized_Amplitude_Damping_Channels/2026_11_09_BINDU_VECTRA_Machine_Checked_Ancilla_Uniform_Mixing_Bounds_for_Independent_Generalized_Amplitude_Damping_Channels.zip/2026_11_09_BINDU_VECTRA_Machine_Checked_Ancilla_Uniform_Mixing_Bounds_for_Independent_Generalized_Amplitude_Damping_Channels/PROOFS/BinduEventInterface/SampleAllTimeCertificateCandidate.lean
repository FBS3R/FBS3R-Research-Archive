import BinduEventInterface.ContinuousODECandidate
import BinduEventInterface.ExampleBound

/-!
# Exact two-site all-time certificate, pending Lean kernel replay

This theorem is only about explicitly defined constant-rate populations.
It does not identify them with the trajectory of an arbitrary quantum
state. The latter requires a separate generator/ODE uniqueness bridge.
-/
namespace BinduEventInterface

/-- For these two constant-rate sites, the joint product never exceeds 7/58. -/
theorem sampleTwoSite_allTime (t : ℝ) (ht : 0 ≤ t) :
    constantRatePopulation ((1 : ℝ) / 5) ((3 : ℝ) / 7) t *
    constantRatePopulation ((2 : ℝ) / 9) ((4 : ℝ) / 11) t ≤
      (7 : ℝ) / 58 := by
  have hA := constantRatePopulation_bounds ((1 : ℝ) / 5) ((3 : ℝ) / 7) t
    (by norm_num) (by norm_num) (by norm_num) ht
  have hB := constantRatePopulation_bounds ((2 : ℝ) / 9) ((4 : ℝ) / 11) t
    (by norm_num) (by norm_num) (by norm_num) ht
  have hAu : constantRatePopulation ((1 : ℝ) / 5) ((3 : ℝ) / 7) t ≤
      (7 : ℝ) / 22 := by
    calc
      _ ≤ ((1 : ℝ) / 5) / ((1 : ℝ) / 5 + (3 : ℝ) / 7) := hA.2
      _ = (7 : ℝ) / 22 := by norm_num
  have hBu : constantRatePopulation ((2 : ℝ) / 9) ((4 : ℝ) / 11) t ≤
      (11 : ℝ) / 29 := by
    calc
      _ ≤ ((2 : ℝ) / 9) / ((2 : ℝ) / 9 + (4 : ℝ) / 11) := hB.2
      _ = (11 : ℝ) / 29 := by norm_num
  calc
    _ ≤ ((7 : ℝ) / 22) * ((11 : ℝ) / 29) := by
      exact mul_le_mul hAu hBu hB.1 (by norm_num)
    _ = (7 : ℝ) / 58 := by norm_num

/-- The explicit two-site constant-rate population respects the threshold. -/
theorem sampleTwoSite_belowQuarter (t : ℝ) (ht : 0 ≤ t) :
    constantRatePopulation ((1 : ℝ) / 5) ((3 : ℝ) / 7) t *
    constantRatePopulation ((2 : ℝ) / 9) ((4 : ℝ) / 11) t <
      (1 : ℝ) / 4 := by
  calc
    _ ≤ (7 : ℝ) / 58 := sampleTwoSite_allTime t ht
    _ < (1 : ℝ) / 4 := by norm_num

#print axioms sampleTwoSite_allTime
#print axioms sampleTwoSite_belowQuarter
end BinduEventInterface
