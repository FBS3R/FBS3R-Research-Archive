import BinduEventInterface.NQubitFullSemigroupSpectralCandidate

/-!
# Independent N-Qubit Global Convergence -- Incremental Proof Candidate

This is an ADDITIVE extension of the frozen verified project.  It DOES NOT change
`nQubitKrausChannel`, the generator, the eigenbasis, or any previously proved theorem.

STATUS: PROOF CANDIDATE, NOT KERNEL-VERIFIED by the authoring environment.
It must pass `lake build BinduEventInterface.NQubitAsymptoticConvergenceCandidate`
and `#print axioms` on the user's pinned Lean 4.19.0/Mathlib checkout.

The convergence is in the usual product topology of finite matrices, obtained
by entrywise `Filter.Tendsto`. This includes N=0 without an extra hypothesis.
-/

namespace BinduEventInterface

open Matrix Filter
open scoped Matrix ComplexOrder Topology

/-- The nonstationary spectral terms are exactly the spectral flow minus the
stationary trace projection. This is a finite-sum identity, not an asymptotic
approximation. -/
theorem nQubitSpectralFlow_sub_stationary_projection {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitSpectralFlow G K t X - Matrix.trace X • nQubitEquilibrium G K =
      ∑ α ∈ Finset.univ.erase (fun _ : Fin N => (0 : Fin 4)),
        (Real.exp (nQubitEigenvalue G K α * t) : ℂ) •
          (Matrix.trace (nQubitDualMatrix G K α * X) • nQubitEigenMatrix G K α) := by
  unfold nQubitSpectralFlow
  rw [← Finset.add_sum_erase _ _
    (Finset.mem_univ (fun _ : Fin N => (0 : Fin 4)))]
  simp only [nQubitEigenvalue_zero, zero_mul, Real.exp_zero, Complex.ofReal_one,
    one_smul, nQubitDualMatrix_zero, Matrix.one_mul, nQubitEigenMatrix_zero,
    add_sub_cancel_left]

/-- Every nonstationary N-qubit spectral exponential decays to zero. -/
theorem nQubit_nonstationary_mode_exp_tendsto_zero {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (α : NQubitModeIndex N) (hα : α ≠ (fun _ => 0)) :
    Tendsto (fun t : ℝ => Real.exp (nQubitEigenvalue G K α * t))
      atTop (nhds 0) := by
  have hle := nQubitEigenvalue_nonpos G K hG hK α
  have hneg : nQubitEigenvalue G K α < 0 := by
    rcases lt_or_eq_of_le hle with hlt | heq
    · exact hlt
    · exact (hα ((nQubitEigenvalue_eq_zero_iff G K hG hK α).mp heq)).elim
  exact Real.tendsto_exp_atBot.comp
    (Filter.Tendsto.const_mul_atTop_of_neg hneg tendsto_id)

/-- Global convergence in the actual finite-matrix product topology for EVERY
complex input matrix, not merely the vacuum or trace-one density matrices. -/
theorem nQubitSpectralFlow_tendsto_atTop {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    Tendsto (fun t : ℝ => nQubitSpectralFlow G K t X)
      atTop (nhds (Matrix.trace X • nQubitEquilibrium G K)) := by
  rw [tendsto_pi_nhds]
  intro i
  rw [tendsto_pi_nhds]
  intro j
  have hdecomp :
      (fun t : ℝ => nQubitSpectralFlow G K t X i j) =
        (fun t : ℝ =>
          (Matrix.trace X • nQubitEquilibrium G K) i j +
            ∑ α ∈ Finset.univ.erase (fun _ : Fin N => (0 : Fin 4)),
              ((Real.exp (nQubitEigenvalue G K α * t) : ℂ) *
                Matrix.trace (nQubitDualMatrix G K α * X)) *
                nQubitEigenMatrix G K α i j) := by
    ext t
    have hsub := congr_fun
      (congr_fun (nQubitSpectralFlow_sub_stationary_projection G K t X) i) j
    simp only [Matrix.sub_apply, Matrix.sum_apply, Matrix.smul_apply,
      smul_eq_mul, mul_assoc] at hsub ⊢
    linear_combination hsub
  rw [hdecomp]
  suffices hzero :
      Tendsto
        (fun t : ℝ =>
          ∑ α ∈ Finset.univ.erase (fun _ : Fin N => (0 : Fin 4)),
            ((Real.exp (nQubitEigenvalue G K α * t) : ℂ) *
              Matrix.trace (nQubitDualMatrix G K α * X)) *
              nQubitEigenMatrix G K α i j)
        atTop (nhds 0) by
    simpa only [add_zero] using
      (tendsto_const_nhds (x := (Matrix.trace X • nQubitEquilibrium G K) i j)).add hzero
  have hsum0 :
      Tendsto
        (fun t : ℝ =>
          ∑ α ∈ Finset.univ.erase (fun _ : Fin N => (0 : Fin 4)),
            ((Real.exp (nQubitEigenvalue G K α * t) : ℂ) *
              Matrix.trace (nQubitDualMatrix G K α * X)) *
              nQubitEigenMatrix G K α i j)
        atTop (nhds
          (∑ _α ∈ Finset.univ.erase (fun _ : Fin N => (0 : Fin 4)), (0 : ℂ))) :=
    tendsto_finset_sum (Finset.univ.erase (fun _ : Fin N => (0 : Fin 4)))
      fun α hmem => by
        have hα : α ≠ (fun _ : Fin N => (0 : Fin 4)) :=
          (Finset.mem_erase.mp hmem).1
        have hexp := nQubit_nonstationary_mode_exp_tendsto_zero G K hG hK α hα
        have hcexp :
            Tendsto (fun t : ℝ => (Real.exp (nQubitEigenvalue G K α * t) : ℂ))
              atTop (nhds (0 : ℂ)) :=
          (Complex.continuous_ofReal.tendsto' 0 0 Complex.ofReal_zero).comp hexp
        have hterm :=
          (hcexp.mul_const (Matrix.trace (nQubitDualMatrix G K α * X))).mul_const
            (nQubitEigenMatrix G K α i j)
        simpa only [zero_mul] using hterm
  simpa only [Finset.sum_const, nsmul_zero] using hsum0

/-- The genuine N-qubit CPTP Kraus channel converges to the stationary trace
projection for arbitrary complex inputs, including entangled matrices. -/
theorem nQubitKrausChannel_tendsto_atTop {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    Tendsto (fun t : ℝ => nQubitKrausChannel G K t X)
      atTop (nhds (Matrix.trace X • nQubitEquilibrium G K)) := by
  refine (nQubitSpectralFlow_tendsto_atTop G K hG hK X).congr' ?_
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
  exact (nQubitKrausChannel_eq_spectralFlow G K hG hK ht X).symm

/-- For an arbitrary trace-one initial matrix the unique asymptotic state is
the previously verified N-qubit product equilibrium. -/
theorem nQubitKrausChannel_tendsto_equilibrium_of_trace_one {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ)
    (htr : Matrix.trace X = 1) :
    Tendsto (fun t : ℝ => nQubitKrausChannel G K t X)
      atTop (nhds (nQubitEquilibrium G K)) := by
  simpa [htr, one_smul] using
    nQubitKrausChannel_tendsto_atTop G K hG hK X

end BinduEventInterface
