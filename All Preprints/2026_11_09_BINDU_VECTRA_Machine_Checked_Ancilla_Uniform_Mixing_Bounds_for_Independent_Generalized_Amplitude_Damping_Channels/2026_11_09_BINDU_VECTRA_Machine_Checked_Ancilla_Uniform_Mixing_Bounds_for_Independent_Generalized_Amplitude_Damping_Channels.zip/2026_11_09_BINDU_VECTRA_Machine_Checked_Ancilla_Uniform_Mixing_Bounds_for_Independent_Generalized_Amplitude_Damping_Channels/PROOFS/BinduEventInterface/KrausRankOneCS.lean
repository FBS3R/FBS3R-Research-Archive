import Mathlib

/-!
One isolated kernel-checkable step proposed after a single Codex Sol xhigh call.
Nothing in this file claims a diamond norm bound or Schatten-one contraction.
-.-/

namespace BinduFiniteKrausCS

noncomputable def eucLength {n : Type*} [Fintype n] (w : n → ℂ) : ℝ :=
  Real.sqrt (∑ i, ‖w i‖ ^ 2)

@[simp] theorem eucLength_sq {n : Type*} [Fintype n] (w : n → ℂ) :
    eucLength w ^ 2 = ∑ i, ‖w i‖ ^ 2 := by
  unfold eucLength
  exact Real.sq_sqrt (Finset.sum_nonneg (fun i _ => sq_nonneg (‖w i‖)))

private theorem finite_cs_nonneg {ι : Type*} [Fintype ι]
    (a b : ι → ℝ) (ha : ∀ i, 0 ≤ a i) (hb : ∀ i, 0 ≤ b i) :
    (∑ i, a i * b i) ≤
      Real.sqrt (∑ i, a i ^ 2) * Real.sqrt (∑ i, b i ^ 2) := by
  classical
  have hcs := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset ι) a b
  have hA : (0 : ℝ) ≤ ∑ i, a i ^ 2 :=
    Finset.sum_nonneg (fun i _ => sq_nonneg (a i))
  have hB : (0 : ℝ) ≤ ∑ i, b i ^ 2 :=
    Finset.sum_nonneg (fun i _ => sq_nonneg (b i))
  have hleft : (0 : ℝ) ≤ ∑ i, a i * b i :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (ha i) (hb i))
  have hright : (0 : ℝ) ≤
      Real.sqrt (∑ i, a i ^ 2) * Real.sqrt (∑ i, b i ^ 2) :=
    mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
  have hright_sq :
      (Real.sqrt (∑ i, a i ^ 2) * Real.sqrt (∑ i, b i ^ 2)) ^ 2 =
        (∑ i, a i ^ 2) * (∑ i, b i ^ 2) := by
    rw [mul_pow, Real.sq_sqrt hA, Real.sq_sqrt hB]
  nlinarith only [hcs, hleft, hright, hright_sq]

theorem kraus_rankOne_cost_cs
    {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ) (u v : n → ℂ) :
    (∑ j, eucLength ((K j).mulVec u) * eucLength ((K j).mulVec v)) ≤
      Real.sqrt (∑ j, ∑ i, ‖((K j).mulVec u) i‖ ^ 2) *
        Real.sqrt (∑ j, ∑ i, ‖((K j).mulVec v) i‖ ^ 2) := by
  have h := finite_cs_nonneg
    (fun j => eucLength ((K j).mulVec u))
    (fun j => eucLength ((K j).mulVec v))
    (fun j => Real.sqrt_nonneg _)
    (fun j => Real.sqrt_nonneg _)
  simpa only [eucLength_sq] using h

end BinduFiniteKrausCS

#print axioms BinduFiniteKrausCS.eucLength_sq
#print axioms BinduFiniteKrausCS.kraus_rankOne_cost_cs
