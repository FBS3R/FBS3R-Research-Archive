import BinduEventInterface.BinduSiteLocalFamilyBridgeCandidate

/-!
# Exact site-dephasing identification and unconditional hybrid-step bound

A SOURCE CANDIDATE ONLY until compiled by the user's pinned Lean.
If its build and axiom gate pass, this removes `hD`, `hR` and `hsite`.
The final assertions are NOT Lean-verified at authoring time.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- The Pauli-Z four-index kernel. -/
def binduLocalZKernel (u p v q : Fin 2) : ℂ :=
  localPauliZ u p * star (localPauliZ v q)

/-- Exact local computational dephasing kernel as (Id + Ad_Z)/2. -/
theorem bindu_local_dephasing_half_Z
    (u p v q : Fin 2) :
    binduLocalDephaseKernel u p v q =
      ((1 : ℂ) / 2) * binduDeltaKernel u p v q +
      ((1 : ℂ) / 2) * binduLocalZKernel u p v q := by
  fin_cases u <;> fin_cases p <;> fin_cases v <;> fin_cases q <;>
    simp [binduLocalDephaseKernel, binduDeltaKernel,
      binduLocalZKernel, localPauliZ] <;> ring

/-- The global site-kernel dephasing IS the already defined global dephasing. -/
theorem bindu_site_dephasing_kernel_bridge
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (k : Fin N)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k binduLocalDephaseKernel Y =
      siteDephasingChannel k Y := by
  calc
    binduSiteKernelAction k binduLocalDephaseKernel Y =
      binduSiteKernelAction k
        (fun u p v q =>
          ((1 : ℂ) / 2) * binduDeltaKernel u p v q +
          ((1 : ℂ) / 2) * binduLocalZKernel u p v q) Y := by
            apply bindu_site_action_congr
            intro u p v q
            exact bindu_local_dephasing_half_Z u p v q
    _ = ((1 : ℂ) / 2) • binduSiteKernelAction k binduDeltaKernel Y +
          ((1 : ℂ) / 2) • binduSiteKernelAction k binduLocalZKernel Y :=
        bindu_site_kernel_two_term k binduDeltaKernel binduLocalZKernel
          ((1 : ℂ) / 2) ((1 : ℂ) / 2) Y
    _ = siteDephasingChannel k Y := by
      rw [bindu_site_delta_action_eq]
      have hZ : binduSiteKernelAction k binduLocalZKernel Y =
          ancillaRightChannel (sitePauliZKraus k) Y := by
        exact bindu_site_pauli_z_kernel_bridge k Y
      rw [hZ]
      unfold siteDephasingChannel
      rw [smul_add]

/-- The full source-level hsite identity, without any unproved hypothesis. -/
theorem bindu_global_site_identity_unconditional
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (ht : 0 ≤ t) (k : Fin N)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k (binduPhysicalDifferenceKernel G K t k) Y =
      binduSiteRplusR2 G K t k Y := by
  unfold binduPhysicalDifferenceKernel binduSiteRplusR2
  exact bindu_global_site_identity_of_two_bridges G K hG hK t ht k Y
    (bindu_site_dephasing_kernel_bridge k Y)
    (bindu_site_replacer_kernel_bridge G K k Y)

/-- The original global hybrid-step r+r² estimate, for arbitrary finite
ancilla and arbitrary complex input matrix: no hstep, hExact or hsite. -/
theorem bindu_global_hybrid_rplusr2_unconditional
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (ht : 0 ≤ t) (k : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm
        (ancillaRightChannel (hybridNQubitKraus G K t (k.val + 1)) X -
         ancillaRightChannel (hybridNQubitKraus G K t k.val) X) ≤
      (localDampingR (G k) (K k) t +
       (localDampingR (G k) (K k) t) ^ 2) *
         schattenOneSpectralNorm X := by
  apply bindu_global_hybrid_rplusr2_of_site_identity G K hG hK t ht k X
  intro Y
  exact bindu_global_site_identity_unconditional G K hG hK t ht k Y

/-- The full physical N-qubit envelope bound, now with no hstep premise. -/
theorem bindu_nQubit_diamond_envelope_unconditional
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (ht : 0 ≤ t)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm
      (ancillaRightChannel (nQubitKraus G K t) X -
       ancillaRightChannel (nQubitReplacerKraus G K) X) ≤
      nQubitDiamondEnvelope G K t * schattenOneSpectralNorm X := by
  apply nQubit_channel_sub_replacer_envelope_bound_of_step G K hG hK ht ?_ X
  intro k hk Y
  exact bindu_global_hybrid_rplusr2_unconditional
    G K hG hK t ht ⟨k, hk⟩ Y

end BinduEventInterface

#print axioms BinduEventInterface.bindu_local_dephasing_half_Z
#print axioms BinduEventInterface.bindu_site_dephasing_kernel_bridge
#print axioms BinduEventInterface.bindu_global_site_identity_unconditional
#print axioms BinduEventInterface.bindu_global_hybrid_rplusr2_unconditional
#print axioms BinduEventInterface.bindu_nQubit_diamond_envelope_unconditional
