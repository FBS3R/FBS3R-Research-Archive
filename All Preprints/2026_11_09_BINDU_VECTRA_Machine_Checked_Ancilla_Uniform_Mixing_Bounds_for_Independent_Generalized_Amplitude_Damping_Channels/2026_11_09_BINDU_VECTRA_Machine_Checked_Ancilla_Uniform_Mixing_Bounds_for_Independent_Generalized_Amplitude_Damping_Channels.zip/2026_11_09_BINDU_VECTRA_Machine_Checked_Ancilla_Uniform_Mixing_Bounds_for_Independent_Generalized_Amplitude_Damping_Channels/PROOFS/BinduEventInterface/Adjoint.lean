import BinduEventInterface.Arithmetic
import Mathlib.Tactic.FinCases

/-! Exact identities, not a formalized trajectory, tensor embedding or parser. -/
namespace BinduEventInterface
open Matrix

noncomputable def dissipatorAdjoint {n : Type*} [Fintype n] [DecidableEq n]
    (L Q : Matrix n n ℂ) : Matrix n n ℂ :=
  L.conjTranspose * Q * L - (1/2 : ℂ) •
    (L.conjTranspose * L * Q + Q * L.conjTranspose * L)

theorem dissipator_identity {n : Type*} [Fintype n] [DecidableEq n]
    (L : Matrix n n ℂ) : dissipatorAdjoint L 1 = 0 := by
  unfold dissipatorAdjoint
  simp only [Matrix.mul_one, Matrix.one_mul]
  ext i j
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply,
    Matrix.zero_apply, smul_eq_mul]
  ring

theorem dissipator_commuting {n : Type*} [Fintype n] [DecidableEq n]
    (L Q : Matrix n n ℂ) (h : Q * L = L * Q)
    (had : Q * L.conjTranspose = L.conjTranspose * Q) :
    dissipatorAdjoint L Q = 0 := by
  have hmid : L.conjTranspose * Q * L = L.conjTranspose * L * Q := by
    rw [Matrix.mul_assoc, h, ← Matrix.mul_assoc]
  have hright : Q * L.conjTranspose * L = L.conjTranspose * L * Q := by
    rw [had, hmid]
  unfold dissipatorAdjoint
  rw [hmid, hright]
  ext i j
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply,
    Matrix.zero_apply, smul_eq_mul]
  ring

def occupation : Matrix (Fin 2) (Fin 2) ℂ := !![0,0;0,1]
def raising : Matrix (Fin 2) (Fin 2) ℂ := !![0,0;1,0]
def lowering : Matrix (Fin 2) (Fin 2) ℂ := !![0,1;0,0]

theorem pump_occupation (rate : ℂ) :
    rate • dissipatorAdjoint raising occupation = rate • (1-occupation) := by
  congr 1
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [dissipatorAdjoint, raising, occupation, Matrix.mul_apply,
      Fin.sum_univ_succ, Matrix.conjTranspose_apply, Matrix.smul_apply,
      Matrix.vecMul, dotProduct, Matrix.conjTranspose, Matrix.transpose_apply]

theorem loss_occupation (rate : ℂ) :
    rate • dissipatorAdjoint lowering occupation = rate • (-occupation) := by
  congr 1
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [dissipatorAdjoint, lowering, occupation, Matrix.mul_apply,
      Fin.sum_univ_succ, Matrix.conjTranspose_apply, Matrix.smul_apply,
      Matrix.vecMul, dotProduct, Matrix.conjTranspose, Matrix.transpose_apply]

/-- Algebraic GKSL adjoint; physical use requires Hermitian H and nonnegative rates. -/
noncomputable def heisenbergGenerator {n a : Type*}
    [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ) (rate : a → ℂ)
    (Q : Matrix n n ℂ) : Matrix n n ℂ :=
  Complex.I • (H * Q - Q * H) + ∑ j, rate j • dissipatorAdjoint (L j) Q

theorem generator_identity {n a : Type*}
    [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ) (rate : a → ℂ) :
    heisenbergGenerator H L rate 1 = 0 := by
  simp [heisenbergGenerator, dissipator_identity]

theorem generator_commuting {n a : Type*}
    [Fintype n] [DecidableEq n] [Fintype a]
    (H Q : Matrix n n ℂ) (L : a → Matrix n n ℂ) (rate : a → ℂ)
    (hH : H * Q = Q * H)
    (hL : ∀ j, Q * L j = L j * Q)
    (hLa : ∀ j, Q * (L j).conjTranspose = (L j).conjTranspose * Q) :
    heisenbergGenerator H L rate Q = 0 := by
  unfold heisenbergGenerator
  rw [hH, sub_self, smul_zero, zero_add]
  apply Finset.sum_eq_zero
  intro j hj
  rw [dissipator_commuting (L j) Q (hL j) (hLa j), smul_zero]

end BinduEventInterface

