import BinduEventInterface.AllTimeConstantCandidate

/-!
# Constant-rate continuous-time ODE: proof candidate.

This formalizes a derivative equation for the *explicit* solution in the
constant-rate case. It is not an existence/uniqueness theorem for an arbitrary
GKSL trajectory, and does not cover non-autonomous rates. Not root-imported.
-/
namespace BinduEventInterface

/-- The explicit vacuum population solves the correct differential equation. -/
theorem constantRatePopulation_hasDerivAt
    (G K t : ℝ) (hpos : 0 < G + K) :
    HasDerivAt (constantRatePopulation G K)
      (G * (1 - constantRatePopulation G K t) -
       K * constantRatePopulation G K t) t := by
  have hline : HasDerivAt (fun s : ℝ => -(G + K) * s) (-(G + K)) t := by
    simpa using (hasDerivAt_id t).const_mul (-(G + K))
  have hexp : HasDerivAt (fun s : ℝ => Real.exp (-(G + K) * s))
      (Real.exp (-(G + K) * t) * (-(G + K))) t :=
    (Real.hasDerivAt_exp _).comp t hline
  have hp := ((hasDerivAt_const t (1 : ℝ)).sub hexp).const_mul (G / (G + K))
  convert hp using 1
  · dsimp [constantRatePopulation]
    field_simp [ne_of_gt hpos]
    ring

#print axioms constantRatePopulation_hasDerivAt
end BinduEventInterface
