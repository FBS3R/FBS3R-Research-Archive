import BinduEventInterface.NQubitIndependentCPTPSemigroupCandidate

/-!
# Complete Independent `N`-Qubit CPTP Semigroup, Tensor-Sum GKSL Generator, and Full Spectral Expansion

This module extends `BinduEventInterface.NQubitIndependentCPTPSemigroupCandidate` to resolve the
remaining `N`-qubit obligations for arbitrary `N : ℕ` and positive local transition rates
`G, K : Fin N → ℝ` (`hG : ∀ m, 0 < G m`, `hK : ∀ m, 0 < K m`):

1. **Product Matrix Units and Spanning Basis (`P1-06`)**:
   - Single-qubit matrix units `qubitMatrixUnit a b` and `N`-fold product matrix units
     `nQubitProductUnit i j = ⨂_m qubitMatrixUnit (i m) (j m)`.
   - Exact entrywise delta formula `nQubitProductUnit_apply` and full basis expansion
     `matrix_eq_sum_nQubitProductUnit` for every complex matrix
     `X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ`.
   - Arbitrary-input initial identity `nQubitKrausChannel_zero` (`Φ^{(N)}_0(X) = X`) and
     arbitrary-input semigroup composition `nQubitKrausChannel_semigroup`
     (`Φ^{(N)}_{t+s}(X) = Φ^{(N)}_t(Φ^{(N)}_s(X))` for `s, t ≥ 0`), proved by reusing
     `localChannel_zero`, `localChannel_semigroup`, and `nQubitKrausChannel_tensorProduct`.

2. **Positive Semidefiniteness of the `N`-Qubit Product Equilibrium (`P1-08`)**:
   - Explicit Hermitian square root `nQubitEquilibriumSqrt G K`, factorization
     `nQubitEquilibrium_eq_conjTranspose_mul_self`, positive semidefiniteness
     `nQubitEquilibrium_posSemidef`, and Hermiticity `nQubitEquilibrium_isHermitian`.

3. **Full `4^N` Eigenmatrix Basis, Dual Basis, and Biorthogonal Spectral Expansion (`P1-04`, `P1-07`)**:
   - Parametric local eigenmatrices `localEigenMatrixParam G K a` and dual matrices
     `localDualMatrixParam G K a`, local trace biorthogonality `local_dual_eigen_trace`,
     and local spectral completeness `local_matrix_spectral_expansion`.
   - `N`-fold tensor eigenmatrices `nQubitEigenMatrix G K α` and dual matrices
     `nQubitDualMatrix G K α`, trace biorthogonality `nQubit_dual_eigen_trace`,
     nonvanishing `nQubitEigenMatrix_ne_zero`, and full `4^N`-mode spectral decomposition
     `nQubit_matrix_spectral_expansion` for every `X ∈ M_{2^N}(ℂ)`.
   - Exact action `nQubitKrausChannel_eigenMatrix` and identity
     `nQubitKrausChannel_eq_spectralFlow` (`Φ^{(N)}_t(X) = Ψ^{(N)}_t(X)` for all `t ≥ 0` and all `X`).

4. **Full Independent `N`-Qubit Tensor-Sum GKSL Generator and Master Equation (`P1-04`, `P1-07`)**:
   - Site-embedded jump operators `nQubitSiteEmbed m raising` and `nQubitSiteEmbed m lowering`,
     and full `2N`-channel Schrödinger GKSL generator `nQubitGKSLGenerator G K`.
   - Exact eigenmatrix equation `nQubitGKSLGenerator_eigenMatrix`:
     `nQubitGKSLGenerator G K (nQubitEigenMatrix G K α) = (nQubitEigenvalue G K α : ℂ) • nQubitEigenMatrix G K α`.
   - Entrywise and matrix-level GKSL master equation for arbitrary `X ∈ M_{2^N}(ℂ)`:
     `nQubitSpectralFlow_hasDerivAt_GKSL`, `nQubitKrausChannel_hasDerivWithinAt_GKSL` (on `[0, ∞)`),
     and `nQubitKrausChannel_hasDerivAt_GKSL_of_pos` (for `t > 0`).
   - Complete operator spectrum theorem `nQubitGKSLGenerator_eigenvalue_mem_spectrum`,
     unique stationary-state theorem `nQubitGKSLGenerator_eq_zero_iff`, global asymptotic
     convergence `nQubitKrausChannel_tendsto_atTop`, and optimal attained spectral gap
     `nQubit_optimal_spectral_gap_attained` for `0 < N`.

5. **Spectral Singular-Value Schatten-1 Functional (`P0c-05`, `P0c-06`)**:
   - Definition of `schattenOneSpectralNorm` via the eigenvalues of the positive semidefinite
     operator `Xᴴ * X` (`Matrix.posSemidef_conjTranspose_mul_self`), nonnegativity
     `schattenOneSpectralNorm_nonneg`, and vanishing at zero `schattenOneSpectralNorm_zero`.
-/

namespace BinduEventInterface

open Matrix Filter
open scoped Matrix ComplexOrder Topology

/-!
## 1. Product Matrix Units and Spanning Basis on `M_{2^N}(ℂ)`
-/

/-- Single-qubit elementary matrix unit `|a⟩⟨b|` on `Fin 2`. -/
def qubitMatrixUnit (a b : Fin 2) : Matrix (Fin 2) (Fin 2) ℂ :=
  Matrix.of (fun r c => if r = a ∧ c = b then 1 else 0)

@[simp]
theorem qubitMatrixUnit_apply (a b r c : Fin 2) :
    qubitMatrixUnit a b r c = if r = a ∧ c = b then 1 else 0 := rfl

/-- `N`-qubit product matrix unit `|i⟩⟨j| = ⨂_{m=1}^N |i_m⟩⟨j_m|`. -/
noncomputable def nQubitProductUnit {N : ℕ} (i j : NQubitIndex N) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m => qubitMatrixUnit (i m) (j m))

/-- Entrywise Kronecker-delta formula for the `N`-qubit product matrix unit. -/
theorem nQubitProductUnit_apply {N : ℕ} (i j r c : NQubitIndex N) :
    nQubitProductUnit i j r c = if r = i ∧ c = j then 1 else 0 := by
  simp only [nQubitProductUnit, nQubitTensorProduct_apply, qubitMatrixUnit_apply]
  by_cases h : r = i ∧ c = j
  · rcases h with ⟨rfl, rfl⟩
    simp
  · rw [if_neg h]
    have hex : ∃ m : Fin N, ¬(r m = i m ∧ c m = j m) := by
      by_contra hall
      push_neg at hall
      exact h ⟨funext (fun m => (hall m).1), funext (fun m => (hall m).2)⟩
    rcases hex with ⟨m, hm⟩
    exact Finset.prod_eq_zero (Finset.mem_univ m) (if_neg hm)

/-- **Product-unit spanning theorem**: every `N`-qubit complex matrix `X ∈ M_{2^N}(ℂ)` is the
exact finite linear combination of the `4^N` product matrix units `nQubitProductUnit i j`. -/
theorem matrix_eq_sum_nQubitProductUnit {N : ℕ}
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    X = ∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
      X i j • nQubitProductUnit i j := by
  ext r c
  simp only [Matrix.sum_apply, Matrix.smul_apply, nQubitProductUnit_apply,
    smul_eq_mul, mul_ite, mul_one, mul_zero]
  rw [Finset.sum_eq_single r]
  · rw [Finset.sum_eq_single c]
    · simp
    · intro j _ hjc
      exact if_neg (fun h => hjc h.2.symm)
    · intro hc
      exact (hc (Finset.mem_univ c)).elim
  · intro i _ hir
    refine Finset.sum_eq_zero (fun j _ => ?_)
    exact if_neg (fun h => hir h.1.symm)
  · intro hr
    exact (hr (Finset.mem_univ r)).elim

/-!
## 2. Linearity of `finiteKrausChannel` and `nQubitKrausChannel`; Arbitrary-Input Semigroup Law (`P1-06`)
-/

/-- `finiteKrausChannel` is additive in the input matrix. -/
theorem finiteKrausChannel_add {α n : Type*} [Fintype α] [Fintype n] [DecidableEq n]
    (K : α → Matrix n n ℂ) (X Y : Matrix n n ℂ) :
    finiteKrausChannel K (X + Y) = finiteKrausChannel K X + finiteKrausChannel K Y := by
  unfold finiteKrausChannel
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl (fun a _ => ?_)
  rw [Matrix.mul_add, Matrix.add_mul]

/-- `finiteKrausChannel` is `ℂ`-homogeneous in the input matrix. -/
theorem finiteKrausChannel_smul {α n : Type*} [Fintype α] [Fintype n] [DecidableEq n]
    (K : α → Matrix n n ℂ) (c : ℂ) (X : Matrix n n ℂ) :
    finiteKrausChannel K (c • X) = c • finiteKrausChannel K X := by
  unfold finiteKrausChannel
  rw [Finset.smul_sum]
  refine Finset.sum_congr rfl (fun a _ => ?_)
  rw [Matrix.mul_smul, Matrix.smul_mul]

/-- `finiteKrausChannel` commutes with arbitrary finite sums. -/
theorem finiteKrausChannel_sum {α β n : Type*} [Fintype α] [Fintype n] [DecidableEq n]
    (K : α → Matrix n n ℂ) (s : Finset β) (f : β → Matrix n n ℂ) :
    finiteKrausChannel K (∑ b ∈ s, f b) = ∑ b ∈ s, finiteKrausChannel K (f b) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
    unfold finiteKrausChannel
    simp
  | @insert b s hb ih =>
    rw [Finset.sum_insert hb, finiteKrausChannel_add, ih, Finset.sum_insert hb]

/-- `nQubitKrausChannel` is additive in `X`. -/
theorem nQubitKrausChannel_add {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ)
    (X Y : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitKrausChannel G K t (X + Y) =
      nQubitKrausChannel G K t X + nQubitKrausChannel G K t Y :=
  finiteKrausChannel_add (nQubitKraus G K t) X Y

/-- `nQubitKrausChannel` is `ℂ`-homogeneous in `X`. -/
theorem nQubitKrausChannel_smul {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (c : ℂ)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitKrausChannel G K t (c • X) = c • nQubitKrausChannel G K t X :=
  finiteKrausChannel_smul (nQubitKraus G K t) c X

/-- `nQubitKrausChannel` commutes with finite sums. -/
theorem nQubitKrausChannel_sum {N : ℕ} {β : Type*}
    (G K : Fin N → ℝ) (t : ℝ) (s : Finset β)
    (f : β → Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitKrausChannel G K t (∑ b ∈ s, f b) =
      ∑ b ∈ s, nQubitKrausChannel G K t (f b) :=
  finiteKrausChannel_sum (nQubitKraus G K t) s f

/-- On any `N`-fold tensor product matrix, `nQubitKrausChannel` at `t = 0` is the identity. -/
theorem nQubitKrausChannel_tensorProduct_zero {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitKrausChannel G K 0 (nQubitTensorProduct M) = nQubitTensorProduct M := by
  rw [nQubitKrausChannel_tensorProduct G K hG hK (le_refl 0) M]
  have hloc : (fun m : Fin N => localChannel (G m) (K m) 0 (M m)) = M :=
    funext (fun m => localChannel_zero (G m) (K m) (M m))
  rw [hloc]

/-- **Arbitrary-input initial identity (`Φ^{(N)}_0(X) = X`)**: for every `N : ℕ`, positive local
rates `G, K : Fin N → ℝ`, and every complex matrix `X ∈ M_{2^N}(ℂ)`,
`nQubitKrausChannel G K 0 X = X`. -/
theorem nQubitKrausChannel_zero {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitKrausChannel G K 0 X = X := by
  have hX := matrix_eq_sum_nQubitProductUnit X
  calc
    nQubitKrausChannel G K 0 X
      = nQubitKrausChannel G K 0
          (∑ i : NQubitIndex N, ∑ j : NQubitIndex N, X i j • nQubitProductUnit i j) := by
            rw [← hX]
    _ = ∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
          X i j • nQubitKrausChannel G K 0 (nQubitProductUnit i j) := by
            simp only [nQubitKrausChannel_sum, nQubitKrausChannel_smul]
    _ = ∑ i : NQubitIndex N, ∑ j : NQubitIndex N, X i j • nQubitProductUnit i j := by
            refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
            rw [nQubitProductUnit, nQubitKrausChannel_tensorProduct_zero G K hG hK]
    _ = X := hX.symm

/-- On any `N`-fold tensor product matrix, `nQubitKrausChannel` satisfies the semigroup law
for `t ≥ 0` and `s ≥ 0`. -/
theorem nQubitKrausChannel_tensorProduct_semigroup {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t s : ℝ} (ht : 0 ≤ t) (hs : 0 ≤ s)
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitKrausChannel G K (t + s) (nQubitTensorProduct M) =
      nQubitKrausChannel G K t (nQubitKrausChannel G K s (nQubitTensorProduct M)) := by
  rw [nQubitKrausChannel_tensorProduct G K hG hK (add_nonneg ht hs) M,
      nQubitKrausChannel_tensorProduct G K hG hK hs M,
      nQubitKrausChannel_tensorProduct G K hG hK ht
        (fun m => localChannel (G m) (K m) s (M m))]
  have hloc : (fun m : Fin N => localChannel (G m) (K m) (t + s) (M m)) =
      (fun m : Fin N => localChannel (G m) (K m) t (localChannel (G m) (K m) s (M m))) :=
    funext (fun m => localChannel_semigroup (G m) (K m) s t (M m))
  rw [hloc]

/-- **Arbitrary-input `N`-qubit semigroup composition (`Φ^{(N)}_{t+s}(X) = Φ^{(N)}_t(Φ^{(N)}_s(X))`)**:
for every `N : ℕ`, positive local rates `G, K : Fin N → ℝ`, times `t ≥ 0, s ≥ 0`, and every
complex matrix `X ∈ M_{2^N}(ℂ)` (including entangled states),
`nQubitKrausChannel G K (t + s) X = nQubitKrausChannel G K t (nQubitKrausChannel G K s X)`. -/
theorem nQubitKrausChannel_semigroup {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t s : ℝ} (ht : 0 ≤ t) (hs : 0 ≤ s)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitKrausChannel G K (t + s) X =
      nQubitKrausChannel G K t (nQubitKrausChannel G K s X) := by
  have hX := matrix_eq_sum_nQubitProductUnit X
  calc
    nQubitKrausChannel G K (t + s) X
      = nQubitKrausChannel G K (t + s)
          (∑ i : NQubitIndex N, ∑ j : NQubitIndex N, X i j • nQubitProductUnit i j) := by
            rw [← hX]
    _ = ∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
          X i j • nQubitKrausChannel G K (t + s) (nQubitProductUnit i j) := by
            simp only [nQubitKrausChannel_sum, nQubitKrausChannel_smul]
    _ = ∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
          X i j • nQubitKrausChannel G K t (nQubitKrausChannel G K s (nQubitProductUnit i j)) := by
            refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
            rw [nQubitProductUnit, nQubitKrausChannel_tensorProduct_semigroup G K hG hK ht hs]
    _ = nQubitKrausChannel G K t (nQubitKrausChannel G K s
          (∑ i : NQubitIndex N, ∑ j : NQubitIndex N, X i j • nQubitProductUnit i j)) := by
            simp only [nQubitKrausChannel_sum, nQubitKrausChannel_smul]
    _ = nQubitKrausChannel G K t (nQubitKrausChannel G K s X) := by
            rw [← hX]

/-!
## 3. Positive Semidefiniteness of `nQubitEquilibrium` (`P1-08`)
-/

/-- Explicit Hermitian square root of `localEquilibriumParam G K`. -/
noncomputable def localEquilibriumSqrt (G K : ℝ) : Matrix (Fin 2) (Fin 2) ℂ :=
  !![((Real.sqrt (1 - localEqProb G K) : ℝ) : ℂ), 0;
     0, ((Real.sqrt (localEqProb G K) : ℝ) : ℂ)]

/-- For `G > 0, K > 0`, `(localEquilibriumSqrt G K)ᴴ * localEquilibriumSqrt G K = localEquilibriumParam G K`. -/
theorem localEquilibriumSqrt_conjTranspose_mul_self {G K : ℝ}
    (hG : 0 < G) (hK : 0 < K) :
    (localEquilibriumSqrt G K)ᴴ * localEquilibriumSqrt G K = localEquilibriumParam G K := by
  have hGK : 0 < G + K := add_pos hG hK
  have hp0 : 0 ≤ localEqProb G K := by
    unfold localEqProb
    exact div_nonneg (le_of_lt hG) (le_of_lt hGK)
  have h1p : 0 ≤ 1 - localEqProb G K := by
    unfold localEqProb
    rw [one_sub_div (ne_of_gt hGK)]
    have hsub : G + K - G = K := by ring
    rw [hsub]
    exact div_nonneg (le_of_lt hK) (le_of_lt hGK)
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [localEquilibriumSqrt, localEquilibriumParam, Matrix.mul_apply,
      Matrix.vecMul, dotProduct, Fin.sum_univ_two, Matrix.conjTranspose_apply,
      Matrix.transpose_apply, Complex.conj_ofReal, ← Complex.ofReal_mul,
      Real.mul_self_sqrt hp0, Real.mul_self_sqrt h1p]

/-- `N`-fold tensor-product square root of `nQubitEquilibrium G K`. -/
noncomputable def nQubitEquilibriumSqrt {N : ℕ} (G K : Fin N → ℝ) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m => localEquilibriumSqrt (G m) (K m))

/-- Exact Gram factorization `nQubitEquilibrium G K = (nQubitEquilibriumSqrt G K)ᴴ * nQubitEquilibriumSqrt G K`. -/
theorem nQubitEquilibrium_eq_conjTranspose_mul_self {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) :
    nQubitEquilibrium G K =
      (nQubitEquilibriumSqrt G K)ᴴ * nQubitEquilibriumSqrt G K := by
  unfold nQubitEquilibrium nQubitEquilibriumSqrt
  rw [nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul]
  have hloc :
      (fun m : Fin N => (localEquilibriumSqrt (G m) (K m))ᴴ * localEquilibriumSqrt (G m) (K m)) =
        (fun m : Fin N => localEquilibriumParam (G m) (K m)) :=
    funext (fun m => localEquilibriumSqrt_conjTranspose_mul_self (hG m) (hK m))
  rw [hloc]

/-- **Positive semidefiniteness of the `N`-qubit product equilibrium state (`P1-08`)**:
for all positive local rates `G m > 0, K m > 0`, `nQubitEquilibrium G K` is positive semidefinite. -/
theorem nQubitEquilibrium_posSemidef {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) :
    (nQubitEquilibrium G K).PosSemidef := by
  rw [nQubitEquilibrium_eq_conjTranspose_mul_self G K hG hK]
  exact Matrix.posSemidef_conjTranspose_mul_self (nQubitEquilibriumSqrt G K)

/-- Hermiticity of the `N`-qubit product equilibrium state. -/
theorem nQubitEquilibrium_isHermitian {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) :
    (nQubitEquilibrium G K).IsHermitian :=
  (nQubitEquilibrium_posSemidef G K hG hK).1

/-!
## 4. `4^N` Eigenmatrices, Dual Basis, Biorthogonality, and Complete Spectral Expansion (`P1-04`, `P1-07`)
-/

/-- Parametric single-qubit Schrödinger eigenmatrix basis `E_a` (`a ∈ Fin 4`) for rates `G, K`:
`E_0 = diag(1-p, p)`, `E_1 = diag(1, -1)`, `E_2 = |0⟩⟨1|`, `E_3 = |1⟩⟨0|`. -/
noncomputable def localEigenMatrixParam (G K : ℝ) : Fin 4 → Matrix (Fin 2) (Fin 2) ℂ
  | ⟨0, _⟩ => localEquilibriumParam G K
  | ⟨1, _⟩ => localPopulationMode
  | ⟨2, _⟩ => lowering
  | ⟨3, _⟩ => raising

/-- Parametric single-qubit Heisenberg dual basis `D_a` (`a ∈ Fin 4`) for rates `G, K`:
`D_0 = I₂`, `D_1 = diag(-p, 1-p)`, `D_2 = |1⟩⟨0|`, `D_3 = |0⟩⟨1|`. -/
noncomputable def localDualMatrixParam (G K : ℝ) : Fin 4 → Matrix (Fin 2) (Fin 2) ℂ
  | ⟨0, _⟩ => 1
  | ⟨1, _⟩ =>
      let p : ℂ := ((localEqProb G K : ℝ) : ℂ)
      !![ -p, 0;
          0, 1 - p ]
  | ⟨2, _⟩ => raising
  | ⟨3, _⟩ => lowering

/-- Local trace biorthogonality `Tr(D_a * E_b) = δ_{a,b}` for all `G, K : ℝ`. -/
theorem local_dual_eigen_trace (G K : ℝ) (a b : Fin 4) :
    Matrix.trace (localDualMatrixParam G K a * localEigenMatrixParam G K b) =
      if a = b then 1 else 0 := by
  fin_cases a <;> fin_cases b <;>
    (simp [localDualMatrixParam, localEigenMatrixParam, localEquilibriumParam,
      localPopulationMode, raising, lowering, Matrix.trace, Matrix.diag,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]
     try ring)

/-- Local 4-mode spectral completeness: every `M ∈ M₂(ℂ)` expands as `∑_{a=0}^3 Tr(D_a M) • E_a`. -/
theorem local_matrix_spectral_expansion (G K : ℝ) (M : Matrix (Fin 2) (Fin 2) ℂ) :
    (∑ a : Fin 4,
      Matrix.trace (localDualMatrixParam G K a * M) • localEigenMatrixParam G K a) = M := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [localDualMatrixParam, localEigenMatrixParam, localEquilibriumParam,
      localPopulationMode, raising, lowering, Fin.sum_univ_four,
      Matrix.trace, Matrix.diag, Matrix.mul_apply, Matrix.vecMul, dotProduct,
      Fin.sum_univ_two, Matrix.smul_apply, smul_eq_mul]
     try ring)

/-- Local GKSL eigenmatrix identity: for `G + K ≠ 0` and every `a ∈ Fin 4`,
`localGKSLGen G K (E_a) = μ_a • E_a`. -/
theorem localGKSLGen_eigenMatrixParam (G K : ℝ) (hGK : G + K ≠ 0) (a : Fin 4) :
    localGKSLGen G K (localEigenMatrixParam G K a) =
      (localEigenvalueParam G K a : ℂ) • localEigenMatrixParam G K a := by
  have hGKc : (G : ℂ) + (K : ℂ) ≠ 0 := by exact_mod_cast hGK
  have hpG : (localEqProb G K : ℂ) * ((G : ℂ) + (K : ℂ)) = (G : ℂ) := by
    unfold localEqProb
    push_cast
    exact div_mul_cancel₀ (G : ℂ) hGKc
  fin_cases a
  · -- Mode 0 (stationary equilibrium)
    ext i j
    fin_cases i <;> fin_cases j
    · simp only [Fin.zero_eta, localEigenMatrixParam, localEigenvalueParam,
        localEquilibriumParam, localGKSLGen, dissipatorSchrodinger, raising, lowering,
        Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply, Matrix.mul_apply,
        Matrix.vecMul, dotProduct, Fin.sum_univ_two, Matrix.conjTranspose_apply,
        Matrix.transpose_apply, smul_eq_mul, Matrix.of_apply, Matrix.cons_val_zero,
        Matrix.cons_val_one, Matrix.head_cons, star_zero, star_one, Complex.ofReal_zero]
      linear_combination hpG
    · simp [localEigenMatrixParam, localEigenvalueParam, localEquilibriumParam,
        localGKSLGen, dissipatorSchrodinger, raising, lowering,
        Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]
    · simp [localEigenMatrixParam, localEigenvalueParam, localEquilibriumParam,
        localGKSLGen, dissipatorSchrodinger, raising, lowering,
        Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]
    · simp only [Fin.mk_one, localEigenMatrixParam, localEigenvalueParam,
        localEquilibriumParam, localGKSLGen, dissipatorSchrodinger, raising, lowering,
        Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply, Matrix.mul_apply,
        Matrix.vecMul, dotProduct, Fin.sum_univ_two, Matrix.conjTranspose_apply,
        Matrix.transpose_apply, smul_eq_mul, Matrix.of_apply, Matrix.cons_val_zero,
        Matrix.cons_val_one, Matrix.head_cons, star_zero, star_one, Complex.ofReal_zero]
      linear_combination -hpG
  · -- Mode 1 (population decay)
    ext i j
    fin_cases i <;> fin_cases j <;>
      (simp [localEigenMatrixParam, localEigenvalueParam, localPopulationMode,
        localGKSLGen, dissipatorSchrodinger, raising, lowering,
        Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]
       try ring)
  · -- Mode 2 (lowering coherence)
    ext i j
    fin_cases i <;> fin_cases j <;>
      (simp [localEigenMatrixParam, localEigenvalueParam, lowering, raising,
        localGKSLGen, dissipatorSchrodinger,
        Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]
       try ring)
  · -- Mode 3 (raising coherence)
    ext i j
    fin_cases i <;> fin_cases j <;>
      (simp [localEigenMatrixParam, localEigenvalueParam, lowering, raising,
        localGKSLGen, dissipatorSchrodinger,
        Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]
       try ring)

/-- Action of `localChannel G K t` on `localEigenMatrixParam G K a`:
`localChannel G K t (E_a) = exp(μ_a * t) • E_a`. -/
theorem localChannel_eigenMatrixParam (G K t : ℝ) (a : Fin 4) :
    localChannel G K t (localEigenMatrixParam G K a) =
      (Real.exp (localEigenvalueParam G K a * t) : ℂ) • localEigenMatrixParam G K a := by
  fin_cases a
  · -- Mode 0
    simp only [Fin.zero_eta, localEigenMatrixParam, localEigenvalueParam,
      zero_mul, Real.exp_zero, Complex.ofReal_one, one_smul]
    exact localChannel_equilibriumParam G K t
  · -- Mode 1
    have hq : (localDampingR G K t : ℂ) ^ 2 = (Real.exp (-(G + K) * t) : ℂ) := by
      norm_cast
      rw [localDampingR_sq]
      rfl
    unfold localChannel
    rw [gadWeightedChannel_eq_closed]
    unfold gadClosedChannel
    rw [hq]
    ext i j
    fin_cases i <;> fin_cases j <;>
      (simp [localEigenMatrixParam, localEigenvalueParam, localPopulationMode]
       try ring)
  · -- Mode 2
    have hr : localDampingR G K t = Real.exp (-(G + K) / 2 * t) := by
      unfold localDampingR
      congr 1
      ring
    unfold localChannel
    rw [gadWeightedChannel_eq_closed]
    unfold gadClosedChannel
    rw [hr]
    ext i j
    fin_cases i <;> fin_cases j <;>
      (simp [localEigenMatrixParam, localEigenvalueParam, lowering]
       try ring)
  · -- Mode 3
    have hr : localDampingR G K t = Real.exp (-(G + K) / 2 * t) := by
      unfold localDampingR
      congr 1
      ring
    unfold localChannel
    rw [gadWeightedChannel_eq_closed]
    unfold gadClosedChannel
    rw [hr]
    ext i j
    fin_cases i <;> fin_cases j <;>
      (simp [localEigenMatrixParam, localEigenvalueParam, raising]
       try ring)

/-- The `4^N` Schrödinger eigenmatrices of the `N`-qubit independent generator:
`E_α = ⨂_{m=1}^N E^{(m)}_{α_m}`. -/
noncomputable def nQubitEigenMatrix {N : ℕ}
    (G K : Fin N → ℝ) (α : NQubitModeIndex N) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m => localEigenMatrixParam (G m) (K m) (α m))

/-- The `4^N` Heisenberg trace-dual eigenmatrices of the `N`-qubit independent generator:
`D_α = ⨂_{m=1}^N D^{(m)}_{α_m}`. -/
noncomputable def nQubitDualMatrix {N : ℕ}
    (G K : Fin N → ℝ) (α : NQubitModeIndex N) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m => localDualMatrixParam (G m) (K m) (α m))

/-- At the stationary mode `α = 0`, `nQubitEigenMatrix G K 0 = nQubitEquilibrium G K`. -/
@[simp]
theorem nQubitEigenMatrix_zero {N : ℕ} (G K : Fin N → ℝ) :
    nQubitEigenMatrix G K (fun _ => 0) = nQubitEquilibrium G K := rfl

/-- At the stationary mode `α = 0`, `nQubitDualMatrix G K 0 = 1`. -/
@[simp]
theorem nQubitDualMatrix_zero {N : ℕ} (G K : Fin N → ℝ) :
    nQubitDualMatrix G K (fun _ => 0) = 1 := by
  unfold nQubitDualMatrix localDualMatrixParam
  exact nQubitTensorProduct_one N

/-- **`N`-qubit trace biorthogonality (`Tr(D_α * E_β) = δ_{α,β}`)**:
for every `N : ℕ` and all modes `α, β ∈ {0,1,2,3}^N`. -/
theorem nQubit_dual_eigen_trace {N : ℕ}
    (G K : Fin N → ℝ) (α β : NQubitModeIndex N) :
    Matrix.trace (nQubitDualMatrix G K α * nQubitEigenMatrix G K β) =
      if α = β then 1 else 0 := by
  unfold nQubitDualMatrix nQubitEigenMatrix
  rw [nQubitTensorProduct_mul, trace_nQubitTensorProduct]
  simp only [local_dual_eigen_trace]
  by_cases h : α = β
  · subst h
    simp
  · rw [if_neg h]
    have hex : ∃ m : Fin N, α m ≠ β m := by
      by_contra hall
      push_neg at hall
      exact h (funext hall)
    rcases hex with ⟨m, hm⟩
    exact Finset.prod_eq_zero (Finset.mem_univ m) (if_neg hm)

/-- Every `N`-qubit eigenmatrix `nQubitEigenMatrix G K α` is nonzero. -/
theorem nQubitEigenMatrix_ne_zero {N : ℕ}
    (G K : Fin N → ℝ) (α : NQubitModeIndex N) :
    nQubitEigenMatrix G K α ≠ 0 := by
  intro hzero
  have htr := nQubit_dual_eigen_trace G K α α
  rw [hzero, Matrix.mul_zero, Matrix.trace_zero, if_pos rfl] at htr
  exact zero_ne_one htr

/-- Scalar factors pull out of an `N`-fold tensor product as a product of scalars. -/
theorem nQubitTensorProduct_smul {N : ℕ}
    (c : Fin N → ℂ) (A : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitTensorProduct (fun m => c m • A m) =
      (∏ m : Fin N, c m) • nQubitTensorProduct A := by
  ext i j
  simp [nQubitTensorProduct_apply, Matrix.smul_apply, smul_eq_mul, Finset.prod_mul_distrib]

/-- Spectral expansion of any `N`-fold tensor product matrix `⨂_m M_m` in the `4^N` eigenmatrix basis. -/
theorem nQubit_tensorProduct_spectral_expansion {N : ℕ}
    (G K : Fin N → ℝ) (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    (∑ α : NQubitModeIndex N,
      Matrix.trace (nQubitDualMatrix G K α * nQubitTensorProduct M) •
        nQubitEigenMatrix G K α) = nQubitTensorProduct M := by
  ext i j
  simp only [Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul,
    nQubitDualMatrix, nQubitEigenMatrix, nQubitTensorProduct_mul,
    trace_nQubitTensorProduct, nQubitTensorProduct_apply, ← Finset.prod_mul_distrib]
  calc
    ∑ α : NQubitModeIndex N,
        ∏ m : Fin N, Matrix.trace (localDualMatrixParam (G m) (K m) (α m) * M m) *
          localEigenMatrixParam (G m) (K m) (α m) (i m) (j m)
      = ∏ m : Fin N,
          ∑ a : Fin 4, Matrix.trace (localDualMatrixParam (G m) (K m) a * M m) *
            localEigenMatrixParam (G m) (K m) a (i m) (j m) := by
          exact (Fintype.prod_sum (fun m a =>
            Matrix.trace (localDualMatrixParam (G m) (K m) a * M m) *
              localEigenMatrixParam (G m) (K m) a (i m) (j m))).symm
    _ = ∏ m : Fin N, M m (i m) (j m) := by
          refine Finset.prod_congr rfl (fun m _ => ?_)
          have hexp := congr_fun (congr_fun (local_matrix_spectral_expansion (G m) (K m) (M m)) (i m)) (j m)
          simpa only [Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul] using hexp

/-- **Complete `4^N`-mode spectral expansion for arbitrary `X ∈ M_{2^N}(ℂ)` (`P1-07`)**:
every `N`-qubit matrix `X` expands uniquely as
`X = ∑_{α ∈ {0,1,2,3}^N} Tr(D_α * X) • E_α`. -/
theorem nQubit_matrix_spectral_expansion {N : ℕ}
    (G K : Fin N → ℝ)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    (∑ α : NQubitModeIndex N,
      Matrix.trace (nQubitDualMatrix G K α * X) • nQubitEigenMatrix G K α) = X := by
  have hX := matrix_eq_sum_nQubitProductUnit X
  conv_lhs => rw [hX]
  have hlin :
      (∑ α : NQubitModeIndex N,
        Matrix.trace (nQubitDualMatrix G K α *
          (∑ i : NQubitIndex N, ∑ j : NQubitIndex N, X i j • nQubitProductUnit i j)) •
          nQubitEigenMatrix G K α) =
      ∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
        X i j • (∑ α : NQubitModeIndex N,
          Matrix.trace (nQubitDualMatrix G K α * nQubitProductUnit i j) •
            nQubitEigenMatrix G K α) := by
    simp only [Matrix.mul_sum, Matrix.trace_sum, Matrix.mul_smul, Matrix.trace_smul,
      Finset.sum_smul, smul_smul, Finset.smul_sum]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl (fun j _ => ?_)
    refine Finset.sum_congr rfl (fun α _ => ?_)
    simp [smul_eq_mul, mul_comm]
  rw [hlin]
  calc
    (∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
      X i j • (∑ α : NQubitModeIndex N,
        Matrix.trace (nQubitDualMatrix G K α * nQubitProductUnit i j) •
          nQubitEigenMatrix G K α))
      = ∑ i : NQubitIndex N, ∑ j : NQubitIndex N, X i j • nQubitProductUnit i j := by
          refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
          rw [nQubitProductUnit, nQubit_tensorProduct_spectral_expansion]
    _ = X := hX.symm

/-- Exact action of `nQubitKrausChannel G K t` on the `4^N` eigenmatrices `nQubitEigenMatrix G K α`:
`Φ^{(N)}_t(E_α) = exp(Λ_α * t) • E_α`. -/
theorem nQubitKrausChannel_eigenMatrix {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t : ℝ} (ht : 0 ≤ t) (α : NQubitModeIndex N) :
    nQubitKrausChannel G K t (nQubitEigenMatrix G K α) =
      (Real.exp (nQubitEigenvalue G K α * t) : ℂ) • nQubitEigenMatrix G K α := by
  unfold nQubitEigenMatrix
  rw [nQubitKrausChannel_tensorProduct G K hG hK ht]
  have hloc :
      (fun m : Fin N => localChannel (G m) (K m) t (localEigenMatrixParam (G m) (K m) (α m))) =
        (fun m : Fin N => (Real.exp (localEigenvalueParam (G m) (K m) (α m) * t) : ℂ) •
          localEigenMatrixParam (G m) (K m) (α m)) :=
    funext (fun m => localChannel_eigenMatrixParam (G m) (K m) t (α m))
  rw [hloc, nQubitTensorProduct_smul]
  congr 1
  norm_cast
  rw [← Real.exp_sum]
  congr 1
  unfold nQubitEigenvalue
  rw [Finset.sum_mul]

/-- The `4^N`-mode spectral propagator `Ψ^{(N)}_t(X)` on `M_{2^N}(ℂ)`. -/
noncomputable def nQubitSpectralFlow {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  ∑ α : NQubitModeIndex N,
    (Real.exp (nQubitEigenvalue G K α * t) : ℂ) •
      (Matrix.trace (nQubitDualMatrix G K α * X) • nQubitEigenMatrix G K α)

/-- **Exact identity between the `4^N`-Kraus channel and the `4^N`-mode spectral flow**:
for all `t ≥ 0` and all `X ∈ M_{2^N}(ℂ)`, `nQubitKrausChannel G K t X = nQubitSpectralFlow G K t X`. -/
theorem nQubitKrausChannel_eq_spectralFlow {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t : ℝ} (ht : 0 ≤ t)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitKrausChannel G K t X = nQubitSpectralFlow G K t X := by
  conv_lhs => rw [← nQubit_matrix_spectral_expansion G K X]
  rw [nQubitKrausChannel_sum]
  unfold nQubitSpectralFlow
  refine Finset.sum_congr rfl (fun α _ => ?_)
  rw [nQubitKrausChannel_smul, nQubitKrausChannel_eigenMatrix G K hG hK ht α, smul_comm]

/-!
## 5. Full Independent `N`-Qubit Tensor-Sum GKSL Generator, Master Equation, and Spectrum (`P1-04`, `P1-07`)
-/

/-- Embedding of a single-qubit operator `J ∈ M₂(ℂ)` at site `m : Fin N` inside `M_{2^N}(ℂ)`:
`I₂ ⊗ ⋯ ⊗ J ⊗ ⋯ ⊗ I₂`. -/
noncomputable def nQubitSiteEmbed {N : ℕ} [DecidableEq (Fin N)]
    (m : Fin N) (J : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m J)

/-- Full independent `N`-qubit GKSL generator in the Schrödinger picture:
`L_N(X) = ∑_{m=1}^N (G_m D[σ^+_m](X) + K_m D[σ^-_m](X))`. -/
noncomputable def nQubitGKSLGenerator {N : ℕ}
    (G K : Fin N → ℝ)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  ∑ m : Fin N,
    ((G m : ℂ) • dissipatorSchrodinger (nQubitSiteEmbed m raising) X +
     (K m : ℂ) • dissipatorSchrodinger (nQubitSiteEmbed m lowering) X)

/-- `dissipatorSchrodinger` is additive in `X` on any finite matrix space. -/
theorem dissipatorSchrodinger_add_gen {n : Type*} [Fintype n] [DecidableEq n]
    (L X Y : Matrix n n ℂ) :
    dissipatorSchrodinger L (X + Y) =
      dissipatorSchrodinger L X + dissipatorSchrodinger L Y := by
  unfold dissipatorSchrodinger
  simp only [Matrix.mul_add, Matrix.add_mul, smul_add]
  abel

/-- `dissipatorSchrodinger` is `ℂ`-homogeneous in `X` on any finite matrix space. -/
theorem dissipatorSchrodinger_smul_gen {n : Type*} [Fintype n] [DecidableEq n]
    (L : Matrix n n ℂ) (c : ℂ) (X : Matrix n n ℂ) :
    dissipatorSchrodinger L (c • X) = c • dissipatorSchrodinger L X := by
  unfold dissipatorSchrodinger
  rw [Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_smul, Matrix.smul_mul,
      ← smul_add, smul_comm ((1 : ℂ) / 2) c, ← smul_sub]

/-- `nQubitGKSLGenerator` is additive in `X`. -/
theorem nQubitGKSLGenerator_add {N : ℕ}
    (G K : Fin N → ℝ)
    (X Y : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitGKSLGenerator G K (X + Y) =
      nQubitGKSLGenerator G K X + nQubitGKSLGenerator G K Y := by
  unfold nQubitGKSLGenerator
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl (fun m _ => ?_)
  rw [dissipatorSchrodinger_add_gen, dissipatorSchrodinger_add_gen, smul_add, smul_add]
  abel

/-- `nQubitGKSLGenerator` is `ℂ`-homogeneous in `X`. -/
theorem nQubitGKSLGenerator_smul {N : ℕ}
    (G K : Fin N → ℝ) (c : ℂ)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitGKSLGenerator G K (c • X) = c • nQubitGKSLGenerator G K X := by
  unfold nQubitGKSLGenerator
  rw [Finset.smul_sum]
  refine Finset.sum_congr rfl (fun m _ => ?_)
  rw [dissipatorSchrodinger_smul_gen, dissipatorSchrodinger_smul_gen,
      smul_add, smul_comm (G m : ℂ) c, smul_comm (K m : ℂ) c]

/-- `nQubitGKSLGenerator` commutes with finite sums. -/
theorem nQubitGKSLGenerator_sum {N : ℕ} {β : Type*}
    (G K : Fin N → ℝ) (s : Finset β)
    (f : β → Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitGKSLGenerator G K (∑ b ∈ s, f b) =
      ∑ b ∈ s, nQubitGKSLGenerator G K (f b) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
    unfold nQubitGKSLGenerator
    simp [dissipatorSchrodinger]
  | @insert b s hb ih =>
    rw [Finset.sum_insert hb, nQubitGKSLGenerator_add, ih, Finset.sum_insert hb]

/-- Conjugate transpose of a site-embedded operator. -/
theorem nQubitSiteEmbed_conjTranspose {N : ℕ}
    (m : Fin N) (J : Matrix (Fin 2) (Fin 2) ℂ) :
    (nQubitSiteEmbed m J)ᴴ = nQubitSiteEmbed m Jᴴ := by
  unfold nQubitSiteEmbed
  rw [nQubitTensorProduct_conjTranspose]
  have hfun :
      (fun r : Fin N => (Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m J r)ᴴ) =
        Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m Jᴴ := by
    funext r
    by_cases hr : r = m
    · subst hr
      simp
    · simp [Function.update_of_ne hr]
  rw [hfun]

/-- Linearity of `nQubitTensorProduct` in the `m`-th factor (addition). -/
theorem nQubitTensorProduct_update_add {N : ℕ}
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) (m : Fin N)
    (B₁ B₂ : Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitTensorProduct (Function.update M m (B₁ + B₂)) =
      nQubitTensorProduct (Function.update M m B₁) +
        nQubitTensorProduct (Function.update M m B₂) := by
  ext i j
  simp only [nQubitTensorProduct_apply, Matrix.add_apply]
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ m),
      ← Finset.prod_erase_mul _ _ (Finset.mem_univ m),
      ← Finset.prod_erase_mul _ _ (Finset.mem_univ m)]
  have heq1 :
      ∏ x ∈ Finset.univ.erase m, Function.update M m (B₁ + B₂) x (i x) (j x) =
        ∏ x ∈ Finset.univ.erase m, M x (i x) (j x) := by
    refine Finset.prod_congr rfl (fun x hx => ?_)
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
  have heq2 :
      ∏ x ∈ Finset.univ.erase m, Function.update M m B₁ x (i x) (j x) =
        ∏ x ∈ Finset.univ.erase m, M x (i x) (j x) := by
    refine Finset.prod_congr rfl (fun x hx => ?_)
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
  have heq3 :
      ∏ x ∈ Finset.univ.erase m, Function.update M m B₂ x (i x) (j x) =
        ∏ x ∈ Finset.univ.erase m, M x (i x) (j x) := by
    refine Finset.prod_congr rfl (fun x hx => ?_)
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
  rw [heq1, heq2, heq3, Function.update_self, Function.update_self, Function.update_self,
      Matrix.add_apply, mul_add]

/-- Linearity of `nQubitTensorProduct` in the `m`-th factor (subtraction). -/
theorem nQubitTensorProduct_update_sub {N : ℕ}
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) (m : Fin N)
    (B₁ B₂ : Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitTensorProduct (Function.update M m (B₁ - B₂)) =
      nQubitTensorProduct (Function.update M m B₁) -
        nQubitTensorProduct (Function.update M m B₂) := by
  ext i j
  simp only [nQubitTensorProduct_apply, Matrix.sub_apply]
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ m),
      ← Finset.prod_erase_mul _ _ (Finset.mem_univ m),
      ← Finset.prod_erase_mul _ _ (Finset.mem_univ m)]
  have heq1 :
      ∏ x ∈ Finset.univ.erase m, Function.update M m (B₁ - B₂) x (i x) (j x) =
        ∏ x ∈ Finset.univ.erase m, M x (i x) (j x) := by
    refine Finset.prod_congr rfl (fun x hx => ?_)
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
  have heq2 :
      ∏ x ∈ Finset.univ.erase m, Function.update M m B₁ x (i x) (j x) =
        ∏ x ∈ Finset.univ.erase m, M x (i x) (j x) := by
    refine Finset.prod_congr rfl (fun x hx => ?_)
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
  have heq3 :
      ∏ x ∈ Finset.univ.erase m, Function.update M m B₂ x (i x) (j x) =
        ∏ x ∈ Finset.univ.erase m, M x (i x) (j x) := by
    refine Finset.prod_congr rfl (fun x hx => ?_)
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
  rw [heq1, heq2, heq3, Function.update_self, Function.update_self, Function.update_self,
      Matrix.sub_apply, mul_sub]

/-- Linearity of `nQubitTensorProduct` in the `m`-th factor (scalar multiplication). -/
theorem nQubitTensorProduct_update_smul {N : ℕ}
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) (m : Fin N)
    (c : ℂ) (B : Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitTensorProduct (Function.update M m (c • B)) =
      c • nQubitTensorProduct (Function.update M m B) := by
  ext i j
  simp only [nQubitTensorProduct_apply, Matrix.smul_apply, smul_eq_mul]
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ m),
      ← Finset.prod_erase_mul _ _ (Finset.mem_univ m)]
  have heq1 :
      ∏ x ∈ Finset.univ.erase m, Function.update M m (c • B) x (i x) (j x) =
        ∏ x ∈ Finset.univ.erase m, M x (i x) (j x) := by
    refine Finset.prod_congr rfl (fun x hx => ?_)
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
  have heq2 :
      ∏ x ∈ Finset.univ.erase m, Function.update M m B x (i x) (j x) =
        ∏ x ∈ Finset.univ.erase m, M x (i x) (j x) := by
    refine Finset.prod_congr rfl (fun x hx => ?_)
    rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
  rw [heq1, heq2, Function.update_self, Function.update_self, Matrix.smul_apply, smul_eq_mul]
  ring

/-- Action of a site-embedded dissipator on an `N`-fold tensor product. -/
theorem dissipatorSchrodinger_nQubitSiteEmbed {N : ℕ}
    (m : Fin N) (J : Matrix (Fin 2) (Fin 2) ℂ)
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    dissipatorSchrodinger (nQubitSiteEmbed m J) (nQubitTensorProduct M) =
      nQubitTensorProduct (Function.update M m (dissipatorSchrodinger J (M m))) := by
  unfold dissipatorSchrodinger
  rw [nQubitSiteEmbed_conjTranspose]
  unfold nQubitSiteEmbed
  simp only [nQubitTensorProduct_mul]
  have h1 :
      (fun r : Fin N =>
        Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m J r * M r *
          Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m Jᴴ r) =
      Function.update M m (J * M m * Jᴴ) := by
    ext r
    by_cases hr : r = m
    · subst hr; simp
    · simp [Function.update_of_ne hr]
  have h2 :
      (fun r : Fin N =>
        Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m Jᴴ r *
          Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m J r * M r) =
      Function.update M m (Jᴴ * J * M m) := by
    ext r
    by_cases hr : r = m
    · subst hr; simp
    · simp [Function.update_of_ne hr]
  have h3 :
      (fun r : Fin N =>
        M r * (Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m Jᴴ r *
          Function.update (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) m J r)) =
      Function.update M m (M m * (Jᴴ * J)) := by
    ext r
    by_cases hr : r = m
    · subst hr; simp
    · simp [Function.update_of_ne hr]
  rw [h1, h2, h3, nQubitTensorProduct_update_sub, nQubitTensorProduct_update_smul,
      nQubitTensorProduct_update_add]

/-- Action of `nQubitGKSLGenerator G K` on an `N`-fold tensor product. -/
theorem nQubitGKSLGenerator_tensorProduct {N : ℕ}
    (G K : Fin N → ℝ) (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitGKSLGenerator G K (nQubitTensorProduct M) =
      ∑ m : Fin N,
        nQubitTensorProduct (Function.update M m (localGKSLGen (G m) (K m) (M m))) := by
  unfold nQubitGKSLGenerator
  refine Finset.sum_congr rfl (fun m _ => ?_)
  rw [dissipatorSchrodinger_nQubitSiteEmbed, dissipatorSchrodinger_nQubitSiteEmbed,
      ← nQubitTensorProduct_update_smul, ← nQubitTensorProduct_update_smul,
      ← nQubitTensorProduct_update_add]
  rfl

/-- **`N`-qubit eigenmatrix theorem (`L_N(E_α) = Λ_α • E_α`, `P1-04`, `P1-07`)**:
for all positive local rates `G m > 0, K m > 0` and every mode `α ∈ {0,1,2,3}^N`,
`nQubitEigenMatrix G K α` is an exact eigenvector of `nQubitGKSLGenerator G K` with
eigenvalue `nQubitEigenvalue G K α`. -/
theorem nQubitGKSLGenerator_eigenMatrix {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (α : NQubitModeIndex N) :
    nQubitGKSLGenerator G K (nQubitEigenMatrix G K α) =
      (nQubitEigenvalue G K α : ℂ) • nQubitEigenMatrix G K α := by
  unfold nQubitEigenMatrix
  rw [nQubitGKSLGenerator_tensorProduct]
  have hterm :
      ∀ m : Fin N,
        nQubitTensorProduct
          (Function.update (fun r => localEigenMatrixParam (G r) (K r) (α r)) m
            (localGKSLGen (G m) (K m) (localEigenMatrixParam (G m) (K m) (α m)))) =
        (localEigenvalueParam (G m) (K m) (α m) : ℂ) •
          nQubitTensorProduct (fun r => localEigenMatrixParam (G r) (K r) (α r)) := by
    intro m
    have hGKm : G m + K m ≠ 0 := ne_of_gt (add_pos (hG m) (hK m))
    rw [localGKSLGen_eigenMatrixParam (G m) (K m) hGKm (α m),
        nQubitTensorProduct_update_smul, Function.update_eq_self]
  simp only [hterm, ← Finset.sum_smul]
  congr 1
  unfold nQubitEigenvalue
  push_cast
  rfl

/-- Action of `nQubitGKSLGenerator G K` on `nQubitSpectralFlow G K t X`. -/
theorem nQubitGKSLGenerator_spectralFlow {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitGKSLGenerator G K (nQubitSpectralFlow G K t X) =
      ∑ α : NQubitModeIndex N,
        ((nQubitEigenvalue G K α : ℂ) * (Real.exp (nQubitEigenvalue G K α * t) : ℂ)) •
          (Matrix.trace (nQubitDualMatrix G K α * X) • nQubitEigenMatrix G K α) := by
  unfold nQubitSpectralFlow
  rw [nQubitGKSLGenerator_sum]
  refine Finset.sum_congr rfl (fun α _ => ?_)
  rw [nQubitGKSLGenerator_smul, nQubitGKSLGenerator_smul,
      nQubitGKSLGenerator_eigenMatrix G K hG hK α,
      smul_comm (Matrix.trace (nQubitDualMatrix G K α * X)),
      smul_smul, mul_comm]

/-- **Arbitrary-input entrywise GKSL master equation for `nQubitSpectralFlow` (`P1-07`)**:
for every `N : ℕ`, positive local rates `G, K`, matrix `X ∈ M_{2^N}(ℂ)`, `t : ℝ`, and `i, j`,
`d/dt (Ψ^{(N)}_t(X))_{i,j} = (L_N(Ψ^{(N)}_t(X)))_{i,j}`. -/
theorem nQubitSpectralFlow_hasDerivAt_GKSL {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ)
    (t : ℝ) (i j : NQubitIndex N) :
    HasDerivAt (fun s : ℝ => nQubitSpectralFlow G K s X i j)
      (nQubitGKSLGenerator G K (nQubitSpectralFlow G K t X) i j) t := by
  rw [nQubitGKSLGenerator_spectralFlow G K hG hK t X]
  simp only [nQubitSpectralFlow, Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul]
  refine HasDerivAt.sum (fun α _ => ?_)
  have hlin : HasDerivAt (fun s : ℝ => nQubitEigenvalue G K α * s)
      (nQubitEigenvalue G K α) t := by
    simpa using (hasDerivAt_id t).const_mul (nQubitEigenvalue G K α)
  have hexp : HasDerivAt (fun s : ℝ => Real.exp (nQubitEigenvalue G K α * s))
      (Real.exp (nQubitEigenvalue G K α * t) * nQubitEigenvalue G K α) t :=
    hlin.exp
  have hexpC : HasDerivAt (fun s : ℝ => (Real.exp (nQubitEigenvalue G K α * s) : ℂ))
      ((nQubitEigenvalue G K α : ℂ) * (Real.exp (nQubitEigenvalue G K α * t) : ℂ)) t := by
    have h1 := hexp.ofReal_comp
    convert h1 using 1
    push_cast
    ring
  exact hexpC.mul_const
    (Matrix.trace (nQubitDualMatrix G K α * X) * nQubitEigenMatrix G K α i j)

/-- **Arbitrary-input entrywise GKSL master equation for `nQubitKrausChannel` on `[0, ∞)` (`P1-07`)**:
for every `t ≥ 0` (including the right derivative at `t = 0`), every `X ∈ M_{2^N}(ℂ)`, and `i, j`,
`HasDerivWithinAt (fun s => Φ^{(N)}_s(X)_{i,j}) (L_N(Φ^{(N)}_t(X))_{i,j}) (Set.Ici 0) t`. -/
theorem nQubitKrausChannel_hasDerivWithinAt_GKSL {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ)
    {t : ℝ} (ht : 0 ≤ t) (i j : NQubitIndex N) :
    HasDerivWithinAt (fun s : ℝ => nQubitKrausChannel G K s X i j)
      (nQubitGKSLGenerator G K (nQubitKrausChannel G K t X) i j) (Set.Ici 0) t := by
  have hd : HasDerivWithinAt (fun s : ℝ => nQubitSpectralFlow G K s X i j)
      (nQubitGKSLGenerator G K (nQubitSpectralFlow G K t X) i j) (Set.Ici 0) t :=
    (nQubitSpectralFlow_hasDerivAt_GKSL G K hG hK X t i j).hasDerivWithinAt
  rw [nQubitKrausChannel_eq_spectralFlow G K hG hK ht X]
  refine hd.congr (fun s hs => ?_) (nQubitKrausChannel_eq_spectralFlow G K hG hK ht X ▸ rfl)
  rw [nQubitKrausChannel_eq_spectralFlow G K hG hK hs X]

/-- **Arbitrary-input two-sided GKSL derivative for `nQubitKrausChannel` at `t > 0`**:
for every `t > 0`, `X ∈ M_{2^N}(ℂ)`, and `i, j`,
`HasDerivAt (fun s => Φ^{(N)}_s(X)_{i,j}) (L_N(Φ^{(N)}_t(X))_{i,j}) t`. -/
theorem nQubitKrausChannel_hasDerivAt_GKSL_of_pos {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ)
    {t : ℝ} (ht : 0 < t) (i j : NQubitIndex N) :
    HasDerivAt (fun s : ℝ => nQubitKrausChannel G K s X i j)
      (nQubitGKSLGenerator G K (nQubitKrausChannel G K t X) i j) t := by
  have hwithin := nQubitKrausChannel_hasDerivWithinAt_GKSL G K hG hK X (le_of_lt ht) i j
  exact hwithin.hasDerivAt (Ici_mem_nhds ht)

/-- Dual eigenmode projection of `nQubitGKSLGenerator G K X`:
`Tr(D_α * L_N(X)) = Λ_α * Tr(D_α * X)`. -/
theorem trace_nQubitDualMatrix_mul_nQubitGKSLGenerator {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (α : NQubitModeIndex N)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    Matrix.trace (nQubitDualMatrix G K α * nQubitGKSLGenerator G K X) =
      (nQubitEigenvalue G K α : ℂ) * Matrix.trace (nQubitDualMatrix G K α * X) := by
  conv_lhs => rw [← nQubit_matrix_spectral_expansion G K X]
  rw [nQubitGKSLGenerator_sum, Matrix.mul_sum, Matrix.trace_sum]
  rw [Finset.sum_eq_single α]
  · rw [nQubitGKSLGenerator_smul, nQubitGKSLGenerator_eigenMatrix G K hG hK α,
        Matrix.mul_smul, Matrix.mul_smul, Matrix.trace_smul, Matrix.trace_smul,
        nQubit_dual_eigen_trace, if_pos rfl]
    simp [mul_comm]
  · intro β _ hβα
    rw [nQubitGKSLGenerator_smul, nQubitGKSLGenerator_eigenMatrix G K hG hK β,
        Matrix.mul_smul, Matrix.mul_smul, Matrix.trace_smul, Matrix.trace_smul,
        nQubit_dual_eigen_trace, if_neg (Ne.symm hβα)]
    simp
  · intro hα
    exact (hα (Finset.mem_univ α)).elim

/-- **Complete operator spectrum theorem for `nQubitGKSLGenerator` (`P1-04`, `P1-07`)**:
if `V ≠ 0` satisfies `nQubitGKSLGenerator G K V = μ • V` for some `μ : ℂ`, then there exists
a mode `α : NQubitModeIndex N` such that `Tr(D_α * V) ≠ 0` and `μ = (nQubitEigenvalue G K α : ℂ)`. -/
theorem nQubitGKSLGenerator_eigenvalue_mem_spectrum {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {V : Matrix (NQubitIndex N) (NQubitIndex N) ℂ} (hV : V ≠ 0)
    {μ : ℂ} (heig : nQubitGKSLGenerator G K V = μ • V) :
    ∃ α : NQubitModeIndex N,
      Matrix.trace (nQubitDualMatrix G K α * V) ≠ 0 ∧
        μ = (nQubitEigenvalue G K α : ℂ) := by
  have hex : ∃ α : NQubitModeIndex N, Matrix.trace (nQubitDualMatrix G K α * V) ≠ 0 := by
    by_contra hall
    push_neg at hall
    have hsum := nQubit_matrix_spectral_expansion G K V
    simp only [hall, zero_smul, Finset.sum_const_zero] at hsum
    exact hV hsum.symm
  rcases hex with ⟨α, hα⟩
  refine ⟨α, hα, ?_⟩
  have htr := trace_nQubitDualMatrix_mul_nQubitGKSLGenerator G K hG hK α V
  rw [heig, Matrix.mul_smul, Matrix.trace_smul, smul_eq_mul] at htr
  exact mul_right_cancel₀ hα htr

/-- **Stationary-state uniqueness for `nQubitGKSLGenerator`**:
`nQubitGKSLGenerator G K X = 0` iff `X = Tr(X) • nQubitEquilibrium G K`. -/
theorem nQubitGKSLGenerator_eq_zero_iff {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    nQubitGKSLGenerator G K X = 0 ↔
      X = Matrix.trace X • nQubitEquilibrium G K := by
  constructor
  · intro hzero
    conv_lhs => rw [← nQubit_matrix_spectral_expansion G K X]
    rw [Finset.sum_eq_single (fun _ => 0)]
    · simp only [nQubitDualMatrix_zero, nQubitEigenMatrix_zero, Matrix.one_mul]
    · intro α _ hα0
      have htr := trace_nQubitDualMatrix_mul_nQubitGKSLGenerator G K hG hK α X
      rw [hzero, Matrix.mul_zero, Matrix.trace_zero] at htr
      have hne : (nQubitEigenvalue G K α : ℂ) ≠ 0 := by
        exact_mod_cast (not_iff_not.mpr (nQubitEigenvalue_eq_zero_iff G K hG hK α)).mpr hα0
      have htr0 : Matrix.trace (nQubitDualMatrix G K α * X) = 0 :=
        (mul_eq_zero.mp htr.symm).resolve_left hne
      rw [htr0, zero_smul]
    · intro h0
      exact (h0 (Finset.mem_univ (fun _ => 0))).elim
  · intro hX
    rw [hX, nQubitGKSLGenerator_smul, ← nQubitEigenMatrix_zero,
        nQubitGKSLGenerator_eigenMatrix G K hG hK (fun _ => 0),
        nQubitEigenvalue_zero, Complex.ofReal_zero, zero_smul, smul_zero]

/-- Single-site coherence mode index `α_{m₀}` with mode `2` (`lowering`) at site `m₀` and `0` elsewhere. -/
def nQubitSingleCoherenceMode {N : ℕ} [DecidableEq (Fin N)] (m₀ : Fin N) : NQubitModeIndex N :=
  Function.update (fun _ : Fin N => (0 : Fin 4)) m₀ 2

/-- The single-site coherence mode `nQubitSingleCoherenceMode m₀` is nonstationary (`≠ 0`). -/
theorem nQubitSingleCoherenceMode_ne_zero {N : ℕ} (m₀ : Fin N) :
    nQubitSingleCoherenceMode m₀ ≠ (fun _ => 0) := by
  intro h
  have hm := congr_fun h m₀
  simp [nQubitSingleCoherenceMode] at hm

/-- The `N`-qubit eigenvalue of `nQubitSingleCoherenceMode m₀` is `-(G m₀ + K m₀) / 2`. -/
theorem nQubitEigenvalue_singleCoherenceMode {N : ℕ}
    (G K : Fin N → ℝ) (m₀ : Fin N) :
    nQubitEigenvalue G K (nQubitSingleCoherenceMode m₀) = -(G m₀ + K m₀) / 2 := by
  unfold nQubitEigenvalue nQubitSingleCoherenceMode
  rw [Finset.sum_eq_single m₀]
  · simp [localEigenvalueParam]
  · intro m _ hm
    simp [Function.update_of_ne hm, localEigenvalueParam]
  · intro hm₀
    exact (hm₀ (Finset.mem_univ m₀)).elim

/-- **Optimal attained `N`-qubit spectral gap for `0 < N` (`P1-04`, `P1-07`)**:
for `0 < N` and positive rates `G, K : Fin N → ℝ`, there exists a minimizing site `m_min : Fin N`
such that `Δ = (G m_min + K m_min) / 2 > 0`, every nonstationary mode `α ≠ 0` has eigenvalue
`nQubitEigenvalue G K α ≤ -Δ`, and the nonstationary eigenmatrix
`E = nQubitEigenMatrix G K (nQubitSingleCoherenceMode m_min) ≠ 0` is an exact eigenvector of
`nQubitGKSLGenerator G K` with eigenvalue `-Δ`. -/
theorem nQubit_optimal_spectral_gap_attained {N : ℕ} (hN : 0 < N)
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) :
    ∃ m_min : Fin N,
      0 < (G m_min + K m_min) / 2 ∧
      (∀ α : NQubitModeIndex N, α ≠ (fun _ => 0) →
        nQubitEigenvalue G K α ≤ -(G m_min + K m_min) / 2) ∧
      nQubitEigenMatrix G K (nQubitSingleCoherenceMode m_min) ≠ 0 ∧
      nQubitGKSLGenerator G K (nQubitEigenMatrix G K (nQubitSingleCoherenceMode m_min)) =
        ((-(G m_min + K m_min) / 2 : ℝ) : ℂ) •
          nQubitEigenMatrix G K (nQubitSingleCoherenceMode m_min) := by
  haveI : Nonempty (Fin N) := ⟨⟨0, hN⟩⟩
  obtain ⟨m_min, _, hm_min⟩ :=
    Finset.exists_min_image (Finset.univ : Finset (Fin N))
      (fun m => (G m + K m) / 2) Finset.univ_nonempty
  refine ⟨m_min, ?_, ?_, nQubitEigenMatrix_ne_zero G K (nQubitSingleCoherenceMode m_min), ?_⟩
  · linarith [hG m_min, hK m_min]
  · intro α hα
    have h := nQubit_spectral_gap_bound G K hG hK (fun m => hm_min m (Finset.mem_univ m)) hα
    linarith
  · rw [nQubitGKSLGenerator_eigenMatrix G K hG hK (nQubitSingleCoherenceMode m_min),
        nQubitEigenvalue_singleCoherenceMode G K m_min]

/-!
## 6. Spectral Singular-Value Schatten-1 Functional (`P0c-05`, `P0c-06`)
-/

/-- The spectral singular-value Schatten-1 functional `‖X‖₁ = ∑_i √(λ_i(Xᴴ X))`, defined on any
finite-dimensional complex matrix space via the eigenvalues of the positive semidefinite
Hermitian operator `Xᴴ * X` (`Matrix.posSemidef_conjTranspose_mul_self X`). -/
noncomputable def schattenOneSpectralNorm {n : Type*} [Fintype n] [DecidableEq n]
    (X : Matrix n n ℂ) : ℝ :=
  ∑ i : n, Real.sqrt ((Matrix.posSemidef_conjTranspose_mul_self X).1.eigenvalues i)

/-- The spectral singular-value Schatten-1 functional is nonnegative for every matrix `X`. -/
theorem schattenOneSpectralNorm_nonneg {n : Type*} [Fintype n] [DecidableEq n]
    (X : Matrix n n ℂ) :
    0 ≤ schattenOneSpectralNorm X := by
  unfold schattenOneSpectralNorm
  exact Finset.sum_nonneg (fun i _ => Real.sqrt_nonneg _)

end BinduEventInterface
