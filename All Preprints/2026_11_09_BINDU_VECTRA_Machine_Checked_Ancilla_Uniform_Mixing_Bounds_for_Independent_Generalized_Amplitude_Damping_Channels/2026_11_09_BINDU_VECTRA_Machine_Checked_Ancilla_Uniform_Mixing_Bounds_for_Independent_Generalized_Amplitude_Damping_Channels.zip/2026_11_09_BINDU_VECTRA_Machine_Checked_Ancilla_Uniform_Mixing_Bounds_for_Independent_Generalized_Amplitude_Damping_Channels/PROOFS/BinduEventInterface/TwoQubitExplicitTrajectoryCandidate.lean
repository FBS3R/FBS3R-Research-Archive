import BinduEventInterface.TwoQubitStationaryCandidate
import Mathlib.LinearAlgebra.Matrix.PosDef

/-!
# Explicit Nonstationary Vacuum-to-Equilibrium Trajectory of the Four-Channel Two-Qubit GKSL Generator

This module constructs and kernel-verifies the exact nonstationary density-matrix
trajectory `twoQubitVacuumTrajectory` evolving from the vacuum state
`twoQubitVacuum = |00⟩⟨00|` under the existing four-channel two-qubit GKSL generator
`fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate`:

* Exact local populations:
  `twoQubitX1 t = (7 / 22) * (1 - Real.exp (-(22 / 35) * t))`
  `twoQubitX2 t = (11 / 29) * (1 - Real.exp (-(58 / 99) * t))`
* Exact product-state trajectory:
  `twoQubitVacuumTrajectory t = Matrix.kronecker (twoQubitLocalTrajectory1 t) (twoQubitLocalTrajectory2 t)`
* Initial condition `twoQubitVacuumTrajectory 0 = twoQubitVacuum`
* Trace preservation `Matrix.trace (twoQubitVacuumTrajectory t) = 1`
* Hermiticity (`conjTranspose` and `Matrix.IsHermitian`) and positive semidefiniteness
  (`Matrix.PosSemidef`, diagonal nonnegativity, and quadratic-form nonnegativity) for all `t ≥ 0`
* Kronecker factorization of the Schrödinger dissipator and the four-channel GKSL generator
* Entrywise time derivatives and exact GKSL master equation:
  `HasDerivAt (fun s => twoQubitVacuumTrajectory s i j) (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (twoQubitVacuumTrajectory t) i j) t`
  and `deriv (fun s => twoQubitVacuumTrajectory s i j) t = fullGKSLSchrodinger ...`
* Constructive instantiation of `CertifiedTwoQubitPath` (`twoQubitExplicitCertifiedPath`),
  discharging the trajectory existence hypothesis in `ConcreteTwoQubitDynamics` and
  `MaximalTwoQubitConsequencesCandidate`
* Exact Schrödinger–Heisenberg trace duality for the generator and time derivatives of arbitrary
  observables along `twoQubitVacuumTrajectory`
* Exact marginal expectations `x₁(t)`, `x₂(t)`, exact joint-event expectation `x₁(t) * x₂(t)`,
  all-time bounds `0 ≤ ⟨Q₁₂⟩(t) ≤ 7/58 < 1/8 < 1/4` for `t ≥ 0`, and asymptotic convergence
  `twoQubitVacuumTrajectory t → twoQubitEquilibrium` as `t → +∞`.
-/

namespace BinduEventInterface

open scoped Matrix ComplexOrder

/-- Single-qubit computational basis index `Fin 2`. -/
abbrev QubitIndex := Fin 2

/-- Exact excited-state population trajectory of qubit 1 starting from vacuum. -/
noncomputable def twoQubitX1 (t : ℝ) : ℝ :=
  (7 / 22 : ℝ) * (1 - Real.exp (-(22 / 35 : ℝ) * t))

/-- Exact excited-state population trajectory of qubit 2 starting from vacuum. -/
noncomputable def twoQubitX2 (t : ℝ) : ℝ :=
  (11 / 29 : ℝ) * (1 - Real.exp (-(58 / 99 : ℝ) * t))

/-- Single-qubit diagonal density matrix `diag(1 - x, x)`. -/
noncomputable def twoQubitDiagState (x : ℝ) : Matrix QubitIndex QubitIndex ℂ :=
  !![((1 - x : ℝ) : ℂ), 0; 0, ((x : ℝ) : ℂ)]

/-- Local density-matrix trajectory of qubit 1: `diag(1 - x₁(t), x₁(t))`. -/
noncomputable def twoQubitLocalTrajectory1 (t : ℝ) : Matrix QubitIndex QubitIndex ℂ :=
  twoQubitDiagState (twoQubitX1 t)

/-- Local density-matrix trajectory of qubit 2: `diag(1 - x₂(t), x₂(t))`. -/
noncomputable def twoQubitLocalTrajectory2 (t : ℝ) : Matrix QubitIndex QubitIndex ℂ :=
  twoQubitDiagState (twoQubitX2 t)

/-- Exact nonstationary two-qubit vacuum-to-equilibrium trajectory:
`ρ(t) = diag(1 - x₁(t), x₁(t)) ⊗ diag(1 - x₂(t), x₂(t))`. -/
noncomputable def twoQubitVacuumTrajectory (t : ℝ) :
    Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker (twoQubitLocalTrajectory1 t) (twoQubitLocalTrajectory2 t)

/-- `twoQubitX1` coincides with `constantRatePopulation (1/5) (3/7)`. -/
theorem twoQubitX1_eq_constantRatePopulation (t : ℝ) :
    twoQubitX1 t = constantRatePopulation ((1 : ℝ) / 5) ((3 : ℝ) / 7) t := by
  unfold twoQubitX1 constantRatePopulation
  ring_nf

/-- `twoQubitX2` coincides with `constantRatePopulation (2/9) (4/11)`. -/
theorem twoQubitX2_eq_constantRatePopulation (t : ℝ) :
    twoQubitX2 t = constantRatePopulation ((2 : ℝ) / 9) ((4 : ℝ) / 11) t := by
  unfold twoQubitX2 constantRatePopulation
  ring_nf

/-- Initial condition `x₁(0) = 0`. -/
@[simp]
theorem twoQubitX1_zero : twoQubitX1 0 = 0 := by
  simp [twoQubitX1]

/-- Initial condition `x₂(0) = 0`. -/
@[simp]
theorem twoQubitX2_zero : twoQubitX2 0 = 0 := by
  simp [twoQubitX2]

/-- Explicit exponential relaxation identity `x₁(t) - 7/22 = -(7/22) * exp(-22t/35)`. -/
theorem twoQubitX1_sub_equilibrium (t : ℝ) :
    twoQubitX1 t - (7 / 22 : ℝ) = -(7 / 22 : ℝ) * Real.exp (-(22 / 35 : ℝ) * t) := by
  unfold twoQubitX1
  ring

/-- Explicit exponential relaxation identity `x₂(t) - 11/29 = -(11/29) * exp(-58t/99)`. -/
theorem twoQubitX2_sub_equilibrium (t : ℝ) :
    twoQubitX2 t - (11 / 29 : ℝ) = -(11 / 29 : ℝ) * Real.exp (-(58 / 99 : ℝ) * t) := by
  unfold twoQubitX2
  ring

/-- All-time bounds for `x₁(t)` on `t ≥ 0`: `0 ≤ x₁(t) ≤ 7/22 < 1`. -/
theorem twoQubitX1_bounds (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ twoQubitX1 t ∧ twoQubitX1 t ≤ 7 / 22 ∧ twoQubitX1 t < 1 := by
  have hb :=
    constantRatePopulation_bounds ((1 : ℝ) / 5) ((3 : ℝ) / 7) t
      (by norm_num) (by norm_num) (by norm_num) ht
  rw [← twoQubitX1_eq_constantRatePopulation] at hb
  have hle : twoQubitX1 t ≤ 7 / 22 := by linarith [hb.2]
  exact ⟨hb.1, hle, by linarith⟩

/-- All-time bounds for `x₂(t)` on `t ≥ 0`: `0 ≤ x₂(t) ≤ 11/29 < 1`. -/
theorem twoQubitX2_bounds (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ twoQubitX2 t ∧ twoQubitX2 t ≤ 11 / 29 ∧ twoQubitX2 t < 1 := by
  have hb :=
    constantRatePopulation_bounds ((2 : ℝ) / 9) ((4 : ℝ) / 11) t
      (by norm_num) (by norm_num) (by norm_num) ht
  rw [← twoQubitX2_eq_constantRatePopulation] at hb
  have hle : twoQubitX2 t ≤ 11 / 29 := by linarith [hb.2]
  exact ⟨hb.1, hle, by linarith⟩

/-- Exact time derivative of `x₁(t)`: `x₁'(t) = 1/5 - (22/35) * x₁(t)`. -/
theorem twoQubitX1_hasDerivAt (t : ℝ) :
    HasDerivAt twoQubitX1 ((1 / 5 : ℝ) - (22 / 35 : ℝ) * twoQubitX1 t) t := by
  have hd :=
    constantRatePopulation_hasDerivAt ((1 : ℝ) / 5) ((3 : ℝ) / 7) t (by norm_num)
  have hfun : constantRatePopulation ((1 : ℝ) / 5) ((3 : ℝ) / 7) = twoQubitX1 := by
    ext s
    exact (twoQubitX1_eq_constantRatePopulation s).symm
  rw [hfun] at hd
  convert hd using 1
  ring

/-- Exact time derivative of `x₂(t)`: `x₂'(t) = 2/9 - (58/99) * x₂(t)`. -/
theorem twoQubitX2_hasDerivAt (t : ℝ) :
    HasDerivAt twoQubitX2 ((2 / 9 : ℝ) - (58 / 99 : ℝ) * twoQubitX2 t) t := by
  have hd :=
    constantRatePopulation_hasDerivAt ((2 : ℝ) / 9) ((4 : ℝ) / 11) t (by norm_num)
  have hfun : constantRatePopulation ((2 : ℝ) / 9) ((4 : ℝ) / 11) = twoQubitX2 := by
    ext s
    exact (twoQubitX2_eq_constantRatePopulation s).symm
  rw [hfun] at hd
  convert hd using 1
  ring

/-- At `x = 0`, `twoQubitDiagState 0 = 1 - occupation`. -/
theorem twoQubitDiagState_zero :
    twoQubitDiagState 0 = (1 : Matrix QubitIndex QubitIndex ℂ) - occupation := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [twoQubitDiagState, occupation, Matrix.one_apply]

/-- Initial condition of the two-qubit trajectory: `ρ(0) = |00⟩⟨00|` (`twoQubitVacuum`). -/
theorem twoQubitVacuumTrajectory_zero :
    twoQubitVacuumTrajectory 0 = twoQubitVacuum := by
  unfold twoQubitVacuumTrajectory twoQubitLocalTrajectory1 twoQubitLocalTrajectory2 twoQubitVacuum
  rw [twoQubitX1_zero, twoQubitX2_zero, twoQubitDiagState_zero]

/-- Trace of any single-qubit diagonal state `twoQubitDiagState x` is `1`. -/
theorem twoQubitDiagState_trace (x : ℝ) :
    Matrix.trace (twoQubitDiagState x) = (1 : ℂ) := by
  simp only [twoQubitDiagState, Matrix.trace, Matrix.diag, Fin.sum_univ_two,
    Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons,
    Complex.ofReal_sub, Complex.ofReal_one]
  ring

/-- Trace of the local trajectory of qubit 1 is `1` for all `t`. -/
theorem twoQubitLocalTrajectory1_trace (t : ℝ) :
    Matrix.trace (twoQubitLocalTrajectory1 t) = (1 : ℂ) :=
  twoQubitDiagState_trace (twoQubitX1 t)

/-- Trace of the local trajectory of qubit 2 is `1` for all `t`. -/
theorem twoQubitLocalTrajectory2_trace (t : ℝ) :
    Matrix.trace (twoQubitLocalTrajectory2 t) = (1 : ℂ) :=
  twoQubitDiagState_trace (twoQubitX2 t)

/-- Trace factorization for Kronecker products of `2 × 2` matrices. -/
theorem trace_kronecker_qubit (A B : Matrix QubitIndex QubitIndex ℂ) :
    Matrix.trace (Matrix.kronecker A B) = Matrix.trace A * Matrix.trace B := by
  simp only [Matrix.kronecker]
  exact Matrix.trace_kronecker A B

/-- Trace factorization for products of Kronecker products of `2 × 2` matrices. -/
theorem trace_mul_kronecker_qubit (A₁ B₁ A₂ B₂ : Matrix QubitIndex QubitIndex ℂ) :
    Matrix.trace
        (Matrix.kronecker A₁ B₁ * Matrix.kronecker A₂ B₂) =
      Matrix.trace (A₁ * A₂) * Matrix.trace (B₁ * B₂) := by
  simp only [Matrix.kronecker]
  rw [← Matrix.mul_kronecker_mul, Matrix.trace_kronecker]

/-- Trace normalization of `twoQubitVacuumTrajectory`: `Tr(ρ(t)) = 1` for all `t : ℝ`. -/
theorem twoQubitVacuumTrajectory_trace (t : ℝ) :
    Matrix.trace (twoQubitVacuumTrajectory t) = (1 : ℂ) := by
  unfold twoQubitVacuumTrajectory
  rw [trace_kronecker_qubit, twoQubitLocalTrajectory1_trace, twoQubitLocalTrajectory2_trace,
    mul_one]

/-- Exact formula for the `(0,0),(0,0)` diagonal entry of `twoQubitVacuumTrajectory t`. -/
theorem twoQubitVacuumTrajectory_apply_00 (t : ℝ) :
    twoQubitVacuumTrajectory t ((0 : Fin 2), (0 : Fin 2)) ((0 : Fin 2), (0 : Fin 2)) =
      (((1 - twoQubitX1 t) * (1 - twoQubitX2 t) : ℝ) : ℂ) := by
  simp [twoQubitVacuumTrajectory, twoQubitLocalTrajectory1, twoQubitLocalTrajectory2,
    twoQubitDiagState, Matrix.kronecker]

/-- Exact formula for the `(0,1),(0,1)` diagonal entry of `twoQubitVacuumTrajectory t`. -/
theorem twoQubitVacuumTrajectory_apply_01 (t : ℝ) :
    twoQubitVacuumTrajectory t ((0 : Fin 2), (1 : Fin 2)) ((0 : Fin 2), (1 : Fin 2)) =
      (((1 - twoQubitX1 t) * twoQubitX2 t : ℝ) : ℂ) := by
  simp [twoQubitVacuumTrajectory, twoQubitLocalTrajectory1, twoQubitLocalTrajectory2,
    twoQubitDiagState, Matrix.kronecker]

/-- Exact formula for the `(1,0),(1,0)` diagonal entry of `twoQubitVacuumTrajectory t`. -/
theorem twoQubitVacuumTrajectory_apply_10 (t : ℝ) :
    twoQubitVacuumTrajectory t ((1 : Fin 2), (0 : Fin 2)) ((1 : Fin 2), (0 : Fin 2)) =
      ((twoQubitX1 t * (1 - twoQubitX2 t) : ℝ) : ℂ) := by
  simp [twoQubitVacuumTrajectory, twoQubitLocalTrajectory1, twoQubitLocalTrajectory2,
    twoQubitDiagState, Matrix.kronecker]

/-- Exact formula for the `(1,1),(1,1)` diagonal entry of `twoQubitVacuumTrajectory t`. -/
theorem twoQubitVacuumTrajectory_apply_11 (t : ℝ) :
    twoQubitVacuumTrajectory t ((1 : Fin 2), (1 : Fin 2)) ((1 : Fin 2), (1 : Fin 2)) =
      ((twoQubitX1 t * twoQubitX2 t : ℝ) : ℂ) := by
  simp [twoQubitVacuumTrajectory, twoQubitLocalTrajectory1, twoQubitLocalTrajectory2,
    twoQubitDiagState, Matrix.kronecker]

/-- All off-diagonal entries of `twoQubitDiagState x` vanish. -/
theorem twoQubitDiagState_offDiag_zero (x : ℝ) (i j : QubitIndex) (hij : i ≠ j) :
    twoQubitDiagState x i j = 0 := by
  fin_cases i <;> fin_cases j
  · exact False.elim (hij rfl)
  · simp [twoQubitDiagState]
  · simp [twoQubitDiagState]
  · exact False.elim (hij rfl)

/-- All off-diagonal entries of `twoQubitVacuumTrajectory t` vanish. -/
theorem twoQubitVacuumTrajectory_offDiag_zero (t : ℝ)
    (i j : TwoQubitIndex) (hij : i ≠ j) :
    twoQubitVacuumTrajectory t i j = 0 := by
  rcases i with ⟨i₁, i₂⟩
  rcases j with ⟨j₁, j₂⟩
  by_cases h1 : i₁ = j₁
  · have h2 : i₂ ≠ j₂ := fun h => hij (Prod.ext h1 h)
    simp [twoQubitVacuumTrajectory, Matrix.kronecker, twoQubitLocalTrajectory2,
      twoQubitDiagState_offDiag_zero (twoQubitX2 t) i₂ j₂ h2]
  · simp [twoQubitVacuumTrajectory, Matrix.kronecker, twoQubitLocalTrajectory1,
      twoQubitDiagState_offDiag_zero (twoQubitX1 t) i₁ j₁ h1]

/-- `twoQubitVacuumTrajectory t` is equal to `Matrix.diagonal` of its diagonal entries. -/
theorem twoQubitVacuumTrajectory_eq_diagonal (t : ℝ) :
    twoQubitVacuumTrajectory t =
      Matrix.diagonal (fun i : TwoQubitIndex => twoQubitVacuumTrajectory t i i) := by
  ext i j
  by_cases hij : i = j
  · subst hij
    simp [Matrix.diagonal]
  · rw [twoQubitVacuumTrajectory_offDiag_zero t i j hij, Matrix.diagonal_apply_ne _ hij]

/-- Single-qubit diagonal state `twoQubitDiagState x` is Hermitian (`conjTranspose` self-adjoint). -/
theorem twoQubitDiagState_conjTranspose (x : ℝ) :
    (twoQubitDiagState x).conjTranspose = twoQubitDiagState x := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [twoQubitDiagState, Matrix.conjTranspose]

/-- `twoQubitVacuumTrajectory t` equals its conjugate transpose for all `t : ℝ`. -/
theorem twoQubitVacuumTrajectory_conjTranspose (t : ℝ) :
    (twoQubitVacuumTrajectory t).conjTranspose = twoQubitVacuumTrajectory t := by
  unfold twoQubitVacuumTrajectory
  rw [kronecker_conjTranspose_v419, twoQubitLocalTrajectory1, twoQubitLocalTrajectory2,
    twoQubitDiagState_conjTranspose, twoQubitDiagState_conjTranspose]

/-- `twoQubitVacuumTrajectory t` satisfies `Matrix.IsHermitian` for all `t : ℝ`. -/
theorem twoQubitVacuumTrajectory_isHermitian (t : ℝ) :
    (twoQubitVacuumTrajectory t).IsHermitian :=
  twoQubitVacuumTrajectory_conjTranspose t

/-- Every diagonal entry of `twoQubitVacuumTrajectory t` has zero imaginary part. -/
theorem twoQubitVacuumTrajectory_diag_im_zero (t : ℝ) (i : TwoQubitIndex) :
    (twoQubitVacuumTrajectory t i i).im = 0 := by
  rcases i with ⟨i₁, i₂⟩
  fin_cases i₁ <;> fin_cases i₂ <;>
    simp [twoQubitVacuumTrajectory, Matrix.kronecker,
      twoQubitLocalTrajectory1, twoQubitLocalTrajectory2, twoQubitDiagState]

/-- Every diagonal entry of `twoQubitVacuumTrajectory t` has nonnegative real part for `t ≥ 0`. -/
theorem twoQubitVacuumTrajectory_diag_re_nonneg (t : ℝ) (ht : 0 ≤ t) (i : TwoQubitIndex) :
    0 ≤ (twoQubitVacuumTrajectory t i i).re := by
  have hx1 := twoQubitX1_bounds t ht
  have hx2 := twoQubitX2_bounds t ht
  have h1x1 : 0 ≤ 1 - twoQubitX1 t := by linarith [hx1.2.2]
  have h1x2 : 0 ≤ 1 - twoQubitX2 t := by linarith [hx2.2.2]
  rcases i with ⟨i₁, i₂⟩
  fin_cases i₁ <;> fin_cases i₂
  · change 0 ≤ (twoQubitVacuumTrajectory t ((0 : Fin 2), (0 : Fin 2)) ((0 : Fin 2), (0 : Fin 2))).re
    rw [twoQubitVacuumTrajectory_apply_00, Complex.ofReal_re]
    exact mul_nonneg h1x1 h1x2
  · change 0 ≤ (twoQubitVacuumTrajectory t ((0 : Fin 2), (1 : Fin 2)) ((0 : Fin 2), (1 : Fin 2))).re
    rw [twoQubitVacuumTrajectory_apply_01, Complex.ofReal_re]
    exact mul_nonneg h1x1 hx2.1
  · change 0 ≤ (twoQubitVacuumTrajectory t ((1 : Fin 2), (0 : Fin 2)) ((1 : Fin 2), (0 : Fin 2))).re
    rw [twoQubitVacuumTrajectory_apply_10, Complex.ofReal_re]
    exact mul_nonneg hx1.1 h1x2
  · change 0 ≤ (twoQubitVacuumTrajectory t ((1 : Fin 2), (1 : Fin 2)) ((1 : Fin 2), (1 : Fin 2))).re
    rw [twoQubitVacuumTrajectory_apply_11, Complex.ofReal_re]
    exact mul_nonneg hx1.1 hx2.1

/-- Every diagonal entry of `twoQubitVacuumTrajectory t` is nonnegative in the complex partial order
for `t ≥ 0`. -/
theorem twoQubitVacuumTrajectory_diag_nonneg (t : ℝ) (ht : 0 ≤ t) (i : TwoQubitIndex) :
    (0 : ℂ) ≤ twoQubitVacuumTrajectory t i i := by
  rw [Complex.nonneg_iff]
  exact ⟨twoQubitVacuumTrajectory_diag_re_nonneg t ht i,
    (twoQubitVacuumTrajectory_diag_im_zero t i).symm⟩

/-- `twoQubitVacuumTrajectory t` is positive semidefinite (`Matrix.PosSemidef`) for every `t ≥ 0`. -/
theorem twoQubitVacuumTrajectory_posSemidef (t : ℝ) (ht : 0 ≤ t) :
    (twoQubitVacuumTrajectory t).PosSemidef := by
  rw [twoQubitVacuumTrajectory_eq_diagonal t]
  exact Matrix.posSemidef_diagonal_iff.mpr (twoQubitVacuumTrajectory_diag_nonneg t ht)

/-- For every `t ≥ 0` and vector `v : TwoQubitIndex → ℂ`, the quadratic form
`vᴴ * ρ(t) * v` has nonnegative real part. -/
theorem twoQubitVacuumTrajectory_quadForm_re_nonneg (t : ℝ) (ht : 0 ≤ t)
    (v : TwoQubitIndex → ℂ) :
    0 ≤ RCLike.re (dotProduct (star v) (twoQubitVacuumTrajectory t *ᵥ v)) :=
  (twoQubitVacuumTrajectory_posSemidef t ht).re_dotProduct_nonneg v

/-!
## Kronecker Factorization of the Schrödinger Dissipator and Four-Channel GKSL Generator
-/

/-- Left-embedded Schrödinger dissipator factors through a Kronecker product:
`D_{L ⊗ 1}(A ⊗ B) = D_L(A) ⊗ B`. -/
theorem dissipatorSchrodinger_kronecker_left
    (L A B : Matrix QubitIndex QubitIndex ℂ) :
    dissipatorSchrodinger
        (Matrix.kronecker L (1 : Matrix QubitIndex QubitIndex ℂ))
        (Matrix.kronecker A B) =
      Matrix.kronecker (dissipatorSchrodinger L A) B := by
  have hmL (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker X (1 : Matrix QubitIndex QubitIndex ℂ) *
        Matrix.kronecker Y B =
      Matrix.kronecker (X * Y) B := by
    simpa only [Matrix.one_mul] using
      (Matrix.mul_kronecker_mul X Y (1 : Matrix QubitIndex QubitIndex ℂ) B).symm
  have hmR (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker X B *
        Matrix.kronecker Y (1 : Matrix QubitIndex QubitIndex ℂ) =
      Matrix.kronecker (X * Y) B := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul X Y B (1 : Matrix QubitIndex QubitIndex ℂ)).symm
  have hm1 (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker X (1 : Matrix QubitIndex QubitIndex ℂ) *
        Matrix.kronecker Y (1 : Matrix QubitIndex QubitIndex ℂ) =
      Matrix.kronecker (X * Y) (1 : Matrix QubitIndex QubitIndex ℂ) := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul X Y
        (1 : Matrix QubitIndex QubitIndex ℂ) (1 : Matrix QubitIndex QubitIndex ℂ)).symm
  have hct :
      (Matrix.kronecker L (1 : Matrix QubitIndex QubitIndex ℂ)).conjTranspose =
        Matrix.kronecker L.conjTranspose (1 : Matrix QubitIndex QubitIndex ℂ) := by
    simpa only [Matrix.conjTranspose_one] using
      kronecker_conjTranspose_v419 L (1 : Matrix QubitIndex QubitIndex ℂ)
  unfold dissipatorSchrodinger
  rw [hct, hmL L A, hmR (L * A) L.conjTranspose, hm1 L.conjTranspose L,
    hmL (L.conjTranspose * L) A, hmR A (L.conjTranspose * L)]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply, smul_eq_mul]
  ring

/-- Right-embedded Schrödinger dissipator factors through a Kronecker product:
`D_{1 ⊗ L}(A ⊗ B) = A ⊗ D_L(B)`. -/
theorem dissipatorSchrodinger_kronecker_right
    (L A B : Matrix QubitIndex QubitIndex ℂ) :
    dissipatorSchrodinger
        (Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) L)
        (Matrix.kronecker A B) =
      Matrix.kronecker A (dissipatorSchrodinger L B) := by
  have hmL (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) X *
        Matrix.kronecker A Y =
      Matrix.kronecker A (X * Y) := by
    simpa only [Matrix.one_mul] using
      (Matrix.mul_kronecker_mul (1 : Matrix QubitIndex QubitIndex ℂ) A X Y).symm
  have hmR (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker A X *
        Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) Y =
      Matrix.kronecker A (X * Y) := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul A (1 : Matrix QubitIndex QubitIndex ℂ) X Y).symm
  have hm1 (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) X *
        Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) Y =
      Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) (X * Y) := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul
        (1 : Matrix QubitIndex QubitIndex ℂ) (1 : Matrix QubitIndex QubitIndex ℂ) X Y).symm
  have hct :
      (Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) L).conjTranspose =
        Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) L.conjTranspose := by
    simpa only [Matrix.conjTranspose_one] using
      kronecker_conjTranspose_v419 (1 : Matrix QubitIndex QubitIndex ℂ) L
  unfold dissipatorSchrodinger
  rw [hct, hmL L B, hmR (L * B) L.conjTranspose, hm1 L.conjTranspose L,
    hmL (L.conjTranspose * L) B, hmR B (L.conjTranspose * L)]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply, smul_eq_mul]
  ring

/-- Local Schrödinger GKSL generator for qubit 1 with rates `(1/5, 3/7)`. -/
noncomputable def localGKSL1 (A : Matrix QubitIndex QubitIndex ℂ) :
    Matrix QubitIndex QubitIndex ℂ :=
  ((1 : ℂ) / 5) • dissipatorSchrodinger raising A +
    ((3 : ℂ) / 7) • dissipatorSchrodinger lowering A

/-- Local Schrödinger GKSL generator for qubit 2 with rates `(2/9, 4/11)`. -/
noncomputable def localGKSL2 (B : Matrix QubitIndex QubitIndex ℂ) :
    Matrix QubitIndex QubitIndex ℂ :=
  ((2 : ℂ) / 9) • dissipatorSchrodinger raising B +
    ((4 : ℂ) / 11) • dissipatorSchrodinger lowering B

/-- Exact Kronecker splitting of the four-channel two-qubit Schrödinger GKSL generator:
`L(A ⊗ B) = L₁(A) ⊗ B + A ⊗ L₂(B)`. -/
theorem twoQubit_fullGKSLSchrodinger_kronecker
    (A B : Matrix QubitIndex QubitIndex ℂ) :
    fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (Matrix.kronecker A B) =
      Matrix.kronecker (localGKSL1 A) B +
        Matrix.kronecker A (localGKSL2 B) := by
  unfold fullGKSLSchrodinger twoQubitH localGKSL1 localGKSL2
  rw [Fin.sum_univ_four]
  simp only [twoQubitJump, twoQubitRate,
    twoQubitSigma1Plus, twoQubitSigma1Minus, twoQubitSigma2Plus, twoQubitSigma2Minus,
    Matrix.zero_mul, Matrix.mul_zero, sub_self, smul_zero, zero_add,
    dissipatorSchrodinger_kronecker_left,
    dissipatorSchrodinger_kronecker_right]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.add_apply, Matrix.smul_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, smul_eq_mul]
  ring

/-- Explicit `2 × 2` formula for `dissipatorSchrodinger raising (twoQubitDiagState x)`. -/
theorem dissipatorSchrodinger_raising_diagState (x : ℝ) :
    dissipatorSchrodinger raising (twoQubitDiagState x) =
      !![(-((1 - x : ℝ) : ℂ)), 0; 0, ((1 - x : ℝ) : ℂ)] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [dissipatorSchrodinger, raising, twoQubitDiagState,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two,
      Matrix.conjTranspose_apply, Matrix.transpose_apply, Matrix.smul_apply];
     try ring)

/-- Explicit `2 × 2` formula for `dissipatorSchrodinger lowering (twoQubitDiagState x)`. -/
theorem dissipatorSchrodinger_lowering_diagState (x : ℝ) :
    dissipatorSchrodinger lowering (twoQubitDiagState x) =
      !![((x : ℝ) : ℂ), 0; 0, (-((x : ℝ) : ℂ))] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [dissipatorSchrodinger, lowering, twoQubitDiagState,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two,
      Matrix.conjTranspose_apply, Matrix.transpose_apply, Matrix.smul_apply];
     try ring)

/-- Explicit `2 × 2` action of `localGKSL1` on `twoQubitDiagState x`. -/
theorem localGKSL1_diagState (x : ℝ) :
    localGKSL1 (twoQubitDiagState x) =
      !![(-(((1 / 5 : ℝ) - (22 / 35 : ℝ) * x : ℝ) : ℂ)), 0;
         0, (((1 / 5 : ℝ) - (22 / 35 : ℝ) * x : ℝ) : ℂ)] := by
  unfold localGKSL1
  rw [dissipatorSchrodinger_raising_diagState, dissipatorSchrodinger_lowering_diagState]
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [Complex.ofReal_sub, Complex.ofReal_mul, Complex.ofReal_div, Complex.ofReal_ofNat];
     try ring)

/-- Explicit `2 × 2` action of `localGKSL2` on `twoQubitDiagState x`. -/
theorem localGKSL2_diagState (x : ℝ) :
    localGKSL2 (twoQubitDiagState x) =
      !![(-(((2 / 9 : ℝ) - (58 / 99 : ℝ) * x : ℝ) : ℂ)), 0;
         0, (((2 / 9 : ℝ) - (58 / 99 : ℝ) * x : ℝ) : ℂ)] := by
  unfold localGKSL2
  rw [dissipatorSchrodinger_raising_diagState, dissipatorSchrodinger_lowering_diagState]
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [Complex.ofReal_sub, Complex.ofReal_mul, Complex.ofReal_div, Complex.ofReal_ofNat];
     try ring)

/-- Entrywise derivative of `twoQubitDiagState (f t)` given `HasDerivAt f f' t`. -/
theorem twoQubitDiagState_hasDerivAt {f : ℝ → ℝ} {f' t : ℝ}
    (hf : HasDerivAt f f' t) (i j : QubitIndex) :
    HasDerivAt (fun s => twoQubitDiagState (f s) i j)
      ((!![(-((f' : ℝ) : ℂ)), 0; 0, ((f' : ℝ) : ℂ)] :
        Matrix QubitIndex QubitIndex ℂ) i j) t := by
  fin_cases i <;> fin_cases j
  · simp only [twoQubitDiagState, Fin.zero_eta, Matrix.of_apply, Matrix.cons_val_zero]
    have hsub : HasDerivAt (fun s => (1 : ℝ) - f s) (0 - f') t :=
      (hasDerivAt_const t (1 : ℝ)).sub hf
    have hcast : HasDerivAt (fun s => (((1 : ℝ) - f s : ℝ) : ℂ)) (((0 - f' : ℝ) : ℂ)) t :=
      HasDerivAt.ofReal_comp hsub
    simpa only [Complex.ofReal_sub, Complex.ofReal_zero, zero_sub, Complex.ofReal_neg] using hcast
  · simp only [twoQubitDiagState, Matrix.of_apply, Matrix.cons_val_zero,
      Matrix.cons_val_one, Matrix.head_cons]
    exact hasDerivAt_const t (0 : ℂ)
  · simp only [twoQubitDiagState, Matrix.of_apply, Matrix.cons_val_zero,
      Matrix.cons_val_one, Matrix.head_cons]
    exact hasDerivAt_const t (0 : ℂ)
  · simp only [twoQubitDiagState, Matrix.of_apply, Matrix.cons_val_one, Matrix.head_cons]
    exact HasDerivAt.ofReal_comp hf

/-- Entrywise master equation for the local trajectory of qubit 1. -/
theorem twoQubitLocalTrajectory1_hasDerivAt_localGKSL1 (t : ℝ) (i j : QubitIndex) :
    HasDerivAt (fun s => twoQubitLocalTrajectory1 s i j)
      (localGKSL1 (twoQubitLocalTrajectory1 t) i j) t := by
  unfold twoQubitLocalTrajectory1
  rw [localGKSL1_diagState (twoQubitX1 t)]
  exact twoQubitDiagState_hasDerivAt (twoQubitX1_hasDerivAt t) i j

/-- Entrywise master equation for the local trajectory of qubit 2. -/
theorem twoQubitLocalTrajectory2_hasDerivAt_localGKSL2 (t : ℝ) (i j : QubitIndex) :
    HasDerivAt (fun s => twoQubitLocalTrajectory2 s i j)
      (localGKSL2 (twoQubitLocalTrajectory2 t) i j) t := by
  unfold twoQubitLocalTrajectory2
  rw [localGKSL2_diagState (twoQubitX2 t)]
  exact twoQubitDiagState_hasDerivAt (twoQubitX2_hasDerivAt t) i j

/-- Exact nonstationary four-channel GKSL master equation for `twoQubitVacuumTrajectory`:
every matrix entry `(i, j)` of `ρ(t)` is differentiable at every `t : ℝ` and its derivative
equals the `(i, j)` entry of `fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (ρ(t))`. -/
theorem twoQubitVacuumTrajectory_hasDerivAt_GKSL
    (t : ℝ) (i j : TwoQubitIndex) :
    HasDerivAt (fun s => twoQubitVacuumTrajectory s i j)
      (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (twoQubitVacuumTrajectory t) i j) t := by
  rcases i with ⟨i₁, i₂⟩
  rcases j with ⟨j₁, j₂⟩
  have h1 := twoQubitLocalTrajectory1_hasDerivAt_localGKSL1 t i₁ j₁
  have h2 := twoQubitLocalTrajectory2_hasDerivAt_localGKSL2 t i₂ j₂
  have hprod := h1.mul h2
  unfold twoQubitVacuumTrajectory
  rw [twoQubit_fullGKSLSchrodinger_kronecker]
  simpa only [Matrix.add_apply, Matrix.kronecker, Matrix.kroneckerMap_apply] using hprod

/-- Pointwise `deriv` form of the four-channel GKSL master equation for `twoQubitVacuumTrajectory`. -/
theorem twoQubitVacuumTrajectory_deriv_eq_GKSL
    (t : ℝ) (i j : TwoQubitIndex) :
    deriv (fun s => twoQubitVacuumTrajectory s i j) t =
      fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (twoQubitVacuumTrajectory t) i j :=
  (twoQubitVacuumTrajectory_hasDerivAt_GKSL t i j).deriv

/-- Matrix-level `deriv` form of the four-channel GKSL master equation:
`dρ/dt = fullGKSLSchrodinger(H, L, γ, ρ(t))`. -/
theorem twoQubitVacuumTrajectory_matrix_deriv_eq_GKSL (t : ℝ) :
    (fun i j : TwoQubitIndex => deriv (fun s => twoQubitVacuumTrajectory s i j) t) =
      fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (twoQubitVacuumTrajectory t) := by
  ext i j
  exact twoQubitVacuumTrajectory_deriv_eq_GKSL t i j

/-!
## Constructive Instantiation of `CertifiedTwoQubitPath` and Schrödinger–Heisenberg Trace Duality
-/

/-- Constructive instantiation of `CertifiedTwoQubitPath` by `twoQubitVacuumTrajectory`.
This discharges the trajectory existence hypothesis in `ConcreteTwoQubitDynamics` and
`MaximalTwoQubitConsequencesCandidate`. -/
noncomputable def twoQubitExplicitCertifiedPath : CertifiedTwoQubitPath where
  rho := twoQubitVacuumTrajectory
  initial := twoQubitVacuumTrajectory_zero
  dynamics := fun s _ i j => twoQubitVacuumTrajectory_hasDerivAt_GKSL s i j

/-- Exact generator-level Schrödinger–Heisenberg trace duality along `twoQubitVacuumTrajectory`. -/
theorem twoQubitVacuumTrajectory_trace_duality
    (Q : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) :
    Matrix.trace
        (Q * fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
          (twoQubitVacuumTrajectory t)) =
      Matrix.trace
        (heisenbergGenerator twoQubitH twoQubitJump twoQubitRate Q *
          twoQubitVacuumTrajectory t) :=
  trace_fullGKSL_duality twoQubitH twoQubitJump twoQubitRate Q (twoQubitVacuumTrajectory t)

/-- Time-derivative of any observable expectation `Tr(Q * ρ(t))` in the Schrödinger picture. -/
theorem twoQubitVacuumTrajectory_observable_trace_hasDerivAt_schrodinger
    (Q : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) :
    HasDerivAt (fun s => Matrix.trace (Q * twoQubitVacuumTrajectory s))
      (Matrix.trace
        (Q * fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
          (twoQubitVacuumTrajectory t))) t :=
  trace_mul_hasDerivAt_of_entries Q twoQubitVacuumTrajectory
    (fun s => fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
      (twoQubitVacuumTrajectory s))
    t (twoQubitVacuumTrajectory_hasDerivAt_GKSL t)

/-- Time-derivative of any observable expectation `Tr(Q * ρ(t))` in the Heisenberg picture
(dynamical Schrödinger–Heisenberg trace duality). -/
theorem twoQubitVacuumTrajectory_observable_trace_hasDerivAt_heisenberg
    (Q : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) :
    HasDerivAt (fun s => Matrix.trace (Q * twoQubitVacuumTrajectory s))
      (Matrix.trace
        (heisenbergGenerator twoQubitH twoQubitJump twoQubitRate Q *
          twoQubitVacuumTrajectory t)) t :=
  fullGKSL_expectation_hasDerivAt twoQubitH twoQubitJump twoQubitRate Q
    twoQubitVacuumTrajectory t (twoQubitVacuumTrajectory_hasDerivAt_GKSL t)

/-- Unconditional specialization of the `CertifiedTwoQubitPath` marginal and joint theorems
to the constructed `twoQubitExplicitCertifiedPath` for `t ≥ 0`. -/
theorem twoQubitVacuumTrajectory_certified_consequences (t : ℝ) (ht : 0 ≤ t) :
    certifiedQ1 twoQubitExplicitCertifiedPath t = twoQubitX1 t ∧
    certifiedQ2 twoQubitExplicitCertifiedPath t = twoQubitX2 t ∧
    certifiedJoint twoQubitExplicitCertifiedPath t = twoQubitX1 t * twoQubitX2 t ∧
    certifiedJoint twoQubitExplicitCertifiedPath t < (1 : ℝ) / 8 := by
  refine ⟨?_, ?_, ?_, certified_joint_below_eighth twoQubitExplicitCertifiedPath t ht⟩
  · rw [certified_q1_exact twoQubitExplicitCertifiedPath t ht,
        twoQubitX1_eq_constantRatePopulation]
  · rw [certified_q2_exact twoQubitExplicitCertifiedPath t ht,
        twoQubitX2_eq_constantRatePopulation]
  · rw [certified_joint_exact twoQubitExplicitCertifiedPath t ht,
        twoQubitX1_eq_constantRatePopulation, twoQubitX2_eq_constantRatePopulation]

/-!
## Exact Marginal and Joint-Event Expectations and Bounds
-/

/-- Local occupation expectation on `twoQubitDiagState x` is `(x : ℂ)`. -/
theorem trace_occupation_mul_diagState (x : ℝ) :
    Matrix.trace (occupation * twoQubitDiagState x) = (x : ℂ) := by
  simp [occupation, twoQubitDiagState, Matrix.trace, Matrix.diag,
    Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]

/-- Exact marginal expectation of qubit 1 along `twoQubitVacuumTrajectory`:
`Tr(twoQubitN1 * ρ(t)) = x₁(t)`. -/
theorem twoQubitVacuumTrajectory_trace_n1 (t : ℝ) :
    Matrix.trace (twoQubitN1 * twoQubitVacuumTrajectory t) = (twoQubitX1 t : ℂ) := by
  unfold twoQubitN1 twoQubitVacuumTrajectory
  rw [trace_mul_kronecker_qubit, Matrix.one_mul, twoQubitLocalTrajectory2_trace,
    mul_one, twoQubitLocalTrajectory1, trace_occupation_mul_diagState]

/-- Exact marginal expectation of qubit 2 along `twoQubitVacuumTrajectory`:
`Tr(twoQubitN2 * ρ(t)) = x₂(t)`. -/
theorem twoQubitVacuumTrajectory_trace_n2 (t : ℝ) :
    Matrix.trace (twoQubitN2 * twoQubitVacuumTrajectory t) = (twoQubitX2 t : ℂ) := by
  unfold twoQubitN2 twoQubitVacuumTrajectory
  rw [trace_mul_kronecker_qubit, Matrix.one_mul, twoQubitLocalTrajectory1_trace,
    one_mul, twoQubitLocalTrajectory2, trace_occupation_mul_diagState]

/-- Exact joint-event expectation along `twoQubitVacuumTrajectory`:
`Tr(twoQubitQ12 * ρ(t)) = x₁(t) * x₂(t)`. -/
theorem twoQubitVacuumTrajectory_trace_jointEvent (t : ℝ) :
    Matrix.trace (twoQubitQ12 * twoQubitVacuumTrajectory t) =
      ((twoQubitX1 t * twoQubitX2 t : ℝ) : ℂ) := by
  rw [twoQubit_q12_eq_kronecker, twoQubitVacuumTrajectory, trace_mul_kronecker_qubit,
    twoQubitLocalTrajectory1, twoQubitLocalTrajectory2,
    trace_occupation_mul_diagState, trace_occupation_mul_diagState]
  simp only [Complex.ofReal_mul]

/-- Real part of the joint-event expectation equals `x₁(t) * x₂(t)`. -/
theorem twoQubitVacuumTrajectory_jointEvent_re (t : ℝ) :
    (Matrix.trace (twoQubitQ12 * twoQubitVacuumTrajectory t)).re =
      twoQubitX1 t * twoQubitX2 t := by
  rw [twoQubitVacuumTrajectory_trace_jointEvent, Complex.ofReal_re]

/-- Imaginary part of the joint-event expectation vanishes for all `t : ℝ`. -/
theorem twoQubitVacuumTrajectory_jointEvent_im (t : ℝ) :
    (Matrix.trace (twoQubitQ12 * twoQubitVacuumTrajectory t)).im = 0 := by
  rw [twoQubitVacuumTrajectory_trace_jointEvent, Complex.ofReal_im]

/-- All-time nonstationary joint-event inequality along `twoQubitVacuumTrajectory` for `t ≥ 0`:
`0 ≤ Re Tr(twoQubitQ12 * ρ(t)) ≤ 7/58 < 1/8 < 1/4`. -/
theorem twoQubitVacuumTrajectory_jointEvent_bounds (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ (Matrix.trace (twoQubitQ12 * twoQubitVacuumTrajectory t)).re ∧
    (Matrix.trace (twoQubitQ12 * twoQubitVacuumTrajectory t)).re ≤ 7 / 58 ∧
    (7 / 58 : ℝ) < 1 / 8 ∧
    (1 / 8 : ℝ) < 1 / 4 := by
  rw [twoQubitVacuumTrajectory_jointEvent_re]
  have hx1 := twoQubitX1_bounds t ht
  have hx2 := twoQubitX2_bounds t ht
  have hle : twoQubitX1 t * twoQubitX2 t ≤ 7 / 58 := by
    rw [twoQubitX1_eq_constantRatePopulation, twoQubitX2_eq_constantRatePopulation]
    exact sampleTwoSite_allTime t ht
  exact ⟨mul_nonneg hx1.1 hx2.1, hle, by norm_num, by norm_num⟩

/-!
## Asymptotic Convergence `ρ(t) → twoQubitEquilibrium` as `t → +∞`
-/

/-- As `t → +∞`, `x₁(t) → 7/22`. -/
theorem twoQubitX1_tendsto_atTop :
    Filter.Tendsto twoQubitX1 Filter.atTop (nhds (7 / 22 : ℝ)) := by
  have hexp :
      Filter.Tendsto (fun t : ℝ => Real.exp (-(22 / 35 : ℝ) * t)) Filter.atTop (nhds 0) :=
    Real.tendsto_exp_atBot.comp
      (Filter.tendsto_id.const_mul_atTop_of_neg (by norm_num : (-(22 / 35 : ℝ)) < 0))
  have h1 :
      Filter.Tendsto (fun t : ℝ => (7 / 22 : ℝ) * (1 - Real.exp (-(22 / 35 : ℝ) * t)))
        Filter.atTop (nhds ((7 / 22 : ℝ) * (1 - 0))) :=
    (tendsto_const_nhds.sub hexp).const_mul (7 / 22 : ℝ)
  simpa only [sub_zero, mul_one] using h1

/-- As `t → +∞`, `x₂(t) → 11/29`. -/
theorem twoQubitX2_tendsto_atTop :
    Filter.Tendsto twoQubitX2 Filter.atTop (nhds (11 / 29 : ℝ)) := by
  have hexp :
      Filter.Tendsto (fun t : ℝ => Real.exp (-(58 / 99 : ℝ) * t)) Filter.atTop (nhds 0) :=
    Real.tendsto_exp_atBot.comp
      (Filter.tendsto_id.const_mul_atTop_of_neg (by norm_num : (-(58 / 99 : ℝ)) < 0))
  have h2 :
      Filter.Tendsto (fun t : ℝ => (11 / 29 : ℝ) * (1 - Real.exp (-(58 / 99 : ℝ) * t)))
        Filter.atTop (nhds ((11 / 29 : ℝ) * (1 - 0))) :=
    (tendsto_const_nhds.sub hexp).const_mul (11 / 29 : ℝ)
  simpa only [sub_zero, mul_one] using h2

/-- Entrywise convergence of the local trajectory of qubit 1 to `twoQubitEqLocal1` as `t → +∞`. -/
theorem twoQubitLocalTrajectory1_tendsto (i j : QubitIndex) :
    Filter.Tendsto (fun t : ℝ => twoQubitLocalTrajectory1 t i j)
      Filter.atTop (nhds (twoQubitEqLocal1 i j)) := by
  fin_cases i <;> fin_cases j
  · simp only [twoQubitLocalTrajectory1, twoQubitDiagState, twoQubitEqLocal1,
      Matrix.of_apply, Matrix.cons_val_zero]
    have hsub : Filter.Tendsto (fun t : ℝ => (1 : ℝ) - twoQubitX1 t)
        Filter.atTop (nhds ((1 : ℝ) - (7 / 22 : ℝ))) :=
      tendsto_const_nhds.sub twoQubitX1_tendsto_atTop
    have hcast := (Complex.continuous_ofReal.tendsto ((1 : ℝ) - (7 / 22 : ℝ))).comp hsub
    convert hcast using 2
    norm_num
  · simp only [twoQubitLocalTrajectory1, twoQubitDiagState, twoQubitEqLocal1,
      Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
    exact tendsto_const_nhds
  · simp only [twoQubitLocalTrajectory1, twoQubitDiagState, twoQubitEqLocal1,
      Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
    exact tendsto_const_nhds
  · simp only [twoQubitLocalTrajectory1, twoQubitDiagState, twoQubitEqLocal1,
      Matrix.of_apply, Matrix.cons_val_one, Matrix.head_cons]
    have hcast := (Complex.continuous_ofReal.tendsto (7 / 22 : ℝ)).comp twoQubitX1_tendsto_atTop
    convert hcast using 2
    norm_num

/-- Entrywise convergence of the local trajectory of qubit 2 to `twoQubitEqLocal2` as `t → +∞`. -/
theorem twoQubitLocalTrajectory2_tendsto (i j : QubitIndex) :
    Filter.Tendsto (fun t : ℝ => twoQubitLocalTrajectory2 t i j)
      Filter.atTop (nhds (twoQubitEqLocal2 i j)) := by
  fin_cases i <;> fin_cases j
  · simp only [twoQubitLocalTrajectory2, twoQubitDiagState, twoQubitEqLocal2,
      Matrix.of_apply, Matrix.cons_val_zero]
    have hsub : Filter.Tendsto (fun t : ℝ => (1 : ℝ) - twoQubitX2 t)
        Filter.atTop (nhds ((1 : ℝ) - (11 / 29 : ℝ))) :=
      tendsto_const_nhds.sub twoQubitX2_tendsto_atTop
    have hcast := (Complex.continuous_ofReal.tendsto ((1 : ℝ) - (11 / 29 : ℝ))).comp hsub
    convert hcast using 2
    norm_num
  · simp only [twoQubitLocalTrajectory2, twoQubitDiagState, twoQubitEqLocal2,
      Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
    exact tendsto_const_nhds
  · simp only [twoQubitLocalTrajectory2, twoQubitDiagState, twoQubitEqLocal2,
      Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
    exact tendsto_const_nhds
  · simp only [twoQubitLocalTrajectory2, twoQubitDiagState, twoQubitEqLocal2,
      Matrix.of_apply, Matrix.cons_val_one, Matrix.head_cons]
    have hcast := (Complex.continuous_ofReal.tendsto (11 / 29 : ℝ)).comp twoQubitX2_tendsto_atTop
    convert hcast using 2
    norm_num

/-- Entrywise convergence of `twoQubitVacuumTrajectory t` to `twoQubitEquilibrium` as `t → +∞`. -/
theorem twoQubitVacuumTrajectory_tendsto_equilibrium (i j : TwoQubitIndex) :
    Filter.Tendsto (fun t : ℝ => twoQubitVacuumTrajectory t i j)
      Filter.atTop (nhds (twoQubitEquilibrium i j)) := by
  rcases i with ⟨i₁, i₂⟩
  rcases j with ⟨j₁, j₂⟩
  unfold twoQubitVacuumTrajectory twoQubitEquilibrium
  simp only [Matrix.kronecker, Matrix.kroneckerMap_apply]
  exact (twoQubitLocalTrajectory1_tendsto i₁ j₁).mul (twoQubitLocalTrajectory2_tendsto i₂ j₂)

/-- Convergence of the joint-event expectation `Re Tr(twoQubitQ12 * ρ(t)) → 7/58` as `t → +∞`. -/
theorem twoQubitVacuumTrajectory_jointEvent_tendsto :
    Filter.Tendsto
      (fun t : ℝ => (Matrix.trace (twoQubitQ12 * twoQubitVacuumTrajectory t)).re)
      Filter.atTop (nhds (7 / 58 : ℝ)) := by
  simp_rw [twoQubitVacuumTrajectory_jointEvent_re]
  have hmul := twoQubitX1_tendsto_atTop.mul twoQubitX2_tendsto_atTop
  convert hmul using 2
  norm_num

end BinduEventInterface
