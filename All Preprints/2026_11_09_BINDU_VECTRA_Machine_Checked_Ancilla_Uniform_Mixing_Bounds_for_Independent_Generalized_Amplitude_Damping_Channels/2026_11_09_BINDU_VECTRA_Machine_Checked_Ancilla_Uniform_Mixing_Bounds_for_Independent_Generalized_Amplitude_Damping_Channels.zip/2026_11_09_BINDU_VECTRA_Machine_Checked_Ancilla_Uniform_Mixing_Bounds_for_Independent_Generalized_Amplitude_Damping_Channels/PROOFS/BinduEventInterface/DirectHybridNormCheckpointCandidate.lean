import BinduEventInterface.DirectHybridOffsiteFactorizationCandidate
import BinduEventInterface.BinduWeightedNormCoreCandidate

/-!
Formal reduction of the unconditional global r+r² theorem to the exact
site-local matrix identity. This file intentionally DOES NOT claim hsite proven.
The offsite factorization and contraction were already compiled on the Mac.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

noncomputable def binduPhysicalDifferenceKernel {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N) :
    Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ :=
  fun u p v q =>
    localKrausKernel (localKraus (G k) (K k) t) u p v q -
    localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q

/-- Definitional abbreviation only: does not change the original target. -/
noncomputable def binduSiteRplusR2
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ :=
  (((localDampingR (G k) (K k) t *
     (1 - localDampingR (G k) (K k) t) : ℝ) : ℂ) •
      (Y - siteDephasingChannel k Y)) +
    (((localDampingR (G k) (K k) t ^ 2 : ℝ) : ℂ) •
      (Y - ancillaRightChannel (siteReplacerKraus G K k) Y))

/-- CONDITIONAL norm consequence: the precise missing hsite is explicit. -/
theorem bindu_site_kernel_rplusr2_of_decomposition
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (ht : 0 ≤ t) (k : Fin N)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ)
    (hsite :
      binduSiteKernelAction k (binduPhysicalDifferenceKernel G K t k) Y =
      binduSiteRplusR2 G K t k Y) :
    schattenOneSpectralNorm
      (binduSiteKernelAction k (binduPhysicalDifferenceKernel G K t k) Y) ≤
    (localDampingR (G k) (K k) t +
     (localDampingR (G k) (K k) t) ^ 2) * schattenOneSpectralNorm Y := by
  have hr := localDampingR_bounds (G k) (K k) t (hG k) (hK k) ht
  have hD := siteOffdiagonal_stabilized_le k Y
  have hR := siteReplacerDifference_stabilized_le G K k hG hK Y
  rw [hsite]
  unfold binduSiteRplusR2
  exact bindu_weighted_norm_two_term
    (localDampingR (G k) (K k) t) hr.1 hr.2
    (Y - siteDephasingChannel k Y)
    (Y - ancillaRightChannel (siteReplacerKraus G K k) Y)
    (schattenOneSpectralNorm Y) hD hR

/-- CONDITIONAL global result; hsite must be separately proved to close it. -/
theorem bindu_global_hybrid_rplusr2_of_site_identity
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (ht : 0 ≤ t) (k : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ)
    (hsite : ∀ Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ,
      binduSiteKernelAction k (binduPhysicalDifferenceKernel G K t k) Y =
      binduSiteRplusR2 G K t k Y) :
    schattenOneSpectralNorm
      (ancillaRightChannel (hybridNQubitKraus G K t (k.val + 1)) X -
       ancillaRightChannel (hybridNQubitKraus G K t k.val) X) ≤
    (localDampingR (G k) (K k) t +
     (localDampingR (G k) (K k) t) ^ 2) * schattenOneSpectralNorm X := by
  let Y := ancillaRightChannel (offsiteKraus G K t k) X
  have hfactor := physicalHybridStep_eq_localKernel_after_offsite G K t k X
  have hlocal := bindu_site_kernel_rplusr2_of_decomposition
    G K hG hK t ht k Y (hsite Y)
  have hpre := offsiteChannel_contracts G K t k hG hK ht X
  have hr := localDampingR_bounds (G k) (K k) t (hG k) (hK k) ht
  have hc : 0 ≤ localDampingR (G k) (K k) t +
      (localDampingR (G k) (K k) t) ^ 2 :=
    add_nonneg hr.1 (sq_nonneg _)
  have hstep :
      schattenOneSpectralNorm
        (ancillaRightChannel (hybridNQubitKraus G K t (k.val + 1)) X -
         ancillaRightChannel (hybridNQubitKraus G K t k.val) X) ≤
      (localDampingR (G k) (K k) t +
        (localDampingR (G k) (K k) t) ^ 2) * schattenOneSpectralNorm Y := by
    rw [hfactor]
    exact hlocal
  exact hstep.trans (mul_le_mul_of_nonneg_left hpre hc)

end BinduEventInterface

#print axioms BinduEventInterface.bindu_site_kernel_rplusr2_of_decomposition
#print axioms BinduEventInterface.bindu_global_hybrid_rplusr2_of_site_identity
