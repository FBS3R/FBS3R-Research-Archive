import BinduEventInterface.NQubitDiamondDirectTelescopingCandidate

/-!
BINDU–VECTRA: algebraic kernel of the full 4^N Kraus superoperator.

This candidate does NOT use the false construction (K_j-L_j) X (K_j-L_j)ᴴ.
Instead, the four-index kernel of a Kraus channel is
  sum_j K_j(u,p) * conj(K_j(v,q)).

The full multi-index sum factorizes into the product of local four-index
kernels. The difference of neighboring hybrid kernels differs at precisely
one site. This is the exact algebraic step towards a channel identity.

Target Lean: 4.19.0, pinned Mathlib. No local Lean installation is available
in the authoring runtime; compile independently before treating as verified.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- Four-index transfer kernel for an arbitrary single-site Kraus family. -/
noncomputable def localKrausKernel
    (L : Fin 4 → Matrix (Fin 2) (Fin 2) ℂ)
    (u p v q : Fin 2) : ℂ :=
  ∑ j : Fin 4, L j u p * star (L j v q)

/-- Entrywise kernel of the N-fold product Kraus family, by full summation. -/
noncomputable def fullKrausKernel {N : ℕ}
    (L : Fin N → Fin 4 → Matrix (Fin 2) (Fin 2) ℂ)
    (u p v q : NQubitIndex N) : ℂ :=
  ∑ α : NQubitModeIndex N,
    (nQubitTensorProduct (fun m => L m (α m))) u p *
      star ((nQubitTensorProduct (fun m => L m (α m))) v q)

/-- The product of the four-index local kernels. -/
noncomputable def productKrausKernel {N : ℕ}
    (L : Fin N → Fin 4 → Matrix (Fin 2) (Fin 2) ℂ)
    (u p v q : NQubitIndex N) : ℂ :=
  ∏ m : Fin N, localKrausKernel (L m) (u m) (p m) (v m) (q m)

/-- Exact factorization of all 4^N Kraus-index contributions.
Crucially the objects summed are kernel coefficients, NOT Kraus-operator differences. -/
theorem fullKrausKernel_eq_productKrausKernel {N : ℕ}
    (L : Fin N → Fin 4 → Matrix (Fin 2) (Fin 2) ℂ)
    (u p v q : NQubitIndex N) :
    fullKrausKernel L u p v q = productKrausKernel L u p v q := by
  classical
  unfold fullKrausKernel productKrausKernel localKrausKernel
  -- Complex conjugation commutes with finite products (the missing rewrite).
  -- Then distribute multiplication of two products pointwise before prod_sum.
  simp only [nQubitTensorProduct_apply, star_prod, ← Finset.prod_mul_distrib]
  exact (Fintype.prod_sum
    (fun m j => L m j (u m) (p m) * star (L m j (v m) (q m)))).symm

/-- Replacing exactly one factor and subtracting factors out. -/
theorem product_replace_one_sub {N : ℕ}
    (k : Fin N) (F : Fin N → ℂ) (P Q : ℂ) :
    (∏ m : Fin N, if m = k then P else F m) -
      (∏ m : Fin N, if m = k then Q else F m) =
    (P - Q) * (∏ m ∈ Finset.univ.erase k, F m) := by
  classical
  have split (x : ℂ) :
      (∏ m : Fin N, if m = k then x else F m) =
        (∏ m ∈ Finset.univ.erase k, F m) * x := by
    rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ k)]
    simp only [if_pos rfl]
    congr 1
    refine Finset.prod_congr rfl (fun m hm => ?_)
    rw [if_neg (Finset.ne_of_mem_erase hm)]
  rw [split P, split Q]
  ring

/-- On the chosen site, the kth hybrid uses the stationary channel. -/
theorem localKrausKernel_hybrid_before {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (u p v q : Fin 2) :
    localKrausKernel (hybridLocalKraus G K t k.val k) u p v q =
      localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q := by
  unfold hybridLocalKraus
  simp [Nat.lt_irrefl]

/-- On the chosen site, the (k+1)st hybrid uses the physical channel. -/
theorem localKrausKernel_hybrid_after {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (u p v q : Fin 2) :
    localKrausKernel (hybridLocalKraus G K t (k.val + 1) k) u p v q =
      localKrausKernel (localKraus (G k) (K k) t) u p v q := by
  unfold hybridLocalKraus
  simp [Nat.lt_succ_self]

/-- At every site other than k the local channels do not change. -/
theorem localKrausKernel_hybrid_offsite {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k m : Fin N)
    (hm : m ≠ k) (u p v q : Fin 2) :
    localKrausKernel (hybridLocalKraus G K t (k.val + 1) m) u p v q =
      localKrausKernel (hybridLocalKraus G K t k.val m) u p v q := by
  have hne : m.val ≠ k.val := by
    intro h
    exact hm (Fin.ext h)
  unfold hybridLocalKraus
  by_cases hlt : m.val < k.val
  · have hnext : m.val < k.val + 1 := by omega
    simp [hlt, hnext]
  · have hnext : ¬m.val < k.val + 1 := by omega
    simp [hlt, hnext]

/-- Full 4^N Kraus kernel difference of adjacent hybrid channels.
This is an unconditional, coefficientwise superoperator factorization. -/
theorem fullKrausKernel_hybrid_step {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (u p v q : NQubitIndex N) :
    fullKrausKernel (hybridLocalKraus G K t (k.val + 1)) u p v q -
      fullKrausKernel (hybridLocalKraus G K t k.val) u p v q =
    (localKrausKernel (localKraus (G k) (K k) t)
        (u k) (p k) (v k) (q k) -
      localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0)
        (u k) (p k) (v k) (q k)) *
      (∏ m ∈ Finset.univ.erase k,
        localKrausKernel (hybridLocalKraus G K t k.val m)
          (u m) (p m) (v m) (q m)) := by
  classical
  rw [fullKrausKernel_eq_productKrausKernel,
      fullKrausKernel_eq_productKrausKernel]
  unfold productKrausKernel
  let F : Fin N → ℂ := fun m =>
    localKrausKernel (hybridLocalKraus G K t k.val m)
      (u m) (p m) (v m) (q m)
  let P : ℂ := localKrausKernel (localKraus (G k) (K k) t)
      (u k) (p k) (v k) (q k)
  let Q : ℂ := localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0)
      (u k) (p k) (v k) (q k)
  have hplus :
      (∏ m : Fin N,
        localKrausKernel (hybridLocalKraus G K t (k.val + 1) m)
          (u m) (p m) (v m) (q m)) =
      ∏ m : Fin N, if m = k then P else F m := by
    refine Finset.prod_congr rfl (fun m _ => ?_)
    by_cases hm : m = k
    · subst m
      simp only [if_pos rfl]
      exact localKrausKernel_hybrid_after G K t k (u k) (p k) (v k) (q k)
    · rw [if_neg hm]
      exact localKrausKernel_hybrid_offsite G K t k m hm
        (u m) (p m) (v m) (q m)
  have hminus :
      (∏ m : Fin N,
        localKrausKernel (hybridLocalKraus G K t k.val m)
          (u m) (p m) (v m) (q m)) =
      ∏ m : Fin N, if m = k then Q else F m := by
    refine Finset.prod_congr rfl (fun m _ => ?_)
    by_cases hm : m = k
    · subst m
      simp only [if_pos rfl]
      exact localKrausKernel_hybrid_before G K t k (u k) (p k) (v k) (q k)
    · rw [if_neg hm]
  rw [hplus, hminus]
  exact product_replace_one_sub k F P Q

end BinduEventInterface

#print axioms BinduEventInterface.fullKrausKernel_eq_productKrausKernel
#print axioms BinduEventInterface.product_replace_one_sub
#print axioms BinduEventInterface.fullKrausKernel_hybrid_step
