import BinduEventInterface.BinduSiteKernelAlgebraCandidate

/-!
# Elementary site-action identities on the original N-qubit index

Proof candidate: these are new declarations, not claimed kernel-verified.
All changes are additive. No `sorry`, `admit`, or extra axioms.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- Pointwise delta factors on a finite bit-string collapse to its indicator. -/
theorem bindu_indicator_prod {N : ℕ} (u p : NQubitIndex N) :
    (∏ m : Fin N, if u m = p m then (1 : ℂ) else 0) =
      if u = p then 1 else 0 := by
  classical
  by_cases h : u = p
  · subst p
    simp
  · have hdiff : ∃ m : Fin N, u m ≠ p m := by
      by_contra hh
      push_neg at hh
      exact h (funext hh)
    obtain ⟨m, hm⟩ := hdiff
    rw [if_neg h]
    exact Finset.prod_eq_zero (Finset.mem_univ m) (by simp [hm])

/-- A product of local four-index identity kernels is the global identity kernel. -/
theorem bindu_global_delta_product {N : ℕ}
    (u p v q : NQubitIndex N) :
    (∏ m : Fin N, binduDeltaKernel (u m) (p m) (v m) (q m)) =
      (if u = p then (1 : ℂ) else 0) *
        (if v = q then (1 : ℂ) else 0) := by
  simp only [binduDeltaKernel, Finset.prod_mul_distrib]
  rw [bindu_indicator_prod u p, bindu_indicator_prod v q]

/-- The delta kernel is exactly the identity operator on any global matrix. -/
theorem bindu_site_delta_action_eq {N : ℕ} {a : Type*} [Fintype a]
    (k : Fin N)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k binduDeltaKernel Y = Y := by
  classical
  ext ⟨u, i⟩ ⟨v, j⟩
  simp only [binduSiteKernelAction, Matrix.of_apply, ite_self]
  simp_rw [bindu_global_delta_product]
  simp

/-- The arbitrary-site action is complex-linear in its unique local kernel. -/
theorem bindu_site_kernel_two_term {N : ℕ} {a : Type*} [Fintype a]
    (k : Fin N)
    (P Q : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (c d : ℂ)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k
        (fun u p v q => c * P u p v q + d * Q u p v q) Y =
      c • binduSiteKernelAction k P Y +
        d • binduSiteKernelAction k Q Y := by
  classical
  ext ⟨u, i⟩ ⟨v, j⟩
  simp only [binduSiteKernelAction, Matrix.of_apply, Matrix.add_apply,
    Matrix.smul_apply, smul_eq_mul]
  simp_rw [bindu_site_product_two_term k P Q c d]
  simp only [add_mul, Finset.sum_add_distrib, mul_assoc,
    ← Finset.mul_sum]

/-- A local-kernel difference acts as the difference of its two site actions. -/
theorem bindu_site_kernel_sub {N : ℕ} {a : Type*} [Fintype a]
    (k : Fin N)
    (P Q : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k (fun u p v q => P u p v q - Q u p v q) Y =
      binduSiteKernelAction k P Y - binduSiteKernelAction k Q Y := by
  calc
    binduSiteKernelAction k (fun u p v q => P u p v q - Q u p v q) Y =
        binduSiteKernelAction k
          (fun u p v q => (1 : ℂ) * P u p v q + (-1 : ℂ) * Q u p v q) Y := by
            apply bindu_site_action_congr
            intro u p v q
            ring
    _ = (1 : ℂ) • binduSiteKernelAction k P Y +
          (-1 : ℂ) • binduSiteKernelAction k Q Y :=
      bindu_site_kernel_two_term k P Q 1 (-1) Y
    _ = binduSiteKernelAction k P Y - binduSiteKernelAction k Q Y := by
      simp [sub_eq_add_neg]

end BinduEventInterface

#print axioms BinduEventInterface.bindu_indicator_prod
#print axioms BinduEventInterface.bindu_global_delta_product
#print axioms BinduEventInterface.bindu_site_delta_action_eq
#print axioms BinduEventInterface.bindu_site_kernel_two_term
#print axioms BinduEventInterface.bindu_site_kernel_sub
