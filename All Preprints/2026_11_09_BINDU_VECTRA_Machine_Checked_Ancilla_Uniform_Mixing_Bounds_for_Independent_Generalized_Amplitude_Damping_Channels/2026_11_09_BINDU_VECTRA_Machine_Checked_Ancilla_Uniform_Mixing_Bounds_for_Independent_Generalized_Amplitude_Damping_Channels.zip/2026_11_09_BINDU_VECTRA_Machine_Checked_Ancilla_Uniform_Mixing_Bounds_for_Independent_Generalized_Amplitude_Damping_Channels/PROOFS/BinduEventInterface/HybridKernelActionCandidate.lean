import BinduEventInterface.HybridKrausKernelCandidate
import BinduEventInterface.NQubitDiamondExponentialMixingCandidate

/-!
Exact matrix action associated to the full 4^N Kraus superoperator kernel.
All sums include the arbitrary external ancilla unchanged.

This gives a FULL SUPEROPERATOR identity for the explicitly defined
`fullKernelAction`; the separate bridge to `ancillaRightChannel` must also
be proved and checked before calling the physical N-qubit hstep unconditional.
-/
namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- Full action via the four-index Kraus kernel. The indices p and q range over
ALL 2^N basis states, while `fullKrausKernel` sums over ALL 4^N Kraus modes. -/
noncomputable def fullKernelAction {N : ℕ}
    {a : Type*} [Fintype a]
    (L : Fin N → Fin 4 → Matrix (Fin 2) (Fin 2) ℂ)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ :=
  Matrix.of fun ⟨u, i⟩ ⟨v, j⟩ =>
    ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
      fullKrausKernel L u p v q * X (p, i) (q, j)

/-- Coefficientwise form of the exactly factored difference of consecutive
GLOBAL (4^N-mode) kernel superoperators. -/
theorem fullKernelAction_hybrid_step {N : ℕ}
    {a : Type*} [Fintype a]
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    fullKernelAction (hybridLocalKraus G K t (k.val + 1)) X -
      fullKernelAction (hybridLocalKraus G K t k.val) X =
      Matrix.of (fun ⟨u, i⟩ ⟨v, j⟩ =>
        ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
          ((localKrausKernel (localKraus (G k) (K k) t)
              (u k) (p k) (v k) (q k) -
            localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0)
              (u k) (p k) (v k) (q k)) *
            (∏ m ∈ Finset.univ.erase k,
              localKrausKernel (hybridLocalKraus G K t k.val m)
                (u m) (p m) (v m) (q m))) *
            X (p, i) (q, j)) := by
  classical
  ext ⟨u, i⟩ ⟨v, j⟩
  simp only [Matrix.sub_apply, fullKernelAction, Matrix.of_apply]
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro p _
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro q _
  rw [← sub_mul]
  rw [fullKrausKernel_hybrid_step G K t k u p v q]

end BinduEventInterface

#print axioms BinduEventInterface.fullKernelAction_hybrid_step
