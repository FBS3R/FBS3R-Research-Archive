import BinduEventInterface.FiniteKrausTraceCandidate
import Mathlib.Tactic.FinCases

/-!
# Exact four-term generalized amplitude-damping (GAD) Kraus certificate

All input parameters are REAL; the matrix entries are complex embeddings.
The weight-and-shape version avoids premature square-root manipulations.
It becomes a genuine Kraus family after multiplying each shape by sqrt(weight).
The module is a kernel-verification candidate.
-/

namespace BinduEventInterface

set_option maxHeartbeats 800000

open Matrix

/-- Four Kraus shapes. Parameter `r` denotes exp(-lambda*t/2). -/
noncomputable def gadShape (r : ℝ) : Fin 4 → Matrix (Fin 2) (Fin 2) ℂ
  | 0 => !![(1 : ℂ), 0; 0, (r : ℂ)]
  | 1 => lowering
  | 2 => !![(r : ℂ), 0; 0, (1 : ℂ)]
  | 3 => raising

/-- The shape weights, with `p` the excited-state equilibrium population. -/
noncomputable def gadWeight (p r : ℝ) : Fin 4 → ℝ
  | 0 => 1 - p
  | 1 => (1 - p) * (1 - r ^ 2)
  | 2 => p
  | 3 => p * (1 - r ^ 2)

/-- At physical parameters 0 ≤ p,r ≤ 1 all four weights are nonnegative. -/
theorem gadWeight_nonneg
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (j : Fin 4) : 0 ≤ gadWeight p r j := by
  have hrr : 0 ≤ 1 - r ^ 2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hr.2) (by linarith : 0 ≤ 1 + r)]
  fin_cases j
  · simpa only [gadWeight] using (show 0 ≤ 1 - p by linarith [hp.2])
  · simpa only [gadWeight] using
      (mul_nonneg (show 0 ≤ 1 - p by linarith [hp.2]) hrr)
  · simpa only [gadWeight] using hp.1
  · simpa only [gadWeight] using (mul_nonneg hp.1 hrr)

/-- The four weighted adjoint products sum to the 2×2 identity.
    This is the algebraic basis of trace preservation; the proof must
    be compiled before it can be used as a kernel-certified certificate. -/
theorem gadWeightedCompleteness (p r : ℝ) :
    ∑ j : Fin 4,
      ((gadWeight p r j : ℝ) : ℂ) •
        ((gadShape r j).conjTranspose * gadShape r j) =
      (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Fin.sum_univ_four, gadShape, gadWeight,
      Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply,
      Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply, raising, lowering,
      Complex.conj_ofReal, Complex.ofReal_sub,
      Complex.ofReal_mul, Complex.ofReal_pow] <;>
    ring

/-- Weighted four-term generalized amplitude-damping channel. -/
noncomputable def gadWeightedChannel
    (p r : ℝ) (M : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  ∑ j : Fin 4, (gadWeight p r j : ℂ) •
    (gadShape r j * M * (gadShape r j).conjTranspose)

end BinduEventInterface
