import BinduEventInterface.DensityMatrixTraceBridgeCandidate
import Mathlib.Analysis.Calculus.Deriv.Add

/-!
# Density-matrix trajectory -> observable derivative (candidate)

This is deliberately *not* a postulated ODE for the observable.  The input is
entrywise real-time differentiability of the density matrix and its specified
matrix-valued derivative.  All conclusions are derived by finite sums and the
trace-duality theorem.

No ``sorry``, ``admit`` or additional axioms.  Lean 4.19.0 still needs to
compile and audit this candidate on the user's pinned project.
-/

namespace BinduEventInterface

open Matrix

/-- Differentiate a finite-dimensional expectation directly from derivatives
of the density-matrix entries.  Neither normalization nor positivity is used
in this purely analytic identity. -/
theorem trace_mul_hasDerivAt_of_entries
    {n : Type*} [Fintype n] [DecidableEq n]
    (Q : Matrix n n ℂ) (ρ ρdot : ℝ → Matrix n n ℂ)
    (t : ℝ)
    (hρ : ∀ i j : n, HasDerivAt (fun s : ℝ => ρ s i j) (ρdot t i j) t) :
    HasDerivAt (fun s : ℝ => Matrix.trace (Q * ρ s))
      (Matrix.trace (Q * ρdot t)) t := by
  classical
  have hsum :
      HasDerivAt
        (fun s : ℝ => ∑ i : n, ∑ j : n, Q i j * ρ s j i)
        (∑ i : n, ∑ j : n, Q i j * ρdot t j i) t := by
    apply HasDerivAt.sum
    intro i hi
    apply HasDerivAt.sum
    intro j hj
    exact (hρ j i).const_mul (Q i j)
  simpa only [Matrix.trace, Matrix.diag_apply, Matrix.mul_apply] using hsum

/-- Direct bridge for one concrete GKSL jump: an entrywise Schrödinger
master equation induces a derivative of the Heisenberg observable pairing.
No derivative hypothesis for the observable is assumed. -/
theorem trace_dissipator_hasDerivAt_of_entries
    {n : Type*} [Fintype n] [DecidableEq n]
    (L Q : Matrix n n ℂ) (ρ : ℝ → Matrix n n ℂ)
    (t : ℝ)
    (hρ : ∀ i j : n,
      HasDerivAt (fun s : ℝ => ρ s i j)
        (dissipatorSchrodinger L (ρ t) i j) t) :
    HasDerivAt (fun s : ℝ => Matrix.trace (Q * ρ s))
      (Matrix.trace (dissipatorAdjoint L Q * ρ t)) t := by
  rw [← trace_dissipator_duality L Q (ρ t)]
  exact trace_mul_hasDerivAt_of_entries Q ρ
    (fun s => dissipatorSchrodinger L (ρ s)) t hρ

/-- General finite-dimensional Schrödinger-to-Heisenberg derivative rule.
Here the concrete duality `hdual` must be established for the generator. -/
theorem trace_generator_hasDerivAt_of_entries
    {n : Type*} [Fintype n] [DecidableEq n]
    (Q : Matrix n n ℂ)
    (schrodinger : Matrix n n ℂ → Matrix n n ℂ)
    (heisenberg : Matrix n n ℂ → Matrix n n ℂ)
    (ρ : ℝ → Matrix n n ℂ) (t : ℝ)
    (hρ : ∀ i j : n,
      HasDerivAt (fun s : ℝ => ρ s i j)
        (schrodinger (ρ t) i j) t)
    (hdual : ∀ M : Matrix n n ℂ,
      Matrix.trace (Q * schrodinger M) =
        Matrix.trace (heisenberg Q * M)) :
    HasDerivAt (fun s : ℝ => Matrix.trace (Q * ρ s))
      (Matrix.trace (heisenberg Q * ρ t)) t := by
  rw [← hdual (ρ t)]
  exact trace_mul_hasDerivAt_of_entries Q ρ
    (fun s => schrodinger (ρ s)) t hρ

end BinduEventInterface