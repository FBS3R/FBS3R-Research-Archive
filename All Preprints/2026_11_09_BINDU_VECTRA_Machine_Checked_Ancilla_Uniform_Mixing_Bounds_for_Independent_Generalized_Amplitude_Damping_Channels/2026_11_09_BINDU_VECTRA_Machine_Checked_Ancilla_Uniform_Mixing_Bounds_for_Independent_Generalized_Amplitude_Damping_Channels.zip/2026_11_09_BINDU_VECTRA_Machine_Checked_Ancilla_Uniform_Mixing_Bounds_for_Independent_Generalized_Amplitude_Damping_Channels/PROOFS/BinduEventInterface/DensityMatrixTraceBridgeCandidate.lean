import BinduEventInterface.JointHierarchyBridgeCandidate
import BinduEventInterface.TensorGKSL
import Mathlib.LinearAlgebra.Matrix.Trace

/-!
# Density-matrix / Heisenberg trace pairing: finite-dimensional bridge

The trace-pairing duality below is a purely algebraic identity between
concrete matrices. It does not assume a particular density matrix is positive,
normalized, or differentiable, and does not by itself derive the two-site ODE
hierarchy from a time-dependent GKSL master equation.

This file is a CANDIDATE until independently accepted by the user's
Lean 4.19.0 / pinned Mathlib compiler and inspected with `#print axioms`.
-/

namespace BinduEventInterface

open Matrix

/-- The Schrödinger-picture GKSL dissipator for a single jump matrix. -/
noncomputable def dissipatorSchrodinger
    {n : Type*} [Fintype n] [DecidableEq n]
    (L ρ : Matrix n n ℂ) : Matrix n n ℂ :=
  L * ρ * L.conjTranspose - (1 / 2 : ℂ) •
    (L.conjTranspose * L * ρ + ρ * (L.conjTranspose * L))

/-- The jump term is dual under the finite-dimensional matrix trace. -/
theorem trace_jump_duality
    {n : Type*} [Fintype n] [DecidableEq n]
    (L Q ρ : Matrix n n ℂ) :
    Matrix.trace (Q * (L * ρ * L.conjTranspose)) =
      Matrix.trace ((L.conjTranspose * Q * L) * ρ) := by
  calc
    Matrix.trace (Q * (L * ρ * L.conjTranspose)) =
        Matrix.trace ((Q * L * ρ) * L.conjTranspose) := by
          simp only [mul_assoc]
    _ = Matrix.trace (L.conjTranspose * (Q * L * ρ)) :=
          Matrix.trace_mul_comm _ _
    _ = Matrix.trace ((L.conjTranspose * Q * L) * ρ) := by
          simp only [mul_assoc]

/-- Moving the final factor cyclically through the trace. -/
theorem trace_anticommutator_cycle
    {n : Type*} [Fintype n] [DecidableEq n]
    (A Q ρ : Matrix n n ℂ) :
    Matrix.trace (Q * (ρ * A)) =
      Matrix.trace ((A * Q) * ρ) := by
  calc
    Matrix.trace (Q * (ρ * A)) =
        Matrix.trace ((Q * ρ) * A) := by simp only [mul_assoc]
    _ = Matrix.trace (A * (Q * ρ)) := Matrix.trace_mul_comm _ _
    _ = Matrix.trace ((A * Q) * ρ) := by simp only [mul_assoc]

/-- The concrete Schrödinger and Heisenberg GKSL dissipators are adjoint
under the trace pairing. This discharges a necessary algebraic obligation
for deriving population ODEs from the density-matrix master equation. -/
theorem trace_dissipator_duality
    {n : Type*} [Fintype n] [DecidableEq n]
    (L Q ρ : Matrix n n ℂ) :
    Matrix.trace (Q * dissipatorSchrodinger L ρ) =
      Matrix.trace (dissipatorAdjoint L Q * ρ) := by
  unfold dissipatorSchrodinger dissipatorAdjoint
  simp only [mul_sub, sub_mul, mul_add, add_mul,
    mul_smul_comm, smul_mul_assoc,
    Matrix.trace_sub, Matrix.trace_add, Matrix.trace_smul,
    smul_eq_mul]
  rw [trace_jump_duality]
  simp only [mul_assoc]
  have hcyc₂ :
      Matrix.trace (Q * (ρ * (L.conjTranspose * L))) =
        Matrix.trace (((L.conjTranspose * L) * Q) * ρ) :=
    trace_anticommutator_cycle (L.conjTranspose * L) Q ρ
  rw [hcyc₂]
  simp only [mul_assoc]
  ring

/-- Trace preservation of the single-jump Schrödinger dissipator,
without assuming positivity or normalization of the input matrix. -/
theorem trace_dissipatorSchrodinger_zero
    {n : Type*} [Fintype n] [DecidableEq n]
    (L ρ : Matrix n n ℂ) :
    Matrix.trace (dissipatorSchrodinger L ρ) = 0 := by
  simpa [dissipator_identity] using
    (trace_dissipator_duality L (1 : Matrix n n ℂ) ρ)

#print axioms trace_jump_duality
#print axioms trace_anticommutator_cycle
#print axioms trace_dissipator_duality
#print axioms trace_dissipatorSchrodinger_zero

end BinduEventInterface
