import BinduEventInterface.ConcreteTwoQubitModel
import BinduEventInterface.FullGKSLTraceBridgeCandidate
import BinduEventInterface.JointHierarchyBridgeCandidate
import Mathlib.Analysis.Calculus.MeanValue

/-!
# Density-trajectory certificate for the fixed two-qubit model

The input trajectory is not postulated to satisfy any observable ODE.  Its only
dynamical hypothesis is the entrywise `HasDerivAt` form of the concrete
Schrödinger GKSL equation on nonnegative times.  Trace normalization and the
three real population equations are derived from that hypothesis.

Existence, Hermiticity, positivity, and complete positivity of the trajectory
are outside the formal statement.
-/

namespace BinduEventInterface

open Matrix

/-- Taking the real part of a trace expectation preserves the real-time
derivative supplied by the full finite GKSL bridge. -/
theorem fullGKSL_real_expectation_hasDerivAt
    {n a : Type*} [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ)
    (rate : a → ℂ) (Q : Matrix n n ℂ)
    (ρ : ℝ → Matrix n n ℂ) (t : ℝ)
    (hρ : ∀ i j : n,
      HasDerivAt (fun s : ℝ => ρ s i j)
        (fullGKSLSchrodinger H L rate (ρ t) i j) t) :
    HasDerivAt
      (fun s : ℝ => Complex.re (Matrix.trace (Q * ρ s)))
      (Complex.re
        (Matrix.trace (heisenbergGenerator H L rate Q * ρ t))) t := by
  have h := fullGKSL_expectation_hasDerivAt H L rate Q ρ t hρ
  have hc := Complex.reCLM.hasFDerivAt.comp t h.hasFDerivAt
  convert hc.hasDerivAt using 1
  all_goals simp [Function.comp_def, Complex.reCLM_apply]

/-- A real one-population ODE follows from its affine operator identity and
trace one at the time under consideration. -/
theorem fullGKSL_real_population_hasDerivAt
    {n a : Type*} [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ)
    (rate : a → ℂ) (Q : Matrix n n ℂ)
    (ρ : ℝ → Matrix n n ℂ) (t G K : ℝ)
    (hρ : ∀ i j : n,
      HasDerivAt (fun s : ℝ => ρ s i j)
        (fullGKSLSchrodinger H L rate (ρ t) i j) t)
    (hQ : heisenbergGenerator H L rate Q =
      (G : ℂ) • (1 : Matrix n n ℂ) - ((G + K : ℝ) : ℂ) • Q)
    (htrace : Matrix.trace (ρ t) = 1) :
    HasDerivAt
      (fun s : ℝ => Complex.re (Matrix.trace (Q * ρ s)))
      (G * (1 - Complex.re (Matrix.trace (Q * ρ t))) -
        K * Complex.re (Matrix.trace (Q * ρ t))) t := by
  convert fullGKSL_real_expectation_hasDerivAt
    H L rate Q ρ t hρ using 1
  rw [hQ]
  simp only [sub_mul, Matrix.trace_sub, smul_mul_assoc,
    Matrix.trace_smul, Matrix.one_mul]
  rw [htrace]
  simp only [Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_re,
    Complex.one_re, Complex.sub_re, smul_eq_mul, Complex.mul_re,
    Complex.ofReal_im, Complex.one_im, Complex.add_re, Complex.add_im,
    zero_mul, sub_zero, add_zero]
  ring

/-- The real joint-population hierarchy follows from its triangular operator
identity, without a factorization or positivity assumption. -/
theorem fullGKSL_real_joint_hasDerivAt
    {n a : Type*} [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ)
    (rate : a → ℂ) (Q₁ Q₂ Q₁₂ : Matrix n n ℂ)
    (ρ : ℝ → Matrix n n ℂ) (t G₁ K₁ G₂ K₂ : ℝ)
    (hρ : ∀ i j : n,
      HasDerivAt (fun s : ℝ => ρ s i j)
        (fullGKSLSchrodinger H L rate (ρ t) i j) t)
    (hQ : heisenbergGenerator H L rate Q₁₂ =
      (G₁ : ℂ) • Q₂ + (G₂ : ℂ) • Q₁ -
        ((G₁ + K₁ + G₂ + K₂ : ℝ) : ℂ) • Q₁₂) :
    HasDerivAt
      (fun s : ℝ => Complex.re (Matrix.trace (Q₁₂ * ρ s)))
      (G₁ * Complex.re (Matrix.trace (Q₂ * ρ t)) +
        G₂ * Complex.re (Matrix.trace (Q₁ * ρ t)) -
        (G₁ + K₁ + G₂ + K₂) *
          Complex.re (Matrix.trace (Q₁₂ * ρ t))) t := by
  convert fullGKSL_real_expectation_hasDerivAt
    H L rate Q₁₂ ρ t hρ using 1
  rw [hQ]
  simp only [add_mul, sub_mul, Matrix.trace_add, Matrix.trace_sub,
    smul_mul_assoc, Matrix.trace_smul]
  simp only [Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_re,
    Complex.add_re, Complex.sub_re, smul_eq_mul, Complex.mul_re,
    Complex.ofReal_im, Complex.add_im, zero_mul, sub_zero, add_zero]
  ring

/-- Trace one on the physical half-line follows from the entrywise GKSL
equation and the normalized concrete vacuum at time zero. -/
theorem twoQubit_trace_eq_one_nonneg
    (ρ : ℝ → Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (hρ0 : ρ 0 = twoQubitVacuum)
    (hρ : ∀ s : ℝ, 0 ≤ s → ∀ i j : TwoQubitIndex,
      HasDerivAt (fun u : ℝ => ρ u i j)
        (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
          (ρ s) i j) s)
    (t : ℝ) (ht : 0 ≤ t) :
    Matrix.trace (ρ t) = (1 : ℂ) := by
  have htraceDeriv : ∀ s : ℝ, 0 ≤ s →
      HasDerivAt (fun u : ℝ => Matrix.trace (ρ u)) 0 s := by
    intro s hs
    have h := fullGKSL_expectation_hasDerivAt
      twoQubitH twoQubitJump twoQubitRate
      (1 : Matrix TwoQubitIndex TwoQubitIndex ℂ) ρ s (hρ s hs)
    simpa [generator_identity] using h
  have hcont : ContinuousOn (fun s : ℝ => Matrix.trace (ρ s))
      (Set.Icc (0 : ℝ) t) := by
    intro s hs
    exact (htraceDeriv s hs.1).continuousAt.continuousWithinAt
  have hwithin : ∀ s ∈ Set.Ico (0 : ℝ) t,
      HasDerivWithinAt (fun u : ℝ => Matrix.trace (ρ u)) 0
        (Set.Ici s) s := by
    intro s hs
    exact (htraceDeriv s hs.1).hasDerivWithinAt
  have hconst : Matrix.trace (ρ t) = Matrix.trace (ρ 0) :=
    constant_of_has_deriv_right_zero hcont hwithin t ⟨ht, le_refl t⟩
  calc
    Matrix.trace (ρ t) = Matrix.trace (ρ 0) := hconst
    _ = Matrix.trace twoQubitVacuum := by rw [hρ0]
    _ = (1 : ℂ) := twoQubit_vacuum_trace

/-- The first real marginal equation is derived from the matrix master
equation and trace normalization. -/
theorem twoQubit_q1_hasDerivAt
    (ρ : ℝ → Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (t : ℝ)
    (hρt : ∀ i j : TwoQubitIndex,
      HasDerivAt (fun u : ℝ => ρ u i j)
        (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
          (ρ t) i j) t)
    (htrace : Matrix.trace (ρ t) = (1 : ℂ)) :
    HasDerivAt
      (fun s : ℝ => Complex.re (Matrix.trace (twoQubitN1 * ρ s)))
      (((1 : ℝ) / 5) *
          (1 - Complex.re (Matrix.trace (twoQubitN1 * ρ t))) -
        ((3 : ℝ) / 7) *
          Complex.re (Matrix.trace (twoQubitN1 * ρ t))) t := by
  apply fullGKSL_real_population_hasDerivAt
    twoQubitH twoQubitJump twoQubitRate twoQubitN1 ρ t
      ((1 : ℝ) / 5) ((3 : ℝ) / 7) hρt
  · convert twoQubit_heisenberg_n1 using 1
    all_goals norm_num
  · exact htrace

/-- The second real marginal equation is derived from the matrix master
equation and trace normalization. -/
theorem twoQubit_q2_hasDerivAt
    (ρ : ℝ → Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (t : ℝ)
    (hρt : ∀ i j : TwoQubitIndex,
      HasDerivAt (fun u : ℝ => ρ u i j)
        (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
          (ρ t) i j) t)
    (htrace : Matrix.trace (ρ t) = (1 : ℂ)) :
    HasDerivAt
      (fun s : ℝ => Complex.re (Matrix.trace (twoQubitN2 * ρ s)))
      (((2 : ℝ) / 9) *
          (1 - Complex.re (Matrix.trace (twoQubitN2 * ρ t))) -
        ((4 : ℝ) / 11) *
          Complex.re (Matrix.trace (twoQubitN2 * ρ t))) t := by
  apply fullGKSL_real_population_hasDerivAt
    twoQubitH twoQubitJump twoQubitRate twoQubitN2 ρ t
      ((2 : ℝ) / 9) ((4 : ℝ) / 11) hρt
  · convert twoQubit_heisenberg_n2 using 1
    all_goals norm_num
  · exact htrace

/-- The real joint equation is derived directly from the matrix master
equation and the concrete triangular operator identity. -/
theorem twoQubit_r_hasDerivAt
    (ρ : ℝ → Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (t : ℝ)
    (hρt : ∀ i j : TwoQubitIndex,
      HasDerivAt (fun u : ℝ => ρ u i j)
        (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
          (ρ t) i j) t) :
    HasDerivAt
      (fun s : ℝ => Complex.re (Matrix.trace (twoQubitQ12 * ρ s)))
      (((1 : ℝ) / 5) *
          Complex.re (Matrix.trace (twoQubitN2 * ρ t)) +
        ((2 : ℝ) / 9) *
          Complex.re (Matrix.trace (twoQubitN1 * ρ t)) -
        (((1 : ℝ) / 5) + ((3 : ℝ) / 7) +
         ((2 : ℝ) / 9) + ((4 : ℝ) / 11)) *
          Complex.re (Matrix.trace (twoQubitQ12 * ρ t))) t := by
  apply fullGKSL_real_joint_hasDerivAt
    twoQubitH twoQubitJump twoQubitRate
    twoQubitN1 twoQubitN2 twoQubitQ12 ρ t
      ((1 : ℝ) / 5) ((3 : ℝ) / 7)
      ((2 : ℝ) / 9) ((4 : ℝ) / 11) hρt
  convert twoQubit_heisenberg_q12 using 1
  all_goals norm_num

/-- Final concrete certificate.  Any supplied matrix path that starts in the
exact two-qubit vacuum and satisfies the fixed entrywise GKSL equation on the
nonnegative half-line has joint excited-state expectation strictly below
`1/4` at every nonnegative time. -/
theorem concreteTwoQubitGKSL_jointEvent_belowQuarter
    (ρ : ℝ → Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (hρ0 : ρ 0 = twoQubitVacuum)
    (hρ : ∀ s : ℝ, 0 ≤ s → ∀ i j : TwoQubitIndex,
      HasDerivAt (fun u : ℝ => ρ u i j)
        (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
          (ρ s) i j) s) :
    ∀ t : ℝ, 0 ≤ t →
      Complex.re (Matrix.trace (twoQubitQ12 * ρ t)) < (1 : ℝ) / 4 := by
  let q₁ : ℝ → ℝ := fun s =>
    Complex.re (Matrix.trace (twoQubitN1 * ρ s))
  let q₂ : ℝ → ℝ := fun s =>
    Complex.re (Matrix.trace (twoQubitN2 * ρ s))
  let r : ℝ → ℝ := fun s =>
    Complex.re (Matrix.trace (twoQubitQ12 * ρ s))
  have hq₁ : ∀ s : ℝ, 0 ≤ s →
      HasDerivAt q₁
        (((1 : ℝ) / 5) * (1 - q₁ s) - ((3 : ℝ) / 7) * q₁ s) s := by
    intro s hs
    have htrace := twoQubit_trace_eq_one_nonneg ρ hρ0 hρ s hs
    simpa only [q₁] using twoQubit_q1_hasDerivAt ρ s (hρ s hs) htrace
  have hq₂ : ∀ s : ℝ, 0 ≤ s →
      HasDerivAt q₂
        (((2 : ℝ) / 9) * (1 - q₂ s) - ((4 : ℝ) / 11) * q₂ s) s := by
    intro s hs
    have htrace := twoQubit_trace_eq_one_nonneg ρ hρ0 hρ s hs
    simpa only [q₂] using twoQubit_q2_hasDerivAt ρ s (hρ s hs) htrace
  have hr : ∀ s : ℝ, 0 ≤ s →
      HasDerivAt r
        (((1 : ℝ) / 5) * q₂ s + ((2 : ℝ) / 9) * q₁ s -
          (((1 : ℝ) / 5) + ((3 : ℝ) / 7) +
           ((2 : ℝ) / 9) + ((4 : ℝ) / 11)) * r s) s := by
    intro s hs
    simpa only [q₁, q₂, r] using
      twoQubit_r_hasDerivAt ρ s (hρ s hs)
  have hq₁0 : q₁ 0 = 0 := by
    dsimp only [q₁]
    rw [hρ0, twoQubit_vacuum_n1]
    exact Complex.zero_re
  have hq₂0 : q₂ 0 = 0 := by
    dsimp only [q₂]
    rw [hρ0, twoQubit_vacuum_n2]
    exact Complex.zero_re
  have hr0 : r 0 = 0 := by
    dsimp only [r]
    rw [hρ0, twoQubit_vacuum_q12]
    exact Complex.zero_re
  intro t ht
  simpa only [r] using
    sampleJointEvent_from_hierarchy q₁ q₂ r
      hq₁ hq₂ hr hq₁0 hq₂0 hr0 t ht

end BinduEventInterface
