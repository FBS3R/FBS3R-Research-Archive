import BinduEventInterface.PhysicalBridge
import Mathlib.Data.Matrix.Kronecker

/-!
# Finite bipartite tensor locality (Lean 4.19 / Mathlib v4.19)

Each factor may have *arbitrary finite index type*. Thus the statement is
not restricted to two qubits or to a particular matrix dimension.

The pinned kernel accepts this module and the root interface imports it.
-/

namespace BinduEventInterface
open Matrix

/-! Compatibility for Mathlib v4.19.0, where the Kronecker adjoint lemma
is not provided by `Mathlib.Data.Matrix.Kronecker`. -/
theorem kronecker_conjTranspose_v419
    {a b : Type*} [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    (A : Matrix a a ℂ) (B : Matrix b b ℂ) :
    (Matrix.kronecker A B).conjTranspose =
      Matrix.kronecker A.conjTranspose B.conjTranspose := by
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp [Matrix.kronecker, Matrix.kroneckerMap, Matrix.conjTranspose_apply, mul_comm]


/-- Operators on the left and right tensor factors commute exactly. -/
theorem kronecker_left_right_commute
    {a b : Type*} [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    (A : Matrix a a ℂ) (B : Matrix b b ℂ) :
    Matrix.kronecker A (1 : Matrix b b ℂ) *
      Matrix.kronecker (1 : Matrix a a ℂ) B =
    Matrix.kronecker (1 : Matrix a a ℂ) B *
      Matrix.kronecker A (1 : Matrix b b ℂ) := by
  calc
    Matrix.kronecker A (1 : Matrix b b ℂ) *
        Matrix.kronecker (1 : Matrix a a ℂ) B
      = Matrix.kronecker (A * 1) (1 * B) := by
          exact (Matrix.mul_kronecker_mul A 1 (1 : Matrix b b ℂ) B).symm
    _ = Matrix.kronecker A B := by simp
    _ = Matrix.kronecker (1 * A) (B * 1) := by simp
    _ = Matrix.kronecker (1 : Matrix a a ℂ) B *
        Matrix.kronecker A (1 : Matrix b b ℂ) := by
          exact Matrix.mul_kronecker_mul 1 A B 1

/-- The same commutation applies to the adjoint of the left factor. -/
theorem kronecker_left_right_adjoint_commute
    {a b : Type*} [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    (A : Matrix a a ℂ) (B : Matrix b b ℂ) :
    Matrix.kronecker (1 : Matrix a a ℂ) B *
      (Matrix.kronecker A (1 : Matrix b b ℂ)).conjTranspose =
    (Matrix.kronecker A (1 : Matrix b b ℂ)).conjTranspose *
      Matrix.kronecker (1 : Matrix a a ℂ) B := by
  rw [kronecker_conjTranspose_v419]
  simp only [Matrix.conjTranspose_one]
  exact (kronecker_left_right_commute A.conjTranspose B).symm

#print axioms kronecker_left_right_commute
#print axioms kronecker_left_right_adjoint_commute

end BinduEventInterface
