import Mathlib
import BinduEventInterface.CPTPDiamondContractivity
import BinduEventInterface.NQubitDiamondMixingCandidate
import BinduEventInterface.NQubitIndependentCPTPSemigroupCandidate

/-!
# Single-Qubit Diamond Bound, Schatten-1 Telescoping, and Exponential Mixing Time

This module provides the formal kernel-checked foundation for exponential diamond-norm
mixing bounds in the `BINDU-VECTRA` framework:

1. **Exact Single-Qubit Stabilized Identities with Arbitrary Ancilla**:
   - `ancillaRightChannel_term_apply`, `ancillaRightChannel_apply`: entrywise action of
     ancilla-stabilized Kraus channels on composite matrix slices.
   - `ancillaDephasingChannel`: ancilla-stabilized computational dephasing map `(D ⊗ id_a)`.
   - `localOffdiagonal_stabilized_le`: `‖((id - D) ⊗ id_a)(X)‖₁ ≤ ‖X‖₁` for any finite `a`.
   - `localReplacerDifference_stabilized_le`: `‖((id - R) ⊗ id_a)(X)‖₁ ≤ 2 ‖X‖₁`.
   - `ancillaLocalChannel_sub_replacer_eq`: exact matrix equality
     `((Φ - R) ⊗ id_a)(X) = r(1-r) ((id - D) ⊗ id_a)(X) + r² ((id - R) ⊗ id_a)(X)`.
   - `singleQubit_channel_sub_replacer_diamond_bound`:
     `‖((Φ - R) ⊗ id_a)(X)‖₁ ≤ (r + r²) ‖X‖₁`.

2. **General Algebraic Telescoping for Schatten-1 Norms**:
   - `schattenOne_sum_le`: finite subadditivity `‖∑ᵢ Aᵢ‖₁ ≤ ∑ᵢ ‖Aᵢ‖₁`.
   - `schattenOne_telescope_sum_le`: telescoping difference bound for any sequence
     of linear channels with step errors `δₖ`.

3. **Arbitrary-N Qubit Diamond Envelope Exponential Decay and Mixing Time**:
   - `isSpectralGapLowerBound`: lower bound on all local relaxation rates `γ ≤ (Gₘ + Kₘ) / 2`.
   - `nQubitDiamondEnvelope_sum_le_two_mul_card_mul_exp`:
     `∑ₘ (rₘ(t) + rₘ(t)²) ≤ 2 * N * exp(-γ * t)`.
   - `nQubitDiamondEnvelope_le_of_mixing_time`: for `N ≥ 1`, `γ > 0`, `0 < ε`,
     if `t ≥ (1 / γ) * log(2 * N / ε)`, then `nQubitDiamondEnvelope G K t ≤ ε`.
   - `nQubitDiamondEnvelope_le_of_mixing_time_factor_two`: specialization for `t ≥ (2 / γ) * log(2 * N / ε)`
     when `0 < ε < 2`.

All proofs are constructively verified in Lean 4.19.0 using only standard foundational
axioms (`propext`, `Classical.choice`, `Quot.sound`).
-/

namespace BinduEventInterface

open Matrix
open scoped BigOperators Matrix ComplexOrder Topology

section AncillaSlices

variable {a : Type*} [Fintype a] [DecidableEq a]

/-- Left-multiplication by `K ⊗ I_a` acts entrywise on the `n`-qubit block slice. -/
theorem kronecker_one_mul_apply {n : Type*} [Fintype n] [DecidableEq n]
    (K : Matrix n n ℂ)
    (X : Matrix (n × a) (n × a) ℂ)
    (u : n) (i : a) (q : n × a) :
    (Matrix.kronecker K (1 : Matrix a a ℂ) * X) (u, i) q =
      ∑ u' : n, K u u' * X (u', i) q := by
  simp only [Matrix.mul_apply, Fintype.sum_prod_type,
    Matrix.kronecker, Matrix.kroneckerMap_apply, Matrix.one_apply]
  refine Finset.sum_congr rfl (fun u' _ => ?_)
  rw [Finset.sum_eq_single i]
  · rw [if_pos rfl, mul_one]
  · intro i' _ hne
    rw [if_neg hne.symm, mul_zero, zero_mul]
  · intro hi
    exact (hi (Finset.mem_univ i)).elim

/-- Right-multiplication by `(K ⊗ I_a)ᴴ` acts entrywise on the `n`-qubit block slice. -/
theorem mul_kronecker_one_conjTranspose_apply {n : Type*} [Fintype n] [DecidableEq n]
    (K : Matrix n n ℂ)
    (Y : Matrix (n × a) (n × a) ℂ)
    (p : n × a) (v : n) (j : a) :
    (Y * (Matrix.kronecker K (1 : Matrix a a ℂ))ᴴ) p (v, j) =
      ∑ v' : n, Y p (v', j) * (Kᴴ v' v) := by
  simp only [Matrix.mul_apply, Fintype.sum_prod_type,
    Matrix.conjTranspose_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply, Matrix.one_apply]
  refine Finset.sum_congr rfl (fun v' _ => ?_)
  rw [Finset.sum_eq_single j]
  · rw [if_pos rfl, mul_one]
  · intro j' _ hne
    rw [if_neg hne.symm, mul_zero, star_zero, mul_zero]
  · intro hj
    exact (hj (Finset.mem_univ j)).elim

/-- Conjugation by `K ⊗ I_a` on `X` restricts on block `(i, j)` to `K * X_slice * Kᴴ`. -/
theorem ancillaRightChannel_term_apply {n : Type*} [Fintype n] [DecidableEq n]
    (K : Matrix n n ℂ)
    (X : Matrix (n × a) (n × a) ℂ)
    (u v : n) (i j : a) :
    (Matrix.kronecker K (1 : Matrix a a ℂ) * X *
      (Matrix.kronecker K (1 : Matrix a a ℂ))ᴴ) (u, i) (v, j) =
      (K * (Matrix.of fun u' v' => X (u', i) (v', j)) * Kᴴ) u v := by
  rw [mul_kronecker_one_conjTranspose_apply]
  simp_rw [kronecker_one_mul_apply]
  simp only [Matrix.mul_apply, Matrix.of_apply]

/-- **Block-Slice Reduction for Ancilla-Stabilized Channels**:
for any finite Kraus family `K`, the `(u, i), (v, j)` entry of `(Φ ⊗ id_a)(X)` equals
the `(u, v)` entry of `Φ(X^{(i, j)})`, where `X^{(i, j)} u' v' = X (u', i) (v', j)`. -/
theorem ancillaRightChannel_apply {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ)
    (X : Matrix (n × a) (n × a) ℂ)
    (u v : n) (i j : a) :
    ancillaRightChannel K X (u, i) (v, j) =
      finiteKrausChannel K (Matrix.of fun u' v' => X (u', i) (v', j)) u v := by
  unfold ancillaRightChannel finiteKrausChannel
  simp only [Matrix.sum_apply]
  refine Finset.sum_congr rfl (fun l _ => ?_)
  exact ancillaRightChannel_term_apply (K l) X u v i j

end AncillaSlices

section SingleQubitStabilized

variable {a : Type*} [Fintype a] [DecidableEq a]

/-- Single-qubit identity Kraus operator (1 element). -/
def singleQubitIdKraus : Fin 1 → Matrix (Fin 2) (Fin 2) ℂ :=
  fun _ => 1

/-- Completeness of single-qubit identity Kraus operator. -/
theorem singleQubitIdKraus_completeness :
    ∑ j : Fin 1, (singleQubitIdKraus j)ᴴ * singleQubitIdKraus j = 1 := by
  simp [singleQubitIdKraus]

/-- Single-qubit Pauli-Z Kraus operator (1 element). -/
def singleQubitPauliZKraus : Fin 1 → Matrix (Fin 2) (Fin 2) ℂ :=
  fun _ => localPauliZ

/-- Completeness of single-qubit Pauli-Z Kraus operator. -/
theorem singleQubitPauliZKraus_completeness :
    ∑ j : Fin 1, (singleQubitPauliZKraus j)ᴴ * singleQubitPauliZKraus j = 1 := by
  simp [singleQubitPauliZKraus, localPauliZ_conjTranspose_mul_self]

/-- Single-qubit identity channel on ancilla is the identity operator. -/
theorem ancillaRightChannel_id (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    ancillaRightChannel singleQubitIdKraus X = X := by
  unfold ancillaRightChannel finiteKrausChannel singleQubitIdKraus
  simp only [Fin.sum_univ_one]
  have hone : Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ) (1 : Matrix a a ℂ) = 1 :=
    Matrix.one_kronecker_one
  rw [hone, Matrix.conjTranspose_one, Matrix.mul_one, Matrix.one_mul]

/-- Ancilla-stabilized computational-basis dephasing:
`ancillaDephasingChannel X = (1/2) • (X + (Z ⊗ I_a) X (Z ⊗ I_a)ᴴ)`. -/
noncomputable def ancillaDephasingChannel (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    Matrix (Fin 2 × a) (Fin 2 × a) ℂ :=
  ((1 : ℂ) / 2) • (X + ancillaRightChannel singleQubitPauliZKraus X)

/-- Off-diagonal extraction identity on ancilla:
`X - (D ⊗ id_a)(X) = (1/2) • (X - (Ad_Z ⊗ id_a)(X))`. -/
theorem ancillaSubDephasing_eq (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    X - ancillaDephasingChannel X =
      ((1 : ℂ) / 2) • (ancillaRightChannel singleQubitIdKraus X -
                       ancillaRightChannel singleQubitPauliZKraus X) := by
  rw [ancillaRightChannel_id]
  unfold ancillaDephasingChannel
  ext i j
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply, smul_eq_mul]
  ring

/-- **Step 2: Stabilized Off-Diagonal Bound**:
for any finite ancilla `a` and any composite matrix `X`,
`‖((id - D) ⊗ id_a)(X)‖₁ ≤ ‖X‖₁`. -/
theorem localOffdiagonal_stabilized_le (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    schattenOneSpectralNorm (X - ancillaDephasingChannel X) ≤
      schattenOneSpectralNorm X := by
  rw [ancillaSubDephasing_eq]
  have hsmul := schattenOne_smul_le ((1 : ℂ) / 2)
    (ancillaRightChannel singleQubitIdKraus X - ancillaRightChannel singleQubitPauliZKraus X)
  have hcptp := cptp_channel_sub_le
    singleQubitIdKraus singleQubitIdKraus_completeness
    singleQubitPauliZKraus singleQubitPauliZKraus_completeness X
  have hnorm_half : ‖(1 : ℂ) / 2‖ = (1 / 2 : ℝ) := by
    norm_num
  calc
    schattenOneSpectralNorm (((1 : ℂ) / 2) •
      (ancillaRightChannel singleQubitIdKraus X - ancillaRightChannel singleQubitPauliZKraus X))
      ≤ ‖(1 : ℂ) / 2‖ * schattenOneSpectralNorm
          (ancillaRightChannel singleQubitIdKraus X - ancillaRightChannel singleQubitPauliZKraus X) :=
        hsmul
    _ ≤ (1 / 2 : ℝ) * (2 * schattenOneSpectralNorm X) := by
        rw [hnorm_half]
        exact mul_le_mul_of_nonneg_left hcptp (by norm_num)
    _ = schattenOneSpectralNorm X := by ring

/-- **Step 3: Stabilized Replacer Difference Bound**:
for any `0 ≤ p ≤ 1`, finite ancilla `a`, and composite matrix `X`,
`‖((id - R_p) ⊗ id_a)(X)‖₁ ≤ 2 ‖X‖₁`. -/
theorem localReplacerDifference_stabilized_le (p : ℝ) (hp : 0 ≤ p ∧ p ≤ 1)
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    schattenOneSpectralNorm (X - ancillaRightChannel (gadKraus p 0) X) ≤
      2 * schattenOneSpectralNorm X := by
  have hid := ancillaRightChannel_id (a := a) X
  conv_lhs =>
    arg 1
    lhs
    rw [← hid]
  have hgad_comp := gadKraus_completeness p 0 hp ⟨le_rfl, zero_le_one⟩
  exact cptp_channel_sub_le
    singleQubitIdKraus singleQubitIdKraus_completeness
    (gadKraus p 0) hgad_comp X

/-- `ancillaDephasingChannel` acts slice-by-slice as `localDephasingMap`. -/
theorem ancillaDephasingChannel_apply
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ)
    (u v : Fin 2) (i j : a) :
    ancillaDephasingChannel X (u, i) (v, j) =
      localDephasingMap (Matrix.of fun u' v' => X (u', i) (v', j)) u v := by
  unfold ancillaDephasingChannel localDephasingMap
  simp only [Matrix.smul_apply, Matrix.add_apply, smul_eq_mul]
  rw [ancillaRightChannel_apply singleQubitPauliZKraus]
  unfold finiteKrausChannel singleQubitPauliZKraus
  simp only [Fin.sum_univ_one, Matrix.of_apply, localPauliZ_isHermitian.eq]

/-- The ancilla-stabilized replacer channel acts slice-by-slice as `localReplacerMap`. -/
theorem ancillaReplacer_apply (p : ℝ) (hp : 0 ≤ p ∧ p ≤ 1)
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ)
    (u v : Fin 2) (i j : a) :
    ancillaRightChannel (gadKraus p 0) X (u, i) (v, j) =
      localReplacerMap p (Matrix.of fun u' v' => X (u', i) (v', j)) u v := by
  rw [ancillaRightChannel_apply (gadKraus p 0)]
  rw [localReplacerMap_eq_finiteKrausChannel p hp]

/-- The ancilla-stabilized local channel acts slice-by-slice as `localChannel`. -/
theorem ancillaLocalChannel_apply (G K t : ℝ) (hG : 0 < G) (hK : 0 < K) (ht : 0 ≤ t)
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ)
    (u v : Fin 2) (i j : a) :
    ancillaRightChannel (localKraus G K t) X (u, i) (v, j) =
      localChannel G K t (Matrix.of fun u' v' => X (u', i) (v', j)) u v := by
  rw [ancillaRightChannel_apply (localKraus G K t)]
  rw [finiteKrausChannel_localKraus_eq_localChannel G K t hG hK ht]

/-- **Exact Ancilla-Stabilized Channel Difference Decomposition**:
for all rates `G, K > 0`, `t ≥ 0`, finite ancilla `a`, and composite matrix `X`,
`((Φ - R) ⊗ id_a)(X) = r(1-r) ((id - D) ⊗ id_a)(X) + r² ((id - R) ⊗ id_a)(X)`. -/
theorem ancillaLocalChannel_sub_replacer_eq (G K t : ℝ)
    (hG : 0 < G) (hK : 0 < K) (ht : 0 ≤ t)
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    ancillaRightChannel (localKraus G K t) X -
      ancillaRightChannel (gadKraus (localEqProb G K) 0) X =
      ((localDampingR G K t * (1 - localDampingR G K t) : ℝ) : ℂ) •
        (X - ancillaDephasingChannel X) +
      (((localDampingR G K t) ^ 2 : ℝ) : ℂ) •
        (X - ancillaRightChannel (gadKraus (localEqProb G K) 0) X) := by
  ext ⟨u, i⟩ ⟨v, j⟩
  let M : Matrix (Fin 2) (Fin 2) ℂ := Matrix.of fun u' v' => X (u', i) (v', j)
  have hp := localEqProb_bounds G K hG hK
  have hM := congr_fun (congr_fun (localChannel_sub_replacer_eq G K t M) u) v
  simp only [Matrix.sub_apply, Matrix.add_apply, Matrix.smul_apply, smul_eq_mul] at hM ⊢
  rw [ancillaLocalChannel_apply G K t hG hK ht X u v i j]
  rw [ancillaReplacer_apply (localEqProb G K) hp X u v i j]
  rw [ancillaDephasingChannel_apply X u v i j]
  have hX : X (u, i) (v, j) = M u v := rfl
  rw [hX]
  exact hM

/-- **Step 4: Local Single-Qubit Diamond Bound with Arbitrary Ancilla**:
`‖((Φ - R) ⊗ id_a)(X)‖₁ ≤ (r + r²) ‖X‖₁`. -/
theorem singleQubit_channel_sub_replacer_diamond_bound (G K t : ℝ)
    (hG : 0 < G) (hK : 0 < K) (ht : 0 ≤ t)
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    schattenOneSpectralNorm
      (ancillaRightChannel (localKraus G K t) X -
       ancillaRightChannel (gadKraus (localEqProb G K) 0) X) ≤
      (localDampingR G K t + (localDampingR G K t) ^ 2) *
        schattenOneSpectralNorm X := by
  let r := localDampingR G K t
  have hr := localDampingR_bounds G K t hG hK ht
  have hp := localEqProb_bounds G K hG hK
  rw [ancillaLocalChannel_sub_replacer_eq G K t hG hK ht X]
  have htri := schattenOne_add_le
    (((r * (1 - r) : ℝ) : ℂ) • (X - ancillaDephasingChannel X))
    (((r ^ 2 : ℝ) : ℂ) • (X - ancillaRightChannel (gadKraus (localEqProb G K) 0) X))
  have hsmul1 := schattenOne_smul_le (((r * (1 - r) : ℝ) : ℂ)) (X - ancillaDephasingChannel X)
  have hsmul2 := schattenOne_smul_le (((r ^ 2 : ℝ) : ℂ)) (X - ancillaRightChannel (gadKraus (localEqProb G K) 0) X)
  have hle1 := localOffdiagonal_stabilized_le X
  have hle2 := localReplacerDifference_stabilized_le (localEqProb G K) hp X
  have hnorm1 : ‖((r * (1 - r) : ℝ) : ℂ)‖ = r * (1 - r) := by
    rw [Complex.norm_real, Real.norm_of_nonneg (mul_nonneg hr.1 (by linarith [hr.2]))]
  have hnorm2 : ‖(((r ^ 2 : ℝ) : ℂ))‖ = r ^ 2 := by
    rw [Complex.norm_real, Real.norm_of_nonneg (sq_nonneg r)]
  have hterm1 : schattenOneSpectralNorm (((r * (1 - r) : ℝ) : ℂ) • (X - ancillaDephasingChannel X)) ≤
      (r * (1 - r)) * schattenOneSpectralNorm X := by
    refine hsmul1.trans ?_
    rw [hnorm1]
    exact mul_le_mul_of_nonneg_left hle1 (mul_nonneg hr.1 (by linarith [hr.2]))
  have hterm2 : schattenOneSpectralNorm (((r ^ 2 : ℝ) : ℂ) • (X - ancillaRightChannel (gadKraus (localEqProb G K) 0) X)) ≤
      (2 * r ^ 2) * schattenOneSpectralNorm X := by
    refine hsmul2.trans ?_
    rw [hnorm2]
    have hmul := mul_le_mul_of_nonneg_left hle2 (sq_nonneg r)
    linarith
  have hsum : (r * (1 - r)) * schattenOneSpectralNorm X + (2 * r ^ 2) * schattenOneSpectralNorm X =
      (r + r ^ 2) * schattenOneSpectralNorm X := by
    ring
  refine htri.trans ?_
  linarith

end SingleQubitStabilized

section TelescopingAlgebra

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- Triangle inequality for finite sums in `schattenOneSpectralNorm`. -/
theorem schattenOne_sum_le {ι : Type*} (s : Finset ι) (f : ι → Matrix n n ℂ) :
    schattenOneSpectralNorm (∑ i ∈ s, f i) ≤ ∑ i ∈ s, schattenOneSpectralNorm (f i) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
      simp only [Finset.sum_empty, schattenOneSpectralNorm_zero, le_rfl]
  | @insert a s ha ih =>
      rw [Finset.sum_insert ha, Finset.sum_insert ha]
      have htri := schattenOne_add_le (f a) (∑ i ∈ s, f i)
      exact le_trans htri (add_le_add_left ih _)

/-- **General Algebraic Telescoping Lemma for Schatten-1 Norms**:
For any sequence of matrices `f : ℕ → Matrix n n ℂ` and local error bounds `δ : ℕ → ℝ`,
if every step satisfies `‖f (k + 1) - f k‖₁ ≤ δ k * B`, then
`‖f N - f 0‖₁ ≤ (∑ k ∈ range N, δ k) * B`. -/
theorem schattenOne_telescope_sum_le (f : ℕ → Matrix n n ℂ) (δ : ℕ → ℝ) (B : ℝ)
    (hstep : ∀ k : ℕ, schattenOneSpectralNorm (f (k + 1) - f k) ≤ δ k * B)
    (N : ℕ) :
    schattenOneSpectralNorm (f N - f 0) ≤ (∑ k ∈ Finset.range N, δ k) * B := by
  have htelescope : f N - f 0 = ∑ k ∈ Finset.range N, (f (k + 1) - f k) := by
    exact (Finset.sum_range_sub f N).symm
  rw [htelescope]
  have hsum := schattenOne_sum_le (Finset.range N) (fun k => f (k + 1) - f k)
  have hbounds : (∑ k ∈ Finset.range N, schattenOneSpectralNorm (f (k + 1) - f k)) ≤
      ∑ k ∈ Finset.range N, δ k * B :=
    Finset.sum_le_sum (fun k _ => hstep k)
  rw [← Finset.sum_mul] at hbounds
  exact le_trans hsum hbounds

end TelescopingAlgebra

section MixingTime

variable {N : ℕ} (G K : Fin N → ℝ)

/-- Minimum local relaxation rate across all `N` qubits:
`γ_min ≤ (G m + K m) / 2` for every `m`. -/
def isSpectralGapLowerBound (γ : ℝ) : Prop :=
  ∀ m : Fin N, γ ≤ (G m + K m) / 2

/-- **Rigorous exponential decay of the diamond envelope sum**:
if `γ > 0` is a lower bound on all local relaxation rates, then for all `t ≥ 0`:
`∑ m, (r_m(t) + r_m(t)²) ≤ 2 * N * exp(-γ * t)`. -/
theorem nQubitDiamondEnvelope_sum_le_two_mul_card_mul_exp
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {γ : ℝ} (hγ : isSpectralGapLowerBound G K γ)
    {t : ℝ} (ht : 0 ≤ t) :
    (∑ m : Fin N, (localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2)) ≤
      2 * (N : ℝ) * Real.exp (-γ * t) := by
  have hterm (m : Fin N) :
      localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2 ≤
        2 * Real.exp (-γ * t) := by
    have hr_bounds := localDampingR_bounds (G m) (K m) t (hG m) (hK m) ht
    have hr_le_two_r := (localDiamondWeights_nonneg_and_sum hr_bounds.1 hr_bounds.2).2.2.2
    unfold localDampingR at hr_le_two_r ⊢
    have hrate : γ ≤ (G m + K m) / 2 := hγ m
    have hexp_le : Real.exp (-(G m + K m) * t / 2) ≤ Real.exp (-γ * t) := by
      apply Real.exp_le_exp.mpr
      have : -(G m + K m) * t / 2 = -((G m + K m) / 2) * t := by ring
      rw [this]
      nlinarith
    linarith
  calc
    (∑ m : Fin N, (localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2))
      ≤ ∑ m : Fin N, 2 * Real.exp (-γ * t) :=
        Finset.sum_le_sum (fun m _ => hterm m)
    _ = (Finset.univ : Finset (Fin N)).card * (2 * Real.exp (-γ * t)) := by
        rw [Finset.sum_const, nsmul_eq_mul]
    _ = 2 * (N : ℝ) * Real.exp (-γ * t) := by
        simp only [Finset.card_univ, Fintype.card_fin]
        ring

/-- **Mixing time bound for the N-qubit diamond envelope**:
For `N ≥ 1`, local relaxation rate lower bound `γ > 0`, precision `0 < ε`,
and `t ≥ 0`, if `t ≥ (1 / γ) * log(2 * N / ε)`, then `nQubitDiamondEnvelope G K t ≤ ε`. -/
theorem nQubitDiamondEnvelope_le_of_mixing_time
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {γ : ℝ} (hγ_pos : 0 < γ) (hγ : isSpectralGapLowerBound G K γ)
    {ε : ℝ} (hε : 0 < ε)
    (hN : 1 ≤ N)
    {t : ℝ} (ht_nonneg : 0 ≤ t)
    (ht : (1 / γ) * Real.log (2 * (N : ℝ) / ε) ≤ t) :
    nQubitDiamondEnvelope G K t ≤ ε := by
  have hN_pos : (0 : ℝ) < (N : ℝ) := by
    have : (1 : ℝ) ≤ (N : ℝ) := Nat.one_le_cast.mpr hN
    linarith
  have h2N_div_eps_pos : 0 < 2 * (N : ℝ) / ε := div_pos (by linarith) hε
  have hsum_le := nQubitDiamondEnvelope_sum_le_two_mul_card_mul_exp G K hG hK hγ ht_nonneg
  have hgamma_t : Real.log (2 * (N : ℝ) / ε) ≤ γ * t := by
    have h1 : γ * ((1 / γ) * Real.log (2 * (N : ℝ) / ε)) ≤ γ * t :=
      mul_le_mul_of_nonneg_left ht (le_of_lt hγ_pos)
    rw [← mul_assoc, mul_one_div_cancel (ne_of_gt hγ_pos), one_mul] at h1
    exact h1
  have hneg_gamma_t : - (γ * t) ≤ - Real.log (2 * (N : ℝ) / ε) := by linarith
  rw [← Real.log_inv] at hneg_gamma_t
  have hexp_le : Real.exp (-γ * t) ≤ (2 * (N : ℝ) / ε)⁻¹ := by
    have h := Real.exp_le_exp.mpr (by linarith : -γ * t ≤ Real.log (2 * (N : ℝ) / ε)⁻¹)
    rw [Real.exp_log (inv_pos.mpr h2N_div_eps_pos)] at h
    exact h
  have hinv : (2 * (N : ℝ) / ε)⁻¹ = ε / (2 * (N : ℝ)) := inv_div (2 * (N : ℝ)) ε
  rw [hinv] at hexp_le
  have h2N_ne : 2 * (N : ℝ) ≠ 0 := by linarith
  have hbound : 2 * (N : ℝ) * Real.exp (-γ * t) ≤ ε := by
    calc
      2 * (N : ℝ) * Real.exp (-γ * t)
        ≤ 2 * (N : ℝ) * (ε / (2 * (N : ℝ))) :=
          mul_le_mul_of_nonneg_left hexp_le (by linarith)
      _ = ε := mul_div_cancel₀ ε h2N_ne
  unfold nQubitDiamondEnvelope
  have hsum_le_eps : (∑ m : Fin N, (localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2)) ≤ ε :=
    le_trans hsum_le hbound
  exact le_trans (min_le_right 2 _) hsum_le_eps

/-- **Mixing time bound with factor `2 / γ`**:
For `N ≥ 1`, local relaxation rate lower bound `γ > 0`, precision `0 < ε < 2`,
and `t ≥ (2 / γ) * log(2 * N / ε)`, `nQubitDiamondEnvelope G K t ≤ ε`. -/
theorem nQubitDiamondEnvelope_le_of_mixing_time_factor_two
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {γ : ℝ} (hγ_pos : 0 < γ) (hγ : isSpectralGapLowerBound G K γ)
    {ε : ℝ} (hε : 0 < ε) (hε2 : ε < 2)
    (hN : 1 ≤ N)
    {t : ℝ} (ht : (2 / γ) * Real.log (2 * (N : ℝ) / ε) ≤ t) :
    nQubitDiamondEnvelope G K t ≤ ε := by
  have hratio : 1 < 2 * (N : ℝ) / ε := by
    have h2 : ε < 2 * (N : ℝ) := lt_of_lt_of_le hε2 (by
      have : (1 : ℝ) ≤ (N : ℝ) := Nat.one_le_cast.mpr hN
      linarith)
    exact (one_lt_div hε).mpr h2
  have hlog_pos : 0 < Real.log (2 * (N : ℝ) / ε) := Real.log_pos hratio
  have h12 : (1 / γ) * Real.log (2 * (N : ℝ) / ε) ≤ (2 / γ) * Real.log (2 * (N : ℝ) / ε) := by
    have : (1 / γ : ℝ) ≤ (2 / γ : ℝ) := by
      rw [div_le_div_iff_of_pos_right hγ_pos]
      linarith
    exact mul_le_mul_of_nonneg_right this (le_of_lt hlog_pos)
  have ht1 : (1 / γ) * Real.log (2 * (N : ℝ) / ε) ≤ t := le_trans h12 ht
  have ht_nonneg : 0 ≤ t := le_trans (by positivity) ht1
  exact nQubitDiamondEnvelope_le_of_mixing_time G K hG hK hγ_pos hγ hε hN ht_nonneg ht1

end MixingTime

end BinduEventInterface

#check BinduEventInterface.singleQubit_channel_sub_replacer_diamond_bound
#check BinduEventInterface.schattenOne_telescope_sum_le
#check BinduEventInterface.nQubitDiamondEnvelope_sum_le_two_mul_card_mul_exp
#check BinduEventInterface.nQubitDiamondEnvelope_le_of_mixing_time
#check BinduEventInterface.nQubitDiamondEnvelope_le_of_mixing_time_factor_two

#print axioms BinduEventInterface.singleQubit_channel_sub_replacer_diamond_bound
#print axioms BinduEventInterface.schattenOne_telescope_sum_le
#print axioms BinduEventInterface.nQubitDiamondEnvelope_sum_le_two_mul_card_mul_exp
#print axioms BinduEventInterface.nQubitDiamondEnvelope_le_of_mixing_time
#print axioms BinduEventInterface.nQubitDiamondEnvelope_le_of_mixing_time_factor_two
