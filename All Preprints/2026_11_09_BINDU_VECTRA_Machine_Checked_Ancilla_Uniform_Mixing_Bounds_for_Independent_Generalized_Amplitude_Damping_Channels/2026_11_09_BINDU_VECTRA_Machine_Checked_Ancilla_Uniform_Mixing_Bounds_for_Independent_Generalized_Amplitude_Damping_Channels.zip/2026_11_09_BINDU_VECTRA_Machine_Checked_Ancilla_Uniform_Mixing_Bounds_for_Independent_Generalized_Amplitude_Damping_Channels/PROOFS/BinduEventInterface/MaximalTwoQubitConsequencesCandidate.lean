import BinduEventInterface.ConcreteTwoQubitDynamics
import BinduEventInterface.SampleAllTimeCertificateCandidate

/-!
# Stronger verified-baseline consequences: kernel-check candidates

All results in this module are NEW CANDIDATES.  They are *not* asserted to
have passed Lean until the accompanying Mac verification script reports success.
They reuse the exact fixed GKSL equation; no observable ODE is postulated.
-/

namespace BinduEventInterface

/-- Matrix path constrained only by the concrete vacuum and matrix GKSL equation. -/
structure CertifiedTwoQubitPath where
  rho : ℝ → Matrix TwoQubitIndex TwoQubitIndex ℂ
  initial : rho 0 = twoQubitVacuum
  dynamics : ∀ s : ℝ, 0 ≤ s → ∀ i j : TwoQubitIndex,
    HasDerivAt (fun u : ℝ => rho u i j)
      (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (rho s) i j) s

/-- First excited-state marginal, *not* assumed to be an ODE solution. -/
noncomputable def certifiedQ1 (p : CertifiedTwoQubitPath) (t : ℝ) : ℝ :=
  Complex.re (Matrix.trace (twoQubitN1 * p.rho t))

/-- Second excited-state marginal. -/
noncomputable def certifiedQ2 (p : CertifiedTwoQubitPath) (t : ℝ) : ℝ :=
  Complex.re (Matrix.trace (twoQubitN2 * p.rho t))

/-- Joint two-qubit event. -/
noncomputable def certifiedJoint (p : CertifiedTwoQubitPath) (t : ℝ) : ℝ :=
  Complex.re (Matrix.trace (twoQubitQ12 * p.rho t))

/-- Trace normalization is a consequence, not an assumption. -/
theorem certified_trace_one (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) : Matrix.trace (p.rho t) = (1 : ℂ) :=
  twoQubit_trace_eq_one_nonneg p.rho p.initial p.dynamics t ht

/-- The three observable initial conditions are direct vacuum calculations. -/
theorem certified_q1_initial (p : CertifiedTwoQubitPath) : certifiedQ1 p 0 = 0 := by
  unfold certifiedQ1
  rw [p.initial, twoQubit_vacuum_n1]
  exact Complex.zero_re

theorem certified_q2_initial (p : CertifiedTwoQubitPath) : certifiedQ2 p 0 = 0 := by
  unfold certifiedQ2
  rw [p.initial, twoQubit_vacuum_n2]
  exact Complex.zero_re

theorem certified_joint_initial (p : CertifiedTwoQubitPath) : certifiedJoint p 0 = 0 := by
  unfold certifiedJoint
  rw [p.initial, twoQubit_vacuum_q12]
  exact Complex.zero_re

/-- The scalar ODEs are *derived* from the matrix evolution. -/
theorem certified_q1_ode (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    HasDerivAt (certifiedQ1 p)
      (((1 : ℝ) / 5) * (1 - certifiedQ1 p t) -
       ((3 : ℝ) / 7) * certifiedQ1 p t) t := by
  simpa only [certifiedQ1] using
    twoQubit_q1_hasDerivAt p.rho t (p.dynamics t ht) (certified_trace_one p t ht)

theorem certified_q2_ode (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    HasDerivAt (certifiedQ2 p)
      (((2 : ℝ) / 9) * (1 - certifiedQ2 p t) -
       ((4 : ℝ) / 11) * certifiedQ2 p t) t := by
  simpa only [certifiedQ2] using
    twoQubit_q2_hasDerivAt p.rho t (p.dynamics t ht) (certified_trace_one p t ht)

theorem certified_joint_ode (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    HasDerivAt (certifiedJoint p)
      (((1 : ℝ) / 5) * certifiedQ2 p t +
       ((2 : ℝ) / 9) * certifiedQ1 p t -
       (((1 : ℝ) / 5) + ((3 : ℝ) / 7) +
        ((2 : ℝ) / 9) + ((4 : ℝ) / 11)) * certifiedJoint p t) t := by
  simpa only [certifiedJoint, certifiedQ1, certifiedQ2] using
    twoQubit_r_hasDerivAt p.rho t (p.dynamics t ht)

/-- Exact marginal solutions, stronger than a threshold bound. -/
theorem certified_q1_exact (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedQ1 p t = constantRatePopulation ((1 : ℝ) / 5) ((3 : ℝ) / 7) t := by
  exact constantRatePopulation_unique_nonneg
    ((1 : ℝ) / 5) ((3 : ℝ) / 7) (by norm_num)
    (certifiedQ1 p) (certified_q1_ode p)
    (certified_q1_initial p) t ht

theorem certified_q2_exact (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedQ2 p t = constantRatePopulation ((2 : ℝ) / 9) ((4 : ℝ) / 11) t := by
  exact constantRatePopulation_unique_nonneg
    ((2 : ℝ) / 9) ((4 : ℝ) / 11) (by norm_num)
    (certifiedQ2 p) (certified_q2_ode p)
    (certified_q2_initial p) t ht

/-- Exact zero covariance on the physical half-line, proved from the full hierarchy. -/
theorem certified_joint_factorizes (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedJoint p t = certifiedQ1 p t * certifiedQ2 p t := by
  have hinit : certifiedJoint p 0 = certifiedQ1 p 0 * certifiedQ2 p 0 := by
    rw [certified_joint_initial p, certified_q1_initial p,
      certified_q2_initial p]
    ring
  exact jointOccupation_unique_nonneg
    ((1 : ℝ) / 5) ((3 : ℝ) / 7)
    ((2 : ℝ) / 9) ((4 : ℝ) / 11)
    (certifiedQ1 p) (certifiedQ2 p) (certifiedJoint p)
    (certified_q1_ode p) (certified_q2_ode p) (certified_joint_ode p)
    hinit t ht

/-- Exact joint observable for every matrix solution of the concrete GKSL law. -/
theorem certified_joint_exact (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedJoint p t =
      constantRatePopulation ((1 : ℝ) / 5) ((3 : ℝ) / 7) t *
      constantRatePopulation ((2 : ℝ) / 9) ((4 : ℝ) / 11) t := by
  rw [certified_joint_factorizes p t ht,
    certified_q1_exact p t ht, certified_q2_exact p t ht]

/-- Sharp finite-time bounds implied by the exact marginals. -/
theorem certified_q1_bounds (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ certifiedQ1 p t ∧ certifiedQ1 p t ≤ (7 : ℝ) / 22 := by
  rw [certified_q1_exact p t ht]
  have h := constantRatePopulation_bounds ((1 : ℝ) / 5) ((3 : ℝ) / 7) t
    (by norm_num) (by norm_num) (by norm_num) ht
  constructor
  · exact h.1
  · calc
      _ ≤ ((1 : ℝ) / 5) / (((1 : ℝ) / 5) + ((3 : ℝ) / 7)) := h.2
      _ = (7 : ℝ) / 22 := by norm_num

theorem certified_q2_bounds (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ certifiedQ2 p t ∧ certifiedQ2 p t ≤ (11 : ℝ) / 29 := by
  rw [certified_q2_exact p t ht]
  have h := constantRatePopulation_bounds ((2 : ℝ) / 9) ((4 : ℝ) / 11) t
    (by norm_num) (by norm_num) (by norm_num) ht
  constructor
  · exact h.1
  · calc
      _ ≤ ((2 : ℝ) / 9) / (((2 : ℝ) / 9) + ((4 : ℝ) / 11)) := h.2
      _ = (11 : ℝ) / 29 := by norm_num

/-- The exact upper bound, stronger than the original strict quarter bound. -/
theorem certified_joint_bounds (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ certifiedJoint p t ∧ certifiedJoint p t ≤ (7 : ℝ) / 58 := by
  rw [certified_joint_exact p t ht]
  constructor
  · exact mul_nonneg
      (constantRatePopulation_bounds ((1 : ℝ) / 5) ((3 : ℝ) / 7) t
        (by norm_num) (by norm_num) (by norm_num) ht).1
      (constantRatePopulation_bounds ((2 : ℝ) / 9) ((4 : ℝ) / 11) t
        (by norm_num) (by norm_num) (by norm_num) ht).1
  · exact sampleTwoSite_allTime t ht

/-- A numerically stronger certified threshold: 7/58 < 1/8. -/
theorem certified_joint_below_eighth (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) : certifiedJoint p t < (1 : ℝ) / 8 := by
  exact lt_of_le_of_lt (certified_joint_bounds p t ht).2 (by norm_num)

/-- Any rational or real threshold above 7/58 is automatically certified. -/
theorem certified_joint_below_any_threshold (p : CertifiedTwoQubitPath)
    (epsilon t : ℝ) (heps : (7 : ℝ) / 58 < epsilon) (ht : 0 ≤ t) :
    certifiedJoint p t < epsilon :=
  lt_of_le_of_lt (certified_joint_bounds p t ht).2 heps

/-- An explicit zero covariance certificate. -/
theorem certified_covariance_zero (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedJoint p t - certifiedQ1 p t * certifiedQ2 p t = 0 := by
  rw [certified_joint_factorizes p t ht, sub_self]

/-- Four classical computational-basis outcome weights. -/
noncomputable def certifiedP00 (p : CertifiedTwoQubitPath) (t : ℝ) : ℝ :=
  1 - certifiedQ1 p t - certifiedQ2 p t + certifiedJoint p t
noncomputable def certifiedP10 (p : CertifiedTwoQubitPath) (t : ℝ) : ℝ :=
  certifiedQ1 p t - certifiedJoint p t
noncomputable def certifiedP01 (p : CertifiedTwoQubitPath) (t : ℝ) : ℝ :=
  certifiedQ2 p t - certifiedJoint p t
noncomputable def certifiedP11 (p : CertifiedTwoQubitPath) (t : ℝ) : ℝ :=
  certifiedJoint p t

/-- Outcome weights form a normalized four-outcome distribution. -/
theorem certified_outcomes_normalized (p : CertifiedTwoQubitPath) (t : ℝ) :
    certifiedP00 p t + certifiedP10 p t +
      certifiedP01 p t + certifiedP11 p t = 1 := by
  unfold certifiedP00 certifiedP10 certifiedP01 certifiedP11
  ring

/-- Factorization is forced by the derived covariance theorem. -/
theorem certified_P00_factor (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedP00 p t = (1 - certifiedQ1 p t) * (1 - certifiedQ2 p t) := by
  unfold certifiedP00
  rw [certified_joint_factorizes p t ht]
  ring

theorem certified_P10_factor (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedP10 p t = certifiedQ1 p t * (1 - certifiedQ2 p t) := by
  unfold certifiedP10
  rw [certified_joint_factorizes p t ht]
  ring

theorem certified_P01_factor (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedP01 p t = (1 - certifiedQ1 p t) * certifiedQ2 p t := by
  unfold certifiedP01
  rw [certified_joint_factorizes p t ht]
  ring

/-- All four diagonal outcome probabilities are nonnegative, without
assuming a density-matrix PSD hypothesis. -/
theorem certified_P00_nonneg (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) : 0 ≤ certifiedP00 p t := by
  rw [certified_P00_factor p t ht]
  have h₁ := (certified_q1_bounds p t ht).2
  have h₂ := (certified_q2_bounds p t ht).2
  exact mul_nonneg (by linarith) (by linarith)

theorem certified_P10_nonneg (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) : 0 ≤ certifiedP10 p t := by
  rw [certified_P10_factor p t ht]
  have h₁ := (certified_q1_bounds p t ht).1
  have h₂ := (certified_q2_bounds p t ht).2
  exact mul_nonneg h₁ (by linarith)

theorem certified_P01_nonneg (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) : 0 ≤ certifiedP01 p t := by
  rw [certified_P01_factor p t ht]
  have h₁ := (certified_q1_bounds p t ht).2
  have h₂ := (certified_q2_bounds p t ht).1
  exact mul_nonneg (by linarith) h₂

theorem certified_P11_nonneg (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) : 0 ≤ certifiedP11 p t := by
  exact (certified_joint_bounds p t ht).1

/-- Full simplex membership of the four computational-basis outcomes. -/
theorem certified_four_outcomes_simplex (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    (0 ≤ certifiedP00 p t ∧ 0 ≤ certifiedP10 p t ∧
      0 ≤ certifiedP01 p t ∧ 0 ≤ certifiedP11 p t) ∧
    (certifiedP00 p t + certifiedP10 p t +
      certifiedP01 p t + certifiedP11 p t = 1) := by
  exact ⟨⟨certified_P00_nonneg p t ht,
    certified_P10_nonneg p t ht,
    certified_P01_nonneg p t ht,
    certified_P11_nonneg p t ht⟩,
    certified_outcomes_normalized p t⟩

/-- Each of the four outcome weights lies in the unit interval. -/
theorem certified_four_outcomes_le_one (p : CertifiedTwoQubitPath)
    (t : ℝ) (ht : 0 ≤ t) :
    certifiedP00 p t ≤ 1 ∧ certifiedP10 p t ≤ 1 ∧
    certifiedP01 p t ≤ 1 ∧ certifiedP11 p t ≤ 1 := by
  have h := certified_four_outcomes_simplex p t ht
  rcases h with ⟨⟨h00, h10, h01, h11⟩, hs⟩
  constructor
  · linarith
  constructor
  · linarith
  constructor
  · linarith
  · linarith

/-- The exact stationary rate ratios, recorded as rational constants. -/
theorem twoQubit_rate_relaxation₁ :
    ((1 : ℝ) / 5) + ((3 : ℝ) / 7) = (22 : ℝ) / 35 := by norm_num

theorem twoQubit_rate_relaxation₂ :
    ((2 : ℝ) / 9) + ((4 : ℝ) / 11) = (58 : ℝ) / 99 := by norm_num

theorem twoQubit_rate_stationary₁ :
    (((1 : ℝ) / 5) / (((1 : ℝ) / 5) + ((3 : ℝ) / 7))) =
      (7 : ℝ) / 22 := by norm_num

theorem twoQubit_rate_stationary₂ :
    (((2 : ℝ) / 9) / (((2 : ℝ) / 9) + ((4 : ℝ) / 11))) =
      (11 : ℝ) / 29 := by norm_num

theorem twoQubit_stationary_joint_probability :
    ((7 : ℝ) / 22) * ((11 : ℝ) / 29) = (7 : ℝ) / 58 := by norm_num

theorem twoQubit_stationary_joint_strict_eighth :
    ((7 : ℝ) / 58) < ((1 : ℝ) / 8) := by norm_num

end BinduEventInterface
