import BinduEventInterface.LocalGADKernelIdentityCandidate
import BinduEventInterface.DirectHybridNormCheckpointCandidate

/-!
A typed algebraic bridge for the final GAD hsite identity.
This is a source candidate, NOT a kernel-verified result until `lake build`
returns 0 and `#print axioms` is inspected in the pinned project.
No sorry, admit, or added axioms are used.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- Isolate the selected site from a product containing identity kernels offsite. -/
theorem bindu_site_product_split
    {N : ℕ} (k : Fin N)
    (P : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (u p v q : NQubitIndex N) :
    (∏ m : Fin N,
      if m = k then P (u m) (p m) (v m) (q m)
      else binduDeltaKernel (u m) (p m) (v m) (q m)) =
    (∏ m ∈ Finset.univ.erase k,
       binduDeltaKernel (u m) (p m) (v m) (q m)) *
       P (u k) (p k) (v k) (q k) := by
  classical
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ k)]
  simp only [if_pos rfl]
  congr 1
  refine Finset.prod_congr rfl (fun m hm => ?_)
  rw [if_neg (Finset.ne_of_mem_erase hm)]

/-- An equality of local four-index kernels lifts to the full site action. -/
theorem bindu_site_action_congr
    {N : ℕ} {a : Type*} [Fintype a]
    (k : Fin N)
    (P Q : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (h : ∀ u p v q, P u p v q = Q u p v q)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k P X = binduSiteKernelAction k Q X := by
  classical
  ext ⟨u, i⟩ ⟨v, j⟩
  simp only [binduSiteKernelAction, Matrix.of_apply]
  apply Finset.sum_congr rfl
  intro p _
  apply Finset.sum_congr rfl
  intro q _
  congr 1
  rw [bindu_site_product_split k P u p v q,
      bindu_site_product_split k Q u p v q,
      h (u k) (p k) (v k) (q k)]

/-- The site product is linear in its unique nontrivial local factor. -/
theorem bindu_site_product_two_term
    {N : ℕ} (k : Fin N)
    (P Q : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (c d : ℂ) (u p v q : NQubitIndex N) :
    (∏ m : Fin N,
      if m = k then
        c * P (u m) (p m) (v m) (q m) +
        d * Q (u m) (p m) (v m) (q m)
      else binduDeltaKernel (u m) (p m) (v m) (q m)) =
    c * (∏ m : Fin N,
      if m = k then P (u m) (p m) (v m) (q m)
      else binduDeltaKernel (u m) (p m) (v m) (q m)) +
    d * (∏ m : Fin N,
      if m = k then Q (u m) (p m) (v m) (q m)
      else binduDeltaKernel (u m) (p m) (v m) (q m)) := by
  rw [bindu_site_product_split k
      (fun a b c' d' => c * P a b c' d' + d * Q a b c' d') u p v q,
      bindu_site_product_split k P u p v q,
      bindu_site_product_split k Q u p v q]
  ring

end BinduEventInterface

#print axioms BinduEventInterface.bindu_site_product_split
#print axioms BinduEventInterface.bindu_site_action_congr
#print axioms BinduEventInterface.bindu_site_product_two_term
