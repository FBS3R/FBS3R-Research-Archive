import BinduEventInterface.LocalWeightedKrausCandidate

/-!
# Fixed two-level generalized amplitude-damping channel

A trace proof using the *previously kernel-checked* weighted Kraus
completeness relation, and an algebraic normal form for the semigroup.
This module is a NEW CANDIDATE, not a Lean-verified theorem until compiled.
-/

namespace BinduEventInterface

set_option maxHeartbeats 1200000
open Matrix

/-- Trace is preserved for all complex 2x2 matrices and all real p,r.
    No positivity assumptions on weights are needed for this algebraic identity. -/
theorem gadWeightedChannel_trace (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace (gadWeightedChannel p r M) = Matrix.trace M := by
  calc
    Matrix.trace (gadWeightedChannel p r M) =
      Matrix.trace ((∑ j : Fin 4,
        (gadWeight p r j : ℂ) •
          ((gadShape r j).conjTranspose * gadShape r j)) * M) := by
      unfold gadWeightedChannel
      rw [Matrix.trace_sum, Matrix.sum_mul, Matrix.trace_sum]
      apply Finset.sum_congr rfl
      intro j _
      simp only [Matrix.trace_smul, smul_mul_assoc]
      congr 1
      simpa only [mul_assoc] using
        (Matrix.trace_mul_comm (gadShape r j * M) (gadShape r j).conjTranspose)
    _ = Matrix.trace M := by
      rw [gadWeightedCompleteness, Matrix.one_mul]

/-- Explicit algebraic form of the weighted generalized amplitude damping map.
    The four matrix entries are polynomial expressions; no square roots appear. -/
private theorem gadWeightedChannel_normal_form (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    gadWeightedChannel p r M =
      !![((1 - p + p * r ^ 2 : ℝ) : ℂ) * M 0 0 +
          (((1 - p) * (1 - r ^ 2) : ℝ) : ℂ) * M 1 1,
          (r : ℂ) * M 0 1;
          (r : ℂ) * M 1 0,
          ((p * (1 - r ^ 2) : ℝ) : ℂ) * M 0 0 +
          ((p + (1 - p) * r ^ 2 : ℝ) : ℂ) * M 1 1] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [gadWeightedChannel, gadShape, gadWeight, Fin.sum_univ_four,
       Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two,
       Matrix.smul_apply, Matrix.conjTranspose_apply, Matrix.transpose_apply,
       Matrix.cons_val_zero, Matrix.cons_val_one,
       raising, lowering, Complex.conj_ofReal,
       Complex.ofReal_sub, Complex.ofReal_mul,
       Complex.ofReal_pow] <;> ring)

/-- Polynomial semigroup: damping coherences by r and populations by r².
    Holds for all real parameters, with no physicality hypotheses. -/
theorem gadWeightedChannel_comp (p r s : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    gadWeightedChannel p r (gadWeightedChannel p s M) =
      gadWeightedChannel p (r * s) M := by
  rw [gadWeightedChannel_normal_form p r (gadWeightedChannel p s M),
      gadWeightedChannel_normal_form p s M,
      gadWeightedChannel_normal_form p (r * s) M]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Matrix.cons_val_zero, Matrix.cons_val_one,
      Complex.ofReal_sub, Complex.ofReal_mul, Complex.ofReal_pow] <;>
    ring

end BinduEventInterface
