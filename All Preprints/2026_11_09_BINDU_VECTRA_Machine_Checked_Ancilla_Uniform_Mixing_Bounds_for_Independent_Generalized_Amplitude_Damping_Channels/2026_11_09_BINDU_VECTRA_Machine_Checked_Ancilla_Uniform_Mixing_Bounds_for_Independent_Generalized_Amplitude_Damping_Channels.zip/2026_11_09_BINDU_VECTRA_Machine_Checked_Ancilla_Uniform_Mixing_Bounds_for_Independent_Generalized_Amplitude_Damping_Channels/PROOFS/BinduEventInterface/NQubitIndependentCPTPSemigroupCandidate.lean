import BinduEventInterface.TwoQubitCPTPSemigroupCandidate

/-!
# P1: Arbitrary-`N` Independent-Qubit CPTP Semigroup, `4^N` Kraus Completeness, and `5^N - 1` Mode Weight Law

This module formalizes the arbitrary-`N` independent-qubit extension (`P1`) of the
two-qubit GAD/GKSL semigroup:

1. State-space multi-index `NQubitIndex N := Fin N → Fin 2` (`2^N` basis states) and
   Kraus/spectral mode multi-index `NQubitModeIndex N := Fin N → Fin 4` (`4^N` modes).
2. `N`-fold matrix tensor product `nQubitTensorProduct` (`⨂_{m=1}^N A_m`) and its fundamental
   algebraic laws:
   - `nQubitTensorProduct_one`: `⨂_{m=1}^N I₂ = I_{2^N}`
   - `nQubitTensorProduct_conjTranspose`: `(⨂ A_m)† = ⨂ A_m†`
   - `nQubitTensorProduct_mul`: `(⨂ A_m) (⨂ B_m) = ⨂ (A_m B_m)`
   - `trace_nQubitTensorProduct`: `Tr(⨂ A_m) = ∏_{m=1}^N Tr(A_m)`
   - `nQubitChannel_tensorProduct`: `(⨂ Φ_m)(⨂ X_m) = ⨂ Φ_m(X_m)`
3. The `4^N` Kraus operators `nQubitKraus G K t α = ⨂_{m=1}^N K^{(m)}_{α_m}(t)` and channel
   `nQubitKrausChannel G K t X = ∑_{α ∈ {0,1,2,3}^N} K_α(t) X K_α(t)†`.
4. Exact `4^N`-operator Kraus completeness `∑_α K_α(t)† K_α(t) = I_{2^N}` for arbitrary
   positive local rates `G m > 0, K m > 0` and `t ≥ 0`, together with trace preservation,
   Hermiticity preservation, PSD preservation, and complete positivity for arbitrary finite
   ancillas (`a` and `Fin d`).
5. Product equilibrium state `nQubitEquilibrium G K = ⨂_{m=1}^N ρ_*^{(m)}`, unit trace,
   and exact fixed-point stationarity `nQubitKrausChannel G K t (nQubitEquilibrium G K) = nQubitEquilibrium G K`.
6. The `4^N` spectral eigenvalues `nQubitEigenvalue G K α = ∑_{m=1}^N μ^{(m)}_{α_m}`,
   nonpositivity, uniqueness of the zero mode (`α = 0`), spectral gap bound
   `nQubitEigenvalue G K α ≤ -Δ` for every nonzero mode `α ≠ 0` whenever `Δ ≤ (G m + K m) / 2`
   for all `m`, and the exact nonstationary mode-weight identity
   `∑_{α ≠ 0} w_α = 5^N - 1`.
-/

namespace BinduEventInterface

open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- `N`-qubit computational basis multi-index `{0, 1}^N`, of cardinality `2^N`. -/
abbrev NQubitIndex (N : ℕ) := Fin N → Fin 2

/-- `N`-qubit Kraus and spectral mode multi-index `{0, 1, 2, 3}^N`, of cardinality `4^N`. -/
abbrev NQubitModeIndex (N : ℕ) := Fin N → Fin 4

/-- Cardinality of the `N`-qubit state index type `NQubitIndex N` is `2^N`. -/
theorem card_nQubitIndex (N : ℕ) :
    Fintype.card (NQubitIndex N) = 2 ^ N := by
  simp [NQubitIndex]

/-- Cardinality of the `N`-qubit mode index type `NQubitModeIndex N` is `4^N`. -/
theorem card_nQubitModeIndex (N : ℕ) :
    Fintype.card (NQubitModeIndex N) = 4 ^ N := by
  simp [NQubitModeIndex]

/-- `N`-fold tensor product of local `2 × 2` complex matrices:
`(⨂_{m=1}^N A_m)_{i, j} = ∏_{m=1}^N (A_m)_{i_m, j_m}`. -/
def nQubitTensorProduct {N : ℕ}
    (A : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  Matrix.of fun i j => ∏ m : Fin N, A m (i m) (j m)

@[simp]
theorem nQubitTensorProduct_apply {N : ℕ}
    (A : Fin N → Matrix (Fin 2) (Fin 2) ℂ)
    (i j : NQubitIndex N) :
    nQubitTensorProduct A i j = ∏ m : Fin N, A m (i m) (j m) :=
  rfl

/-- The `N`-fold tensor product of `2 × 2` identity matrices is the `2^N × 2^N` identity matrix. -/
theorem nQubitTensorProduct_one (N : ℕ) :
    nQubitTensorProduct (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) = 1 := by
  ext i j
  simp only [nQubitTensorProduct_apply, Matrix.one_apply]
  by_cases h : i = j
  · subst h
    simp
  · have hex : ∃ m : Fin N, i m ≠ j m := by
      by_contra hall
      push_neg at hall
      exact h (funext hall)
    rcases hex with ⟨m, hm⟩
    rw [if_neg h]
    exact Finset.prod_eq_zero (Finset.mem_univ m) (by simp [hm])

/-- Conjugate transpose commutes with the `N`-fold tensor product. -/
theorem nQubitTensorProduct_conjTranspose {N : ℕ}
    (A : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    (nQubitTensorProduct A)ᴴ =
      nQubitTensorProduct (fun m => (A m)ᴴ) := by
  ext i j
  simp [nQubitTensorProduct_apply, Matrix.conjTranspose_apply, map_prod]

/-- Multiplication of `N`-fold tensor products factorizes componentwise:
`(⨂ A_m) * (⨂ B_m) = ⨂ (A_m * B_m)`. -/
theorem nQubitTensorProduct_mul {N : ℕ}
    (A B : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitTensorProduct A * nQubitTensorProduct B =
      nQubitTensorProduct (fun m => A m * B m) := by
  ext i j
  simp only [Matrix.mul_apply, nQubitTensorProduct_apply, ← Finset.prod_mul_distrib]
  exact (Fintype.prod_sum (fun m k => A m (i m) k * B m k (j m))).symm

/-- Trace of an `N`-fold tensor product is the product of the local traces:
`Tr(⨂ A_m) = ∏_{m=1}^N Tr(A_m)`. -/
theorem trace_nQubitTensorProduct {N : ℕ}
    (A : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace (nQubitTensorProduct A) =
      ∏ m : Fin N, Matrix.trace (A m) := by
  simp only [Matrix.trace, Matrix.diag, nQubitTensorProduct_apply]
  exact (Fintype.prod_sum (fun m k => A m k k)).symm

/-!
## `4^N` Kraus Operators and Arbitrary-Input CPTP Semigroup for `N` Independent Qubits
-/

/-- The `4^N` Kraus operators for `N` independent qubits with local transition rates
`G, K : Fin N → ℝ` at time `t`:
`K_α(t) = ⨂_{m=1}^N K^{(m)}_{α_m}(t)`. -/
noncomputable def nQubitKraus {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (α : NQubitModeIndex N) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m => localKraus (G m) (K m) t (α m))

/-- The `N`-qubit Kraus quantum dynamical channel:
`Φ^{(N)}_t(X) = ∑_{α ∈ {0,1,2,3}^N} K_α(t) X K_α(t)†`. -/
noncomputable def nQubitKrausChannel {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  finiteKrausChannel (nQubitKraus G K t) X

/-- For any family of local Kraus operators `L_m : Fin 4 → M₂(ℂ)`, the sum of `(⨂ L_m(α_m))† (⨂ L_m(α_m))`
over all `4^N` multi-indices `α` equals the `N`-fold tensor product of the local sums
`∑_{a=0}^3 L_m(a)† L_m(a)`. -/
theorem sum_nQubitTensorProduct_conjTranspose_mul {N : ℕ}
    (L : Fin N → Fin 4 → Matrix (Fin 2) (Fin 2) ℂ) :
    (∑ α : NQubitModeIndex N,
      (nQubitTensorProduct (fun m => L m (α m)))ᴴ *
        nQubitTensorProduct (fun m => L m (α m))) =
      nQubitTensorProduct (fun m => ∑ a : Fin 4, (L m a)ᴴ * L m a) := by
  ext i j
  simp only [Matrix.sum_apply, nQubitTensorProduct_conjTranspose,
    nQubitTensorProduct_mul, nQubitTensorProduct_apply]
  calc
    ∑ α : NQubitModeIndex N, ∏ m : Fin N, ((L m (α m))ᴴ * L m (α m)) (i m) (j m)
      = ∏ m : Fin N, ∑ a : Fin 4, ((L m a)ᴴ * L m a) (i m) (j m) := by
          exact (Fintype.prod_sum (fun m a => ((L m a)ᴴ * L m a) (i m) (j m))).symm
    _ = ∏ m : Fin N, (∑ a : Fin 4, (L m a)ᴴ * L m a) (i m) (j m) := by
          refine Finset.prod_congr rfl (fun m _ => ?_)
          rw [Matrix.sum_apply]

/-- **Exact `4^N` Kraus completeness**: for all positive local rates `G m > 0, K m > 0`
and all `t ≥ 0`,
`∑_{α ∈ {0,1,2,3}^N} K_α(t)† K_α(t) = I_{2^N}`. -/
theorem nQubitKraus_completeness {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t : ℝ} (ht : 0 ≤ t) :
    (∑ α : NQubitModeIndex N,
      (nQubitKraus G K t α)ᴴ * nQubitKraus G K t α) = 1 := by
  unfold nQubitKraus
  rw [sum_nQubitTensorProduct_conjTranspose_mul]
  have hloc : (fun m : Fin N => ∑ a : Fin 4, (localKraus (G m) (K m) t a)ᴴ * localKraus (G m) (K m) t a) =
      (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) := by
    ext m : 1
    exact localKraus_completeness (G m) (K m) t (hG m) (hK m) ht
  rw [hloc, nQubitTensorProduct_one]

/-- **Trace preservation of the `N`-qubit Kraus channel** for arbitrary `X ∈ M_{2^N}(ℂ)` and `t ≥ 0`. -/
theorem nQubitKrausChannel_trace_preserving {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t : ℝ} (ht : 0 ≤ t)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    Matrix.trace (nQubitKrausChannel G K t X) = Matrix.trace X :=
  finiteKrausChannel_trace_preserving (nQubitKraus G K t)
    (nQubitKraus_completeness G K hG hK ht) X

/-- **Hermiticity preservation of the `N`-qubit Kraus channel** for all `t : ℝ`. -/
theorem nQubitKrausChannel_isHermitian {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ)
    {X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ}
    (hX : X.IsHermitian) :
    (nQubitKrausChannel G K t X).IsHermitian := by
  unfold Matrix.IsHermitian nQubitKrausChannel finiteKrausChannel
  rw [Matrix.conjTranspose_sum]
  refine Finset.sum_congr rfl fun α _ => ?_
  rw [Matrix.conjTranspose_mul, Matrix.conjTranspose_mul,
      Matrix.conjTranspose_conjTranspose, hX.eq, mul_assoc]

/-- **Positivity (PSD) preservation of the `N`-qubit Kraus channel** for all `t : ℝ`. -/
theorem nQubitKrausChannel_posSemidef {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ)
    {X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ}
    (hX : X.PosSemidef) :
    (nQubitKrausChannel G K t X).PosSemidef :=
  finiteKrausChannel_posSemidef (nQubitKraus G K t) X hX

/-- The `N`-qubit Kraus channel extended by the identity channel on an arbitrary finite ancilla `a`. -/
noncomputable def nQubitAncillaChannel {N : ℕ}
    (a : Type*) [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (t : ℝ)
    (R : Matrix (a × NQubitIndex N) (a × NQubitIndex N) ℂ) :
    Matrix (a × NQubitIndex N) (a × NQubitIndex N) ℂ :=
  finiteKrausChannel
    (fun α : NQubitModeIndex N =>
      Matrix.kronecker (1 : Matrix a a ℂ) (nQubitKraus G K t α)) R

/-- **Complete positivity of the `N`-qubit Kraus channel** for any finite ancilla type `a`. -/
theorem nQubitKrausChannel_ancilla_posSemidef {N : ℕ}
    (a : Type*) [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (t : ℝ)
    {R : Matrix (a × NQubitIndex N) (a × NQubitIndex N) ℂ}
    (hR : R.PosSemidef) :
    (nQubitAncillaChannel a G K t R).PosSemidef :=
  finiteKrausChannel_ancilla_posSemidef (nQubitKraus G K t) R hR

/-- **Complete positivity of the `N`-qubit Kraus channel** for every finite ancilla dimension `Fin d`. -/
theorem nQubitKrausChannel_finAncilla_posSemidef {N : ℕ}
    (d : ℕ) (G K : Fin N → ℝ) (t : ℝ)
    {R : Matrix (Fin d × NQubitIndex N) (Fin d × NQubitIndex N) ℂ}
    (hR : R.PosSemidef) :
    (nQubitAncillaChannel (Fin d) G K t R).PosSemidef :=
  finiteKrausChannel_ancilla_posSemidef (nQubitKraus G K t) R hR

/-- The `N`-qubit Kraus channel factorizes on `N`-fold tensor product inputs:
`Φ^{(N)}_t(⨂ X_m) = ⨂ Φ^{(m)}_t(X_m)` for `G m > 0, K m > 0, t ≥ 0`. -/
theorem nQubitKrausChannel_tensorProduct {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t : ℝ} (ht : 0 ≤ t)
    (X : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    nQubitKrausChannel G K t (nQubitTensorProduct X) =
      nQubitTensorProduct (fun m => localChannel (G m) (K m) t (X m)) := by
  ext i j
  simp only [nQubitKrausChannel, finiteKrausChannel, Matrix.sum_apply,
    nQubitKraus, nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul,
    nQubitTensorProduct_apply]
  calc
    ∑ α : NQubitModeIndex N,
        ∏ m : Fin N, (localKraus (G m) (K m) t (α m) * X m * (localKraus (G m) (K m) t (α m))ᴴ) (i m) (j m)
      = ∏ m : Fin N,
          ∑ a : Fin 4, (localKraus (G m) (K m) t a * X m * (localKraus (G m) (K m) t a)ᴴ) (i m) (j m) := by
          exact (Fintype.prod_sum (fun m a =>
            (localKraus (G m) (K m) t a * X m * (localKraus (G m) (K m) t a)ᴴ) (i m) (j m))).symm
    _ = ∏ m : Fin N, (finiteKrausChannel (localKraus (G m) (K m) t) (X m)) (i m) (j m) := by
          refine Finset.prod_congr rfl (fun m _ => ?_)
          rw [finiteKrausChannel, Matrix.sum_apply]
    _ = ∏ m : Fin N, (localChannel (G m) (K m) t (X m)) (i m) (j m) := by
          refine Finset.prod_congr rfl (fun m _ => ?_)
          rw [finiteKrausChannel_localKraus_eq_localChannel (G m) (K m) t (hG m) (hK m) ht (X m)]

/-!
## Product Equilibrium State and Stationarity for `N` Qubits
-/

/-- Local single-qubit equilibrium density matrix for transition rates `G, K`:
`ρ_* = diag(K/(G+K), G/(G+K))`. -/
noncomputable def localEquilibriumParam (G K : ℝ) : Matrix (Fin 2) (Fin 2) ℂ :=
  let p : ℂ := ((localEqProb G K : ℝ) : ℂ)
  !![ 1 - p, 0;
      0, p ]

/-- Each local equilibrium matrix has unit trace. -/
theorem localEquilibriumParam_trace (G K : ℝ) :
    Matrix.trace (localEquilibriumParam G K) = 1 := by
  simp [localEquilibriumParam, Matrix.trace, Matrix.diag, Fin.sum_univ_two]

/-- For any `G, K, t : ℝ`, the local equilibrium matrix is invariant under `localChannel G K t`. -/
theorem localChannel_equilibriumParam (G K t : ℝ) :
    localChannel G K t (localEquilibriumParam G K) = localEquilibriumParam G K := by
  unfold localChannel
  rw [gadWeightedChannel_eq_closed]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [gadClosedChannel, localEquilibriumParam] <;>
    ring

/-- The `N`-qubit product equilibrium state:
`ρ_*^{(N)} = ⨂_{m=1}^N diag(K_m/(G_m+K_m), G_m/(G_m+K_m))`. -/
noncomputable def nQubitEquilibrium {N : ℕ}
    (G K : Fin N → ℝ) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m => localEquilibriumParam (G m) (K m))

/-- The `N`-qubit product equilibrium state has unit trace `Tr(ρ_*^{(N)}) = 1`. -/
theorem nQubitEquilibrium_trace {N : ℕ}
    (G K : Fin N → ℝ) :
    Matrix.trace (nQubitEquilibrium G K) = 1 := by
  unfold nQubitEquilibrium
  rw [trace_nQubitTensorProduct]
  simp [localEquilibriumParam_trace]

/-- The `N`-qubit product equilibrium state is an exact fixed point of `nQubitKrausChannel G K t`
for all `t ≥ 0`. -/
theorem nQubitKrausChannel_equilibrium {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t : ℝ} (ht : 0 ≤ t) :
    nQubitKrausChannel G K t (nQubitEquilibrium G K) = nQubitEquilibrium G K := by
  unfold nQubitEquilibrium
  rw [nQubitKrausChannel_tensorProduct G K hG hK ht]
  have hloc :
      (fun m : Fin N => localChannel (G m) (K m) t (localEquilibriumParam (G m) (K m))) =
        (fun m : Fin N => localEquilibriumParam (G m) (K m)) :=
    funext (fun m => localChannel_equilibriumParam (G m) (K m) t)
  rw [hloc]

/-!
## `4^N` Liouvillian Eigenvalues, Spectral Gap `min_m (G_m + K_m)/2`, and `5^N - 1` Mode Weight Sum
-/

/-- Local single-qubit Liouvillian eigenvalue for rates `G, K` and mode index `a ∈ Fin 4`:
`0, -(G+K), -(G+K)/2, -(G+K)/2`. -/
noncomputable def localEigenvalueParam (G K : ℝ) : Fin 4 → ℝ
  | ⟨0, _⟩ => 0
  | ⟨1, _⟩ => -(G + K)
  | ⟨2, _⟩ => -(G + K) / 2
  | ⟨3, _⟩ => -(G + K) / 2

/-- For `G > 0, K > 0`, every local eigenvalue is nonpositive. -/
theorem localEigenvalueParam_nonpos {G K : ℝ}
    (hG : 0 < G) (hK : 0 < K) (a : Fin 4) :
    localEigenvalueParam G K a ≤ 0 := by
  fin_cases a <;>
    simp [localEigenvalueParam] <;>
    linarith

/-- For `G > 0, K > 0`, a local eigenvalue is zero iff the mode index is `0`. -/
theorem localEigenvalueParam_eq_zero_iff {G K : ℝ}
    (hG : 0 < G) (hK : 0 < K) (a : Fin 4) :
    localEigenvalueParam G K a = 0 ↔ a = 0 := by
  fin_cases a <;>
    simp [localEigenvalueParam] <;>
    linarith

/-- For `G > 0, K > 0` and any nonzero local mode `a ≠ 0`,
`localEigenvalueParam G K a ≤ -(G + K) / 2`. -/
theorem localEigenvalueParam_le_neg_half {G K : ℝ}
    (hG : 0 < G) (hK : 0 < K) {a : Fin 4} (ha : a ≠ 0) :
    localEigenvalueParam G K a ≤ -(G + K) / 2 := by
  fin_cases a
  · exact (ha rfl).elim
  · simp [localEigenvalueParam]
    linarith
  · simp [localEigenvalueParam]
  · simp [localEigenvalueParam]

/-- The `4^N` Liouvillian eigenvalues of the `N`-qubit independent generator:
`Λ_α = ∑_{m=1}^N μ^{(m)}_{α_m}`. -/
noncomputable def nQubitEigenvalue {N : ℕ}
    (G K : Fin N → ℝ) (α : NQubitModeIndex N) : ℝ :=
  ∑ m : Fin N, localEigenvalueParam (G m) (K m) (α m)

/-- At the zero mode `α = 0`, the `N`-qubit eigenvalue is `0`. -/
@[simp]
theorem nQubitEigenvalue_zero {N : ℕ} (G K : Fin N → ℝ) :
    nQubitEigenvalue G K (fun _ => 0) = 0 := by
  simp [nQubitEigenvalue, localEigenvalueParam]

/-- Every `N`-qubit eigenvalue is nonpositive for positive rates `G m > 0, K m > 0`. -/
theorem nQubitEigenvalue_nonpos {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (α : NQubitModeIndex N) :
    nQubitEigenvalue G K α ≤ 0 := by
  unfold nQubitEigenvalue
  exact Finset.sum_nonpos (fun m _ => localEigenvalueParam_nonpos (hG m) (hK m) (α m))

/-- **Simple zero mode (`4^N` spectrum)**: for positive local rates `G m > 0, K m > 0`,
`nQubitEigenvalue G K α = 0` if and only if `α = (fun _ => 0)`. -/
theorem nQubitEigenvalue_eq_zero_iff {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (α : NQubitModeIndex N) :
    nQubitEigenvalue G K α = 0 ↔ α = (fun _ => 0) := by
  constructor
  · intro hsum
    unfold nQubitEigenvalue at hsum
    have hall : ∀ m ∈ (Finset.univ : Finset (Fin N)),
        localEigenvalueParam (G m) (K m) (α m) = 0 :=
      (Finset.sum_eq_zero_iff_of_nonpos
        (fun m _ => localEigenvalueParam_nonpos (hG m) (hK m) (α m))).mp hsum
    funext m
    exact (localEigenvalueParam_eq_zero_iff (hG m) (hK m) (α m)).mp (hall m (Finset.mem_univ m))
  · rintro rfl
    exact nQubitEigenvalue_zero G K

/-- **Exact local spectral bound for every nonzero `N`-qubit mode**: if `α m₀ ≠ 0`, then
`nQubitEigenvalue G K α ≤ -(G m₀ + K m₀) / 2`. -/
theorem nQubitEigenvalue_le_of_ne_zero_at {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {α : NQubitModeIndex N} {m₀ : Fin N} (hm₀ : α m₀ ≠ 0) :
    nQubitEigenvalue G K α ≤ -(G m₀ + K m₀) / 2 := by
  unfold nQubitEigenvalue
  have hsplit := Finset.add_sum_erase (Finset.univ : Finset (Fin N))
    (fun m => localEigenvalueParam (G m) (K m) (α m)) (Finset.mem_univ m₀)
  rw [← hsplit]
  have hrest : ∑ m ∈ Finset.univ.erase m₀, localEigenvalueParam (G m) (K m) (α m) ≤ 0 :=
    Finset.sum_nonpos (fun m _ => localEigenvalueParam_nonpos (hG m) (hK m) (α m))
  have hm₀_bound : localEigenvalueParam (G m₀) (K m₀) (α m₀) ≤ -(G m₀ + K m₀) / 2 :=
    localEigenvalueParam_le_neg_half (hG m₀) (hK m₀) hm₀
  linarith

/-- **`N`-qubit spectral gap theorem (`min_m (G_m + K_m)/2`)**: if `Δ ≤ (G m + K m) / 2` for every
qubit `m : Fin N`, then every nonstationary mode `α ≠ 0` satisfies
`nQubitEigenvalue G K α ≤ -Δ`. -/
theorem nQubit_spectral_gap_bound {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {Δ : ℝ} (hΔ : ∀ m : Fin N, Δ ≤ (G m + K m) / 2)
    {α : NQubitModeIndex N} (hα : α ≠ (fun _ => 0)) :
    nQubitEigenvalue G K α ≤ -Δ := by
  have hex : ∃ m₀ : Fin N, α m₀ ≠ 0 := by
    by_contra hall
    push_neg at hall
    exact hα (funext hall)
  rcases hex with ⟨m₀, hm₀⟩
  have h1 := nQubitEigenvalue_le_of_ne_zero_at G K hG hK hm₀
  have h2 := hΔ m₀
  linarith

/-- `N`-qubit mode weight `w_α = ∏_{m=1}^N w_{α_m}`, where `w = (1, 2, 1, 1)`. -/
def nQubitModeWeight {N : ℕ} (α : NQubitModeIndex N) : ℝ :=
  ∏ m : Fin N, localModeWeight (α m)

/-- At the stationary mode `α = 0`, the `N`-qubit mode weight is `1`. -/
@[simp]
theorem nQubitModeWeight_zero (N : ℕ) :
    nQubitModeWeight (fun _ : Fin N => (0 : Fin 4)) = 1 := by
  simp [nQubitModeWeight, localModeWeight]

/-- The sum of all `4^N` mode weights is `5^N`. -/
theorem nQubitModeWeight_sum_univ (N : ℕ) :
    (∑ α : NQubitModeIndex N, nQubitModeWeight α) = (5 : ℝ) ^ N := by
  unfold nQubitModeWeight
  have hprod := (Fintype.prod_sum (fun (_ : Fin N) (a : Fin 4) => localModeWeight a)).symm
  rw [hprod]
  have hloc : (∑ a : Fin 4, localModeWeight a) = 5 := by
    simp [localModeWeight, Fin.sum_univ_four]
    norm_num
  simp [hloc]

/-- **Exact `5^N - 1` nonstationary mode-weight law**:
`∑_{α ≠ 0} w_α = 5^N - 1` for every `N : ℕ` (yielding `5^2 - 1 = 24` at `N = 2`). -/
theorem nQubitModeWeight_sum_nonstationary (N : ℕ) :
    (∑ α ∈ (Finset.univ : Finset (NQubitModeIndex N)).erase (fun _ => 0),
      nQubitModeWeight α) = (5 : ℝ) ^ N - 1 := by
  have hsplit := Finset.add_sum_erase
    (Finset.univ : Finset (NQubitModeIndex N))
    nQubitModeWeight (Finset.mem_univ (fun _ : Fin N => (0 : Fin 4)))
  have huniv := nQubitModeWeight_sum_univ N
  have hzero := nQubitModeWeight_zero N
  linarith

/-- Specialization of the `5^N - 1` law to `N = 2` gives `24`. -/
theorem nQubitModeWeight_sum_nonstationary_two :
    (∑ α ∈ (Finset.univ : Finset (NQubitModeIndex 2)).erase (fun _ => 0),
      nQubitModeWeight α) = 24 := by
  rw [nQubitModeWeight_sum_nonstationary 2]
  norm_num

end BinduEventInterface
