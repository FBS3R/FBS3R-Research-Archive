import BinduEventInterface.TensorKroneckerCandidate

/-!
# Actual Kronecker pump/loss identities

The tensor factors have arbitrary finite dimensions. This discharges both
commutator hypotheses and the one-site pump/loss equation of the existing
`embedded_*_event` theorems for a concrete Kronecker construction.

The pinned kernel accepts this module and the root interface imports it.
No theorem assumption asserts the desired operator identity.
-/
namespace BinduEventInterface
open Matrix

/-- Embedding with an identity spectator factor preserves the dissipator. -/
theorem dissipator_kronecker_one
    {a b : Type*} [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    (L Q : Matrix a a ℂ) :
    dissipatorAdjoint
        (Matrix.kronecker L (1 : Matrix b b ℂ))
        (Matrix.kronecker Q (1 : Matrix b b ℂ)) =
      Matrix.kronecker (dissipatorAdjoint L Q)
        (1 : Matrix b b ℂ) := by
  have hm (A B : Matrix a a ℂ) :
      Matrix.kronecker A (1 : Matrix b b ℂ) *
        Matrix.kronecker B (1 : Matrix b b ℂ) =
      Matrix.kronecker (A * B) (1 : Matrix b b ℂ) := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul A B (1 : Matrix b b ℂ)
        (1 : Matrix b b ℂ)).symm
  unfold dissipatorAdjoint
  rw [kronecker_conjTranspose_v419]
  simp only [Matrix.conjTranspose_one, hm]
  ext i j
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply, smul_eq_mul]
  ring

/-- Actual pump on the first tensor block, arbitrary finite spectators. -/
theorem kronecker_embedded_pump
    {b : Type*} [Fintype b] [DecidableEq b]
    (R : Matrix b b ℂ) :
    dissipatorAdjoint
      (Matrix.kronecker raising (1 : Matrix b b ℂ))
      (Matrix.kronecker occupation (1 : Matrix b b ℂ) *
        Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ) R) =
      (1 - Matrix.kronecker occupation (1 : Matrix b b ℂ)) *
        Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ) R := by
  apply embedded_pump_event
  · rw [dissipator_kronecker_one, local_pump_identity]
    have hI :
        Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ)
            (1 : Matrix b b ℂ) =
          (1 : Matrix (Fin 2 × b) (Fin 2 × b) ℂ) :=
      Matrix.one_kronecker_one
    rw [← hI]
    ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
    simp only [Matrix.kronecker, Matrix.kroneckerMap_apply,
      Matrix.sub_apply, sub_mul]
  · exact (kronecker_left_right_commute raising R).symm
  · exact kronecker_left_right_adjoint_commute raising R

/-- Actual loss on the first tensor block, arbitrary finite spectators. -/
theorem kronecker_embedded_loss
    {b : Type*} [Fintype b] [DecidableEq b]
    (R : Matrix b b ℂ) :
    dissipatorAdjoint
      (Matrix.kronecker lowering (1 : Matrix b b ℂ))
      (Matrix.kronecker occupation (1 : Matrix b b ℂ) *
        Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ) R) =
      (-Matrix.kronecker occupation (1 : Matrix b b ℂ)) *
        Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ) R := by
  apply embedded_loss_event
  · rw [dissipator_kronecker_one, local_loss_identity]
    ext i j
    simp [Matrix.kronecker, Matrix.kroneckerMap_apply,
      Matrix.neg_apply]
  · exact (kronecker_left_right_commute lowering R).symm
  · exact kronecker_left_right_adjoint_commute lowering R

#print axioms dissipator_kronecker_one
#print axioms kronecker_embedded_pump
#print axioms kronecker_embedded_loss
end BinduEventInterface
