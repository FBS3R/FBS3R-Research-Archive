import Mathlib

/-!
A Lean 4 / Mathlib candidate module for the binomial group closure identity,
barrier arithmetic, and exact threshold implications.
The file has no `sorry`, `admit`, or new axioms. Compilation evidence is recorded separately in AUDIT_OUTPUT/lean_audit.json.
-/
namespace BinduEventInterface

/-- The binomial normalization identity used in the group Heisenberg hierarchy. -/
theorem choose_absorption_identity (k r : ℕ) (hr : 1 ≤ r) (hkr : r ≤ k) :
    r * Nat.choose k r = (k - r + 1) * Nat.choose k (r - 1) := by
  have hpred : r - 1 + 1 = r := by omega
  have hsub : k - (r - 1) = k - r + 1 := by omega
  have h := Nat.choose_succ_right_eq k (r - 1)
  rw [hpred, hsub] at h
  calc
    r * Nat.choose k r = Nat.choose k r * r := Nat.mul_comm _ _
    _ = Nat.choose k (r - 1) * (k - r + 1) := h
    _ = (k - r + 1) * Nat.choose k (r - 1) := Nat.mul_comm _ _

/-- The surplus of certified loss over pump at a rational candidate bound. -/
def barrierSurplus (kappa gamma b : ℝ) : ℝ :=
  kappa * b - gamma * (1 - b)

/-- A root-free check is equivalent to the standard square-root barrier check.
The two sign hypotheses are indispensable; squaring without them is unsound. -/
theorem barrier_rational_iff
    (u kappa gamma b : ℝ) (hu : 0 ≤ u) (hb0 : 0 ≤ b) (hb1 : b ≤ 1) :
    (2 * u * Real.sqrt (b * (1 - b)) + gamma * (1 - b) ≤ kappa * b) ↔
    (0 ≤ barrierSurplus kappa gamma b ∧
      4 * u ^ 2 * (b * (1 - b)) ≤ (barrierSurplus kappa gamma b) ^ 2) := by
  let z : ℝ := b * (1 - b)
  have hz : 0 ≤ z := mul_nonneg hb0 (sub_nonneg.mpr hb1)
  let q : ℝ := 2 * u * Real.sqrt z
  have hq0 : 0 ≤ q := by dsimp [q]; positivity
  have hq_sq : q ^ 2 = 4 * u ^ 2 * z := by
    dsimp [q]
    rw [mul_pow, mul_pow, Real.sq_sqrt hz]
    ring
  constructor
  · intro h
    have hle : q ≤ barrierSurplus kappa gamma b := by
      dsimp [q, z, barrierSurplus] at *
      linarith
    have hr0 : 0 ≤ barrierSurplus kappa gamma b := le_trans hq0 hle
    constructor
    · exact hr0
    · rw [← hq_sq]
      nlinarith
  · rintro ⟨hr0, hsquare⟩
    have hle : q ≤ barrierSurplus kappa gamma b := by
      rw [← hq_sq] at hsquare
      nlinarith
    dsimp [q, z, barrierSurplus] at hle
    linarith

/-- Number of symmetric occupation coordinates for independently controlled groups. -/
def groupObserverDim (groupSizes : List ℕ) : ℕ :=
  (groupSizes.map (fun k => k + 1)).prod

theorem groupObserverDim_pos (groupSizes : List ℕ) :
    0 < groupObserverDim groupSizes := by
  unfold groupObserverDim
  induction groupSizes with
  | nil => simp
  | cons k ks ih =>
    simp only [List.map_cons, List.prod_cons]
    exact Nat.mul_pos (Nat.succ_pos k) ih

/-- A factored rational interval bound, without floating-point arithmetic. -/
structure GroupIntervalData where
  k : ℕ
  gammaPlus : ℚ
  kappaMinus : ℚ
  deriving DecidableEq, Repr

def groupFactor (g : GroupIntervalData) : ℚ :=
  g.gammaPlus / (g.gammaPlus + g.kappaMinus)

def minimaxBound (groups : List GroupIntervalData) : ℚ :=
  (groups.map (fun g => groupFactor g ^ g.k)).prod

def validGroupRate (g : GroupIntervalData) : Bool :=
  decide (0 < g.k ∧ 0 ≤ g.gammaPlus ∧ 0 ≤ g.kappaMinus ∧
    0 < g.gammaPlus + g.kappaMinus)

def verifyRationalBound (groups : List GroupIntervalData) (eps : ℚ) : Bool :=
  groups.all validGroupRate && decide (0 < eps ∧ minimaxBound groups < eps)

/-- Arithmetic-only soundness: the checked rational expression is below epsilon. -/
theorem verifyRationalBound_sound (groups : List GroupIntervalData) (eps : ℚ)
    (h : verifyRationalBound groups eps = true) : minimaxBound groups < eps := by
  unfold verifyRationalBound at h
  have h2 := (Bool.and_eq_true_iff.mp h).2
  exact (of_decide_eq_true h2).2

end BinduEventInterface
