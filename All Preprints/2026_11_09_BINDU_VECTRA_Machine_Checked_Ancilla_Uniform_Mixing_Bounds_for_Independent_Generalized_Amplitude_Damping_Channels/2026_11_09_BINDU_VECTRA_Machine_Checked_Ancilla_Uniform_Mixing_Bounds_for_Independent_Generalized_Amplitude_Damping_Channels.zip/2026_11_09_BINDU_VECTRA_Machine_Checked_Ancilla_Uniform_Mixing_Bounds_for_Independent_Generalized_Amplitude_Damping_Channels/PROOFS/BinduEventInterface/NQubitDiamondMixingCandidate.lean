import BinduEventInterface.NQubitAsymptoticConvergenceCandidate

/-!
# Single-Qubit Diamond Decomposition, Ancilla-Stabilized Replacer, and Unconditional Spectral Schatten-1 Decay

This module extends the verified `N`-qubit semigroup and asymptotic convergence hierarchy with:

1. **Exact single-qubit diamond-norm channel decomposition** (`gadClosedChannel_eq_diamond_decomp`,
   `gadWeightedChannel_sub_replacer_eq`, `localChannel_sub_replacer_eq`):
   for every complex `2 × 2` matrix `X ∈ M₂(ℂ)` and all rates `G, K > 0`, `t ≥ 0`,
   `localChannel G K t X - localReplacerMap p X = a(1 - a) (X - D(X)) + a² (X - localReplacerMap p X)`,
   where `D(X) = (X + Z X Z) / 2` is computational-basis dephasing (`Z = diag(1, -1)`),
   `localReplacerMap p X = Tr(X) diag(1 - p, p)` is the stationary replacement channel, and
   `a = localDampingR G K t = exp(-(G + K) t / 2)`.

2. **Arbitrary-`N` stationary replacement CPTP channel, `N = 0` boundary identity, ancilla-marginal
   preservation, and diamond-norm envelopes** (`nQubitReplacerChannel`,
   `nQubitReplacerKraus_completeness`, `nQubitReplacerChannel_eq_finiteKrausChannel`,
   `nQubitKrausChannel_sub_replacer_zero_qubits`,
   `nQubitReplacerKraus_ancilla_eq_kronecker_partialTrace`,
   `nQubitDiamondEnvelope_le_weakEnvelope`, `twoQubitDiamondEnvelope_le_four_exp_gap`).

3. **Unconditional spectral singular-value `schattenOneSpectralNorm` properties and Hilbert–Schmidt
   (Frobenius) bridge** (`isHermitian_trace_eq_sum_eigenvalues`,
   `sum_sq_singularValues_eq_frobeniusNormSq`, `frobeniusNorm_le_schattenOneSpectralNorm`,
   `schattenOneSpectralNorm_le_sqrt_card_mul_frobeniusNorm`,
   `schattenOneSpectralNorm_zero`, `schattenOneSpectralNorm_eq_zero_iff`,
   `entry_norm_le_schattenOneSpectralNorm`).

4. **Exact rational two-qubit Hilbert–Schmidt superoperator majorant certificate
   (`∑ B_{ij,uv}² = 3127886 / 101761 < 36`) and unconditional concrete `schattenOneSpectralNorm`
   exponential decay bounds with prefactors `12` and `24`** (`twoQubitSuperopMajorant_sum_sq`,
   `twoQubitKrausChannel_frobenius_decay_6`,
   `twoQubit_unconditional_schattenOneSpectralNorm_decay_12`,
   `twoQubit_unconditional_schattenOneSpectralNorm_decay_24`).

All proofs are constructive in Lean 4.19.0 without `sorry`, `admit`, or additional axioms.
-/

namespace BinduEventInterface

open Matrix Filter
open scoped Matrix ComplexOrder Topology

/-!
## 1. Exact Single-Qubit Channel Decomposition (`Φ - R = a(1-a)(Id - D) + a²(Id - R)`)
-/

/-- Single-qubit Pauli-`Z` phase matrix `diag(1, -1)`. -/
def localPauliZ : Matrix (Fin 2) (Fin 2) ℂ :=
  !![(1 : ℂ), 0; 0, -1]

/-- `localPauliZ` is Hermitian. -/
theorem localPauliZ_isHermitian : localPauliZ.IsHermitian := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [localPauliZ, Matrix.conjTranspose_apply]

/-- `localPauliZ * localPauliZ = I₂`. -/
theorem localPauliZ_mul_self :
    localPauliZ * localPauliZ = (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [localPauliZ, Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply]

/-- Unitarity of `localPauliZ`: `Zᴴ * Z = I₂`. -/
theorem localPauliZ_conjTranspose_mul_self :
    localPauliZ.conjTranspose * localPauliZ = (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  rw [localPauliZ_isHermitian.eq, localPauliZ_mul_self]

/-- Computational-basis dephasing superoperator `D(X) = (X + Z X Z) / 2`. -/
noncomputable def localDephasingMap (X : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  ((1 : ℂ) / 2) • (X + localPauliZ * X * localPauliZ)

/-- Coherence-extraction superoperator `C(X) = (X - Z X Z) / 2`. -/
noncomputable def localCoherenceMap (X : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  ((1 : ℂ) / 2) • (X - localPauliZ * X * localPauliZ)

/-- Single-qubit stationary replacement channel `R_p(X) = Tr(X) • diag(1 - p, p)`. -/
noncomputable def localReplacerMap (p : ℝ) (X : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  Matrix.trace X • !![(1 - (p : ℂ)), 0; 0, (p : ℂ)]

/-- `localDephasingMap X` extracts the diagonal entries `diag(X 0 0, X 1 1)`. -/
theorem localDephasingMap_eq_diag (X : Matrix (Fin 2) (Fin 2) ℂ) :
    localDephasingMap X = !![X 0 0, 0; 0, X 1 1] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [localDephasingMap, localPauliZ, Matrix.mul_apply, Matrix.vecMul, dotProduct,
       Fin.sum_univ_two, Matrix.smul_apply]
     try ring)

/-- `localCoherenceMap X` extracts the off-diagonal entries `[[0, X 0 1], [X 1 0, 0]]`. -/
theorem localCoherenceMap_eq_offDiag (X : Matrix (Fin 2) (Fin 2) ℂ) :
    localCoherenceMap X = !![0, X 0 1; X 1 0, 0] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [localCoherenceMap, localPauliZ, Matrix.mul_apply, Matrix.vecMul, dotProduct,
       Fin.sum_univ_two, Matrix.smul_apply]
     try ring)

/-- `localCoherenceMap X = X - localDephasingMap X` for every `X ∈ M₂(ℂ)`. -/
theorem localCoherenceMap_eq_sub_dephasing (X : Matrix (Fin 2) (Fin 2) ℂ) :
    localCoherenceMap X = X - localDephasingMap X := by
  rw [localCoherenceMap_eq_offDiag, localDephasingMap_eq_diag]
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp; try ring)

/-- The stationary replacement channel `localReplacerMap p` coincides with `gadClosedChannel p 0`. -/
theorem localReplacerMap_eq_gadClosedChannel_zero (p : ℝ)
    (X : Matrix (Fin 2) (Fin 2) ℂ) :
    localReplacerMap p X = gadClosedChannel p 0 X := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [localReplacerMap, gadClosedChannel, Matrix.trace, Matrix.diag_apply,
       Fin.sum_univ_two, Matrix.smul_apply]
     try ring)

/-- The stationary replacement channel `localReplacerMap p` coincides with `gadWeightedChannel p 0`. -/
theorem localReplacerMap_eq_gadWeightedChannel_zero (p : ℝ)
    (X : Matrix (Fin 2) (Fin 2) ℂ) :
    localReplacerMap p X = gadWeightedChannel p 0 X := by
  rw [gadWeightedChannel_eq_closed, localReplacerMap_eq_gadClosedChannel_zero]

/-- For `0 ≤ p ≤ 1`, `localReplacerMap p` is the genuine 4-Kraus CPTP channel
`finiteKrausChannel (gadKraus p 0)`. -/
theorem localReplacerMap_eq_finiteKrausChannel (p : ℝ) (hp : 0 ≤ p ∧ p ≤ 1)
    (X : Matrix (Fin 2) (Fin 2) ℂ) :
    localReplacerMap p X = finiteKrausChannel (gadKraus p 0) X := by
  rw [localReplacerMap_eq_gadWeightedChannel_zero,
      finiteKrausChannel_gadKraus_eq_gadWeightedChannel p 0 hp ⟨le_rfl, zero_le_one⟩ X]

/-- **Exact superoperator decomposition of `gadClosedChannel`**:
`gadClosedChannel p r X = R_p(X) + r C(X) + r² (D(X) - R_p(X))` for every `X ∈ M₂(ℂ)`. -/
theorem gadClosedChannel_eq_diamond_decomp (p r : ℝ)
    (X : Matrix (Fin 2) (Fin 2) ℂ) :
    gadClosedChannel p r X =
      localReplacerMap p X + (r : ℂ) • localCoherenceMap X +
        ((r : ℂ) ^ 2) • (localDephasingMap X - localReplacerMap p X) := by
  rw [localDephasingMap_eq_diag, localCoherenceMap_eq_offDiag]
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [gadClosedChannel, localReplacerMap, Matrix.trace, Matrix.diag_apply,
       Fin.sum_univ_two, Matrix.smul_apply]
     try ring)

/-- **Exact convex-difference decomposition of `gadWeightedChannel`**:
`gadWeightedChannel p r X - localReplacerMap p X = r(1 - r)(X - D(X)) + r²(X - R_p(X))`
for every `2 × 2` complex matrix `X`. -/
theorem gadWeightedChannel_sub_replacer_eq (p r : ℝ)
    (X : Matrix (Fin 2) (Fin 2) ℂ) :
    gadWeightedChannel p r X - localReplacerMap p X =
      ((r * (1 - r) : ℝ) : ℂ) • (X - localDephasingMap X) +
        ((r ^ 2 : ℝ) : ℂ) • (X - localReplacerMap p X) := by
  rw [gadWeightedChannel_eq_closed, localDephasingMap_eq_diag]
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [gadClosedChannel, localReplacerMap, Matrix.trace, Matrix.diag_apply,
       Fin.sum_univ_two, Matrix.smul_apply, Complex.ofReal_mul, Complex.ofReal_sub,
       Complex.ofReal_pow]
     try ring)

/-- **Exact single-qubit time-dependent channel decomposition (`localChannel`)**:
for all `G, K, t ∈ ℝ` and every `X ∈ M₂(ℂ)`,
`localChannel G K t X - localReplacerMap p X = a(1 - a)(X - D(X)) + a²(X - localReplacerMap p X)`
where `p = localEqProb G K` and `a = localDampingR G K t`. -/
theorem localChannel_sub_replacer_eq (G K t : ℝ)
    (X : Matrix (Fin 2) (Fin 2) ℂ) :
    localChannel G K t X - localReplacerMap (localEqProb G K) X =
      ((localDampingR G K t * (1 - localDampingR G K t) : ℝ) : ℂ) •
        (X - localDephasingMap X) +
      (((localDampingR G K t) ^ 2 : ℝ) : ℂ) •
        (X - localReplacerMap (localEqProb G K) X) := by
  unfold localChannel
  exact gadWeightedChannel_sub_replacer_eq (localEqProb G K) (localDampingR G K t) X

/-- For `0 ≤ r ≤ 1`, both local decomposition weights `r * (1 - r)` and `r ^ 2` are nonnegative,
and `r * (1 - r) + 2 * r ^ 2 = r + r ^ 2 ≤ 2 * r`. -/
theorem localDiamondWeights_nonneg_and_sum {r : ℝ} (hr0 : 0 ≤ r) (hr1 : r ≤ 1) :
    0 ≤ r * (1 - r) ∧
    0 ≤ r ^ 2 ∧
    r * (1 - r) + 2 * r ^ 2 = r + r ^ 2 ∧
    r + r ^ 2 ≤ 2 * r := by
  refine ⟨mul_nonneg hr0 (by linarith), sq_nonneg r, by ring, ?_⟩
  nlinarith

/-!
## 2. Arbitrary-`N` Stationary Replacer Channel, Ancilla Marginal Preservation, and Diamond Envelopes
-/

/-- The `N`-qubit stationary replacement channel `R_N(X) = Tr(X) • nQubitEquilibrium G K`. -/
noncomputable def nQubitReplacerChannel {N : ℕ}
    (G K : Fin N → ℝ)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  Matrix.trace X • nQubitEquilibrium G K

/-- Explicit `4^N` Kraus operators `R_α = otimes_m K^{(m)}_{α_m}(r = 0)` for the `N`-qubit
stationary replacement channel. -/
noncomputable def nQubitReplacerKraus {N : ℕ}
    (G K : Fin N → ℝ) (α : NQubitModeIndex N) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m : Fin N => gadKraus (localEqProb (G m) (K m)) 0 (α m))

/-- `4^N`-operator Kraus completeness `∑_α R_α† R_α = I_{2^N}` for `nQubitReplacerKraus`. -/
theorem nQubitReplacerKraus_completeness {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) :
    ∑ α : NQubitModeIndex N,
      (nQubitReplacerKraus G K α).conjTranspose * nQubitReplacerKraus G K α =
        (1 : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) := by
  unfold nQubitReplacerKraus
  rw [sum_nQubitTensorProduct_conjTranspose_mul]
  have hloc :
      (fun m : Fin N =>
        ∑ j : Fin 4,
          (gadKraus (localEqProb (G m) (K m)) 0 j).conjTranspose *
            gadKraus (localEqProb (G m) (K m)) 0 j) =
      (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) := by
    funext m
    have hp := localEqProb_bounds (G m) (K m) (hG m) (hK m)
    exact gadKraus_completeness (localEqProb (G m) (K m)) 0 hp ⟨le_rfl, zero_le_one⟩
  rw [hloc, nQubitTensorProduct_one]

/-- On `N`-fold tensor products, `finiteKrausChannel (nQubitReplacerKraus G K)` factors into
local replacement channels `localReplacerMap (localEqProb (G m) (K m)) (M m)`. -/
theorem nQubitReplacerKraus_tensorProduct {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) :
    finiteKrausChannel (nQubitReplacerKraus G K) (nQubitTensorProduct M) =
      nQubitReplacerChannel G K (nQubitTensorProduct M) := by
  ext i j
  simp only [finiteKrausChannel, nQubitReplacerKraus, Matrix.sum_apply,
    nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul,
    nQubitTensorProduct_apply]
  calc
    (∑ α : NQubitModeIndex N,
      ∏ m : Fin N,
        (gadKraus (localEqProb (G m) (K m)) 0 (α m) * M m *
          (gadKraus (localEqProb (G m) (K m)) 0 (α m))ᴴ) (i m) (j m))
        = ∏ m : Fin N,
          ∑ a : Fin 4,
            (gadKraus (localEqProb (G m) (K m)) 0 a * M m *
              (gadKraus (localEqProb (G m) (K m)) 0 a)ᴴ) (i m) (j m) := by
          exact (Fintype.prod_sum (fun m a =>
            (gadKraus (localEqProb (G m) (K m)) 0 a * M m *
              (gadKraus (localEqProb (G m) (K m)) 0 a)ᴴ) (i m) (j m))).symm
    _ = ∏ m : Fin N,
          (localReplacerMap (localEqProb (G m) (K m)) (M m)) (i m) (j m) := by
          refine Finset.prod_congr rfl (fun m _ => ?_)
          have hp := localEqProb_bounds (G m) (K m) (hG m) (hK m)
          have hch := (localReplacerMap_eq_finiteKrausChannel
            (localEqProb (G m) (K m)) hp (M m)).symm
          simpa only [finiteKrausChannel, Matrix.sum_apply] using
            congr_fun (congr_fun hch (i m)) (j m)
    _ = nQubitReplacerChannel G K (nQubitTensorProduct M) i j := by
          simp only [nQubitReplacerChannel, trace_nQubitTensorProduct,
            nQubitEquilibrium, nQubitTensorProduct_apply,
            localReplacerMap, localEquilibriumParam,
            Matrix.smul_apply, smul_eq_mul,
            Finset.prod_mul_distrib]

/-- **Equivalence of `nQubitReplacerChannel` and its `4^N`-Kraus representation on all `X ∈ M_{2^N}(ℂ)`**. -/
theorem nQubitReplacerChannel_eq_finiteKrausChannel {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) :
    finiteKrausChannel (nQubitReplacerKraus G K) X = nQubitReplacerChannel G K X := by
  calc
    finiteKrausChannel (nQubitReplacerKraus G K) X
      = finiteKrausChannel (nQubitReplacerKraus G K)
          (∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
            X i j • nQubitProductUnit i j) := by
              exact congrArg (finiteKrausChannel (nQubitReplacerKraus G K))
                (matrix_eq_sum_nQubitProductUnit X)
    _ = ∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
          X i j • finiteKrausChannel (nQubitReplacerKraus G K)
            (nQubitProductUnit i j) := by
              rw [finiteKrausChannel_sum]
              refine Finset.sum_congr rfl (fun i _ => ?_)
              rw [finiteKrausChannel_sum]
              exact Finset.sum_congr rfl (fun j _ =>
                finiteKrausChannel_smul (nQubitReplacerKraus G K)
                  (X i j) (nQubitProductUnit i j))
    _ = ∑ i : NQubitIndex N, ∑ j : NQubitIndex N,
          X i j • nQubitReplacerChannel G K (nQubitProductUnit i j) := by
              refine Finset.sum_congr rfl (fun i _ =>
                Finset.sum_congr rfl (fun j _ => ?_))
              rw [nQubitProductUnit,
                nQubitReplacerKraus_tensorProduct G K hG hK]
    _ = nQubitReplacerChannel G K X := by
              simp only [nQubitReplacerChannel]
              conv_rhs => rw [matrix_eq_sum_nQubitProductUnit X]
              simp only [Matrix.trace_sum, Finset.sum_smul,
                Matrix.trace_smul, smul_smul, smul_eq_mul]

/-- Boundary case `N = 0`: on the 1-dimensional space `M_{2^0}(ℂ)`,
`nQubitKrausChannel G K t X = nQubitReplacerChannel G K X = X`, so their difference vanishes
identically for all `t ≥ 0`. -/
theorem nQubitKrausChannel_sub_replacer_zero_qubits
    (G K : Fin 0 → ℝ) {t : ℝ} (ht : 0 ≤ t)
    (X : Matrix (NQubitIndex 0) (NQubitIndex 0) ℂ) :
    nQubitKrausChannel G K t X - nQubitReplacerChannel G K X = 0 := by
  have hG : ∀ m : Fin 0, 0 < G m := fun m => Fin.elim0 m
  have hK : ∀ m : Fin 0, 0 < K m := fun m => Fin.elim0 m
  rw [nQubitKrausChannel_eq_spectralFlow G K hG hK ht X]
  unfold nQubitReplacerChannel
  rw [nQubitSpectralFlow_sub_stationary_projection G K t X]
  have hempty : (Finset.univ.erase (fun _ : Fin 0 => (0 : Fin 4))) = ∅ := by
    ext α
    simp only [Finset.mem_erase, Finset.mem_univ, and_true, Finset.not_mem_empty, iff_false,
      not_not]
    ext m
    exact Fin.elim0 m
  rw [hempty, Finset.sum_empty]

/-- Partial trace over the `N`-qubit system space `NQubitIndex N`, leaving the ancilla matrix
on `Matrix a a ℂ`. -/
noncomputable def nQubitAncillaPartialTrace {a : Type*} {N : ℕ} [Fintype a]
    (Y : Matrix (a × NQubitIndex N) (a × NQubitIndex N) ℂ) :
    Matrix a a ℂ :=
  fun u v => ∑ i : NQubitIndex N, Y (u, i) (v, i)

/-- **Ancilla-stabilized stationary replacement identity**:
for any finite ancilla type `a` and any joint matrix `Y ∈ M_{a × 2^N}(ℂ)`, the ancilla-lifted
`4^N`-Kraus replacement channel `(I_a ⊗ R_N)(Y)` equals
`Matrix.kronecker (nQubitAncillaPartialTrace Y) (nQubitEquilibrium G K)`, preserving the exact
ancilla marginal `nQubitAncillaPartialTrace Y`. -/
theorem nQubitReplacerKraus_ancilla_eq_kronecker_partialTrace
    {a : Type*} [Fintype a] [DecidableEq a] {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (Y : Matrix (a × NQubitIndex N) (a × NQubitIndex N) ℂ) :
    finiteKrausChannel
      (fun α : NQubitModeIndex N =>
        Matrix.kronecker (1 : Matrix a a ℂ) (nQubitReplacerKraus G K α)) Y =
      Matrix.kronecker (nQubitAncillaPartialTrace Y) (nQubitEquilibrium G K) := by
  ext ⟨u, i⟩ ⟨v, j⟩
  unfold finiteKrausChannel
  rw [Matrix.sum_apply]
  let Yslice : Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
    Matrix.of (fun p q => Y (u, p) (v, q))
  have hslice :
      ∀ α : NQubitModeIndex N,
        (Matrix.kronecker (1 : Matrix a a ℂ) (nQubitReplacerKraus G K α) * Y *
          (Matrix.kronecker (1 : Matrix a a ℂ) (nQubitReplacerKraus G K α)).conjTranspose)
            (u, i) (v, j) =
        (nQubitReplacerKraus G K α * Yslice *
          (nQubitReplacerKraus G K α).conjTranspose) i j := by
    intro α
    simp [Yslice, Matrix.mul_apply, Matrix.conjTranspose_apply,
      Matrix.kronecker, Matrix.kroneckerMap_apply,
      Matrix.of_apply, Fintype.sum_prod_type, Matrix.one_apply,
      mul_assoc, mul_left_comm, mul_comm]
    rw [Finset.sum_eq_single v]
    · simp
    · intro w _ hwv
      simp [Ne.symm hwv]
    · intro hv
      exact (hv (Finset.mem_univ v)).elim
  simp_rw [hslice]
  have hsum := congr_fun (congr_fun
    (nQubitReplacerChannel_eq_finiteKrausChannel G K hG hK Yslice) i) j
  simpa [Yslice, finiteKrausChannel, Matrix.sum_apply, nQubitReplacerChannel,
    nQubitAncillaPartialTrace, Matrix.trace, Matrix.diag_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply, Matrix.of_apply,
    Matrix.smul_apply, smul_eq_mul] using hsum

/-- Improved `N`-qubit diamond-norm envelope `min(2, ∑_m (a_m(t) + a_m(t)²))`. -/
noncomputable def nQubitDiamondEnvelope {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) : ℝ :=
  min 2 (∑ m : Fin N, (localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2))

/-- Standard `N`-qubit diamond-norm weak envelope `2 * min(1, ∑_m a_m(t))`. -/
noncomputable def nQubitDiamondWeakEnvelope {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) : ℝ :=
  2 * min 1 (∑ m : Fin N, localDampingR (G m) (K m) t)

/-- At `N = 0`, both diamond envelopes vanish identically. -/
theorem nQubitDiamondEnvelope_zero_qubits (G K : Fin 0 → ℝ) (t : ℝ) :
    nQubitDiamondEnvelope G K t = 0 ∧ nQubitDiamondWeakEnvelope G K t = 0 := by
  simp [nQubitDiamondEnvelope, nQubitDiamondWeakEnvelope]

/-- For `t ≥ 0`, `0 ≤ nQubitDiamondEnvelope G K t ≤ nQubitDiamondWeakEnvelope G K t ≤ 2 * ∑_m a_m(t)`. -/
theorem nQubitDiamondEnvelope_le_weakEnvelope {N : ℕ}
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t : ℝ} (ht : 0 ≤ t) :
    0 ≤ nQubitDiamondEnvelope G K t ∧
    nQubitDiamondEnvelope G K t ≤ nQubitDiamondWeakEnvelope G K t ∧
    nQubitDiamondWeakEnvelope G K t ≤ 2 * ∑ m : Fin N, localDampingR (G m) (K m) t := by
  unfold nQubitDiamondEnvelope nQubitDiamondWeakEnvelope
  have hterm_nonneg :
      ∀ m : Fin N, 0 ≤ localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2 := by
    intro m
    have hr := localDampingR_bounds (G m) (K m) t (hG m) (hK m) ht
    linarith [hr.1, sq_nonneg (localDampingR (G m) (K m) t)]
  have hterm_le :
      ∀ m : Fin N,
        localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2 ≤
          2 * localDampingR (G m) (K m) t := by
    intro m
    have hr := localDampingR_bounds (G m) (K m) t (hG m) (hK m) ht
    exact (localDiamondWeights_nonneg_and_sum hr.1 hr.2).2.2.2
  have hsum_le :
      (∑ m : Fin N, (localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2)) ≤
        2 * ∑ m : Fin N, localDampingR (G m) (K m) t := by
    rw [Finset.mul_sum]
    exact Finset.sum_le_sum (fun m _ => hterm_le m)
  refine ⟨le_min (by norm_num) (Finset.sum_nonneg (fun m _ => hterm_nonneg m)), ?_, ?_⟩
  · rw [mul_min_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 2), mul_one]
    exact min_le_min le_rfl hsum_le
  · exact mul_le_mul_of_nonneg_left (min_le_right _ _) (by norm_num)

/-- For the concrete two-qubit rates `(G₁, K₁) = (1/5, 3/7)` and `(G₂, K₂) = (2/9, 4/11)` and
all `t ≥ 0`, the diamond-norm envelopes satisfy
`min(2, e^{-11t/35} + e^{-22t/35} + e^{-29t/99} + e^{-58t/99}) ≤ 2 min(1, e^{-11t/35} + e^{-29t/99}) ≤ 4 e^{-29t/99}`. -/
theorem twoQubitDiamondEnvelope_le_four_exp_gap {t : ℝ} (ht : 0 ≤ t) :
    min 2 (Real.exp (-(11 / 35 : ℝ) * t) + Real.exp (-(22 / 35 : ℝ) * t) +
           Real.exp (-(29 / 99 : ℝ) * t) + Real.exp (-(58 / 99 : ℝ) * t)) ≤
      2 * min 1 (Real.exp (-(11 / 35 : ℝ) * t) + Real.exp (-(29 / 99 : ℝ) * t)) ∧
    2 * min 1 (Real.exp (-(11 / 35 : ℝ) * t) + Real.exp (-(29 / 99 : ℝ) * t)) ≤
      4 * Real.exp (-(29 / 99 : ℝ) * t) := by
  have ha1_le_1 : Real.exp (-(11 / 35 : ℝ) * t) ≤ 1 :=
    Real.exp_le_one_iff.mpr (by nlinarith)
  have ha2_le_1 : Real.exp (-(29 / 99 : ℝ) * t) ≤ 1 :=
    Real.exp_le_one_iff.mpr (by nlinarith)
  have ha1_sq : Real.exp (-(22 / 35 : ℝ) * t) ≤ Real.exp (-(11 / 35 : ℝ) * t) :=
    Real.exp_le_exp.mpr (by nlinarith)
  have ha2_sq : Real.exp (-(58 / 99 : ℝ) * t) ≤ Real.exp (-(29 / 99 : ℝ) * t) :=
    Real.exp_le_exp.mpr (by nlinarith)
  have ha1_le_a2 : Real.exp (-(11 / 35 : ℝ) * t) ≤ Real.exp (-(29 / 99 : ℝ) * t) :=
    Real.exp_le_exp.mpr (by nlinarith)
  constructor
  · rw [mul_min_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 2), mul_one]
    refine min_le_min le_rfl (by linarith)
  · have hmin : min 1 (Real.exp (-(11 / 35 : ℝ) * t) + Real.exp (-(29 / 99 : ℝ) * t)) ≤
        Real.exp (-(11 / 35 : ℝ) * t) + Real.exp (-(29 / 99 : ℝ) * t) := min_le_right _ _
    linarith

/-!
## 3. Unconditional Spectral Singular-Value `schattenOneSpectralNorm` Properties and Frobenius Bridge
-/

/-- The trace of any Hermitian matrix `A ∈ M_n(ℂ)` equals the sum of its real eigenvalues. -/
theorem isHermitian_trace_eq_sum_eigenvalues {n : Type*} [Fintype n] [DecidableEq n]
    {A : Matrix n n ℂ} (hA : A.IsHermitian) :
    Matrix.trace A = ∑ i : n, (hA.eigenvalues i : ℂ) := by
  have hspec := congr_arg Matrix.trace hA.spectral_theorem
  rw [Matrix.trace_mul_comm, ← Matrix.mul_assoc,
      unitary.coe_star_mul_self, Matrix.one_mul, Matrix.trace_diagonal] at hspec
  exact hspec

/-- The real part of the trace of any Hermitian matrix `A ∈ M_n(ℂ)` equals the sum of its
real eigenvalues. -/
theorem isHermitian_trace_re_eq_sum_eigenvalues {n : Type*} [Fintype n] [DecidableEq n]
    {A : Matrix n n ℂ} (hA : A.IsHermitian) :
    (Matrix.trace A).re = ∑ i : n, hA.eigenvalues i := by
  rw [isHermitian_trace_eq_sum_eigenvalues hA, Complex.re_sum]
  simp

/-- Squared Frobenius (Hilbert–Schmidt) norm `‖X‖_F² = ∑_{i,j} ‖X i j‖²`. -/
noncomputable def frobeniusNormSq {n : Type*} [Fintype n] (X : Matrix n n ℂ) : ℝ :=
  ∑ i : n, ∑ j : n, ‖X i j‖ ^ 2

/-- Frobenius (Hilbert–Schmidt) norm `‖X‖_F = √(∑_{i,j} ‖X i j‖²)`. -/
noncomputable def frobeniusNorm {n : Type*} [Fintype n] (X : Matrix n n ℂ) : ℝ :=
  Real.sqrt (frobeniusNormSq X)

/-- `frobeniusNormSq X` is nonnegative. -/
theorem frobeniusNormSq_nonneg {n : Type*} [Fintype n] (X : Matrix n n ℂ) :
    0 ≤ frobeniusNormSq X :=
  Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => sq_nonneg _))

/-- `frobeniusNorm X` is nonnegative. -/
theorem frobeniusNorm_nonneg {n : Type*} [Fintype n] (X : Matrix n n ℂ) :
    0 ≤ frobeniusNorm X :=
  Real.sqrt_nonneg _

/-- `(Matrix.trace (Xᴴ * X)).re = frobeniusNormSq X` for every `X ∈ M_n(ℂ)`. -/
theorem trace_conjTranspose_mul_self_re_eq_frobeniusNormSq
    {n : Type*} [Fintype n] (X : Matrix n n ℂ) :
    (Matrix.trace (X.conjTranspose * X)).re = frobeniusNormSq X := by
  unfold frobeniusNormSq
  simp only [Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, Matrix.conjTranspose_apply,
    Complex.re_sum]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
  rw [Complex.star_def, mul_comm, Complex.mul_conj, Complex.ofReal_re,
      Complex.normSq_eq_norm_sq]

/-- **Exact sum-of-squares identity for singular values**:
the sum of squares of the singular values `√(λ_i(Xᴴ X))` equals `frobeniusNormSq X`. -/
theorem sum_sq_singularValues_eq_frobeniusNormSq
    {n : Type*} [Fintype n] [DecidableEq n] (X : Matrix n n ℂ) :
    (∑ i : n, (Real.sqrt ((Matrix.posSemidef_conjTranspose_mul_self X).1.eigenvalues i)) ^ 2) =
      frobeniusNormSq X := by
  have hsq :
      ∀ i : n,
        (Real.sqrt ((Matrix.posSemidef_conjTranspose_mul_self X).1.eigenvalues i)) ^ 2 =
          (Matrix.posSemidef_conjTranspose_mul_self X).1.eigenvalues i :=
    fun i => Real.sq_sqrt ((Matrix.posSemidef_conjTranspose_mul_self X).eigenvalues_nonneg i)
  simp_rw [hsq]
  rw [← isHermitian_trace_re_eq_sum_eigenvalues (Matrix.posSemidef_conjTranspose_mul_self X).1,
      trace_conjTranspose_mul_self_re_eq_frobeniusNormSq]

/-- Helper inequality: for nonnegative reals `f i ≥ 0`, `∑ (f i)² ≤ (∑ f i)²`. -/
private theorem sum_sq_le_sq_sum_of_nonneg {ι : Type*} (s : Finset ι) (f : ι → ℝ)
    (hf : ∀ i ∈ s, 0 ≤ f i) :
    (∑ i ∈ s, (f i) ^ 2) ≤ (∑ i ∈ s, f i) ^ 2 := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
      rw [Finset.sum_insert ha, Finset.sum_insert ha]
      have ha0 : 0 ≤ f a := hf a (Finset.mem_insert_self a s)
      have hs0 : 0 ≤ ∑ i ∈ s, f i :=
        Finset.sum_nonneg (fun i hi => hf i (Finset.mem_insert_of_mem hi))
      have hih : (∑ i ∈ s, (f i) ^ 2) ≤ (∑ i ∈ s, f i) ^ 2 :=
        ih (fun i hi => hf i (Finset.mem_insert_of_mem hi))
      nlinarith

/-- **Unconditional lower bound on `schattenOneSpectralNorm` by `frobeniusNorm`**:
`frobeniusNorm X ≤ schattenOneSpectralNorm X` for every `X ∈ M_n(ℂ)`. -/
theorem frobeniusNorm_le_schattenOneSpectralNorm
    {n : Type*} [Fintype n] [DecidableEq n] (X : Matrix n n ℂ) :
    frobeniusNorm X ≤ schattenOneSpectralNorm X := by
  unfold frobeniusNorm
  rw [← Real.sqrt_sq (schattenOneSpectralNorm_nonneg X)]
  apply Real.sqrt_le_sqrt
  rw [← sum_sq_singularValues_eq_frobeniusNormSq X]
  unfold schattenOneSpectralNorm
  exact sum_sq_le_sq_sum_of_nonneg Finset.univ _ (fun i _ => Real.sqrt_nonneg _)

/-- **Unconditional upper bound on `schattenOneSpectralNorm` by `√(card n) * frobeniusNorm`**:
`schattenOneSpectralNorm X ≤ Real.sqrt (Fintype.card n) * frobeniusNorm X` for every `X ∈ M_n(ℂ)`. -/
theorem schattenOneSpectralNorm_le_sqrt_card_mul_frobeniusNorm
    {n : Type*} [Fintype n] [DecidableEq n] (X : Matrix n n ℂ) :
    schattenOneSpectralNorm X ≤ Real.sqrt (Fintype.card n) * frobeniusNorm X := by
  unfold frobeniusNorm
  have hcs := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ : Finset n)
    (fun _ : n => (1 : ℝ))
    (fun i : n => Real.sqrt ((Matrix.posSemidef_conjTranspose_mul_self X).1.eigenvalues i))
  simp only [one_mul, one_pow, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one,
    sum_sq_singularValues_eq_frobeniusNormSq X] at hcs
  rw [← Real.sqrt_mul (Nat.cast_nonneg (Fintype.card n)),
      ← Real.sqrt_sq (schattenOneSpectralNorm_nonneg X)]
  unfold schattenOneSpectralNorm
  exact Real.sqrt_le_sqrt hcs

/-- On the two-qubit space `TwoQubitIndex = Fin 2 × Fin 2` (`card = 4`),
`schattenOneSpectralNorm X ≤ 2 * frobeniusNorm X` for every `X ∈ M₄(ℂ)`. -/
theorem schattenOneSpectralNorm_twoQubit_le_two_mul_frobeniusNorm
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    schattenOneSpectralNorm X ≤ 2 * frobeniusNorm X := by
  have h := schattenOneSpectralNorm_le_sqrt_card_mul_frobeniusNorm X
  have hcard : (Fintype.card TwoQubitIndex : ℝ) = 4 := by
    simp [TwoQubitIndex]
  have hsqrt4 : Real.sqrt 4 = (2 : ℝ) := by
    rw [(by norm_num : (4 : ℝ) = (2 : ℝ) ^ 2), Real.sqrt_sq (by norm_num)]
  rwa [hcard, hsqrt4] at h

/-- **Unconditional zero property (`schattenOneSpectralNorm 0 = 0`)**. -/
theorem schattenOneSpectralNorm_zero {n : Type*} [Fintype n] [DecidableEq n] :
    schattenOneSpectralNorm (0 : Matrix n n ℂ) = 0 := by
  have hle := schattenOneSpectralNorm_le_sqrt_card_mul_frobeniusNorm (0 : Matrix n n ℂ)
  have hf0 : frobeniusNorm (0 : Matrix n n ℂ) = 0 := by
    unfold frobeniusNorm frobeniusNormSq
    simp
  rw [hf0, mul_zero] at hle
  exact le_antisymm hle (schattenOneSpectralNorm_nonneg 0)

/-- Every matrix entry is bounded by `frobeniusNorm X` and hence by `schattenOneSpectralNorm X`. -/
theorem entry_norm_le_schattenOneSpectralNorm
    {n : Type*} [Fintype n] [DecidableEq n] (X : Matrix n n ℂ) (i j : n) :
    ‖X i j‖ ≤ schattenOneSpectralNorm X := by
  refine le_trans ?_ (frobeniusNorm_le_schattenOneSpectralNorm X)
  unfold frobeniusNorm frobeniusNormSq
  rw [← Real.sqrt_sq (norm_nonneg (X i j))]
  apply Real.sqrt_le_sqrt
  have h1 : ‖X i j‖ ^ 2 ≤ ∑ v : n, ‖X i v‖ ^ 2 :=
    Finset.single_le_sum (fun v _ => sq_nonneg ‖X i v‖) (Finset.mem_univ j)
  have h2 : (∑ v : n, ‖X i v‖ ^ 2) ≤ ∑ u : n, ∑ v : n, ‖X u v‖ ^ 2 :=
    Finset.single_le_sum (fun u _ => Finset.sum_nonneg (fun v _ => sq_nonneg ‖X u v‖))
      (Finset.mem_univ i)
  exact le_trans h1 h2

/-- **Unconditional definiteness of `schattenOneSpectralNorm`**:
`schattenOneSpectralNorm X = 0 ↔ X = 0`. -/
theorem schattenOneSpectralNorm_eq_zero_iff
    {n : Type*} [Fintype n] [DecidableEq n] (X : Matrix n n ℂ) :
    schattenOneSpectralNorm X = 0 ↔ X = 0 := by
  constructor
  · intro h0
    ext i j
    have hij : ‖X i j‖ ≤ 0 := by
      rw [← h0]
      exact entry_norm_le_schattenOneSpectralNorm X i j
    exact norm_le_zero_iff.mp hij
  · intro hX
    rw [hX, schattenOneSpectralNorm_zero]

/-!
## 4. Exact Rational Two-Qubit Hilbert–Schmidt Certificate (`3127886 / 101761 < 36`) and Unconditional `schattenOneSpectralNorm` Decay Bounds (`12` and `24`)
-/

/-- Local real-valued absolute mode majorant `M^{(1)}_{i,j,u,v} = ∑_{a=0}^3 ‖(E^{(1)}_a)_{i,j}‖ ‖(D^{(1)}_a)_{v,u}‖`
for qubit 1. -/
noncomputable def localMajorantM1 (i j u v : Fin 2) : ℝ :=
  ∑ a : Fin 4, ‖localEigenMatrix1 a i j‖ * ‖localDualMatrix1 a v u‖

/-- Local real-valued stationary mode majorant `A^{(1)}_{i,j,u,v} = ‖(E^{(1)}_0)_{i,j}‖ ‖(D^{(1)}_0)_{v,u}‖`
for qubit 1. -/
noncomputable def localMajorantA1 (i j u v : Fin 2) : ℝ :=
  ‖localEigenMatrix1 0 i j‖ * ‖localDualMatrix1 0 v u‖

/-- Local real-valued absolute mode majorant `M^{(2)}_{i,j,u,v} = ∑_{b=0}^3 ‖(E^{(2)}_b)_{i,j}‖ ‖(D^{(2)}_b)_{v,u}‖`
for qubit 2. -/
noncomputable def localMajorantM2 (i j u v : Fin 2) : ℝ :=
  ∑ b : Fin 4, ‖localEigenMatrix2 b i j‖ * ‖localDualMatrix2 b v u‖

/-- Local real-valued stationary mode majorant `A^{(2)}_{i,j,u,v} = ‖(E^{(2)}_0)_{i,j}‖ ‖(D^{(2)}_0)_{v,u}‖`
for qubit 2. -/
noncomputable def localMajorantA2 (i j u v : Fin 2) : ℝ :=
  ‖localEigenMatrix2 0 i j‖ * ‖localDualMatrix2 0 v u‖

/-- The `16 × 16` two-qubit nonstationary superoperator majorant
`B_{(i,j),(u,v)} = ∑_{p ≠ (0,0)} ‖(E_p)_{i,j}‖ ‖(D_p)_{v,u}‖`. -/
noncomputable def twoQubitSuperopMajorant (i j u v : TwoQubitIndex) : ℝ :=
  ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
    ‖twoQubitEigenMatrix p i j‖ * ‖twoQubitDualMatrix p v u‖

/-- Each entry of `twoQubitSuperopMajorant` factors into the local majorants as
`M^{(1)} M^{(2)} - A^{(1)} A^{(2)}`. -/
theorem twoQubitSuperopMajorant_eq_factored (i j u v : TwoQubitIndex) :
    twoQubitSuperopMajorant i j u v =
      localMajorantM1 i.1 j.1 u.1 v.1 * localMajorantM2 i.2 j.2 u.2 v.2 -
        localMajorantA1 i.1 j.1 u.1 v.1 * localMajorantA2 i.2 j.2 u.2 v.2 := by
  unfold twoQubitSuperopMajorant localMajorantM1 localMajorantM2 localMajorantA1 localMajorantA2
  have htot :
      (∑ p : Fin 4 × Fin 4, ‖twoQubitEigenMatrix p i j‖ * ‖twoQubitDualMatrix p v u‖) =
        (∑ a : Fin 4, ‖localEigenMatrix1 a i.1 j.1‖ * ‖localDualMatrix1 a v.1 u.1‖) *
          (∑ b : Fin 4, ‖localEigenMatrix2 b i.2 j.2‖ * ‖localDualMatrix2 b v.2 u.2‖) := by
    rw [Fintype.sum_prod_type, Finset.sum_mul]
    refine Finset.sum_congr rfl (fun a _ => ?_)
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl (fun b _ => ?_)
    simp only [twoQubitEigenMatrix, twoQubitDualMatrix, Matrix.kronecker,
      Matrix.kroneckerMap_apply, norm_mul]
    ring
  have h0 :
      ‖twoQubitEigenMatrix (0, 0) i j‖ * ‖twoQubitDualMatrix (0, 0) v u‖ =
        (‖localEigenMatrix1 0 i.1 j.1‖ * ‖localDualMatrix1 0 v.1 u.1‖) *
          (‖localEigenMatrix2 0 i.2 j.2‖ * ‖localDualMatrix2 0 v.2 u.2‖) := by
    simp only [twoQubitEigenMatrix, twoQubitDualMatrix, Matrix.kronecker,
      Matrix.kroneckerMap_apply, norm_mul]
    ring
  have hadd := Finset.add_sum_erase Finset.univ
    (fun p : Fin 4 × Fin 4 => ‖twoQubitEigenMatrix p i j‖ * ‖twoQubitDualMatrix p v u‖)
    (Finset.mem_univ ((0 : Fin 4), (0 : Fin 4)))
  dsimp only at hadd
  linarith

/-- Exact rational evaluation of the 16-term quadratic sums for qubit 1:
`(∑ M₁² = 758/121, ∑ M₁ A₁ = 258/121, ∑ A₁² = 137/121)`. -/
theorem localMajorant1_sum_identities :
    (∑ i : Fin 2, ∑ j : Fin 2, ∑ u : Fin 2, ∑ v : Fin 2,
      (localMajorantM1 i j u v) ^ 2) = 758 / 121 ∧
    (∑ i : Fin 2, ∑ j : Fin 2, ∑ u : Fin 2, ∑ v : Fin 2,
      localMajorantM1 i j u v * localMajorantA1 i j u v) = 258 / 121 ∧
    (∑ i : Fin 2, ∑ j : Fin 2, ∑ u : Fin 2, ∑ v : Fin 2,
      (localMajorantA1 i j u v) ^ 2) = 137 / 121 := by
  simp only [localMajorantM1, localMajorantA1, Fin.sum_univ_two, Fin.sum_univ_four,
    localEigenMatrix1, localDualMatrix1, twoQubitEqLocal1, localDualPop1, localPopulationMode,
    raising, lowering, Matrix.one_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.head_cons]
  norm_num

/-- Exact rational evaluation of the 16-term quadratic sums for qubit 2:
`(∑ M₂² = 5144/841, ∑ M₂ A₂ = 1731/841, ∑ A₂² = 890/841)`. -/
theorem localMajorant2_sum_identities :
    (∑ i : Fin 2, ∑ j : Fin 2, ∑ u : Fin 2, ∑ v : Fin 2,
      (localMajorantM2 i j u v) ^ 2) = 5144 / 841 ∧
    (∑ i : Fin 2, ∑ j : Fin 2, ∑ u : Fin 2, ∑ v : Fin 2,
      localMajorantM2 i j u v * localMajorantA2 i j u v) = 1731 / 841 ∧
    (∑ i : Fin 2, ∑ j : Fin 2, ∑ u : Fin 2, ∑ v : Fin 2,
      (localMajorantA2 i j u v) ^ 2) = 890 / 841 := by
  simp only [localMajorantM2, localMajorantA2, Fin.sum_univ_two, Fin.sum_univ_four,
    localEigenMatrix2, localDualMatrix2, twoQubitEqLocal2, localDualPop2, localPopulationMode,
    raising, lowering, Matrix.one_apply, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.head_cons]
  norm_num

/-- **Exact rational Hilbert–Schmidt majorant identity (`3127886 / 101761 < 36`)**:
`∑_{i,j,u,v} (twoQubitSuperopMajorant i j u v)² = 3127886 / 101761 ≤ 36`. -/
theorem twoQubitSuperopMajorant_sum_sq :
    (∑ i : TwoQubitIndex, ∑ j : TwoQubitIndex,
      ∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
        (twoQubitSuperopMajorant i j u v) ^ 2) = 3127886 / 101761 ∧
    (∑ i : TwoQubitIndex, ∑ j : TwoQubitIndex,
      ∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
        (twoQubitSuperopMajorant i j u v) ^ 2) ≤ 36 := by
  have hsum :
      (∑ i : TwoQubitIndex, ∑ j : TwoQubitIndex,
        ∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
          (twoQubitSuperopMajorant i j u v) ^ 2) =
      (∑ i₁ : Fin 2, ∑ j₁ : Fin 2, ∑ u₁ : Fin 2, ∑ v₁ : Fin 2,
        (localMajorantM1 i₁ j₁ u₁ v₁) ^ 2) *
      (∑ i₂ : Fin 2, ∑ j₂ : Fin 2, ∑ u₂ : Fin 2, ∑ v₂ : Fin 2,
        (localMajorantM2 i₂ j₂ u₂ v₂) ^ 2) -
      2 *
      (∑ i₁ : Fin 2, ∑ j₁ : Fin 2, ∑ u₁ : Fin 2, ∑ v₁ : Fin 2,
        localMajorantM1 i₁ j₁ u₁ v₁ * localMajorantA1 i₁ j₁ u₁ v₁) *
      (∑ i₂ : Fin 2, ∑ j₂ : Fin 2, ∑ u₂ : Fin 2, ∑ v₂ : Fin 2,
        localMajorantM2 i₂ j₂ u₂ v₂ * localMajorantA2 i₂ j₂ u₂ v₂) +
      (∑ i₁ : Fin 2, ∑ j₁ : Fin 2, ∑ u₁ : Fin 2, ∑ v₁ : Fin 2,
        (localMajorantA1 i₁ j₁ u₁ v₁) ^ 2) *
      (∑ i₂ : Fin 2, ∑ j₂ : Fin 2, ∑ u₂ : Fin 2, ∑ v₂ : Fin 2,
        (localMajorantA2 i₂ j₂ u₂ v₂) ^ 2) := by
    simp_rw [twoQubitSuperopMajorant_eq_factored, Fintype.sum_prod_type]
    simp only [Fin.sum_univ_two]
    ring
  rcases localMajorant1_sum_identities with ⟨hm1, hma1, ha1⟩
  rcases localMajorant2_sum_identities with ⟨hm2, hma2, ha2⟩
  rw [hsum, hm1, hma1, ha1, hm2, hma2, ha2]
  constructor <;> norm_num

/-- Entrywise bound of the two-qubit transition residual in terms of `twoQubitSuperopMajorant`:
for all `t ≥ 0` and all `X ∈ M₄(ℂ)`,
`‖(twoQubitKrausChannel t X - Tr(X) • twoQubitEquilibrium) i j‖ ≤ exp(-29t/99) * ∑_{u,v} B_{i,j,u,v} ‖X u v‖`. -/
theorem twoQubitKrausChannel_entrywise_le_superopMajorant
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) (ht : 0 ≤ t)
    (i j : TwoQubitIndex) :
    ‖(twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium) i j‖ ≤
      Real.exp (-(29 / 99 : ℝ) * t) *
        ∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
          twoQubitSuperopMajorant i j u v * ‖X u v‖ := by
  refine le_trans (twoQubitKrausChannel_entrywise_decay_bound X t ht i j) ?_
  apply mul_le_mul_of_nonneg_left _ (le_of_lt (Real.exp_pos _))
  have htr :
      ∀ p : Fin 4 × Fin 4,
        ‖Matrix.trace (twoQubitDualMatrix p * X)‖ * ‖twoQubitEigenMatrix p i j‖ ≤
          ∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
            (‖twoQubitEigenMatrix p i j‖ * ‖twoQubitDualMatrix p v u‖) * ‖X u v‖ := by
    intro p
    have h1 :
        ‖Matrix.trace (twoQubitDualMatrix p * X)‖ ≤
          ∑ v : TwoQubitIndex, ∑ u : TwoQubitIndex,
            ‖twoQubitDualMatrix p v u‖ * ‖X u v‖ := by
      unfold Matrix.trace
      simp only [Matrix.diag_apply, Matrix.mul_apply]
      refine le_trans (norm_sum_le _ _) (Finset.sum_le_sum fun v _ => ?_)
      refine le_trans (norm_sum_le _ _) (Finset.sum_le_sum fun u _ => ?_)
      rw [norm_mul]
    rw [Finset.sum_comm] at h1
    have h2 := mul_le_mul_of_nonneg_right h1 (norm_nonneg (twoQubitEigenMatrix p i j))
    refine le_trans h2 (le_of_eq ?_)
    rw [Finset.sum_mul]
    refine Finset.sum_congr rfl (fun u _ => ?_)
    rw [Finset.sum_mul]
    refine Finset.sum_congr rfl (fun v _ => by ring)
  refine le_trans (Finset.sum_le_sum (fun p _ => htr p)) (le_of_eq ?_)
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl (fun u _ => ?_)
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl (fun v _ => ?_)
  unfold twoQubitSuperopMajorant
  rw [Finset.sum_mul]

/-- **Unconditional Frobenius (Hilbert–Schmidt) exponential decay with prefactor `6`**:
for all `t ≥ 0` and all `X ∈ M₄(ℂ)`,
`frobeniusNorm (twoQubitKrausChannel t X - Tr(X) • twoQubitEquilibrium) ≤ 6 * exp(-29t/99) * frobeniusNorm X`. -/
theorem twoQubitKrausChannel_frobenius_decay_6
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) (ht : 0 ≤ t) :
    frobeniusNorm (twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium) ≤
      6 * Real.exp (-(29 / 99 : ℝ) * t) * frobeniusNorm X := by
  let Y := twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium
  let E := Real.exp (-(29 / 99 : ℝ) * t)
  have hE : 0 ≤ E := le_of_lt (Real.exp_pos _)
  have hentry_sq :
      ∀ i j : TwoQubitIndex,
        ‖Y i j‖ ^ 2 ≤
          E ^ 2 *
            ((∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
                (twoQubitSuperopMajorant i j u v) ^ 2) *
              frobeniusNormSq X) := by
    intro i j
    have hij := twoQubitKrausChannel_entrywise_le_superopMajorant X t ht i j
    have hsq1 :
        ‖Y i j‖ ^ 2 ≤
          (E * ∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
            twoQubitSuperopMajorant i j u v * ‖X u v‖) ^ 2 :=
      pow_le_pow_left₀ (norm_nonneg _) hij 2
    have hcs :
        (∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
          twoQubitSuperopMajorant i j u v * ‖X u v‖) ^ 2 ≤
        (∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
          (twoQubitSuperopMajorant i j u v) ^ 2) * frobeniusNormSq X := by
      unfold frobeniusNormSq
      have h := Finset.sum_mul_sq_le_sq_mul_sq
        (Finset.univ : Finset (TwoQubitIndex × TwoQubitIndex))
        (fun p => twoQubitSuperopMajorant i j p.1 p.2)
        (fun p => ‖X p.1 p.2‖)
      simpa only [Fintype.sum_prod_type] using h
    refine le_trans hsq1 ?_
    rw [mul_pow]
    exact mul_le_mul_of_nonneg_left hcs (sq_nonneg E)
  have hsum_sq :
      frobeniusNormSq Y ≤ (6 * E) ^ 2 * frobeniusNormSq X := by
    calc
      frobeniusNormSq Y
        ≤ ∑ i : TwoQubitIndex, ∑ j : TwoQubitIndex,
            E ^ 2 *
              ((∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
                  (twoQubitSuperopMajorant i j u v) ^ 2) *
                frobeniusNormSq X) :=
          Finset.sum_le_sum (fun i _ => Finset.sum_le_sum (fun j _ => hentry_sq i j))
      _ = E ^ 2 *
            ((∑ i : TwoQubitIndex, ∑ j : TwoQubitIndex,
                ∑ u : TwoQubitIndex, ∑ v : TwoQubitIndex,
                  (twoQubitSuperopMajorant i j u v) ^ 2) *
              frobeniusNormSq X) := by
          simp_rw [← Finset.mul_sum, ← Finset.sum_mul]
      _ ≤ E ^ 2 * (36 * frobeniusNormSq X) := by
          refine mul_le_mul_of_nonneg_left ?_ (sq_nonneg E)
          exact mul_le_mul_of_nonneg_right twoQubitSuperopMajorant_sum_sq.2 (frobeniusNormSq_nonneg X)
      _ = (6 * E) ^ 2 * frobeniusNormSq X := by ring
  unfold frobeniusNorm
  have hpos : 0 ≤ 6 * E := by positivity
  rw [← Real.sqrt_sq hpos, ← Real.sqrt_mul (sq_nonneg (6 * E))]
  exact Real.sqrt_le_sqrt hsum_sq

/-- **Unconditional concrete two-qubit `schattenOneSpectralNorm` exponential decay with prefactor `12`**:
for all `t ≥ 0` and all `X ∈ M₄(ℂ)` (including non-Hermitian, coherent, and entangled matrices),
`schattenOneSpectralNorm (twoQubitKrausChannel t X - Tr(X) • twoQubitEquilibrium) ≤ 12 * exp(-29t/99) * schattenOneSpectralNorm X`. -/
theorem twoQubit_unconditional_schattenOneSpectralNorm_decay_12
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) (ht : 0 ≤ t) :
    schattenOneSpectralNorm
      (twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium) ≤
      12 * Real.exp (-(29 / 99 : ℝ) * t) * schattenOneSpectralNorm X := by
  calc
    schattenOneSpectralNorm
        (twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium)
      ≤ 2 * frobeniusNorm (twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium) :=
        schattenOneSpectralNorm_twoQubit_le_two_mul_frobeniusNorm _
    _ ≤ 2 * (6 * Real.exp (-(29 / 99 : ℝ) * t) * frobeniusNorm X) :=
        mul_le_mul_of_nonneg_left (twoQubitKrausChannel_frobenius_decay_6 X t ht) (by norm_num)
    _ ≤ 2 * (6 * Real.exp (-(29 / 99 : ℝ) * t) * schattenOneSpectralNorm X) := by
        refine mul_le_mul_of_nonneg_left ?_ (by norm_num)
        exact mul_le_mul_of_nonneg_left (frobeniusNorm_le_schattenOneSpectralNorm X)
          (mul_nonneg (by norm_num) (le_of_lt (Real.exp_pos _)))
    _ = 12 * Real.exp (-(29 / 99 : ℝ) * t) * schattenOneSpectralNorm X := by ring

/-- **Unconditional concrete two-qubit `schattenOneSpectralNorm` exponential decay with prefactor `24` (`P0c-06`)**:
for all `t ≥ 0` and all `X ∈ M₄(ℂ)`,
`schattenOneSpectralNorm (twoQubitKrausChannel t X - Tr(X) • twoQubitEquilibrium) ≤ 24 * exp(-29t/99) * schattenOneSpectralNorm X`. -/
theorem twoQubit_unconditional_schattenOneSpectralNorm_decay_24
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) (ht : 0 ≤ t) :
    schattenOneSpectralNorm
      (twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium) ≤
      24 * Real.exp (-(29 / 99 : ℝ) * t) * schattenOneSpectralNorm X := by
  have h12 := twoQubit_unconditional_schattenOneSpectralNorm_decay_12 X t ht
  have hnonneg : 0 ≤ Real.exp (-(29 / 99 : ℝ) * t) * schattenOneSpectralNorm X :=
    mul_nonneg (le_of_lt (Real.exp_pos _)) (schattenOneSpectralNorm_nonneg X)
  linarith

end BinduEventInterface
