import BinduEventInterface.GlobalKrausActionBridgeCandidate

/-!
Small independent finite-sum lemmas for the exact hybrid-step proof.
These are PROOF CANDIDATES until compiled on the user's pinned Lean + Mathlib.
No trusted source files are overwritten; no admitted proof obligations.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- A double sum over two N-bit strings of a product of sitewise coefficients
    factors into independent two-bit sums. -/
theorem bindu_double_kernel_sum_factors {N : ℕ}
    (f : Fin N → Fin 2 → Fin 2 → ℂ) :
    (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
       ∏ m : Fin N, f m (r m) (s m)) =
    ∏ m : Fin N, ∑ x : Fin 2, ∑ y : Fin 2, f m x y := by
  classical
  calc
    (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
       ∏ m : Fin N, f m (r m) (s m)) =
      ∑ r : NQubitIndex N, ∏ m : Fin N,
        ∑ y : Fin 2, f m (r m) y := by
          apply Finset.sum_congr rfl
          intro r _
          exact (Fintype.prod_sum (fun m y => f m (r m) y)).symm
    _ = ∏ m : Fin N, ∑ x : Fin 2, ∑ y : Fin 2, f m x y := by
      exact (Fintype.prod_sum (fun m x => ∑ y : Fin 2, f m x y)).symm

/-- Kernel convolution respects a product of local four-index kernels. -/
theorem bindu_product_four_kernel_comp {N : ℕ}
    (A B : Fin N → Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (u p v q : NQubitIndex N) :
    (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
      (∏ m : Fin N, A m (u m) (r m) (v m) (s m)) *
      (∏ m : Fin N, B m (r m) (p m) (s m) (q m))) =
    ∏ m : Fin N,
       ∑ x : Fin 2, ∑ y : Fin 2,
         A m (u m) x (v m) y * B m x (p m) y (q m) := by
  classical
  simp only [← Finset.prod_mul_distrib]
  exact bindu_double_kernel_sum_factors
    (fun m x y => A m (u m) x (v m) y * B m x (p m) y (q m))

/-- Delta-kernel eliminates the two independent intermediate matrix indices.
    Never collapse them to one index: the input matrix may be non-diagonal. -/
theorem bindu_two_index_delta_collapse
    (u v : Fin 2) (F : Fin 2 → Fin 2 → ℂ) :
    (∑ r : Fin 2, ∑ s : Fin 2,
      (if u = r then (1 : ℂ) else 0) *
      (if v = s then (1 : ℂ) else 0) * F r s) = F u v := by
  classical
  simp

end BinduEventInterface

#print axioms BinduEventInterface.bindu_double_kernel_sum_factors
#print axioms BinduEventInterface.bindu_product_four_kernel_comp
#print axioms BinduEventInterface.bindu_two_index_delta_collapse
