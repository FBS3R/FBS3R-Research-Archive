import BinduEventInterface.BinduGlobalTwoBridgesCandidate

/-!
# Arbitrary-ancilla kernel/Kraus bridge at one site

This is a new SOURCE CANDIDATE. It requires `lake build` on the pinned Lean
installation; no certification is claimed from authoring this file.

The input/output matrix index remains `NQubitIndex N × a` throughout.
No tensor reindexing is used. The Kraus family may have ANY finite index type.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- The action of a local Kraus kernel at a selected site is exactly the
ancilla-stabilized action of the corresponding embedded local Kraus operators.
Unlike the old `h_reindexed` approach, both sides have the same matrix type. -/
theorem bindu_site_local_family_bridge
    {N : ℕ} {a ι : Type*} [Fintype a] [DecidableEq a] [Fintype ι]
    (k : Fin N) (L : ι → Matrix (Fin 2) (Fin 2) ℂ)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k
      (fun u p v q => ∑ α : ι, L α u p * star (L α v q)) Y =
    ancillaRightChannel
      (fun α : ι => nQubitTensorProduct
        (fun m : Fin N => if m = k then L α else 1)) Y := by
  classical
  have hterm (α : ι) (u p v q : NQubitIndex N) :
      (nQubitTensorProduct
        (fun m : Fin N => if m = k then L α else 1)) u p *
      star ((nQubitTensorProduct
        (fun m : Fin N => if m = k then L α else 1)) v q) =
      (∏ m : Fin N,
        if m = k then L α (u m) (p m) * star (L α (v m) (q m))
        else binduDeltaKernel (u m) (p m) (v m) (q m)) := by
    simp only [nQubitTensorProduct_apply, star_prod,
      ← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro m _
    by_cases hm : m = k
    · simp [hm]
    · simp [hm, binduDeltaKernel, Matrix.one_apply]
  ext ⟨u, i⟩ ⟨v, j⟩
  rw [ancillaRightChannel_apply]
  rw [finiteKrausChannel_apply_kernel]
  simp only [binduSiteKernelAction, Matrix.of_apply]
  apply Finset.sum_congr rfl
  intro p _
  apply Finset.sum_congr rfl
  intro q _
  congr 1
  calc
    (∏ m : Fin N,
      if m = k then
        (∑ α : ι,
          L α (u m) (p m) * star (L α (v m) (q m)))
      else binduDeltaKernel (u m) (p m) (v m) (q m)) =
      (∏ m ∈ Finset.univ.erase k,
        binduDeltaKernel (u m) (p m) (v m) (q m)) *
      (∑ α : ι, L α (u k) (p k) * star (L α (v k) (q k))) :=
        bindu_site_product_split k
          (fun x y z w => ∑ α : ι, L α x y * star (L α z w)) u p v q
    _ = ∑ α : ι,
          (∏ m ∈ Finset.univ.erase k,
            binduDeltaKernel (u m) (p m) (v m) (q m)) *
            (L α (u k) (p k) * star (L α (v k) (q k))) := by
          rw [Finset.mul_sum]
    _ = ∑ α : ι,
          (∏ m : Fin N,
            if m = k then
              L α (u m) (p m) * star (L α (v m) (q m))
            else binduDeltaKernel (u m) (p m) (v m) (q m)) := by
          apply Finset.sum_congr rfl
          intro α _
          exact (bindu_site_product_split k
            (fun x y z w => L α x y * star (L α z w)) u p v q).symm
    _ = ∑ α : ι,
          (nQubitTensorProduct
            (fun m : Fin N => if m = k then L α else 1)) u p *
          star ((nQubitTensorProduct
            (fun m : Fin N => if m = k then L α else 1)) v q) := by
          apply Finset.sum_congr rfl
          intro α _
          exact (hterm α u p v q).symm

/-- Full physical site-replacer equality: removes the old hR hypothesis. -/
theorem bindu_site_replacer_kernel_bridge
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (k : Fin N)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k
        (localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0)) Y =
      ancillaRightChannel (siteReplacerKraus G K k) Y := by
  simpa only [localKrausKernel, siteReplacerKraus] using
    (bindu_site_local_family_bridge k
      (gadKraus (localEqProb (G k) (K k)) 0) Y)

/-- The local Pauli-Z kernel exactly gives the global site-Pauli-Z channel. -/
theorem bindu_site_pauli_z_kernel_bridge
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (k : Fin N)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k
        (fun u p v q => localPauliZ u p * star (localPauliZ v q)) Y =
      ancillaRightChannel (sitePauliZKraus k) Y := by
  simpa only [Fin.sum_univ_one, sitePauliZKraus, sitePauliZ] using
    (bindu_site_local_family_bridge k
      (fun _ : Fin 1 => localPauliZ) Y)

end BinduEventInterface

#print axioms BinduEventInterface.bindu_site_local_family_bridge
#print axioms BinduEventInterface.bindu_site_replacer_kernel_bridge
#print axioms BinduEventInterface.bindu_site_pauli_z_kernel_bridge
