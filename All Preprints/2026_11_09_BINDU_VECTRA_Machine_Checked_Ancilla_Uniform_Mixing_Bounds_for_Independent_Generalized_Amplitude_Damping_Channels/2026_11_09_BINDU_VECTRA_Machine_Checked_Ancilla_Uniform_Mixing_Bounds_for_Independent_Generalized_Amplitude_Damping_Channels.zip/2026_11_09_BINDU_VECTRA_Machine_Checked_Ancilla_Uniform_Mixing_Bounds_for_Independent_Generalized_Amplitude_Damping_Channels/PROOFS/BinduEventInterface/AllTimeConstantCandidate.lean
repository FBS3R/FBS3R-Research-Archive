import BinduEventInterface.ExampleBound
import Mathlib

/-!
# Explicit continuous-time rate envelope, candidate for Lean 4.19

This file proves a real-valued all-time population bound for the explicitly
specified constant-rate solution, plus a finite family product bound.
It does NOT assume that an arbitrary external JSON model has these rates,
or equate a physical GKSL solution to this formula without a generator bridge.
It is intentionally not imported by the verified main module until compiled.
-/

namespace BinduEventInterface

/-- Excited-state probability from the vacuum under constant independent pump
    and loss, at time t. -/
noncomputable def constantRatePopulation (G K t : ℝ) : ℝ :=
  (G / (G + K)) * (1 - Real.exp (-(G + K) * t))

/-- Exact uniform-in-time envelope for a single constant-rate site. -/
theorem constantRatePopulation_bounds (G K t : ℝ)
    (hG : 0 ≤ G) (hK : 0 ≤ K) (hpos : 0 < G + K)
    (ht : 0 ≤ t) :
    0 ≤ constantRatePopulation G K t ∧
      constantRatePopulation G K t ≤ G / (G + K) := by
  have hb : 0 ≤ G / (G + K) := div_nonneg hG (le_of_lt hpos)
  have harg : -(G + K) * t ≤ 0 := by
    have hprod : 0 ≤ (G + K) * t := mul_nonneg (le_of_lt hpos) ht
    linarith
  have he : Real.exp (-(G + K) * t) ≤ 1 := by
    simpa only [Real.exp_zero] using (Real.exp_le_exp.mpr harg)
  have he0 : 0 ≤ Real.exp (-(G + K) * t) := (Real.exp_pos _).le
  constructor
  · unfold constantRatePopulation
    exact mul_nonneg hb (sub_nonneg.mpr he)
  · unfold constantRatePopulation
    have hn := mul_nonneg hb he0
    nlinarith

/-- Finite many independent constant-rate site populations have a global
    bound, independent of the surrounding Hilbert-space dimension. -/
theorem finite_constantRatePopulation_bound
    {ι : Type*} [Fintype ι]
    (G K : ι → ℝ) (t : ℝ)
    (hG : ∀ i, 0 ≤ G i)
    (hK : ∀ i, 0 ≤ K i)
    (hpos : ∀ i, 0 < G i + K i)
    (ht : 0 ≤ t) :
    (∏ i : ι, constantRatePopulation (G i) (K i) t) ≤
      (∏ i : ι, G i / (G i + K i)) := by
  classical
  apply Finset.prod_le_prod
  · intro i hi
    exact (constantRatePopulation_bounds (G i) (K i) t
      (hG i) (hK i) (hpos i) ht).1
  · intro i hi
    exact (constantRatePopulation_bounds (G i) (K i) t
      (hG i) (hK i) (hpos i) ht).2

/-- The explicit site population satisfies the vacuum preparation. -/
theorem constantRatePopulation_initial (G K : ℝ) :
    constantRatePopulation G K 0 = 0 := by
  simp [constantRatePopulation]

#print axioms constantRatePopulation_bounds
#print axioms finite_constantRatePopulation_bound
#print axioms constantRatePopulation_initial

end BinduEventInterface
