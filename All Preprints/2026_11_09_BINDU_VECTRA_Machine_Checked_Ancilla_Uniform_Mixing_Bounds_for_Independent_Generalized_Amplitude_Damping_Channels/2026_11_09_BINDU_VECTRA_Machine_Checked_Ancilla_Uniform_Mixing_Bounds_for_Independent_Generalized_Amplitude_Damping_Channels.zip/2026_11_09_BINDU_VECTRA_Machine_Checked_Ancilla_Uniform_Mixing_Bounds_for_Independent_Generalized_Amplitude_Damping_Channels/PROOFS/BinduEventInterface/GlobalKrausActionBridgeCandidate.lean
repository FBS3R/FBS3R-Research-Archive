import BinduEventInterface.HybridKernelActionCandidate

/-!
Bridge from the actual `ancillaRightChannel` Kraus action (as implemented in
CURRENT(6)) to the exact 4^N four-index kernel identity.

This candidate does NOT yet bound the trace norm; that requires a separate
permutation/CPTP preprocessing argument. It is intended as a target for
independent compilation on the user's pinned Lean 4.19.0 + Mathlib.
-/
namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- Exact four-index expression for a full finite Kraus superoperator.
Here every one of the output coefficients is a sum over all Kraus indices,
and over BOTH input matrix coordinates (p,q). -/
theorem finiteKrausChannel_apply_kernel
    {n ι : Type*} [Fintype n] [DecidableEq n] [Fintype ι]
    (K : ι → Matrix n n ℂ) (Z : Matrix n n ℂ) (u v : n) :
    finiteKrausChannel K Z u v =
      ∑ p : n, ∑ q : n,
        (∑ α : ι, K α u p * star (K α v q)) * Z p q := by
  classical
  simp only [finiteKrausChannel, Matrix.sum_apply,
    Matrix.mul_apply, Matrix.conjTranspose_apply]
  calc
    (∑ α : ι, ∑ q : n, (∑ p : n, K α u p * Z p q) * star (K α v q)) =
        ∑ α : ι, ∑ q : n, ∑ p : n,
          (K α u p * star (K α v q)) * Z p q := by
      apply Finset.sum_congr rfl
      intro α _
      apply Finset.sum_congr rfl
      intro q _
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro p _
      ring
    _ = ∑ α : ι, ∑ p : n, ∑ q : n,
          (K α u p * star (K α v q)) * Z p q := by
      apply Finset.sum_congr rfl
      intro α _
      exact Finset.sum_comm
    _ = ∑ p : n, ∑ α : ι, ∑ q : n,
          (K α u p * star (K α v q)) * Z p q := by
      exact Finset.sum_comm
    _ = ∑ p : n, ∑ q : n, ∑ α : ι,
          (K α u p * star (K α v q)) * Z p q := by
      apply Finset.sum_congr rfl
      intro p _
      exact Finset.sum_comm
    _ = ∑ p : n, ∑ q : n,
          (∑ α : ι, K α u p * star (K α v q)) * Z p q := by
      apply Finset.sum_congr rfl
      intro p _
      apply Finset.sum_congr rfl
      intro q _
      exact (Finset.sum_mul _ _ _).symm

/-- The original ancilla-stabilized global Kraus channel is EXACTLY the
full four-index Kraus kernel action (on all complex input matrices). -/
theorem ancillaRightChannel_eq_fullKernelAction
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (L : Fin N → Fin 4 → Matrix (Fin 2) (Fin 2) ℂ)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    ancillaRightChannel
      (fun α : NQubitModeIndex N =>
        nQubitTensorProduct (fun m => L m (α m))) X =
      fullKernelAction L X := by
  classical
  ext ⟨u, i⟩ ⟨v, j⟩
  rw [ancillaRightChannel_apply]
  rw [finiteKrausChannel_apply_kernel]
  simp only [fullKernelAction, Matrix.of_apply, fullKrausKernel]

/-- Exact equality of the original, PHYSICAL global Kraus superoperators
at two consecutive hybrids to their factored four-index action.
The right side is NOT a channel of Kraus differences. -/
theorem physicalHybridStep_exact_superoperator_factorization
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    ancillaRightChannel (hybridNQubitKraus G K t (k.val + 1)) X -
      ancillaRightChannel (hybridNQubitKraus G K t k.val) X =
      Matrix.of (fun ⟨u, i⟩ ⟨v, j⟩ =>
        ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
          ((localKrausKernel (localKraus (G k) (K k) t)
              (u k) (p k) (v k) (q k) -
            localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0)
              (u k) (p k) (v k) (q k)) *
            (∏ m ∈ Finset.univ.erase k,
              localKrausKernel (hybridLocalKraus G K t k.val m)
                (u m) (p m) (v m) (q m))) *
            X (p, i) (q, j)) := by
  classical
  calc
    ancillaRightChannel (hybridNQubitKraus G K t (k.val + 1)) X -
      ancillaRightChannel (hybridNQubitKraus G K t k.val) X =
      fullKernelAction (hybridLocalKraus G K t (k.val + 1)) X -
        fullKernelAction (hybridLocalKraus G K t k.val) X := by
      rw [show hybridNQubitKraus G K t (k.val + 1) =
          (fun α => nQubitTensorProduct
            (fun m => hybridLocalKraus G K t (k.val + 1) m (α m))) from rfl]
      rw [show hybridNQubitKraus G K t k.val =
          (fun α => nQubitTensorProduct
            (fun m => hybridLocalKraus G K t k.val m (α m))) from rfl]
      rw [ancillaRightChannel_eq_fullKernelAction,
        ancillaRightChannel_eq_fullKernelAction]
    _ = _ := fullKernelAction_hybrid_step G K t k X

end BinduEventInterface

#print axioms BinduEventInterface.finiteKrausChannel_apply_kernel
#print axioms BinduEventInterface.ancillaRightChannel_eq_fullKernelAction
#print axioms BinduEventInterface.physicalHybridStep_exact_superoperator_factorization
