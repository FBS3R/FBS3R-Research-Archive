import BinduEventInterface.FiniteKrausTraceCandidate
import Mathlib.LinearAlgebra.Matrix.PosDef

/-!
# CP core: positivity of finite Kraus maps and of all ancilla lifts

No unproved hypotheses about positivity of channels are assumed.
The statements are Lean 4.19.0 candidates pending kernel compilation.
-/

namespace BinduEventInterface

open scoped Matrix ComplexOrder

/-- A finite Kraus map preserves positivity for every PSD input, with no
    normalization assumptions on the Kraus family. -/
theorem finiteKrausChannel_posSemidef
    {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ) (M : Matrix n n ℂ)
    (hM : M.PosSemidef) :
    (finiteKrausChannel K M).PosSemidef := by
  classical
  have hsum : ∀ s : Finset k,
      (∑ j ∈ s, K j * M * (K j).conjTranspose).PosSemidef := by
    intro s
    induction s using Finset.induction_on with
    | empty =>
        simpa using (Matrix.PosSemidef.zero :
          (0 : Matrix n n ℂ).PosSemidef)
    | @insert j s hj ih =>
        rw [Finset.sum_insert hj]
        exact (hM.mul_mul_conjTranspose_same (K j)).add ih
  simpa only [finiteKrausChannel] using hsum Finset.univ

/-- Positivity holds after tensoring each Kraus operator with any finite
    ancilla identity. This is the fundamental ancilla-positivity property
    behind complete positivity of Kraus maps. -/
theorem finiteKrausChannel_ancilla_posSemidef
    {a n k : Type*} [Fintype a] [DecidableEq a]
    [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ)
    (M : Matrix (a × n) (a × n) ℂ)
    (hM : M.PosSemidef) :
    (finiteKrausChannel
      (fun j => Matrix.kronecker (1 : Matrix a a ℂ) (K j)) M).PosSemidef := by
  exact finiteKrausChannel_posSemidef
    (fun j => Matrix.kronecker (1 : Matrix a a ℂ) (K j)) M hM

end BinduEventInterface
