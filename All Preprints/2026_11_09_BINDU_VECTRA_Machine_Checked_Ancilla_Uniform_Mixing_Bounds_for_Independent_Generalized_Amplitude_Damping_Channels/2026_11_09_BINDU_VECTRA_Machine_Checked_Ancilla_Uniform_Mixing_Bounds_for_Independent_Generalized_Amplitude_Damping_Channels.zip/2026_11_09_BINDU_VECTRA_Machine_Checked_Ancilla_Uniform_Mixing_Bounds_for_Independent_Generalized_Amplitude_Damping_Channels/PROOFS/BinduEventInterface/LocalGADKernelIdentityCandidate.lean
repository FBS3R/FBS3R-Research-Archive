import BinduEventInterface.DirectHybridOffsiteFactorizationCandidate
import BinduEventInterface.NQubitDiamondMixingCandidate

/-!
Local kernel identity checkpoint for the existing BINDU–VECTRA API.
The matrix unit is the identity four-index delta kernel, not `Matrix.single`.
No sorry, admit, or new axioms are introduced.
This module establishes the **local coefficientwise** GAD identity only.
It does not by itself establish its lifting to an arbitrary N-qubit site.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- Local dephasing kernel, acting on matrix-unit coefficients. -/
def binduLocalDephaseKernel (u p v q : Fin 2) : ℂ :=
  if u = v then binduDeltaKernel u p v q else 0

/-- The rank-one matrix unit |p><q|, defined using the already verified delta kernel. -/
def binduMatrixUnit (p q : Fin 2) : Matrix (Fin 2) (Fin 2) ℂ :=
  Matrix.of fun u v => binduDeltaKernel u p v q

@[simp] theorem binduMatrixUnit_apply (p q u v : Fin 2) :
    binduMatrixUnit p q u v = binduDeltaKernel u p v q := rfl

/-- A Kraus coefficient equals its action on the corresponding matrix unit. -/
theorem bindu_local_kernel_eq_on_matrix_unit
    (L : Fin 4 → Matrix (Fin 2) (Fin 2) ℂ)
    (u p v q : Fin 2) :
    localKrausKernel L u p v q =
      finiteKrausChannel L (binduMatrixUnit p q) u v := by
  classical
  rw [finiteKrausChannel_apply_kernel]
  change localKrausKernel L u p v q =
    ∑ x : Fin 2, ∑ y : Fin 2,
      localKrausKernel L u x v y * binduDeltaKernel x p y q
  exact (bindu_delta_right_kernel (localKrausKernel L) u p v q).symm

/-- Dephasing a matrix unit retains only its diagonal contribution. -/
theorem bindu_local_dephasing_matrix_unit
    (u p v q : Fin 2) :
    localDephasingMap (binduMatrixUnit p q) u v =
      binduLocalDephaseKernel u p v q := by
  rw [localDephasingMap_eq_diag]
  fin_cases u <;> fin_cases p <;> fin_cases v <;> fin_cases q <;>
    simp [binduLocalDephaseKernel, binduMatrixUnit, binduDeltaKernel]

/-- Matrix-unit coefficients reproduce the identity four-index kernel. -/
theorem bindu_local_identity_matrix_unit
    (u p v q : Fin 2) :
    binduMatrixUnit p q u v = binduDeltaKernel u p v q := rfl

/-- Exact local GAD-minus-replacer kernel polynomial (not the global lift). -/
theorem bindu_local_gad_kernel_polynomial
    {N : ℕ} (G K : Fin N → ℝ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (ht : 0 ≤ t) (k : Fin N)
    (u p v q : Fin 2) :
    localKrausKernel (localKraus (G k) (K k) t) u p v q -
      localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q =
    (((localDampingR (G k) (K k) t *
       (1 - localDampingR (G k) (K k) t) : ℝ) : ℂ) *
       (binduDeltaKernel u p v q - binduLocalDephaseKernel u p v q)) +
    (((localDampingR (G k) (K k) t) ^ 2 : ℝ) : ℂ) *
       (binduDeltaKernel u p v q -
         localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q) := by
  let E : Matrix (Fin 2) (Fin 2) ℂ := binduMatrixUnit p q
  have hp := localEqProb_bounds (G k) (K k) (hG k) (hK k)
  have hphys :
      localKrausKernel (localKraus (G k) (K k) t) u p v q =
        localChannel (G k) (K k) t E u v := by
    rw [bindu_local_kernel_eq_on_matrix_unit]
    exact congrArg (fun M : Matrix (Fin 2) (Fin 2) ℂ => M u v)
      (finiteKrausChannel_localKraus_eq_localChannel
        (G k) (K k) t (hG k) (hK k) ht E)
  have hrepl :
      localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q =
        localReplacerMap (localEqProb (G k) (K k)) E u v := by
    rw [bindu_local_kernel_eq_on_matrix_unit]
    exact congrArg (fun M : Matrix (Fin 2) (Fin 2) ℂ => M u v)
      (localReplacerMap_eq_finiteKrausChannel
        (localEqProb (G k) (K k)) hp E).symm
  have hlocal := congrArg (fun M : Matrix (Fin 2) (Fin 2) ℂ => M u v)
    (localChannel_sub_replacer_eq (G k) (K k) t E)
  have hentries :
      localChannel (G k) (K k) t E u v -
          localReplacerMap (localEqProb (G k) (K k)) E u v =
      (((localDampingR (G k) (K k) t *
        (1 - localDampingR (G k) (K k) t) : ℝ) : ℂ) *
        (E u v - localDephasingMap E u v)) +
      ((((localDampingR (G k) (K k) t) ^ 2 : ℝ) : ℂ) *
        (E u v - localReplacerMap (localEqProb (G k) (K k)) E u v)) := by
    simpa only [Matrix.sub_apply, Matrix.add_apply,
      Matrix.smul_apply, smul_eq_mul] using hlocal
  calc
    localKrausKernel (localKraus (G k) (K k) t) u p v q -
        localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q =
      localChannel (G k) (K k) t E u v -
        localReplacerMap (localEqProb (G k) (K k)) E u v := by
          rw [hphys, hrepl]
    _ = _ := hentries
    _ = _ := by
      rw [← hrepl]
      simp only [E, binduMatrixUnit_apply,
        bindu_local_dephasing_matrix_unit]

end BinduEventInterface

#print axioms BinduEventInterface.bindu_local_kernel_eq_on_matrix_unit
#print axioms BinduEventInterface.bindu_local_dephasing_matrix_unit
#print axioms BinduEventInterface.bindu_local_identity_matrix_unit
#print axioms BinduEventInterface.bindu_local_gad_kernel_polynomial
