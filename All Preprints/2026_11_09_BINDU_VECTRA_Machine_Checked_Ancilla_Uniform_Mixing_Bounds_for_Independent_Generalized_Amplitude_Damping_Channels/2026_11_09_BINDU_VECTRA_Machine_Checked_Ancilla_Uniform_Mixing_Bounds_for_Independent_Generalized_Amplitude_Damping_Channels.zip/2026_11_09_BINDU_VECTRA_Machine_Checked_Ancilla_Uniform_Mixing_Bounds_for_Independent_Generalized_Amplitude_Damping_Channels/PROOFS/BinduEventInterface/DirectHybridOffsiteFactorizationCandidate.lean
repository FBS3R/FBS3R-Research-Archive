import BinduEventInterface.OffsiteKrausCPTPCandidate

/-!
# Direct hybrid-step action through the offsite CPTP channel

All matrix indices stay `NQubitIndex N × a`. No tensor permutation or
unproved `hstep`/`hExact` premise occurs. The finite kernel convolution is
provided by the previously kernel-checked `bindu_site_offsite_convolution`.

This source is an UNCOMPILED candidate until checked against the pinned
Lean 4.19.0 Mathlib project on the user's Mac. No sorry, no new axioms.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- Four-index action of an arbitrary local kernel at site k, with identity
    action on all other sites and on the external ancilla. -/
noncomputable def binduSiteKernelAction {N : ℕ} {a : Type*} [Fintype a]
    (k : Fin N) (P : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ :=
  Matrix.of fun ⟨u, i⟩ ⟨v, j⟩ =>
    ∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
      (∏ m : Fin N,
         if m = k then P (u m) (r m) (v m) (s m)
         else binduDeltaKernel (u m) (r m) (v m) (s m)) *
        X (r, i) (s, j)

/-- Product-kernel action of identity at site k and local kernels L elsewhere. -/
noncomputable def binduOffsiteKernelAction {N : ℕ} {a : Type*} [Fintype a]
    (k : Fin N)
    (L : Fin N → Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ :=
  Matrix.of fun ⟨u, i⟩ ⟨v, j⟩ =>
    ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
      (∏ m : Fin N,
         if m = k then binduDeltaKernel (u m) (p m) (v m) (q m)
         else L m (u m) (p m) (v m) (q m)) *
        X (p, i) (q, j)

/-- The product over all sites splits into the identity factor at k
    and the physically relevant product over all other sites. -/
theorem bindu_offsite_product_split {N : ℕ} (k : Fin N)
    (L : Fin N → Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (u p v q : NQubitIndex N) :
    (∏ m : Fin N,
      if m = k then binduDeltaKernel (u m) (p m) (v m) (q m)
      else L m (u m) (p m) (v m) (q m)) =
    binduDeltaKernel (u k) (p k) (v k) (q k) *
      (∏ m ∈ Finset.univ.erase k,
        L m (u m) (p m) (v m) (q m)) := by
  classical
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ k)]
  simp only [if_pos rfl]
  have hprod :
      (∏ m ∈ Finset.univ.erase k,
        if m = k then binduDeltaKernel (u m) (p m) (v m) (q m)
        else L m (u m) (p m) (v m) (q m)) =
      (∏ m ∈ Finset.univ.erase k,
        L m (u m) (p m) (v m) (q m)) := by
    refine Finset.prod_congr rfl (fun m hm => ?_)
    rw [if_neg (Finset.ne_of_mem_erase hm)]
  rw [hprod]
  exact mul_comm _ _

/-- The actual Kraus offsite preprocessor equals the abstract product action. -/
theorem offsiteKraus_eq_binduOffsiteKernelAction
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    ancillaRightChannel (offsiteKraus G K t k) X =
      binduOffsiteKernelAction k
        (fun m => localKrausKernel (hybridLocalKraus G K t k.val m)) X := by
  classical
  rw [offsiteChannel_eq_fullKernelAction G K t k X]
  ext ⟨u, i⟩ ⟨v, j⟩
  simp only [fullKernelAction, binduOffsiteKernelAction, Matrix.of_apply]
  apply Finset.sum_congr rfl
  intro p _
  apply Finset.sum_congr rfl
  intro q _
  rw [offsiteFullKernel_eq_product G K t k u p v q]
  rw [bindu_offsite_product_split k
    (fun m => localKrausKernel (hybridLocalKraus G K t k.val m)) u p v q]

/-- Finite convolution gives exact composition of the local and offsite actions
    for every complex matrix and every finite external ancilla. -/
theorem bindu_site_offsite_action_comp
    {N : ℕ} {a : Type*} [Fintype a]
    (k : Fin N) (P : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (L : Fin N → Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    binduSiteKernelAction k P (binduOffsiteKernelAction k L X) =
      Matrix.of (fun ⟨u, i⟩ ⟨v, j⟩ =>
        ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
          (P (u k) (p k) (v k) (q k) *
            (∏ m ∈ Finset.univ.erase k,
              L m (u m) (p m) (v m) (q m))) * X (p, i) (q, j)) := by
  classical
  ext ⟨u, i⟩ ⟨v, j⟩
  simp only [binduSiteKernelAction, binduOffsiteKernelAction, Matrix.of_apply]
  let A : NQubitIndex N → NQubitIndex N → ℂ :=
    fun r s => ∏ m : Fin N,
      if m = k then P (u m) (r m) (v m) (s m)
      else binduDeltaKernel (u m) (r m) (v m) (s m)
  let B : NQubitIndex N → NQubitIndex N → NQubitIndex N → NQubitIndex N → ℂ :=
    fun r p s q => ∏ m : Fin N,
      if m = k then binduDeltaKernel (r m) (p m) (s m) (q m)
      else L m (r m) (p m) (s m) (q m)
  change
    (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
       A r s * (∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
         B r p s q * X (p, i) (q, j))) = _
  calc
    (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
       A r s * (∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
         B r p s q * X (p, i) (q, j))) =
        ∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
          ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
            (A r s * B r p s q) * X (p, i) (q, j) := by
      apply Finset.sum_congr rfl
      intro r _
      apply Finset.sum_congr rfl
      intro s _
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro p _
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro q _
      ring
    _ = ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
          ∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
            (A r s * B r p s q) * X (p, i) (q, j) := by
      calc
        (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
           ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
             (A r s * B r p s q) * X (p, i) (q, j)) =
          ∑ r : NQubitIndex N, ∑ p : NQubitIndex N,
             ∑ s : NQubitIndex N, ∑ q : NQubitIndex N,
               (A r s * B r p s q) * X (p, i) (q, j) := by
          apply Finset.sum_congr rfl
          intro r _
          exact Finset.sum_comm
        _ = ∑ p : NQubitIndex N, ∑ r : NQubitIndex N,
              ∑ s : NQubitIndex N, ∑ q : NQubitIndex N,
                (A r s * B r p s q) * X (p, i) (q, j) := by
          exact Finset.sum_comm
        _ = ∑ p : NQubitIndex N, ∑ r : NQubitIndex N,
              ∑ q : NQubitIndex N, ∑ s : NQubitIndex N,
                (A r s * B r p s q) * X (p, i) (q, j) := by
          apply Finset.sum_congr rfl
          intro p _
          apply Finset.sum_congr rfl
          intro r _
          exact Finset.sum_comm
        _ = ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
              ∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
                (A r s * B r p s q) * X (p, i) (q, j) := by
          apply Finset.sum_congr rfl
          intro p _
          exact Finset.sum_comm
    _ = ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
           (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
             A r s * B r p s q) * X (p, i) (q, j) := by
      simp only [Finset.sum_mul]
    _ = ∑ p : NQubitIndex N, ∑ q : NQubitIndex N,
          (P (u k) (p k) (v k) (q k) *
            (∏ m ∈ Finset.univ.erase k,
              L m (u m) (p m) (v m) (q m))) * X (p, i) (q, j) := by
      apply Finset.sum_congr rfl
      intro p _
      apply Finset.sum_congr rfl
      intro q _
      congr 1
      exact bindu_site_offsite_convolution k P L u p v q

/-- Exact GLOBAL physical hybrid step, with the already certified offsite Kraus
    channel and the selected-site local kernel difference. This is stronger than
    the old four-index expression because it explicitly factors the action.
    It does not yet assert the r+r² trace-norm bound. -/
theorem physicalHybridStep_eq_localKernel_after_offsite
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    ancillaRightChannel (hybridNQubitKraus G K t (k.val + 1)) X -
      ancillaRightChannel (hybridNQubitKraus G K t k.val) X =
    binduSiteKernelAction k
      (fun u p v q =>
        localKrausKernel (localKraus (G k) (K k) t) u p v q -
        localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q)
      (ancillaRightChannel (offsiteKraus G K t k) X) := by
  rw [physicalHybridStep_exact_superoperator_factorization G K t k X]
  rw [offsiteKraus_eq_binduOffsiteKernelAction G K t k X]
  exact (bindu_site_offsite_action_comp k
    (fun u p v q =>
      localKrausKernel (localKraus (G k) (K k) t) u p v q -
      localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q)
    (fun m => localKrausKernel (hybridLocalKraus G K t k.val m)) X).symm

end BinduEventInterface

#print axioms BinduEventInterface.bindu_offsite_product_split
#print axioms BinduEventInterface.offsiteKraus_eq_binduOffsiteKernelAction
#print axioms BinduEventInterface.bindu_site_offsite_action_comp
#print axioms BinduEventInterface.physicalHybridStep_eq_localKernel_after_offsite
