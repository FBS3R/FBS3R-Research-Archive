import BinduEventInterface.DensityTrajectoryDerivativeCandidate
import Mathlib.LinearAlgebra.Matrix.Trace

/-!
# Concrete finite-dimensional GKSL trace / real-time derivative bridge

The Hamiltonian and every finite jump are concrete matrices. Their coefficients
are complex (to allow use with the established algebraic generator); a physical
GKSL interpretation additionally requires Hᴴ = H and real nonnegative rates.

No assumption asserting a desired trace duality or observable ODE is made.
This module is compiled by the pinned toolchain and imported by the root.
-/

namespace BinduEventInterface

open Matrix

/-- Schrödinger GKSL, with ℏ=1 and jump rates outside the dissipators. -/
noncomputable def fullGKSLSchrodinger
    {n a : Type*} [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ) (rate : a → ℂ)
    (ρ : Matrix n n ℂ) : Matrix n n ℂ :=
  (-Complex.I) • (H * ρ - ρ * H) +
    ∑ j, rate j • dissipatorSchrodinger (L j) ρ

/-- Hamiltonian commutator pairing, without a Hermiticity assumption. -/
theorem trace_commutator_duality
    {n : Type*} [Fintype n] [DecidableEq n]
    (H Q ρ : Matrix n n ℂ) :
    Matrix.trace (Q * ((-Complex.I) • (H * ρ - ρ * H))) =
      Matrix.trace ((Complex.I • (H * Q - Q * H)) * ρ) := by
  have hc : Matrix.trace (Q * (ρ * H)) =
      Matrix.trace ((H * Q) * ρ) :=
    trace_anticommutator_cycle H Q ρ
  simp only [mul_smul_comm, smul_mul_assoc, Matrix.trace_smul,
    mul_sub, sub_mul, Matrix.trace_sub]
  rw [hc]
  simp only [mul_assoc, smul_eq_mul]
  ring

/-- Exact trace duality for any finite family of concrete jump matrices. -/
theorem trace_finite_dissipators_duality
    {n a : Type*} [Fintype n] [DecidableEq n] [Fintype a]
    (L : a → Matrix n n ℂ) (rate : a → ℂ)
    (Q ρ : Matrix n n ℂ) :
    Matrix.trace (Q * (∑ j, rate j • dissipatorSchrodinger (L j) ρ)) =
      Matrix.trace ((∑ j, rate j • dissipatorAdjoint (L j) Q) * ρ) := by
  classical
  simp only [Matrix.mul_sum, Matrix.sum_mul, Matrix.trace_sum,
    mul_smul_comm, smul_mul_assoc, Matrix.trace_smul]
  apply Finset.sum_congr rfl
  intro j hj
  exact congrArg (fun z : ℂ => rate j • z)
    (trace_dissipator_duality (L j) Q ρ)

/-- The complete finite GKSL generators are trace adjoints. -/
theorem trace_fullGKSL_duality
    {n a : Type*} [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ)
    (rate : a → ℂ) (Q ρ : Matrix n n ℂ) :
    Matrix.trace (Q * fullGKSLSchrodinger H L rate ρ) =
      Matrix.trace (heisenbergGenerator H L rate Q * ρ) := by
  unfold fullGKSLSchrodinger heisenbergGenerator
  simp only [mul_add, add_mul, Matrix.trace_add]
  rw [trace_commutator_duality, trace_finite_dissipators_duality]

/-- Derive the expectation derivative from entrywise Schrödinger GKSL, not
from an assumed observable ODE. -/
theorem fullGKSL_expectation_hasDerivAt
    {n a : Type*} [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ)
    (rate : a → ℂ) (Q : Matrix n n ℂ)
    (ρ : ℝ → Matrix n n ℂ) (t : ℝ)
    (hρ : ∀ i j : n,
      HasDerivAt (fun s : ℝ => ρ s i j)
        (fullGKSLSchrodinger H L rate (ρ t) i j) t) :
    HasDerivAt (fun s : ℝ => Matrix.trace (Q * ρ s))
      (Matrix.trace (heisenbergGenerator H L rate Q * ρ t)) t := by
  exact trace_generator_hasDerivAt_of_entries Q
    (fullGKSLSchrodinger H L rate)
    (heisenbergGenerator H L rate) ρ t hρ
    (fun M => trace_fullGKSL_duality H L rate Q M)

/-- Trace preservation is a derived algebraic fact of the full generator. -/
theorem trace_fullGKSL_zero
    {n a : Type*} [Fintype n] [DecidableEq n] [Fintype a]
    (H : Matrix n n ℂ) (L : a → Matrix n n ℂ)
    (rate : a → ℂ) (ρ : Matrix n n ℂ) :
    Matrix.trace (fullGKSLSchrodinger H L rate ρ) = 0 := by
  have h := trace_fullGKSL_duality H L rate
    (1 : Matrix n n ℂ) ρ
  simpa [generator_identity] using h

end BinduEventInterface
