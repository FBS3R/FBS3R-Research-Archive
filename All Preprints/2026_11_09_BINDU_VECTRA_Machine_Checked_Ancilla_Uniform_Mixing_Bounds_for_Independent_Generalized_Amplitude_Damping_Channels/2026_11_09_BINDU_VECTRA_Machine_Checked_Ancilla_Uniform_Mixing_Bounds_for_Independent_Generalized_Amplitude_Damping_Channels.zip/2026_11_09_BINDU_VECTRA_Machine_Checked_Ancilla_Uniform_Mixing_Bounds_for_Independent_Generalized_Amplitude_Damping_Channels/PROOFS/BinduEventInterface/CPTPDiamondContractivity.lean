import Mathlib
import BinduEventInterface.TensorKroneckerCandidate
import BinduEventInterface.SchattenOneDecomposition
import BinduEventInterface.NQubitDiamondMixingCandidate
import BinduEventInterface.NQubitIndependentCPTPSemigroupCandidate

/-!
# Stabilized Diamond-Norm Bounds and Arbitrary-Ancilla CPTP Contractivity

This module formalizes:
1. **Kraus Completeness with Arbitrary Ancilla** (`kraus_right_ancilla_completeness`,
   `kraus_left_ancilla_completeness`): for every finite system `n`, finite ancilla `a`,
   and finite Kraus family `K` with `∑ⱼ Kⱼᴴ Kⱼ = 1`, the extended families
   `Kⱼ ⊗ I_a` and `I_a ⊗ Kⱼ` satisfy exact Kraus completeness.
2. **Arbitrary-Ancilla Schatten-1 Contractivity** (`schattenOne_ancillaRightChannel_le`,
   `schattenOne_ancillaLeftChannel_le`): for every complex matrix `X` on `n × a` (or `a × n`),
   `‖(Φ ⊗ Id_a)(X)‖₁ ≤ ‖X‖₁`.
3. **Norm Properties of the Genuine Spectral Functional** (`schattenOne_add_le`,
   `schattenOne_smul_le`, `schattenOne_neg_eq`, `schattenOne_sub_le`): triangle inequality
   and scalar submultiplicativity proved constructively from finite SVD decompositions.
4. **CPTP Channel Difference Diamond Bound** (`cptp_channel_sub_le`):
   for any two CPTP channels `K₁` and `K₂`, `‖(Φ₁ - Φ₂) ⊗ Id_a (X)‖₁ ≤ 2 ‖X‖₁`.
5. **Arbitrary-N Qubit Diamond Mixing Bound** (`nQubit_channel_sub_replacer_diamond_bound`,
   `nQubit_channel_sub_replacer_zero_qubits`): for all `G m > 0, K m > 0`, `t ≥ 0`, any
   finite ancilla `a`, and any composite matrix `X`, the difference between the N-qubit
   semigroup channel and the stationary replacement channel is bounded by `2 ‖X‖₁` uniformly,
   and vanishes identically at `N = 0`.
-/

namespace BinduEventInterface

open Matrix
open scoped BigOperators Matrix ComplexOrder Topology

section AncillaCompleteness

variable {n a k : Type*} [Fintype n] [DecidableEq n] [Fintype a] [DecidableEq a] [Fintype k]

/-- Kraus completeness for `K j ⊗ I_a` on system `n × a`. -/
theorem kraus_right_ancilla_completeness
    (K : k → Matrix n n ℂ) (hK : ∑ j, (K j)ᴴ * K j = (1 : Matrix n n ℂ)) :
    ∑ j, (Matrix.kronecker (K j) (1 : Matrix a a ℂ))ᴴ *
         (Matrix.kronecker (K j) (1 : Matrix a a ℂ)) =
      (1 : Matrix (n × a) (n × a) ℂ) := by
  have hterm (j : k) :
      (Matrix.kronecker (K j) (1 : Matrix a a ℂ))ᴴ *
       (Matrix.kronecker (K j) (1 : Matrix a a ℂ)) =
      Matrix.kronecker ((K j)ᴴ * K j) (1 : Matrix a a ℂ) := by
    rw [kronecker_conjTranspose_v419, conjTranspose_one]
    have hmul := (Matrix.mul_kronecker_mul (K j)ᴴ (K j) (1 : Matrix a a ℂ) (1 : Matrix a a ℂ)).symm
    rw [Matrix.mul_one] at hmul
    exact hmul
  simp_rw [hterm]
  have hkr : (∑ j, Matrix.kronecker ((K j)ᴴ * K j) (1 : Matrix a a ℂ)) =
      Matrix.kronecker (∑ j, (K j)ᴴ * K j) (1 : Matrix a a ℂ) := by
    ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
    simp only [Matrix.sum_apply, Matrix.kronecker, Matrix.kroneckerMap_apply]
    rw [Finset.sum_mul]
  rw [hkr, hK]
  exact Matrix.one_kronecker_one

/-- Kraus completeness for `I_a ⊗ K j` on system `a × n`. -/
theorem kraus_left_ancilla_completeness
    (K : k → Matrix n n ℂ) (hK : ∑ j, (K j)ᴴ * K j = (1 : Matrix n n ℂ)) :
    ∑ j, (Matrix.kronecker (1 : Matrix a a ℂ) (K j))ᴴ *
         (Matrix.kronecker (1 : Matrix a a ℂ) (K j)) =
      (1 : Matrix (a × n) (a × n) ℂ) := by
  have hterm (j : k) :
      (Matrix.kronecker (1 : Matrix a a ℂ) (K j))ᴴ *
       (Matrix.kronecker (1 : Matrix a a ℂ) (K j)) =
      Matrix.kronecker (1 : Matrix a a ℂ) ((K j)ᴴ * K j) := by
    rw [kronecker_conjTranspose_v419, conjTranspose_one]
    have hmul := (Matrix.mul_kronecker_mul (1 : Matrix a a ℂ) (1 : Matrix a a ℂ) (K j)ᴴ (K j)).symm
    rw [Matrix.mul_one] at hmul
    exact hmul
  simp_rw [hterm]
  have hkr : (∑ j, Matrix.kronecker (1 : Matrix a a ℂ) ((K j)ᴴ * K j)) =
      Matrix.kronecker (1 : Matrix a a ℂ) (∑ j, (K j)ᴴ * K j) := by
    ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
    simp only [Matrix.sum_apply, Matrix.kronecker, Matrix.kroneckerMap_apply]
    rw [Finset.mul_sum]
  rw [hkr, hK]
  exact Matrix.one_kronecker_one

/-- Ancilla-stabilized CPTP channel (ancilla on right). -/
noncomputable def ancillaRightChannel
    (K : k → Matrix n n ℂ) (X : Matrix (n × a) (n × a) ℂ) :
    Matrix (n × a) (n × a) ℂ :=
  finiteKrausChannel (fun j => Matrix.kronecker (K j) (1 : Matrix a a ℂ)) X

/-- Ancilla-stabilized CPTP channel (ancilla on left). -/
noncomputable def ancillaLeftChannel
    (K : k → Matrix n n ℂ) (X : Matrix (a × n) (a × n) ℂ) :
    Matrix (a × n) (a × n) ℂ :=
  finiteKrausChannel (fun j => Matrix.kronecker (1 : Matrix a a ℂ) (K j)) X

/-- **Ancilla-stabilized CPTP contraction for arbitrary finite ancilla `a` (ancilla on right)**:
for every complex matrix `X` on `n × a`. -/
theorem schattenOne_ancillaRightChannel_le
    (K : k → Matrix n n ℂ) (hK : ∑ j, (K j)ᴴ * K j = (1 : Matrix n n ℂ))
    (X : Matrix (n × a) (n × a) ℂ) :
    schattenOneSpectralNorm (ancillaRightChannel K X) ≤
      schattenOneSpectralNorm X := by
  unfold ancillaRightChannel
  exact schattenOne_finiteKrausChannel_le
    (fun j => Matrix.kronecker (K j) (1 : Matrix a a ℂ))
    (kraus_right_ancilla_completeness K hK) X

/-- **Ancilla-stabilized CPTP contraction for arbitrary finite ancilla `a` (ancilla on left)**:
for every complex matrix `X` on `a × n`. -/
theorem schattenOne_ancillaLeftChannel_le
    (K : k → Matrix n n ℂ) (hK : ∑ j, (K j)ᴴ * K j = (1 : Matrix n n ℂ))
    (X : Matrix (a × n) (a × n) ℂ) :
    schattenOneSpectralNorm (ancillaLeftChannel K X) ≤
      schattenOneSpectralNorm X := by
  unfold ancillaLeftChannel
  exact schattenOne_finiteKrausChannel_le
    (fun j => Matrix.kronecker (1 : Matrix a a ℂ) (K j))
    (kraus_left_ancilla_completeness K hK) X

end AncillaCompleteness

section NormProperties

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- Triangle inequality for `schattenOneSpectralNorm`:
`schattenOneSpectralNorm (A + B) ≤ schattenOneSpectralNorm A + schattenOneSpectralNorm B`. -/
theorem schattenOne_add_le (A B : Matrix n n ℂ) :
    schattenOneSpectralNorm (A + B) ≤
      schattenOneSpectralNorm A + schattenOneSpectralNorm B := by
  let u : Fin 2 × n → n → ℂ := fun p =>
    if p.1 = 0 then A *ᵥ rv A p.2 else B *ᵥ rv B p.2
  let w : Fin 2 × n → n → ℂ := fun p =>
    if p.1 = 0 then rv A p.2 else rv B p.2
  have hdecomp : A + B = ∑ p : Fin 2 × n, vecMulVec (u p) (star (w p)) := by
    rw [Fintype.sum_prod_type, Fin.sum_univ_two]
    have h0 : (fun x : n => vecMulVec (u ((0 : Fin 2), x)) (star (w ((0 : Fin 2), x)))) =
        (fun x => vecMulVec (A *ᵥ rv A x) (star (rv A x))) := by
      ext x; simp [u, w]
    have h1 : (fun x : n => vecMulVec (u ((1 : Fin 2), x)) (star (w ((1 : Fin 2), x)))) =
        (fun x => vecMulVec (B *ᵥ rv B x) (star (rv B x))) := by
      ext x; simp [u, w]
    rw [h0, h1, ← svd_decomp A, ← svd_decomp B]
  have hle := schattenOne_le_cost (A + B) u w hdecomp
  refine hle.trans ?_
  rw [Fintype.sum_prod_type, Fin.sum_univ_two]
  have h0 : (fun x : n => BinduFiniteKrausCS.eucLength (u ((0 : Fin 2), x)) *
                          BinduFiniteKrausCS.eucLength (w ((0 : Fin 2), x))) =
      (fun x => BinduFiniteKrausCS.eucLength (A *ᵥ rv A x) *
                BinduFiniteKrausCS.eucLength (rv A x)) := by
    ext x; simp [u, w]
  have h1 : (fun x : n => BinduFiniteKrausCS.eucLength (u ((1 : Fin 2), x)) *
                          BinduFiniteKrausCS.eucLength (w ((1 : Fin 2), x))) =
      (fun x => BinduFiniteKrausCS.eucLength (B *ᵥ rv B x) *
                BinduFiniteKrausCS.eucLength (rv B x)) := by
    ext x; simp [u, w]
  rw [h0, h1]
  simp_rw [eucLength_X_rv, eucLength_rv, mul_one]
  rw [← schattenOne_eq_sum_sv, ← schattenOne_eq_sum_sv]

/-- Submultiplicativity under scalar multiplication:
`schattenOneSpectralNorm (c • A) ≤ ‖c‖ * schattenOneSpectralNorm A`. -/
theorem schattenOne_smul_le (c : ℂ) (A : Matrix n n ℂ) :
    schattenOneSpectralNorm (c • A) ≤ ‖c‖ * schattenOneSpectralNorm A := by
  let u : n → n → ℂ := fun i => c • (A *ᵥ rv A i)
  let w : n → n → ℂ := fun i => rv A i
  have hdecomp : c • A = ∑ i, vecMulVec (u i) (star (w i)) := by
    have hA : A = ∑ i, vecMulVec (A *ᵥ rv A i) (star (rv A i)) := svd_decomp A
    conv_lhs => rw [hA]
    rw [Finset.smul_sum]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    ext a b
    simp only [u, vecMulVec_apply, Matrix.smul_apply, Pi.smul_apply, smul_eq_mul]
    ring
  have hle := schattenOne_le_cost (c • A) u w hdecomp
  refine hle.trans ?_
  have hu (i : n) : BinduFiniteKrausCS.eucLength (u i) = ‖c‖ * BinduFiniteKrausCS.eucLength (A *ᵥ rv A i) := by
    unfold u BinduFiniteKrausCS.eucLength
    simp only [Pi.smul_apply, norm_smul, mul_pow]
    rw [← Finset.mul_sum, Real.sqrt_mul (sq_nonneg ‖c‖), Real.sqrt_sq (norm_nonneg c)]
  have hterm (i : n) :
      BinduFiniteKrausCS.eucLength (u i) * BinduFiniteKrausCS.eucLength (w i) =
        ‖c‖ * (sv A i) := by
    have hw : w i = rv A i := rfl
    rw [hu, eucLength_X_rv, hw, eucLength_rv, mul_one]
  rw [Finset.sum_congr rfl (fun i _ => hterm i)]
  rw [← Finset.mul_sum, ← schattenOne_eq_sum_sv]

theorem schattenOne_neg_eq (A : Matrix n n ℂ) :
    schattenOneSpectralNorm (-A) = schattenOneSpectralNorm A := by
  have h1 : schattenOneSpectralNorm (-A) ≤ schattenOneSpectralNorm A := by
    have hsmul : -A = (-1 : ℂ) • A := by simp
    rw [hsmul]
    have h := schattenOne_smul_le (-1 : ℂ) A
    simpa using h
  have h2 : schattenOneSpectralNorm A ≤ schattenOneSpectralNorm (-A) := by
    have hsmul : A = (-1 : ℂ) • (-A) := by simp
    conv_lhs => rw [hsmul]
    have h := schattenOne_smul_le (-1 : ℂ) (-A)
    simpa using h
  exact le_antisymm h1 h2

theorem schattenOne_sub_le (A B : Matrix n n ℂ) :
    schattenOneSpectralNorm (A - B) ≤
      schattenOneSpectralNorm A + schattenOneSpectralNorm B := by
  rw [sub_eq_add_neg]
  exact (schattenOne_add_le A (-B)).trans (by rw [schattenOne_neg_eq])

end NormProperties

section ChannelDifference

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- Difference of two CPTP channels is contractive with factor 2 on any ancilla `a`. -/
theorem cptp_channel_sub_le {k₁ k₂ a : Type*} [Fintype k₁] [Fintype k₂] [Fintype a] [DecidableEq a]
    (K₁ : k₁ → Matrix n n ℂ) (hK₁ : ∑ j, (K₁ j)ᴴ * K₁ j = (1 : Matrix n n ℂ))
    (K₂ : k₂ → Matrix n n ℂ) (hK₂ : ∑ j, (K₂ j)ᴴ * K₂ j = (1 : Matrix n n ℂ))
    (X : Matrix (n × a) (n × a) ℂ) :
    schattenOneSpectralNorm (ancillaRightChannel K₁ X - ancillaRightChannel K₂ X) ≤
      2 * schattenOneSpectralNorm X := by
  have hsub := schattenOne_sub_le (ancillaRightChannel K₁ X) (ancillaRightChannel K₂ X)
  have h1 := schattenOne_ancillaRightChannel_le K₁ hK₁ X
  have h2 := schattenOne_ancillaRightChannel_le K₂ hK₂ X
  linarith

end ChannelDifference

section NQubitTelescoping

/-- **Full diamond-norm contractivity for the arbitrary-N qubit Lindblad channel difference
from the stationary replacement channel on ANY finite-dimensional ancilla `a`**:
for all local rates `G m > 0, K m > 0`, all `t ≥ 0`, any finite ancilla `a`, and any
composite matrix `X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ`,
the difference is bounded by `2 * schattenOneSpectralNorm X` uniformly in `N`. -/
theorem nQubit_channel_sub_replacer_diamond_bound {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    {t : ℝ} (ht : 0 ≤ t)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm
      (ancillaRightChannel (nQubitKraus G K t) X -
       ancillaRightChannel (nQubitReplacerKraus G K) X) ≤
      2 * schattenOneSpectralNorm X := by
  exact cptp_channel_sub_le
    (nQubitKraus G K t) (nQubitKraus_completeness G K hG hK ht)
    (nQubitReplacerKraus G K) (nQubitReplacerKraus_completeness G K hG hK) X

/-- At `N = 0`, the Kraus channel and the replacer channel coincide identically,
so the difference vanishes for any ancilla `a`. -/
theorem nQubit_channel_sub_replacer_zero_qubits {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin 0 → ℝ) (t : ℝ)
    (X : Matrix (NQubitIndex 0 × a) (NQubitIndex 0 × a) ℂ) :
    ancillaRightChannel (nQubitKraus G K t) X =
      ancillaRightChannel (nQubitReplacerKraus G K) X := by
  unfold ancillaRightChannel finiteKrausChannel
  have hKraus : (nQubitKraus G K t : NQubitModeIndex 0 → Matrix (NQubitIndex 0) (NQubitIndex 0) ℂ) =
      nQubitReplacerKraus G K := by
    ext α i j
    have hα : α = default := Subsingleton.elim α default
    subst hα
    have hi : i = default := Subsingleton.elim i default
    have hj : j = default := Subsingleton.elim j default
    subst hi; subst hj
    simp [nQubitKraus, nQubitReplacerKraus, nQubitTensorProduct]
  rw [hKraus]

end NQubitTelescoping

end BinduEventInterface

#print axioms BinduEventInterface.kraus_right_ancilla_completeness
#print axioms BinduEventInterface.schattenOne_ancillaRightChannel_le
#print axioms BinduEventInterface.schattenOne_add_le
#print axioms BinduEventInterface.schattenOne_smul_le
#print axioms BinduEventInterface.cptp_channel_sub_le
#print axioms BinduEventInterface.nQubit_channel_sub_replacer_diamond_bound
#print axioms BinduEventInterface.nQubit_channel_sub_replacer_zero_qubits
