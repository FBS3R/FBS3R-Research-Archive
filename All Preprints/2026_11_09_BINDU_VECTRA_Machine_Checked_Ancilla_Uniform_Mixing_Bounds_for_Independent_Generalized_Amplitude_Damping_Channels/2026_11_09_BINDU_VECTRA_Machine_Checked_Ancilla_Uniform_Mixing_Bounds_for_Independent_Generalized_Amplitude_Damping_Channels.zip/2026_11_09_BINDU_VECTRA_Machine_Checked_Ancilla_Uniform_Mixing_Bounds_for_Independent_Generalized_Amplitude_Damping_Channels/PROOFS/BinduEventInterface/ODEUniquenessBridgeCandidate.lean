import BinduEventInterface.SampleAllTimeCertificateCandidate
import Mathlib.Analysis.Calculus.MeanValue

/-!
# Scalar GKSL population ODE uniqueness on nonnegative times

Compiled with Lean 4.19.0 and the project-pinned Mathlib v4.19.0.

The first theorem identifies any real differentiable trajectory solving the
single-site pump/loss equation on t >= 0 with the explicit checked solution.
The second composes two such trajectories and the checked
sampleTwoSite_belowQuarter bound.

The separate concrete two-qubit dynamics module now derives the scalar ODEs
from an entrywise density-matrix GKSL hypothesis. The corresponding
arbitrary-size and external-model bridge remains outside this module.
-/

namespace BinduEventInterface

/-- Uniqueness on the physical half-line for the scalar constant-rate
pump-loss equation, with vacuum initial condition. -/
theorem constantRatePopulation_unique_nonneg
    (G K : ℝ) (hpos : 0 < G + K)
    (q : ℝ → ℝ)
    (hq : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt q (G * (1 - q t) - K * q t) t)
    (h0 : q 0 = 0)
    (t : ℝ) (ht : 0 ≤ t) :
    q t = constantRatePopulation G K t := by
  let f : ℝ → ℝ := fun s =>
    Real.exp ((G + K) * s) * (q s - constantRatePopulation G K s)
  have hfderiv : ∀ s : ℝ, 0 ≤ s → HasDerivAt f 0 s := by
    intro s hs
    have hline : HasDerivAt (fun u : ℝ => (G + K) * u) (G + K) s := by
      simpa using (hasDerivAt_id s).const_mul (G + K)
    have hexp : HasDerivAt
        (fun u : ℝ => Real.exp ((G + K) * u))
        (Real.exp ((G + K) * s) * (G + K)) s :=
      (Real.hasDerivAt_exp _).comp s hline
    have hdiff : HasDerivAt
        (fun u : ℝ => q u - constantRatePopulation G K u)
        ((G * (1 - q s) - K * q s) -
         (G * (1 - constantRatePopulation G K s) -
          K * constantRatePopulation G K s)) s :=
      (hq s hs).sub (constantRatePopulation_hasDerivAt G K s hpos)
    have hprod := hexp.mul hdiff
    convert hprod using 1 <;> dsimp [f] <;> ring
  have hcont : ContinuousOn f (Set.Icc (0 : ℝ) t) := by
    intro s hs
    exact (hfderiv s hs.1).continuousAt.continuousWithinAt
  have hwithin : ∀ s ∈ Set.Ico (0 : ℝ) t,
      HasDerivWithinAt f 0 (Set.Ici s) s := by
    intro s hs
    exact (hfderiv s hs.1).hasDerivWithinAt
  have hft : f t = f 0 :=
    constant_of_has_deriv_right_zero hcont hwithin t ⟨ht, le_refl t⟩
  have hf0 : f 0 = 0 := by
    simp [f, h0, constantRatePopulation_initial]
  have hmul : Real.exp ((G + K) * t) *
      (q t - constantRatePopulation G K t) = 0 := by
    exact hft.trans hf0
  have hdiffzero : q t - constantRatePopulation G K t = 0 :=
    (mul_eq_zero.mp hmul).resolve_left (Real.exp_ne_zero _)
  exact sub_eq_zero.mp hdiffzero

/-- Any two real trajectories satisfying the sample single-site equations
and vacuum initial conditions obey the strict threshold at all t >= 0.
The antecedent ODE assumptions are not themselves a quantum-state theorem. -/
theorem sampleTwoSite_from_scalarODE
    (q₁ q₂ : ℝ → ℝ)
    (hq₁ : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt q₁
        (((1 : ℝ) / 5) * (1 - q₁ t) - ((3 : ℝ) / 7) * q₁ t) t)
    (hq₂ : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt q₂
        (((2 : ℝ) / 9) * (1 - q₂ t) - ((4 : ℝ) / 11) * q₂ t) t)
    (h₁ : q₁ 0 = 0) (h₂ : q₂ 0 = 0)
    (t : ℝ) (ht : 0 ≤ t) :
    q₁ t * q₂ t < (1 : ℝ) / 4 := by
  have heq₁ := constantRatePopulation_unique_nonneg
    ((1 : ℝ) / 5) ((3 : ℝ) / 7) (by norm_num) q₁ hq₁ h₁ t ht
  have heq₂ := constantRatePopulation_unique_nonneg
    ((2 : ℝ) / 9) ((4 : ℝ) / 11) (by norm_num) q₂ hq₂ h₂ t ht
  rw [heq₁, heq₂]
  exact sampleTwoSite_belowQuarter t ht

#print axioms constantRatePopulation_unique_nonneg
#print axioms sampleTwoSite_from_scalarODE

end BinduEventInterface
