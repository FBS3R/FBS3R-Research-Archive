import BinduEventInterface.TwoQubitLiouvillianSpectrumCandidate

/-!
# A spectral semigroup on all complex 4x4 matrices

Candidate Lean 4.19.0 proofs; not yet kernel-verified. All statements
refer to the exact fixed generator of the existing BINDU project.
No positivity, CP, or differentiability of a channel is assumed here.
-/

namespace BinduEventInterface

set_option maxHeartbeats 800000

open Matrix

/-- Spectral quantum evolution on arbitrary, possibly entangled/coherent,
    complex 4x4 inputs; defined from the already proven 16-mode basis. -/
noncomputable def twoQubitSpectralFlow (t : ℝ)
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  ∑ p : Fin 4 × Fin 4,
    ((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
      Matrix.trace (twoQubitDualMatrix p * M)) • twoQubitEigenMatrix p

/-- The spectral evolution is the identity at time zero. -/
theorem twoQubitSpectralFlow_zero
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitSpectralFlow 0 M = M := by
  unfold twoQubitSpectralFlow
  simp only [mul_zero, Real.exp_zero, Complex.ofReal_one, one_mul]
  exact (twoQubit_matrix_spectral_expansion M).symm

/-- Exact propagation of each of the 16 spectral coefficients. -/
theorem twoQubitSpectralFlow_dual_trace
    (p : Fin 4 × Fin 4) (t : ℝ)
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Matrix.trace (twoQubitDualMatrix p * twoQubitSpectralFlow t M) =
      (Real.exp (twoQubitEigenvalue p * t) : ℂ) *
        Matrix.trace (twoQubitDualMatrix p * M) := by
  classical
  unfold twoQubitSpectralFlow
  simp only [Matrix.mul_sum, Matrix.trace_sum,
    mul_smul_comm, Matrix.trace_smul, smul_eq_mul]
  rw [Finset.sum_eq_single p]
  · rw [twoQubit_dual_eigen_trace p p]
    simp
  · intro q _ hqp
    rw [twoQubit_dual_eigen_trace p q]
    simp [Ne.symm hqp]
  · intro hp
    exact False.elim (hp (Finset.mem_univ p))

/-- The whole 16-dimensional semigroup property, for arbitrary matrices.
    Algebraic equality holds for all real s,t; physical CP is restricted
    to the nonnegative half-line and remains a separate obligation. -/
theorem twoQubitSpectralFlow_semigroup (s t : ℝ)
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitSpectralFlow (t + s) M =
      twoQubitSpectralFlow t (twoQubitSpectralFlow s M) := by
  have hcoeff (p : Fin 4 × Fin 4) :
      Matrix.trace (twoQubitDualMatrix p * twoQubitSpectralFlow (t + s) M) =
        Matrix.trace (twoQubitDualMatrix p *
          twoQubitSpectralFlow t (twoQubitSpectralFlow s M)) := by
    rw [twoQubitSpectralFlow_dual_trace p (t + s) M,
      twoQubitSpectralFlow_dual_trace p t (twoQubitSpectralFlow s M),
      twoQubitSpectralFlow_dual_trace p s M]
    rw [mul_add, Real.exp_add, Complex.ofReal_mul]
    ring
  calc
    twoQubitSpectralFlow (t + s) M =
        ∑ p : Fin 4 × Fin 4,
          Matrix.trace (twoQubitDualMatrix p * twoQubitSpectralFlow (t + s) M) •
            twoQubitEigenMatrix p :=
      twoQubit_matrix_spectral_expansion _
    _ = ∑ p : Fin 4 × Fin 4,
          Matrix.trace (twoQubitDualMatrix p *
            twoQubitSpectralFlow t (twoQubitSpectralFlow s M)) •
              twoQubitEigenMatrix p := by
      apply Finset.sum_congr rfl
      intro p _
      rw [hcoeff p]
    _ = twoQubitSpectralFlow t (twoQubitSpectralFlow s M) :=
      (twoQubit_matrix_spectral_expansion _).symm

/-- Trace preservation on all input matrices, not just density matrices. -/
theorem twoQubitSpectralFlow_trace (t : ℝ)
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Matrix.trace (twoQubitSpectralFlow t M) = Matrix.trace M := by
  have h := twoQubitSpectralFlow_dual_trace
    ((0 : Fin 4), (0 : Fin 4)) t M
  simp only [twoQubitDualMatrix_zero_zero, Matrix.one_mul,
    twoQubitEigenvalue_zero_zero, zero_mul, Real.exp_zero,
    Complex.ofReal_one, one_mul] at h
  exact h

/-- The stationary state is a fixed point of this spectral semigroup. -/
theorem twoQubitSpectralFlow_equilibrium (t : ℝ) :
    twoQubitSpectralFlow t twoQubitEquilibrium = twoQubitEquilibrium := by
  have hzero (p : Fin 4 × Fin 4) :
      Matrix.trace (twoQubitDualMatrix p * twoQubitEquilibrium) =
        if p = ((0 : Fin 4), (0 : Fin 4)) then 1 else 0 := by
    rw [← twoQubitEigenMatrix_zero_zero]
    exact twoQubit_dual_eigen_trace p ((0 : Fin 4), (0 : Fin 4))
  have hcoeff (p : Fin 4 × Fin 4) :
      Matrix.trace (twoQubitDualMatrix p *
        twoQubitSpectralFlow t twoQubitEquilibrium) =
      Matrix.trace (twoQubitDualMatrix p * twoQubitEquilibrium) := by
    rw [twoQubitSpectralFlow_dual_trace p t twoQubitEquilibrium]
    by_cases hp : p = ((0 : Fin 4), (0 : Fin 4))
    · subst p
      simp only [twoQubitEigenvalue_zero_zero, zero_mul,
        Real.exp_zero, Complex.ofReal_one, one_mul]
    · simp only [hzero p, if_neg hp, mul_zero]
  calc
    twoQubitSpectralFlow t twoQubitEquilibrium =
        ∑ p : Fin 4 × Fin 4,
          Matrix.trace (twoQubitDualMatrix p *
            twoQubitSpectralFlow t twoQubitEquilibrium) • twoQubitEigenMatrix p :=
      twoQubit_matrix_spectral_expansion _
    _ = ∑ p : Fin 4 × Fin 4,
          Matrix.trace (twoQubitDualMatrix p * twoQubitEquilibrium) •
            twoQubitEigenMatrix p := by
      apply Finset.sum_congr rfl
      intro p _
      rw [hcoeff p]
    _ = twoQubitEquilibrium :=
      (twoQubit_matrix_spectral_expansion _).symm

end BinduEventInterface
