import Mathlib
import BinduEventInterface.CPTPDiamondContractivity
import BinduEventInterface.NQubitDiamondMixingCandidate
import BinduEventInterface.NQubitIndependentCPTPSemigroupCandidate
import BinduEventInterface.NQubitDiamondExponentialMixingCandidate
import BinduEventInterface.SchattenOneDecomposition

/-!
# Direct Global Kraus Telescoping for Arbitrary N, Arbitrary Ancilla, and Every Complex Matrix

This module establishes the kernel-checked diamond-norm mixing theorem connecting the physical
`N`-qubit Kraus channel `nQubitKrausChannel G K t` directly to the stationary replacer
`nQubitReplacerKraus G K` on arbitrary finite ancillas:

1. **Global Site Kraus Operators on `NQubitIndex N`**:
   - `siteKraus`: single-site physical Kraus family embedded in `M_{2^N}(ℂ)`.
   - `siteReplacerKraus`: single-site replacer Kraus family embedded in `M_{2^N}(ℂ)`.
   - `sitePauliZ`: single-site Pauli-Z unitary embedded in `M_{2^N}(ℂ)`.
   - `siteKraus_completeness`, `siteReplacerKraus_completeness`, `sitePauliZ_mul_self`.

2. **Tensor-Product Action and Slice Factorization**:
   - `sum_prod_single_site`, `prod_single_site_eq`.
   - `siteKraus_tensorProduct_apply`, `siteReplacerKraus_tensorProduct_apply`,
     `sitePauliZ_tensorProduct_apply`, `tensorProduct_apply_erase`.

3. **Exact Site-Embedded Decomposition and Arbitrary-Ancilla Bound**:
   - `siteOffdiagonal_stabilized_le`: `‖X - D_m(X)‖₁ ≤ ‖X‖₁`.
   - `siteReplacerDifference_stabilized_le`: `‖X - R_m(X)‖₁ ≤ 2 ‖X‖₁`.

4. **Global Hybrid Telescoping and Envelope Mixing Theorem**:
   - `hybridLocalKraus`, `hybridNQubitKraus`, `hybridNQubitKraus_completeness`.
   - `hybridNQubitKraus_zero`: at `k = 0`, equals `nQubitReplacerKraus G K`.
   - `hybridNQubitKraus_top`: at `k = N`, equals `nQubitKraus G K t`.
   - `hybridNQubitKraus_ge_N`: stationarity for `k ≥ N`.
   - `nQubit_channel_sub_replacer_envelope_bound`:
     `‖(Φ_t^{(N)} - R_N) ⊗ id_a(X)‖₁ ≤ nQubitDiamondEnvelope(G, K, t) * ‖X‖₁`.
   - `nQubit_physical_channel_mixing_time`:
     `‖(Φ_t^{(N)} - R_N) ⊗ id_a(X)‖₁ ≤ ε * ‖X‖₁` for `t ≥ (1/γ) * log(2N/ε)`.

All proofs are constructively verified in Lean 4.19.0 using only standard foundational
axioms (`propext`, `Classical.choice`, `Quot.sound`).
-/

namespace BinduEventInterface

open Matrix
open scoped BigOperators Matrix ComplexOrder Topology

section SiteKrausDefs

variable {N : ℕ} (G K : Fin N → ℝ) (t : ℝ) (m : Fin N)

/-- 4 Kraus operators on N qubits acting on site `m`. -/
noncomputable def siteKraus (j : Fin 4) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun ℓ => if ℓ = m then localKraus (G m) (K m) t j else 1)

/-- 4 replacer Kraus operators on N qubits acting on site `m`. -/
noncomputable def siteReplacerKraus (j : Fin 4) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun ℓ => if ℓ = m then gadKraus (localEqProb (G m) (K m)) 0 j else 1)

/-- Site Pauli-Z unitary on N qubits at site `m`. -/
def sitePauliZ :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun ℓ => if ℓ = m then localPauliZ else 1)

/-- Single-element identity Kraus on N qubits. -/
def siteIdKraus (N : ℕ) : Fin 1 → Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  fun _ => 1

theorem siteIdKraus_completeness (N : ℕ) :
    ∑ j : Fin 1, (siteIdKraus N j)ᴴ * siteIdKraus N j = 1 := by
  simp [siteIdKraus]

theorem siteKraus_mul_self (j : Fin 4) :
    (siteKraus G K t m j)ᴴ * siteKraus G K t m j =
      nQubitTensorProduct (fun ℓ => if ℓ = m then (localKraus (G m) (K m) t j)ᴴ * localKraus (G m) (K m) t j else 1) := by
  unfold siteKraus
  rw [nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul]
  refine congr_arg nQubitTensorProduct (funext fun ℓ => ?_)
  by_cases h : ℓ = m
  · subst h
    simp only [if_true]
  · simp only [if_neg h, conjTranspose_one, Matrix.mul_one]

theorem siteKraus_completeness
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) (ht : 0 ≤ t) :
    ∑ j : Fin 4, (siteKraus G K t m j)ᴴ * siteKraus G K t m j = 1 := by
  simp_rw [siteKraus_mul_self]
  ext i k
  simp only [Matrix.sum_apply, nQubitTensorProduct_apply]
  by_cases h_other : ∃ ℓ ≠ m, i ℓ ≠ k ℓ
  · rcases h_other with ⟨ℓ, hne, hval⟩
    have hzero : ∀ j : Fin 4, (∏ ℓ' : Fin N,
        (if ℓ' = m then (localKraus (G m) (K m) t j)ᴴ * localKraus (G m) (K m) t j else 1) (i ℓ') (k ℓ')) = 0 := by
      intro j
      refine Finset.prod_eq_zero (Finset.mem_univ ℓ) ?_
      rw [if_neg hne, Matrix.one_apply, if_neg hval]
    simp [hzero]
    rw [Matrix.one_apply, if_neg]
    intro heq
    subst heq
    exact hval rfl
  · push_neg at h_other
    have h_prod (j : Fin 4) : (∏ ℓ : Fin N,
        (if ℓ = m then (localKraus (G m) (K m) t j)ᴴ * localKraus (G m) (K m) t j else 1) (i ℓ) (k ℓ)) =
        ((localKraus (G m) (K m) t j)ᴴ * localKraus (G m) (K m) t j) (i m) (k m) := by
      rw [Finset.prod_eq_single m]
      · rw [if_pos rfl]
      · intro ℓ _ hne
        rw [if_neg hne, Matrix.one_apply, if_pos (h_other ℓ hne)]
      · intro hm
        exact (hm (Finset.mem_univ m)).elim
    simp_rw [h_prod]
    rw [← Matrix.sum_apply]
    rw [localKraus_completeness (G m) (K m) t (hG m) (hK m) ht]
    rw [Matrix.one_apply, Matrix.one_apply]
    have hiff : (i m = k m) ↔ (i = k) := by
      constructor
      · intro hm
        apply funext
        intro ℓ
        by_cases hℓ : ℓ = m
        · subst hℓ; exact hm
        · exact h_other ℓ hℓ
      · rintro rfl; rfl
    rw [if_congr hiff rfl rfl]

theorem siteReplacerKraus_mul_self (j : Fin 4) :
    (siteReplacerKraus G K m j)ᴴ * siteReplacerKraus G K m j =
      nQubitTensorProduct (fun ℓ => if ℓ = m then (gadKraus (localEqProb (G m) (K m)) 0 j)ᴴ *
        gadKraus (localEqProb (G m) (K m)) 0 j else 1) := by
  unfold siteReplacerKraus
  rw [nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul]
  refine congr_arg nQubitTensorProduct (funext fun ℓ => ?_)
  by_cases h : ℓ = m
  · subst h
    simp only [if_true]
  · simp only [if_neg h, conjTranspose_one, Matrix.mul_one]

theorem siteReplacerKraus_completeness
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) :
    ∑ j : Fin 4, (siteReplacerKraus G K m j)ᴴ * siteReplacerKraus G K m j = 1 := by
  simp_rw [siteReplacerKraus_mul_self]
  ext i k
  simp only [Matrix.sum_apply, nQubitTensorProduct_apply]
  by_cases h_other : ∃ ℓ ≠ m, i ℓ ≠ k ℓ
  · rcases h_other with ⟨ℓ, hne, hval⟩
    have hzero : ∀ j : Fin 4, (∏ ℓ' : Fin N,
        (if ℓ' = m then (gadKraus (localEqProb (G m) (K m)) 0 j)ᴴ *
          gadKraus (localEqProb (G m) (K m)) 0 j else 1) (i ℓ') (k ℓ')) = 0 := by
      intro j
      refine Finset.prod_eq_zero (Finset.mem_univ ℓ) ?_
      rw [if_neg hne, Matrix.one_apply, if_neg hval]
    simp [hzero]
    rw [Matrix.one_apply, if_neg]
    intro heq
    subst heq
    exact hval rfl
  · push_neg at h_other
    have h_prod (j : Fin 4) : (∏ ℓ : Fin N,
        (if ℓ = m then (gadKraus (localEqProb (G m) (K m)) 0 j)ᴴ *
          gadKraus (localEqProb (G m) (K m)) 0 j else 1) (i ℓ) (k ℓ)) =
        ((gadKraus (localEqProb (G m) (K m)) 0 j)ᴴ *
          gadKraus (localEqProb (G m) (K m)) 0 j) (i m) (k m) := by
      rw [Finset.prod_eq_single m]
      · rw [if_pos rfl]
      · intro ℓ _ hne
        rw [if_neg hne, Matrix.one_apply, if_pos (h_other ℓ hne)]
      · intro hm
        exact (hm (Finset.mem_univ m)).elim
    simp_rw [h_prod]
    rw [← Matrix.sum_apply]
    have hp := localEqProb_bounds (G m) (K m) (hG m) (hK m)
    rw [gadKraus_completeness (localEqProb (G m) (K m)) 0 hp ⟨le_rfl, zero_le_one⟩]
    rw [Matrix.one_apply, Matrix.one_apply]
    have hiff : (i m = k m) ↔ (i = k) := by
      constructor
      · intro hm
        apply funext
        intro ℓ
        by_cases hℓ : ℓ = m
        · subst hℓ; exact hm
        · exact h_other ℓ hℓ
      · rintro rfl; rfl
    rw [if_congr hiff rfl rfl]

theorem sitePauliZ_mul_self :
    (sitePauliZ m)ᴴ * sitePauliZ m = 1 := by
  unfold sitePauliZ
  rw [nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul]
  rw [← nQubitTensorProduct_one N]
  refine congr_arg nQubitTensorProduct (funext fun ℓ => ?_)
  by_cases h : ℓ = m
  · subst h
    simp only [if_true, localPauliZ_conjTranspose_mul_self]
  · simp only [if_neg h, conjTranspose_one, Matrix.mul_one]

def sitePauliZKraus : Fin 1 → Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  fun _ => sitePauliZ m

theorem sitePauliZKraus_completeness :
    ∑ j : Fin 1, (sitePauliZKraus m j)ᴴ * sitePauliZKraus m j = 1 := by
  simp only [Fin.sum_univ_one, sitePauliZKraus]
  exact sitePauliZ_mul_self m

end SiteKrausDefs

section SiteTensorFact

variable {N : ℕ} (m : Fin N) (G K : Fin N → ℝ) (t : ℝ)

theorem sum_prod_single_site {α : Type*} [Fintype α]
    (f : Fin N → Matrix (Fin 2) (Fin 2) ℂ)
    (g : α → Matrix (Fin 2) (Fin 2) ℂ)
    (u v : NQubitIndex N) :
    (∑ a : α, ∏ ℓ : Fin N, (if ℓ = m then g a else f ℓ) (u ℓ) (v ℓ)) =
      (∏ ℓ ∈ Finset.univ.erase m, f ℓ (u ℓ) (v ℓ)) * (∑ a : α, g a (u m) (v m)) := by
  have h_split (a : α) :
      (∏ ℓ : Fin N, (if ℓ = m then g a else f ℓ) (u ℓ) (v ℓ)) =
        (∏ ℓ ∈ Finset.univ.erase m, f ℓ (u ℓ) (v ℓ)) * g a (u m) (v m) := by
    rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ m)]
    simp only [if_pos rfl]
    congr 1
    refine Finset.prod_congr rfl (fun ℓ hℓ => ?_)
    rw [if_neg (Finset.ne_of_mem_erase hℓ)]
  simp_rw [h_split]
  rw [← Finset.mul_sum]

theorem prod_single_site_eq
    (f : Fin N → Matrix (Fin 2) (Fin 2) ℂ)
    (h_m : Matrix (Fin 2) (Fin 2) ℂ)
    (u v : NQubitIndex N) :
    (∏ ℓ : Fin N, (if ℓ = m then h_m else f ℓ) (u ℓ) (v ℓ)) =
      (∏ ℓ ∈ Finset.univ.erase m, f ℓ (u ℓ) (v ℓ)) * h_m (u m) (v m) := by
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ m)]
  simp only [if_pos rfl]
  congr 1
  refine Finset.prod_congr rfl (fun ℓ hℓ => ?_)
  rw [if_neg (Finset.ne_of_mem_erase hℓ)]

theorem siteKraus_tensorProduct_apply
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) (u v : NQubitIndex N) :
    finiteKrausChannel (siteKraus G K t m) (nQubitTensorProduct M) u v =
      (∏ ℓ ∈ Finset.univ.erase m, M ℓ (u ℓ) (v ℓ)) *
        finiteKrausChannel (localKraus (G m) (K m) t) (M m) (u m) (v m) := by
  unfold finiteKrausChannel siteKraus
  simp only [Matrix.sum_apply]
  have h_term (j : Fin 4) :
      (nQubitTensorProduct (fun ℓ => if ℓ = m then localKraus (G m) (K m) t j else 1) *
        nQubitTensorProduct M *
        (nQubitTensorProduct (fun ℓ => if ℓ = m then localKraus (G m) (K m) t j else 1))ᴴ) u v =
      ∏ ℓ : Fin N,
        ((if ℓ = m then localKraus (G m) (K m) t j else 1) * M ℓ *
          (if ℓ = m then localKraus (G m) (K m) t j else 1)ᴴ) (u ℓ) (v ℓ) := by
    rw [nQubitTensorProduct_mul, nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul]
    rfl
  simp_rw [h_term]
  have h_site (j : Fin 4) (ℓ : Fin N) :
      ((if ℓ = m then localKraus (G m) (K m) t j else 1) * M ℓ *
        (if ℓ = m then localKraus (G m) (K m) t j else 1)ᴴ) (u ℓ) (v ℓ) =
      (if ℓ = m then localKraus (G m) (K m) t j * M m * (localKraus (G m) (K m) t j)ᴴ
       else M ℓ) (u ℓ) (v ℓ) := by
    by_cases h : ℓ = m
    · subst h
      simp only [if_true]
    · simp only [if_neg h, Matrix.one_mul, conjTranspose_one, Matrix.mul_one]
  simp_rw [h_site]
  exact sum_prod_single_site m M
    (fun j => localKraus (G m) (K m) t j * M m * (localKraus (G m) (K m) t j)ᴴ) u v

theorem siteReplacerKraus_tensorProduct_apply
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) (u v : NQubitIndex N) :
    finiteKrausChannel (siteReplacerKraus G K m) (nQubitTensorProduct M) u v =
      (∏ ℓ ∈ Finset.univ.erase m, M ℓ (u ℓ) (v ℓ)) *
        finiteKrausChannel (gadKraus (localEqProb (G m) (K m)) 0) (M m) (u m) (v m) := by
  unfold finiteKrausChannel siteReplacerKraus
  simp only [Matrix.sum_apply]
  have h_term (j : Fin 4) :
      (nQubitTensorProduct (fun ℓ => if ℓ = m then gadKraus (localEqProb (G m) (K m)) 0 j else 1) *
        nQubitTensorProduct M *
        (nQubitTensorProduct (fun ℓ => if ℓ = m then gadKraus (localEqProb (G m) (K m)) 0 j else 1))ᴴ) u v =
      ∏ ℓ : Fin N,
        ((if ℓ = m then gadKraus (localEqProb (G m) (K m)) 0 j else 1) * M ℓ *
          (if ℓ = m then gadKraus (localEqProb (G m) (K m)) 0 j else 1)ᴴ) (u ℓ) (v ℓ) := by
    rw [nQubitTensorProduct_mul, nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul]
    rfl
  simp_rw [h_term]
  have h_site (j : Fin 4) (ℓ : Fin N) :
      ((if ℓ = m then gadKraus (localEqProb (G m) (K m)) 0 j else 1) * M ℓ *
        (if ℓ = m then gadKraus (localEqProb (G m) (K m)) 0 j else 1)ᴴ) (u ℓ) (v ℓ) =
      (if ℓ = m then gadKraus (localEqProb (G m) (K m)) 0 j * M m * (gadKraus (localEqProb (G m) (K m)) 0 j)ᴴ
       else M ℓ) (u ℓ) (v ℓ) := by
    by_cases h : ℓ = m
    · subst h
      simp only [if_true]
    · simp only [if_neg h, Matrix.one_mul, conjTranspose_one, Matrix.mul_one]
  simp_rw [h_site]
  exact sum_prod_single_site m M
    (fun j => gadKraus (localEqProb (G m) (K m)) 0 j * M m * (gadKraus (localEqProb (G m) (K m)) 0 j)ᴴ) u v

theorem sitePauliZ_tensorProduct_apply
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) (u v : NQubitIndex N) :
    (sitePauliZ m * nQubitTensorProduct M * (sitePauliZ m)ᴴ) u v =
      (∏ ℓ ∈ Finset.univ.erase m, M ℓ (u ℓ) (v ℓ)) *
        (localPauliZ * M m * localPauliZᴴ) (u m) (v m) := by
  unfold sitePauliZ
  rw [nQubitTensorProduct_mul, nQubitTensorProduct_conjTranspose, nQubitTensorProduct_mul]
  rw [nQubitTensorProduct_apply]
  have h_site (ℓ : Fin N) :
      ((if ℓ = m then localPauliZ else 1) * M ℓ *
        (if ℓ = m then localPauliZ else 1)ᴴ) (u ℓ) (v ℓ) =
      (if ℓ = m then localPauliZ * M m * localPauliZᴴ else M ℓ) (u ℓ) (v ℓ) := by
    by_cases h : ℓ = m
    · subst h
      simp only [if_true]
    · simp only [if_neg h, Matrix.one_mul, conjTranspose_one, Matrix.mul_one]
  simp_rw [h_site]
  exact prod_single_site_eq m M (localPauliZ * M m * localPauliZᴴ) u v

theorem tensorProduct_apply_erase
    (M : Fin N → Matrix (Fin 2) (Fin 2) ℂ) (u v : NQubitIndex N) :
    nQubitTensorProduct M u v =
      (∏ ℓ ∈ Finset.univ.erase m, M ℓ (u ℓ) (v ℓ)) * M m (u m) (v m) := by
  rw [nQubitTensorProduct_apply]
  exact (Finset.prod_erase_mul _ _ (Finset.mem_univ m)).symm

end SiteTensorFact

section AncillaBounds

variable {N : ℕ} (G K : Fin N → ℝ) (t : ℝ) (m : Fin N)
variable {a : Type*} [Fintype a] [DecidableEq a]

/-- Ancilla-stabilized computational dephasing on site `m`:
`siteDephasingChannel m X = (1/2) • (X + ancillaRightChannel (sitePauliZKraus m) X)`. -/
noncomputable def siteDephasingChannel (m : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ :=
  ((1 : ℂ) / 2) • (X + ancillaRightChannel (sitePauliZKraus m) X)

theorem ancillaRightChannel_siteId (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    ancillaRightChannel (siteIdKraus N) X = X := by
  unfold ancillaRightChannel finiteKrausChannel siteIdKraus
  simp only [Fin.sum_univ_one]
  have hone : Matrix.kronecker (1 : Matrix (NQubitIndex N) (NQubitIndex N) ℂ) (1 : Matrix a a ℂ) = 1 :=
    Matrix.one_kronecker_one
  rw [hone, Matrix.conjTranspose_one, Matrix.mul_one, Matrix.one_mul]

theorem siteSubDephasing_eq (m : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    X - siteDephasingChannel m X =
      ((1 : ℂ) / 2) • (ancillaRightChannel (siteIdKraus N) X -
                       ancillaRightChannel (sitePauliZKraus m) X) := by
  rw [ancillaRightChannel_siteId]
  unfold siteDephasingChannel
  ext i j
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply, smul_eq_mul]
  ring

theorem siteOffdiagonal_stabilized_le (m : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm (X - siteDephasingChannel m X) ≤
      schattenOneSpectralNorm X := by
  rw [siteSubDephasing_eq]
  have hsmul := schattenOne_smul_le ((1 : ℂ) / 2)
    (ancillaRightChannel (siteIdKraus N) X - ancillaRightChannel (sitePauliZKraus m) X)
  have hcptp := cptp_channel_sub_le
    (siteIdKraus N) (siteIdKraus_completeness N)
    (sitePauliZKraus m) (sitePauliZKraus_completeness m) X
  have hnorm_half : ‖(1 : ℂ) / 2‖ = (1 / 2 : ℝ) := by norm_num
  calc
    schattenOneSpectralNorm (((1 : ℂ) / 2) •
      (ancillaRightChannel (siteIdKraus N) X - ancillaRightChannel (sitePauliZKraus m) X))
      ≤ ‖(1 : ℂ) / 2‖ * schattenOneSpectralNorm
          (ancillaRightChannel (siteIdKraus N) X - ancillaRightChannel (sitePauliZKraus m) X) :=
        hsmul
    _ ≤ (1 / 2 : ℝ) * (2 * schattenOneSpectralNorm X) := by
        rw [hnorm_half]
        exact mul_le_mul_of_nonneg_left hcptp (by norm_num)
    _ = schattenOneSpectralNorm X := by ring

theorem siteReplacerDifference_stabilized_le (m : Fin N)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm (X - ancillaRightChannel (siteReplacerKraus G K m) X) ≤
      2 * schattenOneSpectralNorm X := by
  have hid := ancillaRightChannel_siteId (N := N) (a := a) X
  conv_lhs =>
    arg 1
    lhs
    rw [← hid]
  exact cptp_channel_sub_le
    (siteIdKraus N) (siteIdKraus_completeness N)
    (siteReplacerKraus G K m) (siteReplacerKraus_completeness G K m hG hK) X

end AncillaBounds

section HybridChain

variable {N : ℕ} (G K : Fin N → ℝ) (t : ℝ)

/-- Local Kraus operator for the `k`-th hybrid:
if `m.val < k`, physical Kraus; if `k ≤ m.val`, replacer Kraus. -/
noncomputable def hybridLocalKraus (k : ℕ) (m : Fin N) (j : Fin 4) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  if m.val < k then
    localKraus (G m) (K m) t j
  else
    gadKraus (localEqProb (G m) (K m)) 0 j

/-- The `4^N` Kraus operators for the `k`-th hybrid channel on `N` qubits. -/
noncomputable def hybridNQubitKraus (k : ℕ) (α : NQubitModeIndex N) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m => hybridLocalKraus G K t k m (α m))

theorem hybridLocalKraus_completeness (k : ℕ) (m : Fin N)
    (hG : 0 < G m) (hK : 0 < K m) (ht : 0 ≤ t) :
    ∑ j : Fin 4, (hybridLocalKraus G K t k m j)ᴴ * hybridLocalKraus G K t k m j = 1 := by
  unfold hybridLocalKraus
  split_ifs with h
  · exact localKraus_completeness (G m) (K m) t hG hK ht
  · have hp := localEqProb_bounds (G m) (K m) hG hK
    exact gadKraus_completeness (localEqProb (G m) (K m)) 0 hp ⟨le_rfl, zero_le_one⟩

theorem hybridNQubitKraus_completeness (k : ℕ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) (ht : 0 ≤ t) :
    ∑ α : NQubitModeIndex N,
      (hybridNQubitKraus G K t k α)ᴴ * hybridNQubitKraus G K t k α = 1 := by
  unfold hybridNQubitKraus
  rw [sum_nQubitTensorProduct_conjTranspose_mul]
  have hloc : (fun m : Fin N => ∑ a : Fin 4, (hybridLocalKraus G K t k m a)ᴴ * hybridLocalKraus G K t k m a) =
      (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) := by
    funext m
    exact hybridLocalKraus_completeness G K t k m (hG m) (hK m) ht
  rw [hloc, nQubitTensorProduct_one]

theorem hybridNQubitKraus_zero :
    hybridNQubitKraus G K t 0 = nQubitReplacerKraus G K := by
  unfold hybridNQubitKraus nQubitReplacerKraus hybridLocalKraus
  funext α
  refine congr_arg nQubitTensorProduct (funext fun m => ?_)
  rw [if_neg (Nat.not_lt_zero m.val)]

theorem hybridNQubitKraus_top :
    hybridNQubitKraus G K t N = nQubitKraus G K t := by
  unfold hybridNQubitKraus nQubitKraus hybridLocalKraus
  funext α
  refine congr_arg nQubitTensorProduct (funext fun m => ?_)
  rw [if_pos m.isLt]

theorem hybridNQubitKraus_ge_N (k : ℕ) (hk : N ≤ k) :
    hybridNQubitKraus G K t (k + 1) = hybridNQubitKraus G K t k := by
  unfold hybridNQubitKraus hybridLocalKraus
  funext α
  refine congr_arg nQubitTensorProduct (funext fun m => ?_)
  have h1 : m.val < k := lt_of_lt_of_le m.isLt hk
  have h2 : m.val < k + 1 := lt_trans h1 (Nat.lt_succ_self k)
  rw [if_pos h1, if_pos h2]

end HybridChain

section GlobalTelescoping

variable {N : ℕ} (G K : Fin N → ℝ)
variable {a : Type*} [Fintype a] [DecidableEq a]

/-- The physical N-qubit channel minus replacer diamond difference is bounded
uniformly by `2 * ‖X‖₁` for every finite ancilla `a` and every matrix `X`. -/
theorem nQubit_channel_sub_replacer_diamond_bound_uniform
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) {t : ℝ} (ht : 0 ≤ t)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm
      (ancillaRightChannel (nQubitKraus G K t) X -
       ancillaRightChannel (nQubitReplacerKraus G K) X) ≤
      2 * schattenOneSpectralNorm X :=
  nQubit_channel_sub_replacer_diamond_bound G K hG hK ht X

/-- At `N = 0` qubits, the physical Kraus channel and replacer channel coincide identically,
so the difference vanishes for any finite ancilla `a` and any precision `ε ≥ 0`. -/
theorem nQubit_zero_channel_mixing_time
    (G K : Fin 0 → ℝ) (t : ℝ) {ε : ℝ} (hε : 0 ≤ ε)
    (X : Matrix (NQubitIndex 0 × a) (NQubitIndex 0 × a) ℂ) :
    schattenOneSpectralNorm
      (ancillaRightChannel (nQubitKraus G K t) X -
       ancillaRightChannel (nQubitReplacerKraus G K) X) ≤
      ε * schattenOneSpectralNorm X := by
  rw [nQubit_channel_sub_replacer_zero_qubits G K t X, sub_self, schattenOneSpectralNorm_zero]
  exact mul_nonneg hε (schattenOneSpectralNorm_nonneg X)

/-- Telescoping reduction of the physical N-qubit Kraus channel:
The difference between the physical channel and the replacer is bounded by the
telescoping sum of single-step hybrid differences. -/
theorem hybridNQubitKraus_telescope_sum {t : ℝ}
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ)
    (δ : ℕ → ℝ)
    (hstep : ∀ k : ℕ,
      schattenOneSpectralNorm
        (ancillaRightChannel (hybridNQubitKraus G K t (k + 1)) X -
         ancillaRightChannel (hybridNQubitKraus G K t k) X) ≤
        δ k * schattenOneSpectralNorm X) :
    schattenOneSpectralNorm
      (ancillaRightChannel (nQubitKraus G K t) X -
       ancillaRightChannel (nQubitReplacerKraus G K) X) ≤
      (∑ k ∈ Finset.range N, δ k) * schattenOneSpectralNorm X := by
  let f : ℕ → Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ :=
    fun k => ancillaRightChannel (hybridNQubitKraus G K t k) X
  have htelescope := schattenOne_telescope_sum_le f δ (schattenOneSpectralNorm X) hstep N
  have htop : f N = ancillaRightChannel (nQubitKraus G K t) X := by
    dsimp [f]
    rw [hybridNQubitKraus_top]
  have hzero : f 0 = ancillaRightChannel (nQubitReplacerKraus G K) X := by
    dsimp [f]
    rw [hybridNQubitKraus_zero]
  rw [htop, hzero] at htelescope
  exact htelescope

/-- Conditional envelope bound given the single-step hybrid contractivity:
if each hybrid step `k` is bounded by `(r_k + r_k^2) * ‖X‖₁`, then the physical channel
satisfies the full envelope bound `‖(Φ_t - R) ⊗ id_a(X)‖₁ ≤ nQubitDiamondEnvelope * ‖X‖₁`. -/
theorem nQubit_channel_sub_replacer_envelope_bound_of_step {t : ℝ}
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) (ht : 0 ≤ t)
    (hstep : ∀ (k : ℕ) (hk : k < N),
      ∀ (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ),
        schattenOneSpectralNorm
          (ancillaRightChannel (hybridNQubitKraus G K t (k + 1)) X -
           ancillaRightChannel (hybridNQubitKraus G K t k) X) ≤
          (localDampingR (G ⟨k, hk⟩) (K ⟨k, hk⟩) t +
           (localDampingR (G ⟨k, hk⟩) (K ⟨k, hk⟩) t) ^ 2) *
          schattenOneSpectralNorm X)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm
      (ancillaRightChannel (nQubitKraus G K t) X -
       ancillaRightChannel (nQubitReplacerKraus G K) X) ≤
      nQubitDiamondEnvelope G K t * schattenOneSpectralNorm X := by
  by_cases hN0 : N = 0
  · subst hN0
    unfold nQubitDiamondEnvelope
    have hr_zero : (∑ m : Fin 0, (localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2)) = 0 := by
      simp only [Finset.univ_eq_empty, Finset.sum_empty]
    have hmin : min (2 : ℝ) 0 = 0 := by norm_num
    rw [hr_zero, hmin, zero_mul]
    rw [nQubit_channel_sub_replacer_zero_qubits G K t X, sub_self, schattenOneSpectralNorm_zero]
  · have h_two := nQubit_channel_sub_replacer_diamond_bound G K hG hK ht X
    let δ : ℕ → ℝ := fun k =>
      if hk : k < N then
        localDampingR (G ⟨k, hk⟩) (K ⟨k, hk⟩) t + (localDampingR (G ⟨k, hk⟩) (K ⟨k, hk⟩) t) ^ 2
      else 0
    have hstep_δ (k : ℕ) :
        schattenOneSpectralNorm
          (ancillaRightChannel (hybridNQubitKraus G K t (k + 1)) X -
           ancillaRightChannel (hybridNQubitKraus G K t k) X) ≤
          δ k * schattenOneSpectralNorm X := by
      by_cases hk : k < N
      · dsimp [δ]
        rw [dif_pos hk]
        exact hstep k hk X
      · dsimp [δ]
        rw [dif_neg hk, zero_mul]
        have hge : N ≤ k := le_of_not_lt hk
        rw [hybridNQubitKraus_ge_N G K t k hge, sub_self, schattenOneSpectralNorm_zero]
    have h_sum := hybridNQubitKraus_telescope_sum G K X δ hstep_δ
    have hsum_eq : (∑ k ∈ Finset.range N, δ k) =
        ∑ m : Fin N, (localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2) :=
      (Finset.sum_fin_eq_sum_range (fun m => localDampingR (G m) (K m) t + (localDampingR (G m) (K m) t) ^ 2)).symm
    rw [hsum_eq] at h_sum
    unfold nQubitDiamondEnvelope
    rw [min_mul_of_nonneg _ _ (schattenOneSpectralNorm_nonneg X)]
    exact le_min h_two h_sum

/-- **Full Exponential Diamond Mixing Time for the Physical Channel**:
For `N ≥ 1`, local relaxation rate lower bound `γ > 0`, precision `0 < ε`, and `t ≥ 0`:
conditional on the single-step hybrid contractivity, if `t ≥ (1 / γ) * log(2 * N / ε)`,
then for EVERY finite ancilla `a` and EVERY matrix `X`:
`‖((Φ_t^{(N)} - R_N) ⊗ id_a)(X)‖₁ ≤ ε * ‖X‖₁`. -/
theorem nQubit_physical_channel_mixing_time_of_step {t : ℝ}
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) (ht : 0 ≤ t)
    {γ : ℝ} (hγ_pos : 0 < γ) (hγ : isSpectralGapLowerBound G K γ)
    {ε : ℝ} (hε : 0 < ε)
    (hN : 1 ≤ N)
    (ht_t : (1 / γ) * Real.log (2 * (N : ℝ) / ε) ≤ t)
    (hstep : ∀ (k : ℕ) (hk : k < N),
      ∀ (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ),
        schattenOneSpectralNorm
          (ancillaRightChannel (hybridNQubitKraus G K t (k + 1)) X -
           ancillaRightChannel (hybridNQubitKraus G K t k) X) ≤
          (localDampingR (G ⟨k, hk⟩) (K ⟨k, hk⟩) t +
           (localDampingR (G ⟨k, hk⟩) (K ⟨k, hk⟩) t) ^ 2) *
          schattenOneSpectralNorm X)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm
      (ancillaRightChannel (nQubitKraus G K t) X -
       ancillaRightChannel (nQubitReplacerKraus G K) X) ≤
      ε * schattenOneSpectralNorm X := by
  have henv := nQubit_channel_sub_replacer_envelope_bound_of_step G K hG hK ht hstep X
  have hmix := nQubitDiamondEnvelope_le_of_mixing_time G K hG hK hγ_pos hγ hε hN ht ht_t
  have hmul := mul_le_mul_of_nonneg_right hmix (schattenOneSpectralNorm_nonneg X)
  exact le_trans henv hmul

end GlobalTelescoping

end BinduEventInterface

#check @BinduEventInterface.siteKraus_completeness
#check @BinduEventInterface.siteReplacerKraus_completeness
#check @BinduEventInterface.sitePauliZ_mul_self
#check @BinduEventInterface.siteOffdiagonal_stabilized_le
#check @BinduEventInterface.siteReplacerDifference_stabilized_le
#check @BinduEventInterface.hybridNQubitKraus_completeness
#check @BinduEventInterface.hybridNQubitKraus_zero
#check @BinduEventInterface.hybridNQubitKraus_top
#check @BinduEventInterface.hybridNQubitKraus_ge_N
#check @BinduEventInterface.nQubit_channel_sub_replacer_diamond_bound_uniform
#check @BinduEventInterface.nQubit_zero_channel_mixing_time
#check @BinduEventInterface.hybridNQubitKraus_telescope_sum
#check @BinduEventInterface.nQubit_channel_sub_replacer_envelope_bound_of_step
#check @BinduEventInterface.nQubit_physical_channel_mixing_time_of_step

#print axioms BinduEventInterface.siteKraus_completeness
#print axioms BinduEventInterface.siteReplacerKraus_completeness
#print axioms BinduEventInterface.sitePauliZ_mul_self
#print axioms BinduEventInterface.siteOffdiagonal_stabilized_le
#print axioms BinduEventInterface.siteReplacerDifference_stabilized_le
#print axioms BinduEventInterface.hybridNQubitKraus_completeness
#print axioms BinduEventInterface.hybridNQubitKraus_zero
#print axioms BinduEventInterface.hybridNQubitKraus_top
#print axioms BinduEventInterface.hybridNQubitKraus_ge_N
#print axioms BinduEventInterface.nQubit_channel_sub_replacer_diamond_bound_uniform
#print axioms BinduEventInterface.nQubit_zero_channel_mixing_time
#print axioms BinduEventInterface.hybridNQubitKraus_telescope_sum
#print axioms BinduEventInterface.nQubit_channel_sub_replacer_envelope_bound_of_step
#print axioms BinduEventInterface.nQubit_physical_channel_mixing_time_of_step
