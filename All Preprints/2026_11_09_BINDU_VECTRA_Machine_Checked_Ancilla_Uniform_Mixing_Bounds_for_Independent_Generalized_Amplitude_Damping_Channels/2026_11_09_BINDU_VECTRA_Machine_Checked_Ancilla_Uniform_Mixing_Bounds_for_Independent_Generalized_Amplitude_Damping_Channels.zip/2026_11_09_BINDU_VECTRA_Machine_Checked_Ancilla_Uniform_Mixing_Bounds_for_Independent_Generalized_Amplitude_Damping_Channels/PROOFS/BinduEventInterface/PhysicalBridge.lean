import BinduEventInterface.TensorGKSL

namespace BinduEventInterface

theorem local_pump_identity :
    dissipatorAdjoint raising occupation =
      1 - occupation := by
  simpa using pump_occupation (1 : ℂ)

theorem local_loss_identity :
    dissipatorAdjoint lowering occupation =
      -occupation := by
  simpa using loss_occupation (1 : ℂ)

end BinduEventInterface
