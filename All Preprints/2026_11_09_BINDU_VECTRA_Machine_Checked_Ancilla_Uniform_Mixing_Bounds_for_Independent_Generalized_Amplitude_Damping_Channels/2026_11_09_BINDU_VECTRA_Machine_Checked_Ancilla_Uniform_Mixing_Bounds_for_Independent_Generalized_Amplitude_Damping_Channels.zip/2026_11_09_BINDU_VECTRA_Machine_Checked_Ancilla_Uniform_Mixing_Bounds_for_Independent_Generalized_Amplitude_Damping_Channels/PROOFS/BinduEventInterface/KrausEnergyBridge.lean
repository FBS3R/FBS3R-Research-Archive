import Mathlib
import BinduEventInterface.KrausRankOneCS
import BinduEventInterface.FiniteKrausTraceCandidate

namespace BinduKrausEnergyBridge
open Matrix
open scoped BigOperators

noncomputable def rankOne {n : Type*} [Fintype n] (w : n → ℂ) :
    Matrix n n ℂ := Matrix.vecMulVec w (star w)

theorem trace_rankOne {n : Type*} [Fintype n] (w : n → ℂ) :
    Matrix.trace (rankOne w) =
      (↑(∑ i, ‖w i‖ ^ 2 : ℝ) : ℂ) := by
  change (∑ i, w i * star (w i)) = _
  push_cast
  apply Finset.sum_congr rfl
  intro i hi
  exact Complex.mul_conj' (w i)

private theorem mul_vecMulVec_local
    {n : Type*} [Fintype n] [DecidableEq n]
    (A : Matrix n n ℂ) (w v : n → ℂ) :
    A * Matrix.vecMulVec w v = Matrix.vecMulVec (A.mulVec w) v := by
  classical
  ext i j
  simp only [Matrix.mul_apply, Matrix.vecMulVec_apply, Matrix.mulVec, dotProduct,
    mul_assoc, Finset.sum_mul]

private theorem vecMulVec_mul_local
    {n : Type*} [Fintype n] [DecidableEq n]
    (w v : n → ℂ) (A : Matrix n n ℂ) :
    Matrix.vecMulVec w v * A = Matrix.vecMulVec w (Matrix.vecMul v A) := by
  classical
  ext i j
  simp only [Matrix.mul_apply, Matrix.vecMulVec_apply, Matrix.vecMul, dotProduct,
    mul_assoc, Finset.mul_sum]

theorem rankOne_under_K
    {n : Type*} [Fintype n] [DecidableEq n]
    (A : Matrix n n ℂ) (w : n → ℂ) :
    A * rankOne w * A.conjTranspose = rankOne (A.mulVec w) := by
  unfold rankOne
  rw [mul_vecMulVec_local, vecMulVec_mul_local, ← Matrix.star_mulVec]

theorem trace_kraus_rankOne
    {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ) (w : n → ℂ) :
    Matrix.trace (BinduEventInterface.finiteKrausChannel K (rankOne w)) =
      ∑ j, Matrix.trace (rankOne ((K j).mulVec w)) := by
  classical
  unfold BinduEventInterface.finiteKrausChannel
  rw [Matrix.trace_sum]
  apply Finset.sum_congr rfl
  intro j hj
  rw [rankOne_under_K]

theorem kraus_energy_preserved
    {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ)
    (hK : ∑ j, (K j).conjTranspose * K j = (1 : Matrix n n ℂ))
    (w : n → ℂ) :
    (∑ j, ∑ i, ‖((K j).mulVec w) i‖ ^ 2) =
      (∑ i, ‖w i‖ ^ 2) := by
  apply Complex.ofReal_injective
  have h := BinduEventInterface.finiteKrausChannel_trace_preserving K hK (rankOne w)
  simpa [trace_kraus_rankOne K w, trace_rankOne] using h

end BinduKrausEnergyBridge
