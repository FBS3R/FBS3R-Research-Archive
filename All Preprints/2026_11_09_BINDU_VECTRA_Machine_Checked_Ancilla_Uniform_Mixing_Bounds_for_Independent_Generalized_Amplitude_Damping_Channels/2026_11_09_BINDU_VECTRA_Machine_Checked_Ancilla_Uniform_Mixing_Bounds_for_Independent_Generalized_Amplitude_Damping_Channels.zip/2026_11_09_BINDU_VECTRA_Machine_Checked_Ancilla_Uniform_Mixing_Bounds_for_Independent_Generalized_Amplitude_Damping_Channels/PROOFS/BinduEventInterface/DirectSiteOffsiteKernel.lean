import BinduEventInterface.KernelFiniteSumLemmas

/-!
# Site/offsite convolution without tensor reindexing

A targeted algebraic gate for the remaining global GAD hybrid-step identity.
The outer matrix index is unchanged: `NQubitIndex N`.
This module does NOT assert that the physical GAD norm bound is closed.
Its purpose is to prove the core scalar convolution identity in Lean.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- The identity superoperator's four-index local kernel. -/
def binduDeltaKernel (u p v q : Fin 2) : ℂ :=
  (if u = p then 1 else 0) * (if v = q then 1 else 0)

/-- Identity kernel on the left of a local four-index transfer kernel. -/
theorem bindu_delta_left_kernel
    (B : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (u p v q : Fin 2) :
    (∑ x : Fin 2, ∑ y : Fin 2,
      binduDeltaKernel u x v y * B x p y q) = B u p v q := by
  classical
  simp [binduDeltaKernel]

/-- Identity kernel on the right of a local four-index transfer kernel. -/
theorem bindu_delta_right_kernel
    (A : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (u p v q : Fin 2) :
    (∑ x : Fin 2, ∑ y : Fin 2,
      A u x v y * binduDeltaKernel x p y q) = A u p v q := by
  classical
  simp [binduDeltaKernel]

/-- Convolution of a kernel acting only at site `k` with a kernel acting
    on the complementary sites. No `Equiv.prod_assoc`, `Matrix.kronecker`,
    or change of matrix index type occurs anywhere in this statement. -/
theorem bindu_site_offsite_convolution
    {N : ℕ} (k : Fin N)
    (P : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (L : Fin N → Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ)
    (u p v q : NQubitIndex N) :
    (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
      (∏ m : Fin N,
        if m = k then P (u m) (r m) (v m) (s m)
        else binduDeltaKernel (u m) (r m) (v m) (s m)) *
      (∏ m : Fin N,
        if m = k then binduDeltaKernel (r m) (p m) (s m) (q m)
        else L m (r m) (p m) (s m) (q m))) =
    P (u k) (p k) (v k) (q k) *
      (∏ m ∈ Finset.univ.erase k,
        L m (u m) (p m) (v m) (q m)) := by
  classical
  let A : Fin N → Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ :=
    fun m a b c d => if m = k then P a b c d else binduDeltaKernel a b c d
  let B : Fin N → Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ :=
    fun m a b c d => if m = k then binduDeltaKernel a b c d else L m a b c d
  have hsite (m : Fin N) :
      (∑ x : Fin 2, ∑ y : Fin 2,
        A m (u m) x (v m) y * B m x (p m) y (q m)) =
      if m = k then P (u m) (p m) (v m) (q m)
      else L m (u m) (p m) (v m) (q m) := by
    by_cases hm : m = k
    · subst m
      simp only [A, B, if_pos rfl]
      exact bindu_delta_right_kernel P (u k) (p k) (v k) (q k)
    · simp only [A, B, if_neg hm]
      exact bindu_delta_left_kernel (L m) (u m) (p m) (v m) (q m)
  have hsplit :
      (∏ m : Fin N,
        if m = k then P (u m) (p m) (v m) (q m)
        else L m (u m) (p m) (v m) (q m)) =
      (∏ m ∈ Finset.univ.erase k,
        L m (u m) (p m) (v m) (q m)) *
        P (u k) (p k) (v k) (q k) := by
    rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ k)]
    simp only [if_pos rfl]
    congr 1
    refine Finset.prod_congr rfl (fun m hm => ?_)
    exact if_neg (Finset.ne_of_mem_erase hm)
  calc
    (∑ r : NQubitIndex N, ∑ s : NQubitIndex N,
      (∏ m : Fin N,
        if m = k then P (u m) (r m) (v m) (s m)
        else binduDeltaKernel (u m) (r m) (v m) (s m)) *
      (∏ m : Fin N,
        if m = k then binduDeltaKernel (r m) (p m) (s m) (q m)
        else L m (r m) (p m) (s m) (q m))) =
      ∏ m : Fin N, ∑ x : Fin 2, ∑ y : Fin 2,
        A m (u m) x (v m) y * B m x (p m) y (q m) := by
        exact bindu_product_four_kernel_comp A B u p v q
    _ = ∏ m : Fin N,
          if m = k then P (u m) (p m) (v m) (q m)
          else L m (u m) (p m) (v m) (q m) := by
        exact Finset.prod_congr rfl (fun m _ => hsite m)
    _ = (∏ m ∈ Finset.univ.erase k,
          L m (u m) (p m) (v m) (q m)) *
          P (u k) (p k) (v k) (q k) := hsplit
    _ = _ := mul_comm _ _

end BinduEventInterface

#print axioms BinduEventInterface.bindu_delta_left_kernel
#print axioms BinduEventInterface.bindu_delta_right_kernel
#print axioms BinduEventInterface.bindu_site_offsite_convolution
