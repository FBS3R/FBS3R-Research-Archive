import BinduEventInterface.DirectSiteOffsiteKernel
import BinduEventInterface.GlobalKrausActionBridgeCandidate

/-!
# Independent CPTP offsite preprocessor (candidate for Mac verification)

The selected site k carries the identity channel, represented as the four-mode
Kraus family {I,0,0,0}. All complementary sites carry their physical/replacer
hybrid family. Consequently the full ancillary superoperator has the SAME
matrix index type as the global hybrid.

IMPORTANT: this file is a proof CANDIDATE. It was written outside the Lean
runtime. None of the claims below may be marked Lean-verified until the user's
pinned `lake build` and `#print axioms` checks pass.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- Local Kraus matrices of the offsite preprocessor: identity at site k,
    original kth-hybrid factors everywhere else. -/
noncomputable def offsiteLocalKraus {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k m : Fin N) (j : Fin 4) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  if m = k then (if j = 0 then 1 else 0)
  else hybridLocalKraus G K t k.val m j

/-- The full offsite preprocessor, still acting on all N original qubits. -/
noncomputable def offsiteKraus {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (α : NQubitModeIndex N) :
    Matrix (NQubitIndex N) (NQubitIndex N) ℂ :=
  nQubitTensorProduct (fun m => offsiteLocalKraus G K t k m (α m))

/-- Local Kraus completeness; at k the sum contains exactly one identity. -/
theorem offsiteLocalKraus_completeness {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k m : Fin N)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) (ht : 0 ≤ t) :
    ∑ j : Fin 4,
      (offsiteLocalKraus G K t k m j)ᴴ * offsiteLocalKraus G K t k m j = 1 := by
  classical
  by_cases hm : m = k
  · subst m
    simp [offsiteLocalKraus, Fin.sum_univ_four]
  · simpa [offsiteLocalKraus, hm] using
      (hybridLocalKraus_completeness G K t k.val m (hG m) (hK m) ht)

/-- Completeness of the 4^N-Kraus offsite channel. -/
theorem offsiteKraus_completeness {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) (ht : 0 ≤ t) :
    ∑ α : NQubitModeIndex N,
      (offsiteKraus G K t k α)ᴴ * offsiteKraus G K t k α = 1 := by
  unfold offsiteKraus
  rw [sum_nQubitTensorProduct_conjTranspose_mul]
  have hloc :
      (fun m : Fin N =>
        ∑ j : Fin 4,
          (offsiteLocalKraus G K t k m j)ᴴ * offsiteLocalKraus G K t k m j) =
      (fun _ : Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ)) := by
    funext m
    exact offsiteLocalKraus_completeness G K t k m hG hK ht
  rw [hloc, nQubitTensorProduct_one]

/-- The site-k local 4-mode kernel is exactly the identity superoperator kernel. -/
theorem offsiteLocalKernel_at_site {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (u p v q : Fin 2) :
    localKrausKernel (offsiteLocalKraus G K t k k) u p v q =
      binduDeltaKernel u p v q := by
  classical
  simp [localKrausKernel, offsiteLocalKraus, binduDeltaKernel,
    Fin.sum_univ_four, Matrix.one_apply]

/-- Away from k, the offsite kernel is precisely the original hybrid kernel. -/
theorem offsiteLocalKernel_other_site {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k m : Fin N) (hm : m ≠ k)
    (u p v q : Fin 2) :
    localKrausKernel (offsiteLocalKraus G K t k m) u p v q =
      localKrausKernel (hybridLocalKraus G K t k.val m) u p v q := by
  have hfamily :
      offsiteLocalKraus G K t k m =
        hybridLocalKraus G K t k.val m := by
    funext j
    simp [offsiteLocalKraus, hm]
  rw [hfamily]

/-- Exact factorization of the OFFSITE full Kraus kernel. This is the missing
    link between abstract site/offsite convolution and a physical Kraus family. -/
theorem offsiteFullKernel_eq_product {N : ℕ}
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (u p v q : NQubitIndex N) :
    fullKrausKernel (offsiteLocalKraus G K t k) u p v q =
      binduDeltaKernel (u k) (p k) (v k) (q k) *
        (∏ m ∈ Finset.univ.erase k,
          localKrausKernel (hybridLocalKraus G K t k.val m)
            (u m) (p m) (v m) (q m)) := by
  classical
  rw [fullKrausKernel_eq_productKrausKernel]
  unfold productKrausKernel
  rw [← Finset.prod_erase_mul _ _ (Finset.mem_univ k)]
  rw [offsiteLocalKernel_at_site]
  have hprod :
      (∏ m ∈ Finset.univ.erase k,
        localKrausKernel (offsiteLocalKraus G K t k m)
          (u m) (p m) (v m) (q m)) =
      (∏ m ∈ Finset.univ.erase k,
        localKrausKernel (hybridLocalKraus G K t k.val m)
          (u m) (p m) (v m) (q m)) := by
    refine Finset.prod_congr rfl (fun m hm => ?_)
    exact offsiteLocalKernel_other_site G K t k m
      (Finset.ne_of_mem_erase hm) (u m) (p m) (v m) (q m)
  rw [hprod]
  exact mul_comm _ _

/-- Trace-norm contractivity of the actual offsite preprocessor, with arbitrary
    finite ancilla and arbitrary (not necessarily positive) complex matrices. -/
theorem offsiteChannel_contracts {N : ℕ}
    {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m) (ht : 0 ≤ t)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm (ancillaRightChannel (offsiteKraus G K t k) X) ≤
      schattenOneSpectralNorm X := by
  exact schattenOne_ancillaRightChannel_le
    (offsiteKraus G K t k) (offsiteKraus_completeness G K t k hG hK ht) X

/-- Actual ancillary action is the four-index kernel action, without tensor
    reindexing or any identification of unrelated matrix spaces. -/
theorem offsiteChannel_eq_fullKernelAction {N : ℕ}
    {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ) (t : ℝ) (k : Fin N)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    ancillaRightChannel (offsiteKraus G K t k) X =
      fullKernelAction (offsiteLocalKraus G K t k) X := by
  exact ancillaRightChannel_eq_fullKernelAction (offsiteLocalKraus G K t k) X

end BinduEventInterface

#print axioms BinduEventInterface.offsiteLocalKraus_completeness
#print axioms BinduEventInterface.offsiteKraus_completeness
#print axioms BinduEventInterface.offsiteLocalKernel_at_site
#print axioms BinduEventInterface.offsiteLocalKernel_other_site
#print axioms BinduEventInterface.offsiteFullKernel_eq_product
#print axioms BinduEventInterface.offsiteChannel_contracts
#print axioms BinduEventInterface.offsiteChannel_eq_fullKernelAction
