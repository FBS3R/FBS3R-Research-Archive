import BinduEventInterface.BinduSiteDeltaLinearityCandidate
import BinduEventInterface.LocalGADKernelIdentityCandidate
import BinduEventInterface.DirectHybridNormCheckpointCandidate

/-!
# Exact reduction of the last global GAD proof boundary

The previously Lean-verified local GAD polynomial is lifted to the original
N-qubit matrix type. The TWO remaining missing lemmas are explicitly exposed:
* site dephasing equals the dephasing-kernel action;
* site replacer equals the replacer-kernel action.

This file makes no claim of unconditional closure. The hD and hR hypotheses
must be discharged in another module before the final theorem is certified.
There are no proof holes or added axioms in these candidates.
-/

namespace BinduEventInterface
open Matrix
open scoped BigOperators Matrix ComplexOrder

/-- The local GAD polynomial lifts pointwise to all N-qubit matrices, provided
    the two channel/kernel interfaces have been proved at the specified site. -/
theorem bindu_global_site_identity_of_two_bridges
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (ht : 0 ≤ t) (k : Fin N)
    (Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ)
    (hD : binduSiteKernelAction k binduLocalDephaseKernel Y =
      siteDephasingChannel k Y)
    (hR : binduSiteKernelAction k
        (localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0)) Y =
      ancillaRightChannel (siteReplacerKraus G K k) Y) :
    binduSiteKernelAction k
      (fun u p v q =>
        localKrausKernel (localKraus (G k) (K k) t) u p v q -
        localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q) Y =
      ((localDampingR (G k) (K k) t *
         (1 - localDampingR (G k) (K k) t) : ℝ) : ℂ) •
         (Y - siteDephasingChannel k Y) +
      (((localDampingR (G k) (K k) t) ^ 2 : ℝ) : ℂ) •
         (Y - ancillaRightChannel (siteReplacerKraus G K k) Y) := by
  let r : ℝ := localDampingR (G k) (K k) t
  let c : ℂ := ((r * (1 - r) : ℝ) : ℂ)
  let d : ℂ := ((r ^ 2 : ℝ) : ℂ)
  let P : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ :=
    fun u p v q => binduDeltaKernel u p v q - binduLocalDephaseKernel u p v q
  let Q : Fin 2 → Fin 2 → Fin 2 → Fin 2 → ℂ :=
    fun u p v q => binduDeltaKernel u p v q -
      localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q
  have hcoef (u p v q : Fin 2) :
      localKrausKernel (localKraus (G k) (K k) t) u p v q -
      localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q =
      c * P u p v q + d * Q u p v q := by
    exact bindu_local_gad_kernel_polynomial G K hG hK t ht k u p v q
  have hP : binduSiteKernelAction k P Y = Y - siteDephasingChannel k Y := by
    change binduSiteKernelAction k
      (fun u p v q => binduDeltaKernel u p v q - binduLocalDephaseKernel u p v q) Y = _
    rw [bindu_site_kernel_sub, bindu_site_delta_action_eq, hD]
  have hQ : binduSiteKernelAction k Q Y =
      Y - ancillaRightChannel (siteReplacerKraus G K k) Y := by
    change binduSiteKernelAction k
      (fun u p v q => binduDeltaKernel u p v q -
        localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q) Y = _
    rw [bindu_site_kernel_sub, bindu_site_delta_action_eq, hR]
  calc
    binduSiteKernelAction k
        (fun u p v q =>
          localKrausKernel (localKraus (G k) (K k) t) u p v q -
          localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q) Y =
      binduSiteKernelAction k (fun u p v q => c * P u p v q + d * Q u p v q) Y := by
        apply bindu_site_action_congr
        exact hcoef
    _ = c • binduSiteKernelAction k P Y +
        d • binduSiteKernelAction k Q Y :=
      bindu_site_kernel_two_term k P Q c d Y
    _ = _ := by
      rw [hP, hQ]

/-- The actual hybrid-step r+r² bound follows from just the two operator
    identifications, with no `hsite` hypothesis in its public type. -/
theorem bindu_hybrid_rplusr2_of_two_bridges
    {N : ℕ} {a : Type*} [Fintype a] [DecidableEq a]
    (G K : Fin N → ℝ)
    (hG : ∀ m, 0 < G m) (hK : ∀ m, 0 < K m)
    (t : ℝ) (ht : 0 ≤ t) (k : Fin N)
    (hD : ∀ Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ,
      binduSiteKernelAction k binduLocalDephaseKernel Y =
        siteDephasingChannel k Y)
    (hR : ∀ Y : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ,
      binduSiteKernelAction k
          (localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0)) Y =
        ancillaRightChannel (siteReplacerKraus G K k) Y)
    (X : Matrix (NQubitIndex N × a) (NQubitIndex N × a) ℂ) :
    schattenOneSpectralNorm
        (ancillaRightChannel (hybridNQubitKraus G K t (k.val + 1)) X -
         ancillaRightChannel (hybridNQubitKraus G K t k.val) X) ≤
      (localDampingR (G k) (K k) t +
       (localDampingR (G k) (K k) t) ^ 2) *
         schattenOneSpectralNorm X := by
  apply bindu_global_hybrid_rplusr2_of_site_identity G K hG hK t ht k X
  intro Y
  change binduSiteKernelAction k
    (fun u p v q =>
      localKrausKernel (localKraus (G k) (K k) t) u p v q -
      localKrausKernel (gadKraus (localEqProb (G k) (K k)) 0) u p v q) Y = _
  exact bindu_global_site_identity_of_two_bridges G K hG hK t ht k Y (hD Y) (hR Y)

end BinduEventInterface

#print axioms BinduEventInterface.bindu_global_site_identity_of_two_bridges
#print axioms BinduEventInterface.bindu_hybrid_rplusr2_of_two_bridges
