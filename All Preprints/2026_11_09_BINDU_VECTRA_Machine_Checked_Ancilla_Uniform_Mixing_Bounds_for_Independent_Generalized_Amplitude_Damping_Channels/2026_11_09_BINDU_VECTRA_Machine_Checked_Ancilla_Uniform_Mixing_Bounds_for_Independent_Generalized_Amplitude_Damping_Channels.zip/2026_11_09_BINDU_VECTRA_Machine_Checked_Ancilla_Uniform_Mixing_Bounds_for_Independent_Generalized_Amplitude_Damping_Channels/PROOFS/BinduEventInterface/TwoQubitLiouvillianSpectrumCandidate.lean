import BinduEventInterface.TwoQubitExplicitTrajectoryCandidate

/-!
# Complete 16-Mode Liouvillian Eigenbasis, Spectral Gap `29/99`, and Unique Stationary State

This module constructs and kernel-verifies the complete finite-dimensional spectral
decomposition of the four-channel two-qubit GKSL generator
`fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate` and its Heisenberg adjoint
`heisenbergGenerator twoQubitH twoQubitJump twoQubitRate` on `M₄(ℂ)`:

* Local 4-element Schrödinger eigenbases `localEigenMatrix1`, `localEigenMatrix2` and
  biorthogonal Heisenberg dual bases `localDualMatrix1`, `localDualMatrix2`
* Exact local eigenvalues:
  `localEigenvalue1 = ![0, -11/35, -11/35, -22/35]`
  `localEigenvalue2 = ![0, -29/99, -29/99, -58/99]`
* Complete 16-element two-qubit Kronecker eigenbasis
  `twoQubitEigenMatrix (a, b) = Matrix.kronecker (localEigenMatrix1 a) (localEigenMatrix2 b)`
  and dual basis
  `twoQubitDualMatrix (a, b) = Matrix.kronecker (localDualMatrix1 a) (localDualMatrix2 b)`
  indexed by `Fin 4 × Fin 4`
* Exact 16-mode eigenvalue equations:
  `fullGKSLSchrodinger ... (twoQubitEigenMatrix p) = (twoQubitEigenvalue p : ℂ) • twoQubitEigenMatrix p`
  `heisenbergGenerator ... (twoQubitDualMatrix p) = (twoQubitEigenvalue p : ℂ) • twoQubitDualMatrix p`
* Exact trace biorthogonality:
  `Matrix.trace (twoQubitDualMatrix p * twoQubitEigenMatrix q) = if p = q then 1 else 0`
* Complete 16-dimensional basis expansion for every `M : Matrix TwoQubitIndex TwoQubitIndex ℂ`:
  `M = ∑ p : Fin 4 × Fin 4, Matrix.trace (twoQubitDualMatrix p * M) • twoQubitEigenMatrix p`
* Simple zero eigenvalue `(0, 0)` and exact spectral gap `29/99`:
  `∀ p : Fin 4 × Fin 4, p ≠ (0, 0) → 29 / 99 ≤ -twoQubitEigenvalue p`,
  attained at `p = (0, 1)` and `p = (0, 2)`
* Uniqueness of the stationary density matrix in `M₄(ℂ)`:
  `fullGKSLSchrodinger ... M = 0 ∧ Matrix.trace M = 1 → M = twoQubitEquilibrium`.
-/

namespace BinduEventInterface

open scoped Matrix

/-- Single-qubit traceless population-inversion mode `diag(-1, 1)`. -/
def localPopulationMode : Matrix QubitIndex QubitIndex ℂ :=
  !![(-1 : ℂ), 0; 0, (1 : ℂ)]

/-- Dual population functional for qubit 1: `diag(-7/22, 15/22)`. -/
noncomputable def localDualPop1 : Matrix QubitIndex QubitIndex ℂ :=
  !![(-(7 : ℂ) / 22), 0; 0, (15 : ℂ) / 22]

/-- Dual population functional for qubit 2: `diag(-11/29, 18/29)`. -/
noncomputable def localDualPop2 : Matrix QubitIndex QubitIndex ℂ :=
  !![(-(11 : ℂ) / 29), 0; 0, (18 : ℂ) / 29]

/-- Four-element Schrödinger eigenbasis for qubit 1. -/
noncomputable def localEigenMatrix1 : Fin 4 → Matrix QubitIndex QubitIndex ℂ
  | ⟨0, _⟩ => twoQubitEqLocal1
  | ⟨1, _⟩ => raising
  | ⟨2, _⟩ => lowering
  | ⟨3, _⟩ => localPopulationMode

/-- Four-element Schrödinger eigenbasis for qubit 2. -/
noncomputable def localEigenMatrix2 : Fin 4 → Matrix QubitIndex QubitIndex ℂ
  | ⟨0, _⟩ => twoQubitEqLocal2
  | ⟨1, _⟩ => raising
  | ⟨2, _⟩ => lowering
  | ⟨3, _⟩ => localPopulationMode

/-- Four-element biorthogonal Heisenberg dual basis for qubit 1. -/
noncomputable def localDualMatrix1 : Fin 4 → Matrix QubitIndex QubitIndex ℂ
  | ⟨0, _⟩ => (1 : Matrix QubitIndex QubitIndex ℂ)
  | ⟨1, _⟩ => lowering
  | ⟨2, _⟩ => raising
  | ⟨3, _⟩ => localDualPop1

/-- Four-element biorthogonal Heisenberg dual basis for qubit 2. -/
noncomputable def localDualMatrix2 : Fin 4 → Matrix QubitIndex QubitIndex ℂ
  | ⟨0, _⟩ => (1 : Matrix QubitIndex QubitIndex ℂ)
  | ⟨1, _⟩ => lowering
  | ⟨2, _⟩ => raising
  | ⟨3, _⟩ => localDualPop2

/-- Exact eigenvalues of the local GKSL generator `localGKSL1` for qubit 1:
`(0, -11/35, -11/35, -22/35)`. -/
noncomputable def localEigenvalue1 : Fin 4 → ℝ
  | ⟨0, _⟩ => 0
  | ⟨1, _⟩ => -(11 / 35 : ℝ)
  | ⟨2, _⟩ => -(11 / 35 : ℝ)
  | ⟨3, _⟩ => -(22 / 35 : ℝ)

/-- Exact eigenvalues of the local GKSL generator `localGKSL2` for qubit 2:
`(0, -29/99, -29/99, -58/99)`. -/
noncomputable def localEigenvalue2 : Fin 4 → ℝ
  | ⟨0, _⟩ => 0
  | ⟨1, _⟩ => -(29 / 99 : ℝ)
  | ⟨2, _⟩ => -(29 / 99 : ℝ)
  | ⟨3, _⟩ => -(58 / 99 : ℝ)

/-- Local Heisenberg GKSL generator for qubit 1 with rates `(1/5, 3/7)`. -/
noncomputable def localHeisenberg1 (A : Matrix QubitIndex QubitIndex ℂ) :
    Matrix QubitIndex QubitIndex ℂ :=
  ((1 : ℂ) / 5) • dissipatorAdjoint raising A +
    ((3 : ℂ) / 7) • dissipatorAdjoint lowering A

/-- Local Heisenberg GKSL generator for qubit 2 with rates `(2/9, 4/11)`. -/
noncomputable def localHeisenberg2 (B : Matrix QubitIndex QubitIndex ℂ) :
    Matrix QubitIndex QubitIndex ℂ :=
  ((2 : ℂ) / 9) • dissipatorAdjoint raising B +
    ((4 : ℂ) / 11) • dissipatorAdjoint lowering B

/-- Left-embedded Heisenberg dissipator factors through a Kronecker product:
`D†_{L ⊗ 1}(A ⊗ B) = D†_L(A) ⊗ B`. -/
theorem dissipatorAdjoint_kronecker_left
    (L A B : Matrix QubitIndex QubitIndex ℂ) :
    dissipatorAdjoint
        (Matrix.kronecker L (1 : Matrix QubitIndex QubitIndex ℂ))
        (Matrix.kronecker A B) =
      Matrix.kronecker (dissipatorAdjoint L A) B := by
  have hmL (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker X (1 : Matrix QubitIndex QubitIndex ℂ) *
        Matrix.kronecker Y B =
      Matrix.kronecker (X * Y) B := by
    simpa only [Matrix.one_mul] using
      (Matrix.mul_kronecker_mul X Y (1 : Matrix QubitIndex QubitIndex ℂ) B).symm
  have hmR (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker X B *
        Matrix.kronecker Y (1 : Matrix QubitIndex QubitIndex ℂ) =
      Matrix.kronecker (X * Y) B := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul X Y B (1 : Matrix QubitIndex QubitIndex ℂ)).symm
  have hm1 (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker X (1 : Matrix QubitIndex QubitIndex ℂ) *
        Matrix.kronecker Y (1 : Matrix QubitIndex QubitIndex ℂ) =
      Matrix.kronecker (X * Y) (1 : Matrix QubitIndex QubitIndex ℂ) := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul X Y
        (1 : Matrix QubitIndex QubitIndex ℂ) (1 : Matrix QubitIndex QubitIndex ℂ)).symm
  have hct :
      (Matrix.kronecker L (1 : Matrix QubitIndex QubitIndex ℂ)).conjTranspose =
        Matrix.kronecker L.conjTranspose (1 : Matrix QubitIndex QubitIndex ℂ) := by
    simpa only [Matrix.conjTranspose_one] using
      kronecker_conjTranspose_v419 L (1 : Matrix QubitIndex QubitIndex ℂ)
  unfold dissipatorAdjoint
  rw [hct, hmL L.conjTranspose A, hmR (L.conjTranspose * A) L, hm1 L.conjTranspose L,
    hmL (L.conjTranspose * L) A, hmR A L.conjTranspose, hmR (A * L.conjTranspose) L]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply, smul_eq_mul]
  ring

/-- Right-embedded Heisenberg dissipator factors through a Kronecker product:
`D†_{1 ⊗ L}(A ⊗ B) = A ⊗ D†_L(B)`. -/
theorem dissipatorAdjoint_kronecker_right
    (L A B : Matrix QubitIndex QubitIndex ℂ) :
    dissipatorAdjoint
        (Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) L)
        (Matrix.kronecker A B) =
      Matrix.kronecker A (dissipatorAdjoint L B) := by
  have hmL (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) X *
        Matrix.kronecker A Y =
      Matrix.kronecker A (X * Y) := by
    simpa only [Matrix.one_mul] using
      (Matrix.mul_kronecker_mul (1 : Matrix QubitIndex QubitIndex ℂ) A X Y).symm
  have hmR (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker A X *
        Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) Y =
      Matrix.kronecker A (X * Y) := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul A (1 : Matrix QubitIndex QubitIndex ℂ) X Y).symm
  have hm1 (X Y : Matrix QubitIndex QubitIndex ℂ) :
      Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) X *
        Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) Y =
      Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) (X * Y) := by
    simpa only [Matrix.mul_one] using
      (Matrix.mul_kronecker_mul
        (1 : Matrix QubitIndex QubitIndex ℂ) (1 : Matrix QubitIndex QubitIndex ℂ) X Y).symm
  have hct :
      (Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) L).conjTranspose =
        Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ) L.conjTranspose := by
    simpa only [Matrix.conjTranspose_one] using
      kronecker_conjTranspose_v419 (1 : Matrix QubitIndex QubitIndex ℂ) L
  unfold dissipatorAdjoint
  rw [hct, hmL L.conjTranspose B, hmR (L.conjTranspose * B) L, hm1 L.conjTranspose L,
    hmL (L.conjTranspose * L) B, hmR B L.conjTranspose, hmR (B * L.conjTranspose) L]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply, smul_eq_mul]
  ring

/-- Exact Kronecker splitting of the four-channel two-qubit Heisenberg generator:
`L†(A ⊗ B) = L₁†(A) ⊗ B + A ⊗ L₂†(B)`. -/
theorem twoQubit_heisenbergGenerator_kronecker
    (A B : Matrix QubitIndex QubitIndex ℂ) :
    heisenbergGenerator twoQubitH twoQubitJump twoQubitRate
        (Matrix.kronecker A B) =
      Matrix.kronecker (localHeisenberg1 A) B +
        Matrix.kronecker A (localHeisenberg2 B) := by
  unfold heisenbergGenerator twoQubitH localHeisenberg1 localHeisenberg2
  rw [Fin.sum_univ_four]
  simp only [twoQubitJump, twoQubitRate,
    twoQubitSigma1Plus, twoQubitSigma1Minus, twoQubitSigma2Plus, twoQubitSigma2Minus,
    Matrix.zero_mul, Matrix.mul_zero, sub_self, smul_zero, zero_add,
    dissipatorAdjoint_kronecker_left,
    dissipatorAdjoint_kronecker_right]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.add_apply, Matrix.smul_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, smul_eq_mul]
  ring

/-- Local Schrödinger eigenvalue equation for qubit 1 across all 4 modes. -/
theorem localGKSL1_eigen (a : Fin 4) :
    localGKSL1 (localEigenMatrix1 a) =
      (localEigenvalue1 a : ℂ) • localEigenMatrix1 a := by
  fin_cases a <;>
    ext i j <;>
    fin_cases i <;> fin_cases j <;>
    simp [localGKSL1, localEigenMatrix1, localEigenvalue1,
      twoQubitEqLocal1, raising, lowering, localPopulationMode,
      dissipatorSchrodinger, Matrix.mul_apply, Matrix.vecMul, dotProduct,
      Fin.sum_univ_two, Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply] <;>
    norm_num

/-- Local Schrödinger eigenvalue equation for qubit 2 across all 4 modes. -/
theorem localGKSL2_eigen (b : Fin 4) :
    localGKSL2 (localEigenMatrix2 b) =
      (localEigenvalue2 b : ℂ) • localEigenMatrix2 b := by
  fin_cases b <;>
    ext i j <;>
    fin_cases i <;> fin_cases j <;>
    simp [localGKSL2, localEigenMatrix2, localEigenvalue2,
      twoQubitEqLocal2, raising, lowering, localPopulationMode,
      dissipatorSchrodinger, Matrix.mul_apply, Matrix.vecMul, dotProduct,
      Fin.sum_univ_two, Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply] <;>
    norm_num

/-- Local Heisenberg eigenvalue equation for qubit 1 across all 4 dual modes. -/
theorem localHeisenberg1_dual_eigen (a : Fin 4) :
    localHeisenberg1 (localDualMatrix1 a) =
      (localEigenvalue1 a : ℂ) • localDualMatrix1 a := by
  fin_cases a <;>
    ext i j <;>
    fin_cases i <;> fin_cases j <;>
    simp [localHeisenberg1, localDualMatrix1, localEigenvalue1,
      localDualPop1, raising, lowering,
      dissipatorAdjoint, Matrix.mul_apply, Matrix.vecMul, dotProduct,
      Fin.sum_univ_two, Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply, Matrix.one_apply] <;>
    norm_num

/-- Local Heisenberg eigenvalue equation for qubit 2 across all 4 dual modes. -/
theorem localHeisenberg2_dual_eigen (b : Fin 4) :
    localHeisenberg2 (localDualMatrix2 b) =
      (localEigenvalue2 b : ℂ) • localDualMatrix2 b := by
  fin_cases b <;>
    ext i j <;>
    fin_cases i <;> fin_cases j <;>
    simp [localHeisenberg2, localDualMatrix2, localEigenvalue2,
      localDualPop2, raising, lowering,
      dissipatorAdjoint, Matrix.mul_apply, Matrix.vecMul, dotProduct,
      Fin.sum_univ_two, Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply, Matrix.one_apply] <;>
    norm_num

/-- Trace biorthogonality of `localDualMatrix1` and `localEigenMatrix1`. -/
theorem local_dual1_eigen1_trace (a a' : Fin 4) :
    Matrix.trace (localDualMatrix1 a * localEigenMatrix1 a') =
      if a = a' then 1 else 0 := by
  fin_cases a <;> fin_cases a' <;>
    simp [localDualMatrix1, localEigenMatrix1, twoQubitEqLocal1, localDualPop1,
      localPopulationMode, raising, lowering, Matrix.trace, Matrix.diag,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two, Matrix.one_apply] <;>
    norm_num

/-- Trace biorthogonality of `localDualMatrix2` and `localEigenMatrix2`. -/
theorem local_dual2_eigen2_trace (b b' : Fin 4) :
    Matrix.trace (localDualMatrix2 b * localEigenMatrix2 b') =
      if b = b' then 1 else 0 := by
  fin_cases b <;> fin_cases b' <;>
    simp [localDualMatrix2, localEigenMatrix2, twoQubitEqLocal2, localDualPop2,
      localPopulationMode, raising, lowering, Matrix.trace, Matrix.diag,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two, Matrix.one_apply] <;>
    norm_num

/-- Completeness of the 4-element biorthogonal eigenbasis for qubit 1 on `M₂(ℂ)`. -/
theorem local1_spectral_expansion (A : Matrix QubitIndex QubitIndex ℂ) :
    A = ∑ a : Fin 4, Matrix.trace (localDualMatrix1 a * A) • localEigenMatrix1 a := by
  ext i j
  rw [Fin.sum_univ_four]
  fin_cases i <;> fin_cases j <;>
    simp [localDualMatrix1, localEigenMatrix1, twoQubitEqLocal1, localDualPop1,
      localPopulationMode, raising, lowering, Matrix.trace, Matrix.diag,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two, Matrix.one_apply] <;>
    ring

/-- Completeness of the 4-element biorthogonal eigenbasis for qubit 2 on `M₂(ℂ)`. -/
theorem local2_spectral_expansion (B : Matrix QubitIndex QubitIndex ℂ) :
    B = ∑ b : Fin 4, Matrix.trace (localDualMatrix2 b * B) • localEigenMatrix2 b := by
  ext i j
  rw [Fin.sum_univ_four]
  fin_cases i <;> fin_cases j <;>
    simp [localDualMatrix2, localEigenMatrix2, twoQubitEqLocal2, localDualPop2,
      localPopulationMode, raising, lowering, Matrix.trace, Matrix.diag,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two, Matrix.one_apply] <;>
    ring

/-!
## 16-Element Two-Qubit Liouvillian Eigenbasis and Biorthogonal Dual Basis
-/

/-- The 16-element two-qubit Schrödinger eigenbasis indexed by `Fin 4 × Fin 4`. -/
noncomputable def twoQubitEigenMatrix (p : Fin 4 × Fin 4) :
    Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker (localEigenMatrix1 p.1) (localEigenMatrix2 p.2)

/-- The 16-element two-qubit Heisenberg dual eigenbasis indexed by `Fin 4 × Fin 4`. -/
noncomputable def twoQubitDualMatrix (p : Fin 4 × Fin 4) :
    Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker (localDualMatrix1 p.1) (localDualMatrix2 p.2)

/-- The 16 exact Liouvillian eigenvalues `λ_{a,b} = μ_{1,a} + μ_{2,b}`. -/
noncomputable def twoQubitEigenvalue (p : Fin 4 × Fin 4) : ℝ :=
  localEigenvalue1 p.1 + localEigenvalue2 p.2

/-- The `(0, 0)` eigenmatrix is the exact stationary state `twoQubitEquilibrium`. -/
theorem twoQubitEigenMatrix_zero_zero :
    twoQubitEigenMatrix ((0 : Fin 4), (0 : Fin 4)) = twoQubitEquilibrium :=
  rfl

/-- The `(0, 0)` dual eigenmatrix is the `4 × 4` identity matrix `1`. -/
theorem twoQubitDualMatrix_zero_zero :
    twoQubitDualMatrix ((0 : Fin 4), (0 : Fin 4)) =
      (1 : Matrix TwoQubitIndex TwoQubitIndex ℂ) := by
  change Matrix.kronecker (1 : Matrix QubitIndex QubitIndex ℂ)
      (1 : Matrix QubitIndex QubitIndex ℂ) =
    (1 : Matrix TwoQubitIndex TwoQubitIndex ℂ)
  exact Matrix.one_kronecker_one

/-- Exact 16-mode eigenvalue theorem for the four-channel Schrödinger GKSL generator:
`L(E_{a,b}) = λ_{a,b} • E_{a,b}` for every `p = (a, b) : Fin 4 × Fin 4`. -/
theorem twoQubit_fullGKSLSchrodinger_eigenMatrix (p : Fin 4 × Fin 4) :
    fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (twoQubitEigenMatrix p) =
      (twoQubitEigenvalue p : ℂ) • twoQubitEigenMatrix p := by
  rcases p with ⟨a, b⟩
  unfold twoQubitEigenMatrix twoQubitEigenvalue
  rw [twoQubit_fullGKSLSchrodinger_kronecker, localGKSL1_eigen a, localGKSL2_eigen b]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.add_apply, Matrix.smul_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, Complex.ofReal_add, smul_eq_mul]
  ring

/-- Exact 16-mode eigenvalue theorem for the four-channel Heisenberg GKSL generator:
`L†(DualE_{a,b}) = λ_{a,b} • DualE_{a,b}` for every `p = (a, b) : Fin 4 × Fin 4`. -/
theorem twoQubit_heisenbergGenerator_dualMatrix (p : Fin 4 × Fin 4) :
    heisenbergGenerator twoQubitH twoQubitJump twoQubitRate (twoQubitDualMatrix p) =
      (twoQubitEigenvalue p : ℂ) • twoQubitDualMatrix p := by
  rcases p with ⟨a, b⟩
  unfold twoQubitDualMatrix twoQubitEigenvalue
  rw [twoQubit_heisenbergGenerator_kronecker,
    localHeisenberg1_dual_eigen a, localHeisenberg2_dual_eigen b]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.add_apply, Matrix.smul_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, Complex.ofReal_add, smul_eq_mul]
  ring

/-- Exact trace biorthogonality of the 16-element dual and primal eigenbases on `M₄(ℂ)`:
`Tr(DualE_p * E_q) = 1` if `p = q` and `0` otherwise. -/
theorem twoQubit_dual_eigen_trace (p q : Fin 4 × Fin 4) :
    Matrix.trace (twoQubitDualMatrix p * twoQubitEigenMatrix q) =
      if p = q then 1 else 0 := by
  rcases p with ⟨a, b⟩
  rcases q with ⟨a', b'⟩
  unfold twoQubitDualMatrix twoQubitEigenMatrix
  rw [trace_mul_kronecker_qubit, local_dual1_eigen1_trace, local_dual2_eigen2_trace]
  by_cases ha : a = a' <;> by_cases hb : b = b' <;>
    simp [Prod.ext_iff, ha, hb]

/-- Right-factor `2 × 2` slice of a `4 × 4` two-qubit matrix at fixed first-qubit indices. -/
def sliceRight (M : Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (l₁ k₁ : QubitIndex) : Matrix QubitIndex QubitIndex ℂ :=
  fun i₂ j₂ => M (l₁, i₂) (k₁, j₂)

/-- Left-factor `2 × 2` slice of a `4 × 4` two-qubit matrix at fixed second-qubit indices. -/
def sliceLeft (M : Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (i₂ j₂ : QubitIndex) : Matrix QubitIndex QubitIndex ℂ :=
  fun l₁ k₁ => M (l₁, i₂) (k₁, j₂)

/-- Trace of `(A ⊗ B) * M` factored through `sliceRight M`. -/
theorem trace_kronecker_mul_sliceRight
    (A B : Matrix QubitIndex QubitIndex ℂ)
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Matrix.trace (Matrix.kronecker A B * M) =
      Matrix.trace
        (A * (Matrix.of fun l₁ k₁ => Matrix.trace (B * sliceRight M l₁ k₁))) := by
  simp only [Matrix.trace, Matrix.diag, Matrix.mul_apply, Fintype.sum_prod_type,
    Fin.sum_univ_two, Matrix.kronecker, Matrix.kroneckerMap_apply, Matrix.of_apply,
    sliceRight]
  ring

/-- Complete 16-dimensional spectral basis expansion of any two-qubit matrix `M ∈ M₄(ℂ)`:
every `4 × 4` complex matrix equals the sum of its 16 biorthogonal eigenmode projections. -/
theorem twoQubit_matrix_spectral_expansion
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    M = ∑ p : Fin 4 × Fin 4,
      Matrix.trace (twoQubitDualMatrix p * M) • twoQubitEigenMatrix p := by
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  rw [Fintype.sum_prod_type]
  simp only [Matrix.sum_apply, Matrix.smul_apply, twoQubitDualMatrix, twoQubitEigenMatrix,
    smul_eq_mul, trace_kronecker_mul_sliceRight]
  simp only [Matrix.kronecker, Matrix.kroneckerMap_apply]
  have hinner (a : Fin 4) :
      (∑ b : Fin 4,
        Matrix.trace (localDualMatrix1 a *
          Matrix.of (fun l₁ k₁ => Matrix.trace (localDualMatrix2 b * sliceRight M l₁ k₁))) *
          (localEigenMatrix1 a i₁ j₁ * localEigenMatrix2 b i₂ j₂)) =
      Matrix.trace (localDualMatrix1 a * sliceLeft M i₂ j₂) * localEigenMatrix1 a i₁ j₁ := by
    have h2 :
        ∀ l₁ k₁ : QubitIndex,
          sliceLeft M i₂ j₂ l₁ k₁ =
            ∑ b : Fin 4,
              Matrix.trace (localDualMatrix2 b * sliceRight M l₁ k₁) *
                localEigenMatrix2 b i₂ j₂ := by
      intro l₁ k₁
      have hexp := congr_fun (congr_fun (local2_spectral_expansion (sliceRight M l₁ k₁)) i₂) j₂
      simpa only [sliceLeft, sliceRight, Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul]
        using hexp
    have hmat :
        sliceLeft M i₂ j₂ =
          Matrix.of (fun l₁ k₁ =>
            ∑ b : Fin 4,
              Matrix.trace (localDualMatrix2 b * sliceRight M l₁ k₁) *
                localEigenMatrix2 b i₂ j₂) := by
      ext l₁ k₁
      exact h2 l₁ k₁
    rw [hmat]
    simp only [Fin.sum_univ_four, Matrix.trace, Matrix.diag, Matrix.mul_apply,
      Fin.sum_univ_two, Matrix.of_apply]
    ring
  simp_rw [hinner]
  have h1 := congr_fun (congr_fun (local1_spectral_expansion (sliceLeft M i₂ j₂)) i₁) j₁
  simpa only [sliceLeft, Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul] using h1

/-- Action of the four-channel GKSL generator on the 16 biorthogonal spectral coefficients:
`Tr(DualE_p * L(M)) = λ_p * Tr(DualE_p * M)`. -/
theorem twoQubit_dual_trace_fullGKSLSchrodinger
    (p : Fin 4 × Fin 4) (M : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Matrix.trace
        (twoQubitDualMatrix p *
          fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate M) =
      (twoQubitEigenvalue p : ℂ) * Matrix.trace (twoQubitDualMatrix p * M) := by
  rw [trace_fullGKSL_duality twoQubitH twoQubitJump twoQubitRate (twoQubitDualMatrix p) M,
      twoQubit_heisenbergGenerator_dualMatrix p, Matrix.smul_mul, Matrix.trace_smul,
      smul_eq_mul]

/-!
## Exact 16-Mode Spectrum, Simple Zero Mode, Spectral Gap `29/99`, and Unique Stationary State
-/

/-- The `(0, 0)` mode has eigenvalue `0`. -/
@[simp]
theorem twoQubitEigenvalue_zero_zero :
    twoQubitEigenvalue ((0 : Fin 4), (0 : Fin 4)) = 0 := by
  simp [twoQubitEigenvalue, localEigenvalue1, localEigenvalue2]

/-- The `(0, 1)` coherence mode has eigenvalue `-29/99`. -/
theorem twoQubitEigenvalue_zero_one :
    twoQubitEigenvalue ((0 : Fin 4), (1 : Fin 4)) = -(29 / 99 : ℝ) := by
  simp [twoQubitEigenvalue, localEigenvalue1, localEigenvalue2]

/-- The `(0, 2)` coherence mode has eigenvalue `-29/99`. -/
theorem twoQubitEigenvalue_zero_two :
    twoQubitEigenvalue ((0 : Fin 4), (2 : Fin 4)) = -(29 / 99 : ℝ) := by
  simp [twoQubitEigenvalue, localEigenvalue1, localEigenvalue2]

/-- Every non-stationary eigenmode `p ≠ (0, 0)` has decay rate `-λ_p ≥ 29/99`. -/
theorem twoQubitEigenvalue_gap_bound (p : Fin 4 × Fin 4)
    (hp : p ≠ ((0 : Fin 4), (0 : Fin 4))) :
    (29 / 99 : ℝ) ≤ -twoQubitEigenvalue p := by
  rcases p with ⟨a, b⟩
  fin_cases a <;> fin_cases b
  · exact False.elim (hp rfl)
  all_goals
    simp only [twoQubitEigenvalue, localEigenvalue1, localEigenvalue2]
    norm_num

/-- Simple zero eigenvalue theorem: `twoQubitEigenvalue p = 0 ↔ p = (0, 0)`. -/
theorem twoQubitEigenvalue_eq_zero_iff (p : Fin 4 × Fin 4) :
    twoQubitEigenvalue p = 0 ↔ p = ((0 : Fin 4), (0 : Fin 4)) := by
  constructor
  · intro hz
    by_contra hp
    have hgap := twoQubitEigenvalue_gap_bound p hp
    linarith
  · rintro rfl
    exact twoQubitEigenvalue_zero_zero

/-- Complete kernel-verified spectral gap theorem for the four-channel two-qubit GKSL generator:
the spectral gap is `Δ = 29/99 > 0`, attained at the two coherence modes `(0, 1)` and `(0, 2)`
of qubit 2, and `-λ_p ≥ 29/99` for all 15 non-stationary modes `p ≠ (0, 0)`. -/
theorem twoQubit_spectral_gap :
    (0 : ℝ) < 29 / 99 ∧
    -twoQubitEigenvalue ((0 : Fin 4), (1 : Fin 4)) = 29 / 99 ∧
    -twoQubitEigenvalue ((0 : Fin 4), (2 : Fin 4)) = 29 / 99 ∧
    ∀ p : Fin 4 × Fin 4,
      p ≠ ((0 : Fin 4), (0 : Fin 4)) → (29 / 99 : ℝ) ≤ -twoQubitEigenvalue p := by
  refine ⟨by norm_num, ?_, ?_, twoQubitEigenvalue_gap_bound⟩
  · rw [twoQubitEigenvalue_zero_one, neg_neg]
  · rw [twoQubitEigenvalue_zero_two, neg_neg]

/-- Every stationary matrix `M ∈ M₄(ℂ)` satisfying `fullGKSLSchrodinger ... M = 0` is a scalar
multiple `Tr(M) • twoQubitEquilibrium` of the equilibrium density matrix. -/
theorem twoQubit_stationary_eq_trace_smul_equilibrium
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (hstat : fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate M = 0) :
    M = Matrix.trace M • twoQubitEquilibrium := by
  have hcoeff :
      ∀ p : Fin 4 × Fin 4,
        p ≠ ((0 : Fin 4), (0 : Fin 4)) →
          Matrix.trace (twoQubitDualMatrix p * M) = 0 := by
    intro p hp
    have htr := twoQubit_dual_trace_fullGKSLSchrodinger p M
    rw [hstat, Matrix.mul_zero, Matrix.trace_zero] at htr
    have hval_ne : (twoQubitEigenvalue p : ℂ) ≠ 0 := by
      rw [Ne, Complex.ofReal_eq_zero, twoQubitEigenvalue_eq_zero_iff]
      exact hp
    exact (mul_eq_zero.mp htr.symm).resolve_left hval_ne
  conv_lhs => rw [twoQubit_matrix_spectral_expansion M]
  rw [Finset.sum_eq_single ((0 : Fin 4), (0 : Fin 4))]
  · rw [twoQubitDualMatrix_zero_zero, Matrix.one_mul, twoQubitEigenMatrix_zero_zero]
  · intro p _ hp
    rw [hcoeff p hp, zero_smul]
  · intro hmem
    exact False.elim (hmem (Finset.mem_univ _))

/-- Uniqueness of the stationary density matrix in `M₄(ℂ)`:
`twoQubitEquilibrium` is the unique trace-one matrix in the kernel of the four-channel
two-qubit GKSL generator `fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate`. -/
theorem twoQubit_equilibrium_unique_stationary
    (M : Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (hstat : fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate M = 0)
    (htr : Matrix.trace M = 1) :
    M = twoQubitEquilibrium := by
  rw [twoQubit_stationary_eq_trace_smul_equilibrium M hstat, htr, one_smul]

/-!
## Full 16-Dimensional Matrix-Trajectory Uniqueness on `[0, ∞)`
-/

/-- Any real differentiable function `g : ℝ → ℝ` satisfying `g'(s) = λ * g(s)` on `s ≥ 0`
with `g(0) = 0` vanishes identically on `t ≥ 0`. -/
theorem real_linear_ode_zero_nonneg
    (lam : ℝ) (g : ℝ → ℝ)
    (hg : ∀ s : ℝ, 0 ≤ s → HasDerivAt g (lam * g s) s)
    (hg0 : g 0 = 0)
    (t : ℝ) (ht : 0 ≤ t) :
    g t = 0 := by
  let f : ℝ → ℝ := fun s => Real.exp (-lam * s) * g s
  have hfderiv : ∀ s : ℝ, 0 ≤ s → HasDerivAt f 0 s := by
    intro s hs
    have hline : HasDerivAt (fun u : ℝ => -lam * u) (-lam) s := by
      simpa using (hasDerivAt_id s).const_mul (-lam)
    have hexp : HasDerivAt
        (fun u : ℝ => Real.exp (-lam * u))
        (Real.exp (-lam * s) * (-lam)) s :=
      (Real.hasDerivAt_exp _).comp s hline
    have hprod := hexp.mul (hg s hs)
    convert hprod using 1
    ring
  have hcont : ContinuousOn f (Set.Icc (0 : ℝ) t) := by
    intro s hs
    exact (hfderiv s hs.1).continuousAt.continuousWithinAt
  have hwithin : ∀ s ∈ Set.Ico (0 : ℝ) t,
      HasDerivWithinAt f 0 (Set.Ici s) s := by
    intro s hs
    exact (hfderiv s hs.1).hasDerivWithinAt
  have hft : f t = f 0 :=
    constant_of_has_deriv_right_zero hcont hwithin t ⟨ht, le_refl t⟩
  have hf0 : f 0 = 0 := by
    simp [f, hg0]
  have hmul : Real.exp (-lam * t) * g t = 0 := hft.trans hf0
  exact (mul_eq_zero.mp hmul).resolve_left (Real.exp_ne_zero _)

/-- Any complex differentiable function `z : ℝ → ℂ` satisfying `z'(s) = λ * z(s)` (for real `λ`)
on `s ≥ 0` with `z(0) = 0` vanishes identically on `t ≥ 0`. -/
theorem complex_linear_ode_zero_nonneg
    (lam : ℝ) (z : ℝ → ℂ)
    (hz : ∀ s : ℝ, 0 ≤ s → HasDerivAt z ((lam : ℂ) * z s) s)
    (hz0 : z 0 = 0)
    (t : ℝ) (ht : 0 ≤ t) :
    z t = 0 := by
  have hre : ∀ s : ℝ, 0 ≤ s → HasDerivAt (fun u => (z u).re) (lam * (z s).re) s := by
    intro s hs
    have hc := Complex.reCLM.hasFDerivAt.comp s (hz s hs).hasFDerivAt
    convert hc.hasDerivAt using 1
    simp [Function.comp_def, Complex.reCLM_apply]
  have him : ∀ s : ℝ, 0 ≤ s → HasDerivAt (fun u => (z u).im) (lam * (z s).im) s := by
    intro s hs
    have hc := Complex.imCLM.hasFDerivAt.comp s (hz s hs).hasFDerivAt
    convert hc.hasDerivAt using 1
    simp [Function.comp_def, Complex.imCLM_apply]
  have hre0 : (z 0).re = 0 := by rw [hz0, Complex.zero_re]
  have him0 : (z 0).im = 0 := by rw [hz0, Complex.zero_im]
  have hret := real_linear_ode_zero_nonneg lam (fun u => (z u).re) hre hre0 t ht
  have himt := real_linear_ode_zero_nonneg lam (fun u => (z u).im) him him0 t ht
  exact Complex.ext hret himt

/-- Along any `CertifiedTwoQubitPath`, each of the 16 Heisenberg dual eigenmode expectations
`Tr(DualE_q * ρ(t))` satisfies the decoupled scalar ODE `c_q'(s) = λ_q * c_q(s)` for `s ≥ 0`. -/
theorem certifiedTwoQubitPath_dual_mode_hasDerivAt
    (p : CertifiedTwoQubitPath) (q : Fin 4 × Fin 4)
    (s : ℝ) (hs : 0 ≤ s) :
    HasDerivAt (fun u => Matrix.trace (twoQubitDualMatrix q * p.rho u))
      ((twoQubitEigenvalue q : ℂ) *
        Matrix.trace (twoQubitDualMatrix q * p.rho s)) s := by
  have hd :=
    fullGKSL_expectation_hasDerivAt twoQubitH twoQubitJump twoQubitRate
      (twoQubitDualMatrix q) p.rho s (p.dynamics s hs)
  rw [twoQubit_heisenbergGenerator_dualMatrix q, Matrix.smul_mul,
      Matrix.trace_smul, smul_eq_mul] at hd
  exact hd

/-- Full 16-dimensional matrix-level ODE uniqueness of `twoQubitVacuumTrajectory`:
every `CertifiedTwoQubitPath` (any entrywise differentiable matrix trajectory on `[0, ∞)`
solving the four-channel GKSL equation with initial condition `twoQubitVacuum`) is
entrywise and matrix-level identical to `twoQubitVacuumTrajectory` for all `t ≥ 0`. -/
theorem twoQubit_trajectory_unique
    (p : CertifiedTwoQubitPath) (t : ℝ) (ht : 0 ≤ t) :
    p.rho t = twoQubitVacuumTrajectory t := by
  have hmode :
      ∀ q : Fin 4 × Fin 4,
        Matrix.trace (twoQubitDualMatrix q * p.rho t) =
          Matrix.trace (twoQubitDualMatrix q * twoQubitVacuumTrajectory t) := by
    intro q
    let z : ℝ → ℂ := fun u =>
      Matrix.trace (twoQubitDualMatrix q * p.rho u) -
        Matrix.trace (twoQubitDualMatrix q * twoQubitVacuumTrajectory u)
    have hz0 : z 0 = 0 := by
      dsimp [z]
      rw [p.initial, twoQubitVacuumTrajectory_zero, sub_self]
    have hz : ∀ s : ℝ, 0 ≤ s → HasDerivAt z ((twoQubitEigenvalue q : ℂ) * z s) s := by
      intro s hs
      have h1 := certifiedTwoQubitPath_dual_mode_hasDerivAt p q s hs
      have h2 := certifiedTwoQubitPath_dual_mode_hasDerivAt twoQubitExplicitCertifiedPath q s hs
      have hsub := h1.sub h2
      convert hsub using 1
      dsimp [z, twoQubitExplicitCertifiedPath]
      ring
    have hzt := complex_linear_ode_zero_nonneg (twoQubitEigenvalue q) z hz hz0 t ht
    exact sub_eq_zero.mp hzt
  rw [twoQubit_matrix_spectral_expansion (p.rho t),
      twoQubit_matrix_spectral_expansion (twoQubitVacuumTrajectory t)]
  refine Finset.sum_congr rfl fun q _ => ?_
  rw [hmode q]

end BinduEventInterface
