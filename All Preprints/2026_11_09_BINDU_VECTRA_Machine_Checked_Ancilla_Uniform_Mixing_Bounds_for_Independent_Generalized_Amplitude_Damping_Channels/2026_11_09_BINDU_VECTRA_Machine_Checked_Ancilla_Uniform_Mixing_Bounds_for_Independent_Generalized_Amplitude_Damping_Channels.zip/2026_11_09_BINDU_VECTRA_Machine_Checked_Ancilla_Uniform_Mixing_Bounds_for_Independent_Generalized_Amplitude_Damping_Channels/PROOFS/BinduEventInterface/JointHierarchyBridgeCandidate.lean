import BinduEventInterface.ODEUniquenessBridgeCandidate

/-!
# Two-site joint-event ODE uniqueness and certified bound

A conditional mathematical theorem: if q₁, q₂, and the **joint** probability r
satisfy their indicated constant-rate hierarchy, then r = q₁*q₂ for t >= 0.
Unlike a product-of-marginals estimate, the hierarchy explicitly constrains r.

The separate concrete two-qubit dynamics module derives these three ODE
hypotheses and the vacuum initial data from its entrywise GKSL trajectory
hypothesis. Both modules are checked by the pinned Lean/Mathlib kernel.
-/
namespace BinduEventInterface

/-- The closed two-site hierarchy forces the joint event to factor, provided
that the initial joint population is the product of the initial marginals.
No positivity assumptions are needed for this uniqueness result. -/
theorem jointOccupation_unique_nonneg
    (G₁ K₁ G₂ K₂ : ℝ)
    (q₁ q₂ r : ℝ → ℝ)
    (hq₁ : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt q₁ (G₁ * (1 - q₁ t) - K₁ * q₁ t) t)
    (hq₂ : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt q₂ (G₂ * (1 - q₂ t) - K₂ * q₂ t) t)
    (hr : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt r
        (G₁ * q₂ t + G₂ * q₁ t -
          (G₁ + K₁ + G₂ + K₂) * r t) t)
    (hinit : r 0 = q₁ 0 * q₂ 0)
    (t : ℝ) (ht : 0 ≤ t) :
    r t = q₁ t * q₂ t := by
  let f : ℝ → ℝ := fun s =>
    Real.exp ((G₁ + K₁ + G₂ + K₂) * s) *
      (r s - q₁ s * q₂ s)
  have hfderiv : ∀ s : ℝ, 0 ≤ s → HasDerivAt f 0 s := by
    intro s hs
    have hline : HasDerivAt
        (fun u : ℝ => (G₁ + K₁ + G₂ + K₂) * u)
        (G₁ + K₁ + G₂ + K₂) s := by
      simpa using (hasDerivAt_id s).const_mul
        (G₁ + K₁ + G₂ + K₂)
    have hexp : HasDerivAt
        (fun u : ℝ => Real.exp ((G₁ + K₁ + G₂ + K₂) * u))
        (Real.exp ((G₁ + K₁ + G₂ + K₂) * s) *
          (G₁ + K₁ + G₂ + K₂)) s :=
      (Real.hasDerivAt_exp _).comp s hline
    have hdiff : HasDerivAt
        (fun u : ℝ => r u - q₁ u * q₂ u)
        ((G₁ * q₂ s + G₂ * q₁ s -
             (G₁ + K₁ + G₂ + K₂) * r s) -
          ((G₁ * (1 - q₁ s) - K₁ * q₁ s) * q₂ s +
            q₁ s * (G₂ * (1 - q₂ s) - K₂ * q₂ s))) s :=
      (hr s hs).sub ((hq₁ s hs).mul (hq₂ s hs))
    have hprod := hexp.mul hdiff
    convert hprod using 1 <;> dsimp [f] <;> ring
  have hcont : ContinuousOn f (Set.Icc (0 : ℝ) t) := by
    intro s hs
    exact (hfderiv s hs.1).continuousAt.continuousWithinAt
  have hwithin : ∀ s ∈ Set.Ico (0 : ℝ) t,
      HasDerivWithinAt f 0 (Set.Ici s) s := by
    intro s hs
    exact (hfderiv s hs.1).hasDerivWithinAt
  have hft : f t = f 0 :=
    constant_of_has_deriv_right_zero hcont hwithin t ⟨ht, le_refl t⟩
  have hf0 : f 0 = 0 := by
    simp [f, hinit]
  have hmul : Real.exp ((G₁ + K₁ + G₂ + K₂) * t) *
      (r t - q₁ t * q₂ t) = 0 := by
    exact hft.trans hf0
  have hdiffzero : r t - q₁ t * q₂ t = 0 :=
    (mul_eq_zero.mp hmul).resolve_left (Real.exp_ne_zero _)
  exact sub_eq_zero.mp hdiffzero

/-- An actual joint-event upper bound, assuming the complete two-site
closed hierarchy, not merely the two marginal ODEs. -/
theorem sampleJointEvent_from_hierarchy
    (q₁ q₂ r : ℝ → ℝ)
    (hq₁ : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt q₁
        (((1 : ℝ) / 5) * (1 - q₁ t) - ((3 : ℝ) / 7) * q₁ t) t)
    (hq₂ : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt q₂
        (((2 : ℝ) / 9) * (1 - q₂ t) - ((4 : ℝ) / 11) * q₂ t) t)
    (hr : ∀ t : ℝ, 0 ≤ t →
      HasDerivAt r
        (((1 : ℝ) / 5) * q₂ t + ((2 : ℝ) / 9) * q₁ t -
          (((1 : ℝ) / 5) + ((3 : ℝ) / 7) +
           ((2 : ℝ) / 9) + ((4 : ℝ) / 11)) * r t) t)
    (h₁ : q₁ 0 = 0) (h₂ : q₂ 0 = 0) (hjoint : r 0 = 0)
    (t : ℝ) (ht : 0 ≤ t) :
    r t < (1 : ℝ) / 4 := by
  have hinit : r 0 = q₁ 0 * q₂ 0 := by simp [h₁, h₂, hjoint]
  have heq := jointOccupation_unique_nonneg
    ((1 : ℝ) / 5) ((3 : ℝ) / 7)
    ((2 : ℝ) / 9) ((4 : ℝ) / 11)
    q₁ q₂ r hq₁ hq₂ hr hinit t ht
  rw [heq]
  exact sampleTwoSite_from_scalarODE q₁ q₂ hq₁ hq₂ h₁ h₂ t ht

#print axioms jointOccupation_unique_nonneg
#print axioms sampleJointEvent_from_hierarchy
end BinduEventInterface
