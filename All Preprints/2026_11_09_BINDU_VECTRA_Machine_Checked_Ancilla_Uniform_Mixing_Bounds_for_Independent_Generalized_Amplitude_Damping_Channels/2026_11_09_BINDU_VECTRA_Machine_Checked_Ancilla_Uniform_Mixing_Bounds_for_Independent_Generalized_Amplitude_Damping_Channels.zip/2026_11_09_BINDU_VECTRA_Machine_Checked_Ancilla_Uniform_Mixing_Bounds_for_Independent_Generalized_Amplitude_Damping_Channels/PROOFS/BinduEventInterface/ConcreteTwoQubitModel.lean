import BinduEventInterface.TensorDissipatorCandidate
import Mathlib.LinearAlgebra.Matrix.Trace

/-!
# Fixed two-qubit pump/loss GKSL model

This module constructs one concrete model on `Fin 2 × Fin 2`.  The Hamiltonian
is zero and the four channels, in order, are pump 1, loss 1, pump 2, and loss
2.  The rates are the explicitly typed complex numbers `1/5`, `3/7`, `2/9`,
and `4/11`.

The results are exact matrix identities.  No trajectory, observable ODE,
positivity, or complete-positivity hypothesis is used here.
-/

namespace BinduEventInterface

open Matrix

/-- Computational basis index for the fixed two-qubit Hilbert space. -/
abbrev TwoQubitIndex := Fin 2 × Fin 2

/-- The first-qubit occupation projector `n ⊗ I`. -/
def twoQubitN1 : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker occupation (1 : Matrix (Fin 2) (Fin 2) ℂ)

/-- The second-qubit occupation projector `I ⊗ n`. -/
def twoQubitN2 : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ) occupation

/-- The joint excited-state event `n₁ n₂`. -/
noncomputable def twoQubitQ12 : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  twoQubitN1 * twoQubitN2

/-- Raising on the first qubit. -/
def twoQubitSigma1Plus : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker raising (1 : Matrix (Fin 2) (Fin 2) ℂ)

/-- Lowering on the first qubit. -/
def twoQubitSigma1Minus : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker lowering (1 : Matrix (Fin 2) (Fin 2) ℂ)

/-- Raising on the second qubit. -/
def twoQubitSigma2Plus : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ) raising

/-- Lowering on the second qubit. -/
def twoQubitSigma2Minus : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ) lowering

/-- Population-preserving Hamiltonian chosen as zero for the fixed example. -/
def twoQubitH : Matrix TwoQubitIndex TwoQubitIndex ℂ := 0

/-- Four concrete channels: pump 1, loss 1, pump 2, loss 2. -/
abbrev TwoQubitChannel := Fin 4

/-- Concrete jump matrix for each of the four channels. -/
noncomputable def twoQubitJump : TwoQubitChannel →
    Matrix TwoQubitIndex TwoQubitIndex ℂ
  | 0 => twoQubitSigma1Plus
  | 1 => twoQubitSigma1Minus
  | 2 => twoQubitSigma2Plus
  | 3 => twoQubitSigma2Minus

/-- Explicit complex GKSL coefficient for each channel. -/
noncomputable def twoQubitRate : TwoQubitChannel → ℂ
  | 0 => (1 : ℂ) / 5
  | 1 => (3 : ℂ) / 7
  | 2 => (2 : ℂ) / 9
  | 3 => (4 : ℂ) / 11

/-- Right-factor analogue of `dissipator_kronecker_one`. -/
theorem dissipator_one_kronecker
    {a b : Type*} [Fintype a] [DecidableEq a]
    [Fintype b] [DecidableEq b]
    (L Q : Matrix b b ℂ) :
    dissipatorAdjoint
        (Matrix.kronecker (1 : Matrix a a ℂ) L)
        (Matrix.kronecker (1 : Matrix a a ℂ) Q) =
      Matrix.kronecker (1 : Matrix a a ℂ)
        (dissipatorAdjoint L Q) := by
  have hm (A B : Matrix b b ℂ) :
      Matrix.kronecker (1 : Matrix a a ℂ) A *
        Matrix.kronecker (1 : Matrix a a ℂ) B =
      Matrix.kronecker (1 : Matrix a a ℂ) (A * B) := by
    simpa only [Matrix.one_mul] using
      (Matrix.mul_kronecker_mul (1 : Matrix a a ℂ)
        (1 : Matrix a a ℂ) A B).symm
  unfold dissipatorAdjoint
  rw [kronecker_conjTranspose_v419]
  simp only [Matrix.conjTranspose_one, hm]
  ext i j
  simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply,
    Matrix.kronecker, Matrix.kroneckerMap_apply, smul_eq_mul]
  ring

/-- The two local occupation projectors commute. -/
theorem twoQubit_n1_n2_commute :
    twoQubitN1 * twoQubitN2 = twoQubitN2 * twoQubitN1 := by
  exact kronecker_left_right_commute occupation occupation

/-- The joint event is the direct Kronecker product `n ⊗ n`. -/
theorem twoQubit_q12_eq_kronecker :
    twoQubitQ12 = Matrix.kronecker occupation occupation := by
  rw [twoQubitQ12, twoQubitN1, twoQubitN2]
  exact (Matrix.mul_kronecker_mul occupation 1 1 occupation).symm.trans (by simp)

theorem twoQubit_pump1_n1 :
    dissipatorAdjoint (twoQubitJump 0) twoQubitN1 = 1 - twoQubitN1 := by
  simpa [twoQubitJump, twoQubitSigma1Plus, twoQubitN1] using
    kronecker_embedded_pump (1 : Matrix (Fin 2) (Fin 2) ℂ)

theorem twoQubit_loss1_n1 :
    dissipatorAdjoint (twoQubitJump 1) twoQubitN1 = -twoQubitN1 := by
  simpa [twoQubitJump, twoQubitSigma1Minus, twoQubitN1] using
    kronecker_embedded_loss (1 : Matrix (Fin 2) (Fin 2) ℂ)

theorem twoQubit_pump2_n2 :
    dissipatorAdjoint (twoQubitJump 2) twoQubitN2 = 1 - twoQubitN2 := by
  rw [twoQubitJump, twoQubitSigma2Plus, twoQubitN2,
    dissipator_one_kronecker, local_pump_identity]
  have hI :
      Matrix.kronecker (1 : Matrix (Fin 2) (Fin 2) ℂ)
          (1 : Matrix (Fin 2) (Fin 2) ℂ) =
        (1 : Matrix TwoQubitIndex TwoQubitIndex ℂ) :=
    Matrix.one_kronecker_one
  rw [← hI]
  ext i j
  simp only [Matrix.kronecker, Matrix.kroneckerMap_apply,
    Matrix.sub_apply]
  ring

theorem twoQubit_loss2_n2 :
    dissipatorAdjoint (twoQubitJump 3) twoQubitN2 = -twoQubitN2 := by
  rw [twoQubitJump, twoQubitSigma2Minus, twoQubitN2,
    dissipator_one_kronecker, local_loss_identity]
  ext i j
  simp [Matrix.kronecker, Matrix.kroneckerMap_apply]

theorem twoQubit_pump1_n2 :
    dissipatorAdjoint (twoQubitJump 0) twoQubitN2 = 0 := by
  apply dissipator_commuting
  · exact (kronecker_left_right_commute raising occupation).symm
  · exact kronecker_left_right_adjoint_commute raising occupation

theorem twoQubit_loss1_n2 :
    dissipatorAdjoint (twoQubitJump 1) twoQubitN2 = 0 := by
  apply dissipator_commuting
  · exact (kronecker_left_right_commute lowering occupation).symm
  · exact kronecker_left_right_adjoint_commute lowering occupation

theorem twoQubit_pump2_n1 :
    dissipatorAdjoint (twoQubitJump 2) twoQubitN1 = 0 := by
  apply dissipator_commuting
  · exact kronecker_left_right_commute occupation raising
  · simp only [twoQubitJump, twoQubitSigma2Plus]
    rw [kronecker_conjTranspose_v419]
    simp only [Matrix.conjTranspose_one]
    exact kronecker_left_right_commute occupation raising.conjTranspose

theorem twoQubit_loss2_n1 :
    dissipatorAdjoint (twoQubitJump 3) twoQubitN1 = 0 := by
  apply dissipator_commuting
  · exact kronecker_left_right_commute occupation lowering
  · simp only [twoQubitJump, twoQubitSigma2Minus]
    rw [kronecker_conjTranspose_v419]
    simp only [Matrix.conjTranspose_one]
    exact kronecker_left_right_commute occupation lowering.conjTranspose

theorem twoQubit_pump1_q12 :
    dissipatorAdjoint (twoQubitJump 0) twoQubitQ12 =
      twoQubitN2 - twoQubitQ12 := by
  rw [twoQubitJump, twoQubitSigma1Plus, twoQubitQ12,
    twoQubitN1, twoQubitN2, kronecker_embedded_pump occupation]
  simp only [sub_mul, Matrix.one_mul]

theorem twoQubit_loss1_q12 :
    dissipatorAdjoint (twoQubitJump 1) twoQubitQ12 =
      -twoQubitQ12 := by
  rw [twoQubitJump, twoQubitSigma1Minus, twoQubitQ12,
    twoQubitN1, twoQubitN2, kronecker_embedded_loss occupation]
  simp

theorem twoQubit_pump2_q12 :
    dissipatorAdjoint (twoQubitJump 2) twoQubitQ12 =
      twoQubitN1 - twoQubitQ12 := by
  rw [twoQubitQ12, twoQubit_n1_n2_commute]
  rw [show twoQubitN1 - twoQubitN2 * twoQubitN1 =
      (1 - twoQubitN2) * twoQubitN1 by simp [sub_mul]]
  apply embedded_pump_event
  · exact twoQubit_pump2_n2
  · exact kronecker_left_right_commute occupation raising
  · simp only [twoQubitJump, twoQubitSigma2Plus]
    rw [kronecker_conjTranspose_v419]
    simp only [Matrix.conjTranspose_one]
    exact kronecker_left_right_commute occupation raising.conjTranspose

theorem twoQubit_loss2_q12 :
    dissipatorAdjoint (twoQubitJump 3) twoQubitQ12 =
      -twoQubitQ12 := by
  rw [twoQubitQ12, twoQubit_n1_n2_commute]
  rw [show -(twoQubitN2 * twoQubitN1) =
      (-twoQubitN2) * twoQubitN1 by simp]
  apply embedded_loss_event
  · exact twoQubit_loss2_n2
  · exact kronecker_left_right_commute occupation lowering
  · simp only [twoQubitJump, twoQubitSigma2Minus]
    rw [kronecker_conjTranspose_v419]
    simp only [Matrix.conjTranspose_one]
    exact kronecker_left_right_commute occupation lowering.conjTranspose

/-- Exact first marginal Heisenberg equation for the four-channel model. -/
theorem twoQubit_heisenberg_n1 :
    heisenbergGenerator twoQubitH twoQubitJump twoQubitRate twoQubitN1 =
      ((1 : ℂ) / 5) • (1 : Matrix TwoQubitIndex TwoQubitIndex ℂ) -
        (((1 : ℂ) / 5) + ((3 : ℂ) / 7)) • twoQubitN1 := by
  rw [heisenbergGenerator, Fin.sum_univ_four]
  simp only [twoQubitH, Matrix.zero_mul, Matrix.mul_zero, sub_self,
    smul_zero, zero_add, twoQubitRate]
  rw [twoQubit_pump1_n1, twoQubit_loss1_n1,
    twoQubit_pump2_n1, twoQubit_loss2_n1]
  simp only [smul_zero, add_zero]
  module

/-- Exact second marginal Heisenberg equation for the four-channel model. -/
theorem twoQubit_heisenberg_n2 :
    heisenbergGenerator twoQubitH twoQubitJump twoQubitRate twoQubitN2 =
      ((2 : ℂ) / 9) • (1 : Matrix TwoQubitIndex TwoQubitIndex ℂ) -
        (((2 : ℂ) / 9) + ((4 : ℂ) / 11)) • twoQubitN2 := by
  rw [heisenbergGenerator, Fin.sum_univ_four]
  simp only [twoQubitH, Matrix.zero_mul, Matrix.mul_zero, sub_self,
    smul_zero, zero_add, twoQubitRate]
  rw [twoQubit_pump1_n2, twoQubit_loss1_n2,
    twoQubit_pump2_n2, twoQubit_loss2_n2]
  simp only [smul_zero, zero_add]
  module

/-- Exact joint-population Heisenberg equation for the four-channel model. -/
theorem twoQubit_heisenberg_q12 :
    heisenbergGenerator twoQubitH twoQubitJump twoQubitRate twoQubitQ12 =
      ((1 : ℂ) / 5) • twoQubitN2 + ((2 : ℂ) / 9) • twoQubitN1 -
        (((1 : ℂ) / 5) + ((3 : ℂ) / 7) +
         ((2 : ℂ) / 9) + ((4 : ℂ) / 11)) • twoQubitQ12 := by
  rw [heisenbergGenerator, Fin.sum_univ_four]
  simp only [twoQubitH, Matrix.zero_mul, Matrix.mul_zero, sub_self,
    smul_zero, zero_add, twoQubitRate]
  rw [twoQubit_pump1_q12, twoQubit_loss1_q12,
    twoQubit_pump2_q12, twoQubit_loss2_q12]
  module

/-! ## Exact vacuum initial matrix -/

/-- The real computational vacuum projector `|00⟩⟨00|`. -/
def twoQubitVacuum : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker
    ((1 : Matrix (Fin 2) (Fin 2) ℂ) - occupation)
    ((1 : Matrix (Fin 2) (Fin 2) ℂ) - occupation)

/-- The occupied and vacuum one-qubit projectors are orthogonal. -/
theorem occupation_mul_complement :
    occupation * ((1 : Matrix (Fin 2) (Fin 2) ℂ) - occupation) = 0 := by
  have hsq : occupation * occupation = occupation := by
    ext i j
    fin_cases i <;> fin_cases j <;>
      norm_num [occupation, Matrix.mul_apply, Matrix.vecMul, dotProduct,
        Fin.sum_univ_succ]
  rw [mul_sub, Matrix.mul_one, hsq, sub_self]

/-- The concrete vacuum matrix is normalized. -/
theorem twoQubit_vacuum_trace :
    Matrix.trace twoQubitVacuum = (1 : ℂ) := by
  rw [twoQubitVacuum]
  simp only [Matrix.kronecker]
  rw [Matrix.trace_kronecker]
  norm_num [Matrix.trace, Matrix.diag_apply, occupation,
    Fin.sum_univ_succ]

/-- The first-qubit population vanishes in the concrete vacuum. -/
theorem twoQubit_vacuum_n1 :
    Matrix.trace (twoQubitN1 * twoQubitVacuum) = (0 : ℂ) := by
  rw [twoQubitN1, twoQubitVacuum]
  simp only [Matrix.kronecker]
  rw [← Matrix.mul_kronecker_mul, occupation_mul_complement]
  simp

/-- The second-qubit population vanishes in the concrete vacuum. -/
theorem twoQubit_vacuum_n2 :
    Matrix.trace (twoQubitN2 * twoQubitVacuum) = (0 : ℂ) := by
  rw [twoQubitN2, twoQubitVacuum]
  simp only [Matrix.kronecker]
  rw [← Matrix.mul_kronecker_mul, occupation_mul_complement]
  simp

/-- The joint population vanishes in the concrete vacuum. -/
theorem twoQubit_vacuum_q12 :
    Matrix.trace (twoQubitQ12 * twoQubitVacuum) = (0 : ℂ) := by
  rw [twoQubit_q12_eq_kronecker, twoQubitVacuum]
  simp only [Matrix.kronecker]
  rw [← Matrix.mul_kronecker_mul, occupation_mul_complement]
  simp

end BinduEventInterface
