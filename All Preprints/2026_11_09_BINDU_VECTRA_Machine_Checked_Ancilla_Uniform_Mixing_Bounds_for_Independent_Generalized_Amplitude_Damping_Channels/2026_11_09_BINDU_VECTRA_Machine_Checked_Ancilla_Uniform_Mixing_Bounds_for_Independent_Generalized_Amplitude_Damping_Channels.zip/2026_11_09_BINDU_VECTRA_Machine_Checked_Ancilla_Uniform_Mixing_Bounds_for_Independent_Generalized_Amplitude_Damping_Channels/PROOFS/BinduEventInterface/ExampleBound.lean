import BinduEventInterface.Arithmetic

/-! Closed exact-rational arithmetic instance derived from sample physical input.
No inference that the supplied JSON is a laboratory Hamiltonian is made here.
This module is new and awaits independent `lake build` on Lean 4.19.0. -/
namespace BinduEventInterface

def sampleCertifiedGroups : List GroupIntervalData :=
  [{k := 1, gammaPlus := (1 : ℚ) / 5, kappaMinus := (3 : ℚ) / 7},
   {k := 1, gammaPlus := (2 : ℚ) / 9, kappaMinus := (4 : ℚ) / 11}]

theorem sampleCertifiedBound : minimaxBound sampleCertifiedGroups = (7 : ℚ) / 58 := by
  norm_num [sampleCertifiedGroups, minimaxBound, groupFactor]

theorem sampleCertifiedThreshold :
    minimaxBound sampleCertifiedGroups < (1 : ℚ) / 4 := by
  rw [sampleCertifiedBound]
  norm_num

end BinduEventInterface
