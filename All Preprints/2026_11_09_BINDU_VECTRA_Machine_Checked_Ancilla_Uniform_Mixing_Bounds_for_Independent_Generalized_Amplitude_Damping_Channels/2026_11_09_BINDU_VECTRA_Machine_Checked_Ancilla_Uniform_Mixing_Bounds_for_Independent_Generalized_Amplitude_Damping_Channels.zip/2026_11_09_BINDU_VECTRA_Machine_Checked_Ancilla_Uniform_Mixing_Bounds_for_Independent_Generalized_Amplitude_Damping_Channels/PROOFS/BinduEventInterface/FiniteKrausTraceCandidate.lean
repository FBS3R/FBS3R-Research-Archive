import BinduEventInterface.FullGKSLTraceBridgeCandidate

/-!
# General finite Kraus trace preservation in any finite dimension

Lean kernel candidate. This is a general, model-independent building
block for CPTP, not yet a complete-positivity theorem.
-/

namespace BinduEventInterface

open Matrix

/-- A finite Kraus-operator map acting on any finite-dimensional matrix. -/
noncomputable def finiteKrausChannel
    {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ) (M : Matrix n n ℂ) : Matrix n n ℂ :=
  ∑ j, K j * M * (K j).conjTranspose

/-- The trace of a Kraus map is the trace paired with its completeness operator. -/
theorem trace_finiteKrausChannel
    {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ) (M : Matrix n n ℂ) :
    Matrix.trace (finiteKrausChannel K M) =
      Matrix.trace ((∑ j, (K j).conjTranspose * K j) * M) := by
  classical
  unfold finiteKrausChannel
  rw [Matrix.trace_sum, Matrix.sum_mul, Matrix.trace_sum]
  apply Finset.sum_congr rfl
  intro j _
  simpa only [mul_assoc] using
    (Matrix.trace_mul_comm (K j * M) (K j).conjTranspose)

/-- Exact trace preservation, provided Kraus normalization is proved. -/
theorem finiteKrausChannel_trace_preserving
    {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ)
    (hK : ∑ j, (K j).conjTranspose * K j =
      (1 : Matrix n n ℂ))
    (M : Matrix n n ℂ) :
    Matrix.trace (finiteKrausChannel K M) = Matrix.trace M := by
  rw [trace_finiteKrausChannel, hK, Matrix.one_mul]

end BinduEventInterface
