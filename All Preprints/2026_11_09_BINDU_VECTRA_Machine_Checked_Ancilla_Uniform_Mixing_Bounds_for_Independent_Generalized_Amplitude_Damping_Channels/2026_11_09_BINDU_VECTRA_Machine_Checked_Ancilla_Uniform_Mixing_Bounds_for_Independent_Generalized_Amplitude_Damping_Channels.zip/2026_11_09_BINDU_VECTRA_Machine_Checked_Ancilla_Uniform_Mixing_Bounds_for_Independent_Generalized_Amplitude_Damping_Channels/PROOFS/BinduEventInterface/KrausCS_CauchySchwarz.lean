import Mathlib
import BinduEventInterface.KrausRankOneCS
import BinduEventInterface.KrausEnergyBridge
import BinduEventInterface.FiniteKrausTraceCandidate

namespace BinduKrausCS

open scoped BigOperators
open Matrix
open BinduFiniteKrausCS
open BinduKrausEnergyBridge

/--
Cauchy–Schwarz inequality for the Euclidean lengths of Kraus‑transformed vectors.

For any Kraus operators `K : k → Matrix n n ℂ` satisfying the trace‑preserving condition
`∑ j, (K j).conjTranspose ⬝ K j = 1`, and any vectors `u v : n → ℂ`, we have

```lean
∑ j, eucLength ((K j).mulVec u) * eucLength ((K j).mulVec v)
  ≤ eucLength u * eucLength v
```
-/

theorem cauchy_schwarz_energy {n k : Type*} [Fintype n] [DecidableEq n] [Fintype k]
    (K : k → Matrix n n ℂ)
    (hK : ∑ j, (K j).conjTranspose * K j = (1 : Matrix n n ℂ))
    (u v : n → ℂ) :
    (∑ j, eucLength ((K j).mulVec u) * eucLength ((K j).mulVec v))
      ≤ eucLength u * eucLength v := by
  -- start from the Cauchy‑Schwarz inequality for the real inner product
  have hcs := BinduFiniteKrausCS.kraus_rankOne_cost_cs K u v
  -- rewrite the right‑hand side using `kraus_energy_preserved`
  have hpres_u : (∑ j, ∑ i, ‖((K j).mulVec u) i‖ ^ 2) = ∑ i, ‖u i‖ ^ 2 :=
    BinduKrausEnergyBridge.kraus_energy_preserved K hK u
  have hpres_v : (∑ j, ∑ i, ‖((K j).mulVec v) i‖ ^ 2) = ∑ i, ‖v i‖ ^ 2 :=
    BinduKrausEnergyBridge.kraus_energy_preserved K hK v
  -- rewrite the rhs of `hcs` using these equalities
  have : (∑ j, eucLength ((K j).mulVec u) * eucLength ((K j).mulVec v)) ≤
        Real.sqrt (∑ i, ‖u i‖ ^ 2) * Real.sqrt (∑ i, ‖v i‖ ^ 2) := by
    simpa [eucLength, hpres_u, hpres_v] using hcs
  -- finally, note that `eucLength` is defined as the square root of the same sums
  simpa [eucLength] using this

end BinduKrausCS
