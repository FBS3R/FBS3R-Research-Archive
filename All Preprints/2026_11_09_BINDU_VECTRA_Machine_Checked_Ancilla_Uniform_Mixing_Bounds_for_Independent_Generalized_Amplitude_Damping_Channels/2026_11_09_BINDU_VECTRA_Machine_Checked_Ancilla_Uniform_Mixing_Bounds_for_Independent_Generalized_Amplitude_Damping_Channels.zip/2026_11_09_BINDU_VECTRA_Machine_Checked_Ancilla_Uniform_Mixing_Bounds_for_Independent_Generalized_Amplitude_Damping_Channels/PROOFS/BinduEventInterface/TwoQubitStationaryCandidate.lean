import BinduEventInterface.MaximalTwoQubitConsequencesCandidate
import BinduEventInterface.FullGKSLTraceBridgeCandidate
import Mathlib.Tactic.FinCases

/-!
# Fixed-model stationary density-matrix construction

NEW, UNCOMPILED LEAN CANDIDATE. This file must pass the pinned Lean 4.19.0
compiler and axiom audit before being described as formally verified.

The equilibrium density matrix is a concrete tensor of two diagonal 2x2
matrices with rational entries. Its stationary GKSL equation is checked
entrywise for the *actual four-channel generator*, not assumed.

This is not yet a proof of the vacuum-started, time-varying trajectory's
existence or of complete positivity of the full quantum channel.
-/

namespace BinduEventInterface

open Matrix

/-- One-qubit stationary density matrix for G₁ = 1/5, K₁ = 3/7. -/
noncomputable def twoQubitEqLocal1 : Matrix (Fin 2) (Fin 2) ℂ :=
  !![(15 : ℂ) / 22, 0; 0, (7 : ℂ) / 22]

/-- One-qubit stationary density matrix for G₂ = 2/9, K₂ = 4/11. -/
noncomputable def twoQubitEqLocal2 : Matrix (Fin 2) (Fin 2) ℂ :=
  !![(18 : ℂ) / 29, 0; 0, (11 : ℂ) / 29]

/-- Concrete four-dimensional stationary density matrix. -/
noncomputable def twoQubitEquilibrium : Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker twoQubitEqLocal1 twoQubitEqLocal2

/-- The first local stationary matrix is trace-normalized. -/
theorem twoQubit_eq_local1_trace :
    Matrix.trace twoQubitEqLocal1 = (1 : ℂ) := by
  norm_num [twoQubitEqLocal1, Matrix.trace, Matrix.diag_apply,
    Fin.sum_univ_succ]

/-- The second local stationary matrix is trace-normalized. -/
theorem twoQubit_eq_local2_trace :
    Matrix.trace twoQubitEqLocal2 = (1 : ℂ) := by
  norm_num [twoQubitEqLocal2, Matrix.trace, Matrix.diag_apply,
    Fin.sum_univ_succ]

/-- The tensor-product equilibrium is normalized. -/
theorem twoQubit_equilibrium_trace :
    Matrix.trace twoQubitEquilibrium = (1 : ℂ) := by
  simp only [twoQubitEquilibrium, Matrix.kronecker]
  rw [Matrix.trace_kronecker, twoQubit_eq_local1_trace,
    twoQubit_eq_local2_trace]
  ring

/-- Exact first stationary marginal. -/
theorem twoQubit_equilibrium_n1 :
    Matrix.trace (twoQubitN1 * twoQubitEquilibrium) = (7 : ℂ) / 22 := by
  simp only [twoQubitN1, twoQubitEquilibrium, Matrix.kronecker]
  rw [← Matrix.mul_kronecker_mul, Matrix.trace_kronecker]
  norm_num [occupation, twoQubitEqLocal1, twoQubitEqLocal2,
    Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, Matrix.vecMul,
    dotProduct, Fin.sum_univ_succ]

/-- Exact second stationary marginal. -/
theorem twoQubit_equilibrium_n2 :
    Matrix.trace (twoQubitN2 * twoQubitEquilibrium) = (11 : ℂ) / 29 := by
  simp only [twoQubitN2, twoQubitEquilibrium, Matrix.kronecker]
  rw [← Matrix.mul_kronecker_mul, Matrix.trace_kronecker]
  norm_num [occupation, twoQubitEqLocal1, twoQubitEqLocal2,
    Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, Matrix.vecMul,
    dotProduct, Fin.sum_univ_succ]

/-- Exact joint event in the stationary density matrix. -/
theorem twoQubit_equilibrium_joint :
    Matrix.trace (twoQubitQ12 * twoQubitEquilibrium) = (7 : ℂ) / 58 := by
  rw [twoQubit_q12_eq_kronecker]
  simp only [twoQubitEquilibrium, Matrix.kronecker]
  rw [← Matrix.mul_kronecker_mul, Matrix.trace_kronecker]
  norm_num [occupation, twoQubitEqLocal1, twoQubitEqLocal2,
    Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, Matrix.vecMul,
    dotProduct, Fin.sum_univ_succ]

set_option maxRecDepth 2048 in
set_option maxHeartbeats 1500000 in
/- Key matrix-level goal: the actual four-channel GKSL generator vanishes. -/
theorem twoQubit_equilibrium_GKSL_zero :
    fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
      twoQubitEquilibrium = 0 := by
  classical
  simp only [fullGKSLSchrodinger, twoQubitH, Matrix.zero_mul,
    Matrix.mul_zero, sub_self, smul_zero, zero_add, Fin.sum_univ_four,
    twoQubitRate]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  fin_cases i₁ <;> fin_cases i₂ <;> fin_cases j₁ <;> fin_cases j₂ <;>
    norm_num [Matrix.one_apply, dissipatorSchrodinger, twoQubitJump,
      twoQubitSigma1Plus, twoQubitSigma1Minus,
      twoQubitSigma2Plus, twoQubitSigma2Minus,
      twoQubitEquilibrium, twoQubitEqLocal1, twoQubitEqLocal2,
      raising, lowering, Matrix.mul_apply, Matrix.vecMul, dotProduct,
      Matrix.kronecker, Matrix.kroneckerMap_apply,
      Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply, Fin.sum_univ_succ, Fintype.sum_prod_type,
      Matrix.one_apply]

/-- A constant matrix path is a genuine stationary GKSL solution. -/
theorem twoQubit_equilibrium_constant_trajectory
    (s : ℝ) (i j : TwoQubitIndex) :
    HasDerivAt (fun _ : ℝ => twoQubitEquilibrium i j)
      (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        twoQubitEquilibrium i j) s := by
  rw [twoQubit_equilibrium_GKSL_zero]
  simpa using (hasDerivAt_const s (twoQubitEquilibrium i j))

/-- The stationary joint event is strictly below one eighth. -/
theorem twoQubit_equilibrium_below_eighth :
    Complex.re (Matrix.trace (twoQubitQ12 * twoQubitEquilibrium)) <
      (1 : ℝ) / 8 := by
  rw [twoQubit_equilibrium_joint]
  norm_num

end BinduEventInterface
