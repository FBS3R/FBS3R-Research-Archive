import Mathlib
import BinduEventInterface.KrausCS_CauchySchwarz
import BinduEventInterface.NQubitFullSemigroupSpectralCandidate

/-!
# Exact Schatten-1 / Trace-Norm Contraction for Arbitrary CPTP Channels

This module proves that for ANY finite-dimensional system `n`, ANY finite Kraus family
`K : k → Matrix n n ℂ` satisfying the completeness condition `∑ j, (K j)ᴴ * K j = 1`,
and ANY complex matrix `X : Matrix n n ℂ`:

`schattenOneSpectralNorm (finiteKrausChannel K X) ≤ schattenOneSpectralNorm X`

where `schattenOneSpectralNorm X = ∑ i, √(λᵢ(Xᴴ X))` is the project's genuine spectral functional.

Key architectural theorems:
1. `bessel_dot`: Finite Bessel inequality for orthonormal coordinate families.
2. `svd_decomp`: Exact singular-value decomposition `X = ∑ i, vecMulVec (X *ᵥ vᵢ) (star vᵢ)`
   where `vᵢ` are the orthonormal eigenvectors of `Xᴴ X`.
3. `schattenOne_le_cost`: For EVERY finite rank-one decomposition `X = ∑ r, vecMulVec (u r) (star (w r))`,
   `schattenOneSpectralNorm X ≤ ∑ r, eucLength (u r) * eucLength (w r)`.
4. `kraus_decomp`: Explicit rank-one decomposition of `finiteKrausChannel K X` of size `k × n`.
5. `schattenOne_finiteKrausChannel_le`: Full contractivity using `cauchy_schwarz_energy`.
-/

namespace BinduEventInterface

open Matrix
open scoped BigOperators Matrix ComplexOrder Topology
open BinduFiniteKrausCS (eucLength eucLength_sq)

section EuclideanHelpers

variable {n : Type*} [Fintype n]

theorem eucLength_nonneg (w : n → ℂ) : 0 ≤ eucLength w := Real.sqrt_nonneg _

theorem star_dotProduct_self_eq (w : n → ℂ) :
    star w ⬝ᵥ w = ((eucLength w ^ 2 : ℝ) : ℂ) := by
  rw [eucLength_sq]
  simp only [dotProduct, Pi.star_apply, Complex.ofReal_sum, Complex.ofReal_pow]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  exact Complex.conj_mul' (w i)

noncomputable def toE (w : n → ℂ) : EuclideanSpace ℂ n := (WithLp.equiv 2 (n → ℂ)).symm w

theorem norm_toE (w : n → ℂ) : ‖toE w‖ = eucLength w := by
  rw [EuclideanSpace.norm_eq]
  rfl

theorem inner_toE (a b : n → ℂ) : (inner (toE a) (toE b) : ℂ) = b ⬝ᵥ star a := rfl

theorem bessel_dot {ι : Type*} [DecidableEq ι] (s : Finset ι) (f : ι → n → ℂ)
    (hf : ∀ i ∈ s, ∀ j ∈ s, star (f i) ⬝ᵥ f j = if i = j then 1 else 0) (w : n → ℂ) :
    ∑ i ∈ s, ‖star (f i) ⬝ᵥ w‖ ^ 2 ≤ eucLength w ^ 2 := by
  let g : s → EuclideanSpace ℂ n := fun i => toE (f i)
  have hg : Orthonormal ℂ g := by
    rw [orthonormal_iff_ite]
    intro i j
    show (inner (toE (f i)) (toE (f j)) : ℂ) = _
    rw [inner_toE, dotProduct_comm, hf i i.2 j j.2]
    by_cases hij : i = j
    · subst hij; simp
    · have hij' : (i : ι) ≠ j := fun h => hij (Subtype.ext h)
      simp [hij, hij']
  have h := hg.sum_inner_products_le (x := toE w) (s := Finset.univ)
  rw [norm_toE] at h
  calc ∑ i ∈ s, ‖star (f i) ⬝ᵥ w‖ ^ 2
        = ∑ i : s, ‖(inner (g i) (toE w) : ℂ)‖ ^ 2 := by
          rw [← Finset.sum_coe_sort s]
          refine Finset.sum_congr rfl (fun i _ => ?_)
          show _ = ‖(inner (toE (f i)) (toE w) : ℂ)‖ ^ 2
          rw [inner_toE, dotProduct_comm]
    _ ≤ eucLength w ^ 2 := h

end EuclideanHelpers

section Spectral

variable {n : Type*} [Fintype n] [DecidableEq n] (X : Matrix n n ℂ)

noncomputable def gramHerm : (Xᴴ * X).IsHermitian :=
  (Matrix.posSemidef_conjTranspose_mul_self X).1

noncomputable def rv (i : n) : n → ℂ := ⇑((gramHerm X).eigenvectorBasis i)

noncomputable def lam (i : n) : ℝ := (gramHerm X).eigenvalues i

noncomputable def sv (i : n) : ℝ := Real.sqrt (lam X i)

theorem schattenOne_eq_sum_sv : schattenOneSpectralNorm X = ∑ i, sv X i := rfl

theorem lam_nonneg (i : n) : 0 ≤ lam X i :=
  (Matrix.posSemidef_conjTranspose_mul_self X).eigenvalues_nonneg i

theorem sv_nonneg (i : n) : 0 ≤ sv X i := Real.sqrt_nonneg _

theorem lam_eq_sv_sq (i : n) : (lam X i : ℂ) = (sv X i : ℂ) ^ 2 := by
  unfold sv
  rw [← Complex.ofReal_pow, Real.sq_sqrt (lam_nonneg X i)]

theorem rv_orthonormal (i j : n) :
    star (rv X i) ⬝ᵥ rv X j = if i = j then 1 else 0 := by
  have h := (orthonormal_iff_ite.mp (gramHerm X).eigenvectorBasis.orthonormal) i j
  rw [← h, dotProduct_comm]
  rfl

theorem gram_mulVec_rv (j : n) :
    (Xᴴ * X) *ᵥ rv X j = (lam X j : ℂ) • rv X j := by
  have h := (gramHerm X).mulVec_eigenvectorBasis j
  unfold rv lam
  rw [h]
  ext a
  simp [Complex.real_smul]

theorem dot_X_rv (i j : n) :
    star (X *ᵥ rv X i) ⬝ᵥ (X *ᵥ rv X j) = if i = j then (lam X j : ℂ) else 0 := by
  rw [star_mulVec, ← dotProduct_mulVec, mulVec_mulVec, gram_mulVec_rv, _root_.dotProduct_smul,
    rv_orthonormal]
  split_ifs <;> simp

theorem eucLength_X_rv (i : n) : eucLength (X *ᵥ rv X i) = sv X i := by
  have h := dot_X_rv X i i
  rw [if_pos rfl, star_dotProduct_self_eq] at h
  have h2 : eucLength (X *ᵥ rv X i) ^ 2 = lam X i := by exact_mod_cast h
  unfold sv
  rw [← h2, Real.sqrt_sq (eucLength_nonneg _)]

theorem eucLength_rv (i : n) : eucLength (rv X i) = 1 := by
  have h := rv_orthonormal X i i
  rw [if_pos rfl, star_dotProduct_self_eq] at h
  have h2 : eucLength (rv X i) ^ 2 = 1 := by exact_mod_cast h
  have hs : ∑ a, ‖rv X i a‖ ^ 2 = 1 := by rw [← eucLength_sq]; exact h2
  unfold eucLength
  rw [hs, Real.sqrt_one]

theorem svd_decomp : X = ∑ i, vecMulVec (X *ᵥ rv X i) (star (rv X i)) := by
  have hU := (Matrix.mem_unitaryGroup_iff).mp ((gramHerm X).eigenvectorUnitary).2
  calc X = X * (((gramHerm X).eigenvectorUnitary : Matrix n n ℂ) *
              star ((gramHerm X).eigenvectorUnitary : Matrix n n ℂ)) := by rw [hU, Matrix.mul_one]
    _ = (X * ((gramHerm X).eigenvectorUnitary : Matrix n n ℂ)) *
              star ((gramHerm X).eigenvectorUnitary : Matrix n n ℂ) := (Matrix.mul_assoc _ _ _).symm
    _ = ∑ i, vecMulVec (X *ᵥ rv X i) (star (rv X i)) := by
          ext a b
          simp only [Matrix.mul_apply, Matrix.sum_apply, vecMulVec_apply, mulVec, dotProduct,
            Matrix.star_apply, Matrix.IsHermitian.eigenvectorUnitary_apply, Pi.star_apply, rv]

theorem schattenOne_le_cost {ι : Type*} [Fintype ι] (u w : ι → n → ℂ)
    (hX : X = ∑ r, vecMulVec (u r) (star (w r))) :
    schattenOneSpectralNorm X ≤ ∑ r, eucLength (u r) * eucLength (w r) := by
  classical
  set e : n → n → ℂ := fun i => ((sv X i : ℂ)⁻¹) • (X *ᵥ rv X i) with he
  have hstar : ∀ i, star (e i) = ((sv X i : ℂ)⁻¹) • star (X *ᵥ rv X i) := by
    intro i
    simp only [he, star_smul]
    congr 1
    simp [Complex.conj_ofReal]
  have hsig : ∀ i, (sv X i : ℂ) = star (e i) ⬝ᵥ (X *ᵥ rv X i) := by
    intro i
    rw [hstar, smul_dotProduct, dot_X_rv X i i, if_pos rfl, lam_eq_sv_sq, smul_eq_mul]
    by_cases h0 : (sv X i : ℂ) = 0
    · simp [h0]
    · have : (sv X i : ℂ)⁻¹ * (sv X i : ℂ) ^ 2 = (sv X i : ℂ) := by
        field_simp
        ring
      exact this.symm
  have hXv : ∀ i, X *ᵥ rv X i = ∑ r, (star (w r) ⬝ᵥ rv X i) • u r := by
    intro i
    have hX_eq : X *ᵥ rv X i = (∑ r, vecMulVec (u r) (star (w r))) *ᵥ rv X i :=
      congrFun (congrArg mulVec hX) (rv X i)
    rw [hX_eq]
    ext a
    simp only [mulVec, dotProduct, Matrix.sum_apply, Finset.sum_apply, vecMulVec_apply, Pi.smul_apply,
      smul_eq_mul, Finset.sum_mul, Finset.mul_sum, Pi.star_apply]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro r _
    apply Finset.sum_congr rfl
    intro c _
    ring
  have hc : ∀ i, (sv X i : ℂ) = ∑ r, (star (w r) ⬝ᵥ rv X i) * (star (e i) ⬝ᵥ u r) := by
    intro i
    rw [hsig i, hXv i]
    simp only [dotProduct, Finset.sum_apply, Pi.smul_apply, smul_eq_mul, Finset.mul_sum]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro r _
    apply Finset.sum_congr rfl
    intro c _
    ring
  have hS : schattenOneSpectralNorm X =
      ‖∑ i, ∑ r, (star (w r) ⬝ᵥ rv X i) * (star (e i) ⬝ᵥ u r)‖ := by
    rw [schattenOne_eq_sum_sv]
    simp_rw [← hc]
    rw [← Complex.ofReal_sum, Complex.norm_real,
      Real.norm_of_nonneg (Finset.sum_nonneg (fun i _ => sv_nonneg X i))]
  have hW : ∀ r, √(∑ i, ‖star (w r) ⬝ᵥ rv X i‖ ^ 2) ≤ eucLength (w r) := by
    intro r
    have hb := bessel_dot Finset.univ (rv X) (fun i _ j _ => rv_orthonormal X i j) (w r)
    have heq : ∑ i, ‖star (w r) ⬝ᵥ rv X i‖ ^ 2 = ∑ i, ‖star (rv X i) ⬝ᵥ w r‖ ^ 2 := by
      refine Finset.sum_congr rfl (fun i _ => ?_)
      rw [star_dotProduct (w r) (rv X i), norm_star]
    rw [heq, ← Real.sqrt_sq (eucLength_nonneg (w r))]
    exact Real.sqrt_le_sqrt hb
  set S0 : Finset n := Finset.univ.filter (fun i => sv X i ≠ 0) with hS0
  have he_orth : ∀ i ∈ S0, ∀ j ∈ S0, star (e i) ⬝ᵥ e j = if i = j then 1 else 0 := by
    intro i hi j hj
    have hi' : (sv X i : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (Finset.mem_filter.mp hi).2
    rw [hstar, smul_dotProduct, he]
    simp only
    rw [_root_.dotProduct_smul, dot_X_rv]
    split_ifs with hij
    · subst hij
      rw [lam_eq_sv_sq, smul_eq_mul, smul_eq_mul]
      have : (sv X i : ℂ)⁻¹ * ((sv X i : ℂ)⁻¹ * (sv X i : ℂ) ^ 2) = 1 := by
        field_simp
        ring
      exact this
    · simp
  have he_zero : ∀ i, sv X i = 0 → e i = 0 := by
    intro i h
    simp [he, h]
  have hU : ∀ r, √(∑ i, ‖star (e i) ⬝ᵥ u r‖ ^ 2) ≤ eucLength (u r) := by
    intro r
    have hb := bessel_dot S0 e he_orth (u r)
    have heq : ∑ i, ‖star (e i) ⬝ᵥ u r‖ ^ 2 = ∑ i ∈ S0, ‖star (e i) ⬝ᵥ u r‖ ^ 2 := by
      rw [hS0, Finset.sum_filter]
      refine Finset.sum_congr rfl (fun i _ => ?_)
      split_ifs with h
      · rfl
      · rw [he_zero i (not_not.mp h)]
        simp
    rw [heq, ← Real.sqrt_sq (eucLength_nonneg (u r))]
    exact Real.sqrt_le_sqrt hb
  rw [hS]
  calc ‖∑ i, ∑ r, (star (w r) ⬝ᵥ rv X i) * (star (e i) ⬝ᵥ u r)‖
        ≤ ∑ i, ∑ r, ‖(star (w r) ⬝ᵥ rv X i) * (star (e i) ⬝ᵥ u r)‖ :=
          (norm_sum_le _ _).trans (Finset.sum_le_sum fun i _ => norm_sum_le _ _)
    _ = ∑ r, ∑ i, ‖star (w r) ⬝ᵥ rv X i‖ * ‖star (e i) ⬝ᵥ u r‖ := by
          rw [Finset.sum_comm]
          simp only [norm_mul]
    _ ≤ ∑ r, √(∑ i, ‖star (w r) ⬝ᵥ rv X i‖ ^ 2) * √(∑ i, ‖star (e i) ⬝ᵥ u r‖ ^ 2) :=
          Finset.sum_le_sum fun r _ => Real.sum_mul_le_sqrt_mul_sqrt _ _ _
    _ ≤ ∑ r, eucLength (w r) * eucLength (u r) :=
          Finset.sum_le_sum fun r _ =>
            mul_le_mul (hW r) (hU r) (Real.sqrt_nonneg _) (eucLength_nonneg (w r))
    _ = ∑ r, eucLength (u r) * eucLength (w r) := by
          apply Finset.sum_congr rfl
          intro r _
          ring

end Spectral

section ChannelContraction

variable {n : Type*} [Fintype n]

theorem mul_vecMulVec_mul_conjTranspose (A : Matrix n n ℂ) (a b : n → ℂ) :
    A * vecMulVec a (star b) * Aᴴ = vecMulVec (A *ᵥ a) (star (A *ᵥ b)) := by
  have h1 : A * vecMulVec a (star b) = vecMulVec (A *ᵥ a) (star b) := by
    ext i j
    simp only [Matrix.mul_apply, vecMulVec_apply, mulVec, dotProduct, mul_assoc, Finset.sum_mul]
  have h2 : vecMulVec (A *ᵥ a) (star b) * Aᴴ = vecMulVec (A *ᵥ a) (star b ᵥ* Aᴴ) := by
    ext i j
    simp only [Matrix.mul_apply, vecMulVec_apply, vecMul, dotProduct, mul_assoc, Finset.mul_sum]
  rw [h1, h2, ← star_mulVec]

variable [DecidableEq n]

theorem kraus_decomp {k : Type*} [Fintype k] (K : k → Matrix n n ℂ) (X : Matrix n n ℂ) :
    finiteKrausChannel K X =
      ∑ p : k × n, vecMulVec (K p.1 *ᵥ (X *ᵥ rv X p.2)) (star (K p.1 *ᵥ rv X p.2)) := by
  unfold finiteKrausChannel
  conv_lhs => rw [svd_decomp X]
  simp_rw [Finset.mul_sum, Finset.sum_mul, mul_vecMulVec_mul_conjTranspose]
  rw [Fintype.sum_prod_type]

/-- **Full Schatten-1 / trace-norm contractivity for every finite Kraus CPTP map and every matrix `X`.** -/
theorem schattenOne_finiteKrausChannel_le {k : Type*} [Fintype k]
    (K : k → Matrix n n ℂ) (hK : ∑ j, (K j)ᴴ * K j = (1 : Matrix n n ℂ))
    (X : Matrix n n ℂ) :
    schattenOneSpectralNorm (finiteKrausChannel K X) ≤ schattenOneSpectralNorm X := by
  have h1 := schattenOne_le_cost (finiteKrausChannel K X)
    (fun p : k × n => K p.1 *ᵥ (X *ᵥ rv X p.2)) (fun p => K p.1 *ᵥ rv X p.2) (kraus_decomp K X)
  refine h1.trans ?_
  rw [Fintype.sum_prod_type, Finset.sum_comm, schattenOne_eq_sum_sv]
  refine Finset.sum_le_sum (fun i _ => ?_)
  have h2 := BinduKrausCS.cauchy_schwarz_energy K hK (X *ᵥ rv X i) (rv X i)
  rw [eucLength_X_rv, eucLength_rv, mul_one] at h2
  exact h2

end ChannelContraction

section ReindexInvariance

theorem eucLength_comp_equiv {m n : Type*} [Fintype m] [Fintype n] (e : m ≃ n) (v : m → ℂ) :
    eucLength (v ∘ e.symm) = eucLength v := by
  unfold eucLength
  congr 1
  simp only [Function.comp_apply]
  exact e.symm.sum_comp (fun y => ‖v y‖ ^ 2)

theorem reindex_vecMulVec {m n : Type*} (e : m ≃ n) (u w : m → ℂ) :
    Matrix.reindex e e (vecMulVec u (star w)) =
      vecMulVec (u ∘ e.symm) (star (w ∘ e.symm)) := by
  ext i j
  simp only [Matrix.reindex_apply, Matrix.submatrix_apply, vecMulVec_apply, Function.comp_apply,
    Pi.star_apply, star_apply]

theorem reindex_sum {m n ι : Type*} [Fintype ι] (e : m ≃ n) (f : ι → Matrix m m ℂ) :
    Matrix.reindex e e (∑ i, f i) = ∑ i, Matrix.reindex e e (f i) := by
  ext i j
  simp only [Matrix.reindex_apply, Matrix.submatrix_apply, Matrix.sum_apply]

theorem reindex_symm_reindex {m n : Type*} (e : m ≃ n) (X : Matrix m m ℂ) :
    Matrix.reindex e.symm e.symm (Matrix.reindex e e X) = X := by
  ext i j
  simp only [Matrix.reindex_apply, Matrix.submatrix_apply, Equiv.symm_symm, Equiv.symm_apply_apply]

/-- **Invariance of `schattenOneSpectralNorm` under arbitrary index-type equivalences**:
for any bijection `e : m ≃ n` between finite types and any matrix `X ∈ M_m(ℂ)`,
`‖reindex e e X‖₁ = ‖X‖₁`. -/
theorem schattenOneSpectralNorm_reindex_le {m n : Type*} [Fintype m] [DecidableEq m] [Fintype n] [DecidableEq n]
    (e : m ≃ n) (X : Matrix m m ℂ) :
    schattenOneSpectralNorm (Matrix.reindex e e X) ≤ schattenOneSpectralNorm X := by
  have hdec := svd_decomp X
  have hdec_re : Matrix.reindex e e X =
      ∑ i : m, vecMulVec ((X *ᵥ rv X i) ∘ e.symm) (star ((rv X i) ∘ e.symm)) := by
    conv_lhs => rw [hdec]
    rw [reindex_sum]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    exact reindex_vecMulVec e (X *ᵥ rv X i) (rv X i)
  have hle := schattenOne_le_cost (Matrix.reindex e e X)
    (fun i => (X *ᵥ rv X i) ∘ e.symm) (fun i => (rv X i) ∘ e.symm) hdec_re
  have hcost_eq : (∑ r : m, eucLength ((X *ᵥ rv X r) ∘ e.symm) * eucLength ((rv X r) ∘ e.symm)) =
      schattenOneSpectralNorm X := by
    simp_rw [eucLength_comp_equiv]
    simp_rw [eucLength_X_rv, eucLength_rv, mul_one]
    exact (schattenOne_eq_sum_sv X).symm
  rw [hcost_eq] at hle
  exact hle

theorem schattenOneSpectralNorm_reindex_eq {m n : Type*} [Fintype m] [DecidableEq m] [Fintype n] [DecidableEq n]
    (e : m ≃ n) (X : Matrix m m ℂ) :
    schattenOneSpectralNorm (Matrix.reindex e e X) = schattenOneSpectralNorm X := by
  apply le_antisymm (schattenOneSpectralNorm_reindex_le e X)
  have hsymm := schattenOneSpectralNorm_reindex_le e.symm (Matrix.reindex e e X)
  rw [reindex_symm_reindex] at hsymm
  exact hsymm

end ReindexInvariance

end BinduEventInterface

#print axioms BinduEventInterface.bessel_dot
#print axioms BinduEventInterface.svd_decomp
#print axioms BinduEventInterface.schattenOne_le_cost
#print axioms BinduEventInterface.schattenOne_finiteKrausChannel_le
#print axioms BinduEventInterface.schattenOneSpectralNorm_reindex_eq
