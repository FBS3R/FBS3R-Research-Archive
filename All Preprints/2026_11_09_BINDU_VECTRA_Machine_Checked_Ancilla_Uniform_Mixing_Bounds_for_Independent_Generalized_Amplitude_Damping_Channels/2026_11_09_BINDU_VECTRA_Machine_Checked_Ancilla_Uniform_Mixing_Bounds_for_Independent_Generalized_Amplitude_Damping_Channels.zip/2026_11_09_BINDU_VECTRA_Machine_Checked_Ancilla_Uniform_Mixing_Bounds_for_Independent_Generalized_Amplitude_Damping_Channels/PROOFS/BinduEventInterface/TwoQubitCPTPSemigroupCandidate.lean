import BinduEventInterface.FiniteKrausPositivityCandidate
import BinduEventInterface.LocalWeightedKrausSemigroupCandidate
import BinduEventInterface.TwoQubitSpectralSemigroupCandidate

/-!
# Arbitrary-Input Two-Qubit CPTP Quantum Dynamical Semigroup and Spectral Convergence

This module completes the kernel verification of the arbitrary-input CPTP quantum dynamical
semigroup for the fixed four-channel two-qubit GKSL generator
`fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate` (`P0a`, `P0b`, `P0c`):

* **P0a (Exact `2 × 2` local Kraus channels)**:
  - Closed-form local channel `gadClosedChannel` and equivalence `gadWeightedChannel_eq_closed`
  - Genuine square-root Kraus operators `gadKraus` (`K₀, K₁, K₂, K₃`), explicit formulas,
    completeness `gadKraus_completeness`, and equivalence
    `finiteKrausChannel_gadKraus_eq_gadWeightedChannel`
  - Time-parametrized local Kraus families `localKraus G K t` and channels `localChannel G K t`,
    trace preservation, Hermiticity preservation, PSD preservation, complete positivity for
    arbitrary finite ancillas (`a` and `Fin n`), `Φ₀ = id`, semigroup composition
    `Φ_{t+s} = Φ_t ∘ Φ_s`, and arbitrary-matrix entrywise GKSL master equation
    `localChannel_hasDerivAt_GKSL`
  - Local eigenmatrix propagation `localChannel1_eigen` and `localChannel2_eigen`

* **P0b (Full `4 × 4` two-qubit channel with 16 Kraus operators)**:
  - 16 tensor-product Kraus operators `twoQubitKraus t (a, b) = localKraus1 t a ⊗ localKraus2 t b`
    and channel `twoQubitKrausChannel t X`
  - 16-operator Kraus completeness `twoQubitKraus_completeness` (`∑ K_p† K_p = I₄`) for `t ≥ 0`
  - Trace preservation `twoQubitKrausChannel_trace_preserving`, Hermiticity preservation
    `twoQubitKrausChannel_isHermitian`, PSD preservation `twoQubitKrausChannel_posSemidef`,
    and complete positivity `twoQubitKrausChannel_ancilla_posSemidef` and
    `twoQubitKrausChannel_finAncilla_posSemidef` for arbitrary finite ancillas
  - Exact identity `twoQubitKrausChannel t X = twoQubitSpectralFlow t X` for all `t ≥ 0` and
    all `X ∈ M₄(ℂ)` (including coherent and entangled initial states)
  - Identity `Φ₀(X) = X`, semigroup composition `Φ_{t+s}(X) = Φ_t(Φ_s(X))` for `s, t ≥ 0`,
    arbitrary-input entrywise and matrix-level GKSL master equation, and arbitrary-input
    ODE uniqueness `twoQubit_arbitrary_initial_ode_unique`

* **P0c (Spectral propagator, stationary projection, global convergence, and `29/99` decay)**:
  - Exact agreement on vacuum input: `twoQubitKrausChannel t twoQubitVacuum = twoQubitVacuumTrajectory t`
  - Global convergence `twoQubitSpectralFlow t X → Tr(X) • twoQubitEquilibrium` and
    `twoQubitKrausChannel t X → Tr(X) • twoQubitEquilibrium` as `t → +∞` for every `X ∈ M₄(ℂ)`
  - Convergence `twoQubitKrausChannel t X → twoQubitEquilibrium` for every trace-one `X ∈ M₄(ℂ)`
  - Quantitative exponential decay bounds at the exact spectral gap rate `29/99`, mode-weight
    identity `∑_{p ≠ (0,0)} w_p = 24`, entrywise exponential decay bound, and abstract
    Schatten-1 norm decay bound with prefactor `24`.
-/

namespace BinduEventInterface

open Matrix Filter
open scoped Matrix ComplexOrder Topology

/-!
## P0a: Exact `2 × 2` Local Kraus Operators, Closed Channel Formula, and Local GKSL ODE
-/

/-- Explicit closed-form `2 × 2` generalized amplitude-damping map:
    populations mix with weight `1 - r²` toward `(1 - p, p)` while coherences scale by `r`. -/
noncomputable def gadClosedChannel (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  !![((1 - (p : ℂ)) + (p : ℂ) * (r : ℂ) ^ 2) * M 0 0 +
      (1 - (p : ℂ)) * (1 - (r : ℂ) ^ 2) * M 1 1,
     (r : ℂ) * M 0 1;
     (r : ℂ) * M 1 0,
     (p : ℂ) * (1 - (r : ℂ) ^ 2) * M 0 0 +
      ((p : ℂ) + (1 - (p : ℂ)) * (r : ℂ) ^ 2) * M 1 1]

/-- The 4-term weighted Kraus sum equals the explicit closed-form `2 × 2` channel. -/
theorem gadWeightedChannel_eq_closed (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    gadWeightedChannel p r M = gadClosedChannel p r M := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [gadWeightedChannel, gadClosedChannel, gadShape, gadWeight, Fin.sum_univ_four,
       Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two,
       Matrix.smul_apply, Matrix.conjTranspose_apply, Matrix.transpose_apply,
       Matrix.cons_val_zero, Matrix.cons_val_one,
       raising, lowering, Complex.conj_ofReal,
       Complex.ofReal_sub, Complex.ofReal_mul,
       Complex.ofReal_pow]
     ring)

/-- At `r = 1` (corresponding to `t = 0`), the local channel is the identity on all `M ∈ M₂(ℂ)`. -/
theorem gadWeightedChannel_one (p : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    gadWeightedChannel p 1 M = M := by
  rw [gadWeightedChannel_eq_closed]
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [gadClosedChannel]; try ring)

/-- The local channel commutes with `conjTranspose` for all real `p, r` and all `M ∈ M₂(ℂ)`. -/
theorem gadWeightedChannel_conjTranspose (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    (gadWeightedChannel p r M).conjTranspose =
      gadWeightedChannel p r M.conjTranspose := by
  rw [gadWeightedChannel_eq_closed p r M,
      gadWeightedChannel_eq_closed p r M.conjTranspose]
  ext i j
  fin_cases i <;> fin_cases j <;>
    (simp [gadClosedChannel, Matrix.conjTranspose_apply, Complex.conj_ofReal]; try ring)

/-- The local channel preserves Hermiticity for all real `p, r`. -/
theorem gadWeightedChannel_isHermitian (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) (hM : M.IsHermitian) :
    (gadWeightedChannel p r M).IsHermitian := by
  unfold Matrix.IsHermitian
  rw [gadWeightedChannel_conjTranspose, hM.eq]

/-- Genuine four-element Kraus operator family `K_j = √(w_j) • S_j`. -/
noncomputable def gadKraus (p r : ℝ) (j : Fin 4) : Matrix (Fin 2) (Fin 2) ℂ :=
  ((Real.sqrt (gadWeight p r j) : ℝ) : ℂ) • gadShape r j

/-- Explicit formula for `K₀ = √(1 - p) • diag(1, r)`. -/
theorem gadKraus_zero (p r : ℝ) :
    gadKraus p r 0 = ((Real.sqrt (1 - p) : ℝ) : ℂ) • !![(1 : ℂ), 0; 0, (r : ℂ)] :=
  rfl

/-- Explicit formula for `K₁ = √((1 - p)(1 - r²)) • |0⟩⟨1|`, factored as
`√(1 - p) √(1 - r²) • lowering` when `0 ≤ p ≤ 1`. -/
theorem gadKraus_one (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) :
    gadKraus p r 1 =
      (((Real.sqrt (1 - p) * Real.sqrt (1 - r ^ 2) : ℝ) : ℂ)) • lowering := by
  unfold gadKraus gadWeight gadShape
  rw [Real.sqrt_mul (by linarith)]

/-- Explicit formula for `K₂ = √p • diag(r, 1)`. -/
theorem gadKraus_two (p r : ℝ) :
    gadKraus p r 2 = ((Real.sqrt p : ℝ) : ℂ) • !![(r : ℂ), 0; 0, (1 : ℂ)] :=
  rfl

/-- Explicit formula for `K₃ = √(p(1 - r²)) • |1⟩⟨0|`, factored as
`√p √(1 - r²) • raising` when `0 ≤ p`. -/
theorem gadKraus_three (p r : ℝ) (hp : 0 ≤ p) :
    gadKraus p r 3 =
      (((Real.sqrt p * Real.sqrt (1 - r ^ 2) : ℝ) : ℂ)) • raising := by
  unfold gadKraus gadWeight gadShape
  rw [Real.sqrt_mul hp]

/-- Each squared Kraus term `(K_j)† * K_j` equals the weighted shape product
when `0 ≤ p, r ≤ 1`. -/
theorem gadKraus_conjTranspose_mul_self
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) (j : Fin 4) :
    (gadKraus p r j).conjTranspose * gadKraus p r j =
      ((gadWeight p r j : ℝ) : ℂ) • ((gadShape r j).conjTranspose * gadShape r j) := by
  have hw : 0 ≤ gadWeight p r j := gadWeight_nonneg p r hp hr j
  unfold gadKraus
  rw [Matrix.conjTranspose_smul, Complex.star_def, Complex.conj_ofReal,
      Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  congr 1
  norm_cast
  exact Real.mul_self_sqrt hw

/-- Exact Kraus completeness `∑_{j=0}^3 K_j† K_j = I₂` for the genuine square-root
Kraus operators when `0 ≤ p, r ≤ 1`. -/
theorem gadKraus_completeness
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    ∑ j : Fin 4, (gadKraus p r j).conjTranspose * gadKraus p r j =
      (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  have hterm :
      ∀ j : Fin 4,
        (gadKraus p r j).conjTranspose * gadKraus p r j =
          ((gadWeight p r j : ℝ) : ℂ) • ((gadShape r j).conjTranspose * gadShape r j) :=
    gadKraus_conjTranspose_mul_self p r hp hr
  simp_rw [hterm]
  exact gadWeightedCompleteness p r

/-- Each Kraus sandwich `K_j M K_j†` equals the weighted shape sandwich when `0 ≤ p, r ≤ 1`. -/
theorem gadKraus_sandwich
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (M : Matrix (Fin 2) (Fin 2) ℂ) (j : Fin 4) :
    gadKraus p r j * M * (gadKraus p r j).conjTranspose =
      ((gadWeight p r j : ℝ) : ℂ) • (gadShape r j * M * (gadShape r j).conjTranspose) := by
  have hw : 0 ≤ gadWeight p r j := gadWeight_nonneg p r hp hr j
  unfold gadKraus
  rw [Matrix.conjTranspose_smul, Complex.star_def, Complex.conj_ofReal,
      Matrix.smul_mul, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  congr 1
  norm_cast
  exact Real.mul_self_sqrt hw

/-- Equivalence of the square-root Kraus channel `finiteKrausChannel (gadKraus p r)` and
`gadWeightedChannel p r` on `0 ≤ p, r ≤ 1`. -/
theorem finiteKrausChannel_gadKraus_eq_gadWeightedChannel
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    finiteKrausChannel (gadKraus p r) M = gadWeightedChannel p r M := by
  unfold finiteKrausChannel gadWeightedChannel
  refine Finset.sum_congr rfl fun j _ => ?_
  exact gadKraus_sandwich p r hp hr M j

/-- For `0 ≤ p, r ≤ 1`, the genuine Kraus channel equals `gadClosedChannel p r M`. -/
theorem finiteKrausChannel_gadKraus_eq_closed
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    finiteKrausChannel (gadKraus p r) M = gadClosedChannel p r M := by
  rw [finiteKrausChannel_gadKraus_eq_gadWeightedChannel p r hp hr M,
      gadWeightedChannel_eq_closed]

/-- Trace preservation of the genuine 4-Kraus local channel via Kraus completeness. -/
theorem gadKraus_trace_preserving
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace (finiteKrausChannel (gadKraus p r) M) = Matrix.trace M :=
  finiteKrausChannel_trace_preserving (gadKraus p r) (gadKraus_completeness p r hp hr) M

/-- Positivity preservation of the local Kraus channel on any PSD `2 × 2` matrix. -/
theorem gadKraus_posSemidef
    (p r : ℝ) (M : Matrix (Fin 2) (Fin 2) ℂ) (hM : M.PosSemidef) :
    (finiteKrausChannel (gadKraus p r) M).PosSemidef :=
  finiteKrausChannel_posSemidef (gadKraus p r) M hM

/-- Positivity preservation of `gadWeightedChannel p r` on `0 ≤ p, r ≤ 1`. -/
theorem gadWeightedChannel_posSemidef
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (M : Matrix (Fin 2) (Fin 2) ℂ) (hM : M.PosSemidef) :
    (gadWeightedChannel p r M).PosSemidef := by
  rw [← finiteKrausChannel_gadKraus_eq_gadWeightedChannel p r hp hr M]
  exact gadKraus_posSemidef p r M hM

/-- Complete positivity of the local Kraus channel for any finite ancilla type `a`. -/
theorem gadKraus_ancilla_posSemidef
    {a : Type*} [Fintype a] [DecidableEq a]
    (p r : ℝ) (M : Matrix (a × Fin 2) (a × Fin 2) ℂ) (hM : M.PosSemidef) :
    (finiteKrausChannel
      (fun j : Fin 4 => Matrix.kronecker (1 : Matrix a a ℂ) (gadKraus p r j)) M).PosSemidef :=
  finiteKrausChannel_ancilla_posSemidef (gadKraus p r) M hM

/-- Complete positivity of the local Kraus channel for any `Fin n` ancilla (`n : ℕ`),
both with left-ancilla `1_n ⊗ K_j` and right-ancilla `K_j ⊗ 1_n`. -/
theorem gadKraus_finAncilla_posSemidef
    (n : ℕ) (p r : ℝ)
    (M₁ : Matrix (Fin n × Fin 2) (Fin n × Fin 2) ℂ) (hM₁ : M₁.PosSemidef)
    (M₂ : Matrix (Fin 2 × Fin n) (Fin 2 × Fin n) ℂ) (hM₂ : M₂.PosSemidef) :
    (finiteKrausChannel
      (fun j : Fin 4 => Matrix.kronecker (1 : Matrix (Fin n) (Fin n) ℂ) (gadKraus p r j))
      M₁).PosSemidef ∧
    (finiteKrausChannel
      (fun j : Fin 4 => Matrix.kronecker (gadKraus p r j) (1 : Matrix (Fin n) (Fin n) ℂ))
      M₂).PosSemidef :=
  ⟨finiteKrausChannel_posSemidef _ M₁ hM₁, finiteKrausChannel_posSemidef _ M₂ hM₂⟩

/-!
## Time-Parametrized Single-Qubit CPTP Semigroup for Arbitrary `G, K > 0`
-/

/-- Local equilibrium excited-state probability `p = G / (G + K)`. -/
noncomputable def localEqProb (G K : ℝ) : ℝ := G / (G + K)

/-- Local coherence damping factor `r(t) = exp(-(G + K) * t / 2)`. -/
noncomputable def localDampingR (G K t : ℝ) : ℝ :=
  Real.exp (-(G + K) * t / 2)

/-- Local population damping factor `q(t) = exp(-(G + K) * t)`. -/
noncomputable def localDampingQ (G K t : ℝ) : ℝ :=
  Real.exp (-(G + K) * t)

/-- Exact identity `r(t)² = q(t) = exp(-(G + K) * t)`. -/
theorem localDampingR_sq (G K t : ℝ) :
    (localDampingR G K t) ^ 2 = localDampingQ G K t := by
  unfold localDampingR localDampingQ
  rw [sq, ← Real.exp_add]
  congr 1
  ring

/-- Multiplicative law `r(t + s) = r(t) * r(s)` for the local damping factor. -/
theorem localDampingR_add (G K t s : ℝ) :
    localDampingR G K (t + s) = localDampingR G K t * localDampingR G K s := by
  unfold localDampingR
  rw [← Real.exp_add]
  congr 1
  ring

/-- At `t = 0`, `r(0) = 1`. -/
@[simp]
theorem localDampingR_zero (G K : ℝ) :
    localDampingR G K 0 = 1 := by
  simp [localDampingR]

/-- Bounds `0 ≤ p ≤ 1` for `p = G / (G + K)` when `G, K > 0`. -/
theorem localEqProb_bounds (G K : ℝ) (hG : 0 < G) (hK : 0 < K) :
    0 ≤ localEqProb G K ∧ localEqProb G K ≤ 1 := by
  unfold localEqProb
  have hsum : 0 < G + K := by linarith
  refine ⟨div_nonneg (le_of_lt hG) (le_of_lt hsum), ?_⟩
  rw [div_le_one hsum]
  linarith

/-- Bounds `0 ≤ r(t) ≤ 1` for `r(t) = exp(-(G + K) * t / 2)` when `G, K > 0` and `t ≥ 0`. -/
theorem localDampingR_bounds (G K t : ℝ) (hG : 0 < G) (hK : 0 < K) (ht : 0 ≤ t) :
    0 ≤ localDampingR G K t ∧ localDampingR G K t ≤ 1 := by
  unfold localDampingR
  refine ⟨le_of_lt (Real.exp_pos _), ?_⟩
  rw [Real.exp_le_one_iff]
  have hsum : 0 ≤ G + K := by linarith
  have hprod : 0 ≤ (G + K) * t := mul_nonneg hsum ht
  linarith

/-- Time-parametrized 4-element square-root Kraus family for a single qubit with rates `(G, K)`. -/
noncomputable def localKraus (G K t : ℝ) : Fin 4 → Matrix (Fin 2) (Fin 2) ℂ :=
  gadKraus (localEqProb G K) (localDampingR G K t)

/-- Time-parametrized local channel `Φ_{G,K,t}` on `M₂(ℂ)`. -/
noncomputable def localChannel (G K t : ℝ) (M : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  gadWeightedChannel (localEqProb G K) (localDampingR G K t) M

/-- Local Schrödinger GKSL generator `G • D_{σ⁺}(M) + K • D_{σ⁻}(M)` on `M₂(ℂ)`. -/
noncomputable def localGKSLGen (G K : ℝ) (M : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  (G : ℂ) • dissipatorSchrodinger raising M +
    (K : ℂ) • dissipatorSchrodinger lowering M

/-- Exact Kraus completeness `∑_{j=0}^3 K_j(t)† K_j(t) = I₂` for `G, K > 0` and `t ≥ 0`. -/
theorem localKraus_completeness
    (G K t : ℝ) (hG : 0 < G) (hK : 0 < K) (ht : 0 ≤ t) :
    ∑ j : Fin 4, (localKraus G K t j).conjTranspose * localKraus G K t j =
      (1 : Matrix (Fin 2) (Fin 2) ℂ) :=
  gadKraus_completeness (localEqProb G K) (localDampingR G K t)
    (localEqProb_bounds G K hG hK) (localDampingR_bounds G K t hG hK ht)

/-- For `G, K > 0` and `t ≥ 0`, the genuine square-root Kraus map equals `localChannel G K t`. -/
theorem finiteKrausChannel_localKraus_eq_localChannel
    (G K t : ℝ) (hG : 0 < G) (hK : 0 < K) (ht : 0 ≤ t)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    finiteKrausChannel (localKraus G K t) M = localChannel G K t M :=
  finiteKrausChannel_gadKraus_eq_gadWeightedChannel
    (localEqProb G K) (localDampingR G K t)
    (localEqProb_bounds G K hG hK) (localDampingR_bounds G K t hG hK ht) M

/-- At `t = 0`, `localChannel G K 0 M = M` for every `M ∈ M₂(ℂ)`. -/
theorem localChannel_zero (G K : ℝ) (M : Matrix (Fin 2) (Fin 2) ℂ) :
    localChannel G K 0 M = M := by
  unfold localChannel
  rw [localDampingR_zero, gadWeightedChannel_one]

/-- Exact semigroup composition `Φ_{G,K,t+s}(M) = Φ_{G,K,t}(Φ_{G,K,s}(M))` for all `s, t ∈ ℝ`
and all `M ∈ M₂(ℂ)`. -/
theorem localChannel_semigroup (G K s t : ℝ) (M : Matrix (Fin 2) (Fin 2) ℂ) :
    localChannel G K (t + s) M = localChannel G K t (localChannel G K s M) := by
  unfold localChannel
  rw [localDampingR_add, gadWeightedChannel_comp]

/-- Exact trace preservation `Tr(Φ_{G,K,t}(M)) = Tr(M)` for all `M ∈ M₂(ℂ)`. -/
theorem localChannel_trace (G K t : ℝ) (M : Matrix (Fin 2) (Fin 2) ℂ) :
    Matrix.trace (localChannel G K t M) = Matrix.trace M :=
  gadWeightedChannel_trace (localEqProb G K) (localDampingR G K t) M

/-- Positive-semidefinite preservation of `localChannel G K t` for `G, K > 0` and `t ≥ 0`. -/
theorem localChannel_posSemidef
    (G K t : ℝ) (hG : 0 < G) (hK : 0 < K) (ht : 0 ≤ t)
    (M : Matrix (Fin 2) (Fin 2) ℂ) (hM : M.PosSemidef) :
    (localChannel G K t M).PosSemidef :=
  gadWeightedChannel_posSemidef (localEqProb G K) (localDampingR G K t)
    (localEqProb_bounds G K hG hK) (localDampingR_bounds G K t hG hK ht) M hM

/-- Complete positivity of `localKraus G K t` for any finite ancilla type `a`. -/
theorem localKraus_ancilla_posSemidef
    {a : Type*} [Fintype a] [DecidableEq a]
    (G K t : ℝ) (M : Matrix (a × Fin 2) (a × Fin 2) ℂ) (hM : M.PosSemidef) :
    (finiteKrausChannel
      (fun j : Fin 4 => Matrix.kronecker (1 : Matrix a a ℂ) (localKraus G K t j)) M).PosSemidef :=
  finiteKrausChannel_ancilla_posSemidef (localKraus G K t) M hM

/-- Exact derivative of the local coherence damping factor `r(t) = exp(-(G + K) * t / 2)`. -/
theorem localDampingR_hasDerivAt (G K t : ℝ) :
    HasDerivAt (localDampingR G K) (-((G + K) / 2) * localDampingR G K t) t := by
  unfold localDampingR
  have hlin : HasDerivAt (fun s : ℝ => -(G + K) * s / 2) (-((G + K) / 2)) t := by
    have h1 := (hasDerivAt_id t).const_mul (-(G + K))
    have h2 := h1.div_const (2 : ℝ)
    convert h2 using 1
    ring
  have hexp := (Real.hasDerivAt_exp (-(G + K) * t / 2)).comp t hlin
  convert hexp using 1
  ring

/-- Complex-cast derivative of `s ↦ (localDampingR G K s : ℂ)`. -/
theorem localDampingR_complex_hasDerivAt (G K t : ℝ) :
    HasDerivAt (fun s : ℝ => (localDampingR G K s : ℂ))
      (((-((G + K) / 2) * localDampingR G K t : ℝ) : ℂ)) t := by
  simpa using (localDampingR_hasDerivAt G K t).ofReal_comp

/-- Complex-cast derivative of `s ↦ ((localDampingR G K s : ℂ) ^ 2)`. -/
theorem localDampingR_sq_complex_hasDerivAt (G K t : ℝ) :
    HasDerivAt (fun s : ℝ => (localDampingR G K s : ℂ) ^ 2)
      (-((G + K : ℝ) : ℂ) * (localDampingR G K t : ℂ) ^ 2) t := by
  have hr := localDampingR_complex_hasDerivAt G K t
  have hsq := hr.mul hr
  convert hsq using 1
  · ext s; ring
  · push_cast; ring

/-- Exact entrywise GKSL master equation for the local channel on ANY `2 × 2` complex matrix `M`
(whenever `G + K ≠ 0`, in particular for all `G, K > 0`):
`d/dt (localChannel G K t M)_{i,j} = (localGKSLGen G K (localChannel G K t M))_{i,j}`. -/
theorem localChannel_hasDerivAt_GKSL
    (G K : ℝ) (hGK : G + K ≠ 0) (M : Matrix (Fin 2) (Fin 2) ℂ)
    (t : ℝ) (i j : Fin 2) :
    HasDerivAt (fun s : ℝ => localChannel G K s M i j)
      (localGKSLGen G K (localChannel G K t M) i j) t := by
  have hGKc : (G : ℂ) + (K : ℂ) ≠ 0 := by
    exact_mod_cast hGK
  have hpG : (localEqProb G K : ℂ) * ((G : ℂ) + (K : ℂ)) = (G : ℂ) := by
    unfold localEqProb
    push_cast
    exact div_mul_cancel₀ (G : ℂ) hGKc
  have hpK : (1 - (localEqProb G K : ℂ)) * ((G : ℂ) + (K : ℂ)) = (K : ℂ) := by
    calc
      (1 - (localEqProb G K : ℂ)) * ((G : ℂ) + (K : ℂ)) =
          ((G : ℂ) + (K : ℂ)) - (localEqProb G K : ℂ) * ((G : ℂ) + (K : ℂ)) := by ring
      _ = ((G : ℂ) + (K : ℂ)) - (G : ℂ) := by rw [hpG]
      _ = (K : ℂ) := by ring
  have hr := localDampingR_complex_hasDerivAt G K t
  have hq := localDampingR_sq_complex_hasDerivAt G K t
  have hfun :
      (fun s : ℝ => localChannel G K s M i j) =
        (fun s : ℝ => gadClosedChannel (localEqProb G K) (localDampingR G K s) M i j) := by
    ext s
    unfold localChannel
    rw [gadWeightedChannel_eq_closed]
  rw [hfun]
  unfold localChannel
  rw [gadWeightedChannel_eq_closed]
  fin_cases i <;> fin_cases j
  · -- Entry (0, 0)
    simp only [Fin.zero_eta, gadClosedChannel, Matrix.of_apply,
      Matrix.cons_val_zero]
    have hd1 := ((hq.const_mul (localEqProb G K : ℂ)).const_add
      (1 - (localEqProb G K : ℂ))).mul_const (M 0 0)
    have hd2 := (((hasDerivAt_const t (1 : ℂ)).sub hq).const_mul
      (1 - (localEqProb G K : ℂ))).mul_const (M 1 1)
    have hsum := hd1.add hd2
    convert hsum using 1
    simp only [localGKSLGen, dissipatorSchrodinger, raising, lowering,
      gadClosedChannel, Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two,
      Matrix.conjTranspose_apply, Matrix.transpose_apply, smul_eq_mul,
      Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons,
      star_zero, star_one, Complex.ofReal_add, Complex.ofReal_sub,
      Complex.ofReal_mul, Complex.ofReal_neg, Complex.ofReal_div, Complex.ofReal_ofNat]
    linear_combination
      ((localDampingR G K t : ℂ) ^ 2 * M 0 0 + (1 + (localDampingR G K t : ℂ) ^ 2) * M 1 1) * hpG +
      (-(1 - (localDampingR G K t : ℂ) ^ 2) * M 0 0 + (localDampingR G K t : ℂ) ^ 2 * M 1 1) * hpK
  · -- Entry (0, 1)
    simp only [Fin.zero_eta, Fin.mk_one, gadClosedChannel, Matrix.of_apply,
      Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
    have hd := hr.mul_const (M 0 1)
    convert hd using 1
    simp only [localGKSLGen, dissipatorSchrodinger, raising, lowering,
      gadClosedChannel, Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two,
      Matrix.conjTranspose_apply, Matrix.transpose_apply, smul_eq_mul,
      Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons,
      star_zero, star_one, Complex.ofReal_mul, Complex.ofReal_neg,
      Complex.ofReal_div, Complex.ofReal_add, Complex.ofReal_ofNat]
    ring
  · -- Entry (1, 0)
    simp only [Fin.mk_one, Fin.zero_eta, gadClosedChannel, Matrix.of_apply,
      Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons]
    have hd := hr.mul_const (M 1 0)
    convert hd using 1
    simp only [localGKSLGen, dissipatorSchrodinger, raising, lowering,
      gadClosedChannel, Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two,
      Matrix.conjTranspose_apply, Matrix.transpose_apply, smul_eq_mul,
      Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons,
      star_zero, star_one, Complex.ofReal_mul, Complex.ofReal_neg,
      Complex.ofReal_div, Complex.ofReal_add, Complex.ofReal_ofNat]
    ring
  · -- Entry (1, 1)
    simp only [Fin.mk_one, gadClosedChannel, Matrix.of_apply,
      Matrix.cons_val_one, Matrix.head_cons]
    have hd1 := (((hasDerivAt_const t (1 : ℂ)).sub hq).const_mul
      (localEqProb G K : ℂ)).mul_const (M 0 0)
    have hd2 := ((hq.const_mul (1 - (localEqProb G K : ℂ))).const_add
      (localEqProb G K : ℂ)).mul_const (M 1 1)
    have hsum := hd1.add hd2
    convert hsum using 1
    simp only [localGKSLGen, dissipatorSchrodinger, raising, lowering,
      gadClosedChannel, Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
      Matrix.mul_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two,
      Matrix.conjTranspose_apply, Matrix.transpose_apply, smul_eq_mul,
      Matrix.of_apply, Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.head_cons,
      star_zero, star_one, Complex.ofReal_add, Complex.ofReal_sub,
      Complex.ofReal_mul, Complex.ofReal_neg, Complex.ofReal_div, Complex.ofReal_ofNat]
    linear_combination
      (-(localDampingR G K t : ℂ) ^ 2 * M 0 0 - (1 + (localDampingR G K t : ℂ) ^ 2) * M 1 1) * hpG +
      ((1 - (localDampingR G K t : ℂ) ^ 2) * M 0 0 - (localDampingR G K t : ℂ) ^ 2 * M 1 1) * hpK

/-!
## Concrete Local Qubit 1 (`G₁ = 1/5, K₁ = 3/7`) and Qubit 2 (`G₂ = 2/9, K₂ = 4/11`) Specializations
-/

/-- Local Kraus family for qubit 1 with rates `G₁ = 1/5, K₁ = 3/7`. -/
noncomputable def localKraus1 (t : ℝ) : Fin 4 → Matrix QubitIndex QubitIndex ℂ :=
  localKraus (1 / 5) (3 / 7) t

/-- Local Kraus family for qubit 2 with rates `G₂ = 2/9, K₂ = 4/11`. -/
noncomputable def localKraus2 (t : ℝ) : Fin 4 → Matrix QubitIndex QubitIndex ℂ :=
  localKraus (2 / 9) (4 / 11) t

/-- Local CPTP channel for qubit 1 with rates `G₁ = 1/5, K₁ = 3/7`. -/
noncomputable def localChannel1 (t : ℝ) (M : Matrix QubitIndex QubitIndex ℂ) :
    Matrix QubitIndex QubitIndex ℂ :=
  localChannel (1 / 5) (3 / 7) t M

/-- Local CPTP channel for qubit 2 with rates `G₂ = 2/9, K₂ = 4/11`. -/
noncomputable def localChannel2 (t : ℝ) (M : Matrix QubitIndex QubitIndex ℂ) :
    Matrix QubitIndex QubitIndex ℂ :=
  localChannel (2 / 9) (4 / 11) t M

/-- `localGKSLGen (1/5) (3/7)` is judgmentally and extensionally equal to `localGKSL1`. -/
theorem localGKSLGen_one_eq_localGKSL1 (M : Matrix QubitIndex QubitIndex ℂ) :
    localGKSLGen (1 / 5) (3 / 7) M = localGKSL1 M := by
  unfold localGKSLGen localGKSL1
  push_cast
  rfl

/-- `localGKSLGen (2/9) (4/11)` is judgmentally and extensionally equal to `localGKSL2`. -/
theorem localGKSLGen_two_eq_localGKSL2 (M : Matrix QubitIndex QubitIndex ℂ) :
    localGKSLGen (2 / 9) (4 / 11) M = localGKSL2 M := by
  unfold localGKSLGen localGKSL2
  push_cast
  rfl

/-- Entrywise GKSL master equation for `localChannel1` on any `M ∈ M₂(ℂ)`. -/
theorem localChannel1_hasDerivAt_localGKSL1
    (M : Matrix QubitIndex QubitIndex ℂ) (t : ℝ) (i j : QubitIndex) :
    HasDerivAt (fun s : ℝ => localChannel1 s M i j)
      (localGKSL1 (localChannel1 t M) i j) t := by
  rw [← localGKSLGen_one_eq_localGKSL1]
  exact localChannel_hasDerivAt_GKSL (1 / 5) (3 / 7) (by norm_num) M t i j

/-- Entrywise GKSL master equation for `localChannel2` on any `M ∈ M₂(ℂ)`. -/
theorem localChannel2_hasDerivAt_localGKSL2
    (M : Matrix QubitIndex QubitIndex ℂ) (t : ℝ) (i j : QubitIndex) :
    HasDerivAt (fun s : ℝ => localChannel2 s M i j)
      (localGKSL2 (localChannel2 t M) i j) t := by
  rw [← localGKSLGen_two_eq_localGKSL2]
  exact localChannel_hasDerivAt_GKSL (2 / 9) (4 / 11) (by norm_num) M t i j

/-- Exact action of `localChannel1 t` on the four local eigenmatrices `localEigenMatrix1 a`:
`localChannel1 t (localEigenMatrix1 a) = exp(localEigenvalue1 a * t) • localEigenMatrix1 a`. -/
theorem localChannel1_eigen (t : ℝ) (a : Fin 4) :
    localChannel1 t (localEigenMatrix1 a) =
      (Real.exp (localEigenvalue1 a * t) : ℂ) • localEigenMatrix1 a := by
  unfold localChannel1 localChannel
  rw [gadWeightedChannel_eq_closed]
  have hr1 : localDampingR (1 / 5) (3 / 7) t = Real.exp (-(11 / 35 : ℝ) * t) := by
    unfold localDampingR
    congr 1
    ring
  have hq1 : (localDampingR (1 / 5) (3 / 7) t : ℂ) ^ 2 =
      (Real.exp (-(22 / 35 : ℝ) * t) : ℂ) := by
    norm_cast
    rw [localDampingR_sq]
    unfold localDampingQ
    congr 1
    ring
  have hp1 : localEqProb (1 / 5) (3 / 7) = 7 / 22 := by
    unfold localEqProb
    norm_num
  unfold gadClosedChannel
  rw [hq1, hr1, hp1]
  fin_cases a <;>
    ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [localEigenMatrix1, localEigenvalue1,
      twoQubitEqLocal1, raising, lowering, localPopulationMode] <;>
    ring

/-- Exact action of `localChannel2 t` on the four local eigenmatrices `localEigenMatrix2 b`:
`localChannel2 t (localEigenMatrix2 b) = exp(localEigenvalue2 b * t) • localEigenMatrix2 b`. -/
theorem localChannel2_eigen (t : ℝ) (b : Fin 4) :
    localChannel2 t (localEigenMatrix2 b) =
      (Real.exp (localEigenvalue2 b * t) : ℂ) • localEigenMatrix2 b := by
  unfold localChannel2 localChannel
  rw [gadWeightedChannel_eq_closed]
  have hr2 : localDampingR (2 / 9) (4 / 11) t = Real.exp (-(29 / 99 : ℝ) * t) := by
    unfold localDampingR
    congr 1
    ring
  have hq2 : (localDampingR (2 / 9) (4 / 11) t : ℂ) ^ 2 =
      (Real.exp (-(58 / 99 : ℝ) * t) : ℂ) := by
    norm_cast
    rw [localDampingR_sq]
    unfold localDampingQ
    congr 1
    ring
  have hp2 : localEqProb (2 / 9) (4 / 11) = 11 / 29 := by
    unfold localEqProb
    norm_num
  unfold gadClosedChannel
  rw [hq2, hr2, hp2]
  fin_cases b <;>
    ext i j <;> fin_cases i <;> fin_cases j <;>
    simp [localEigenMatrix2, localEigenvalue2,
      twoQubitEqLocal2, raising, lowering, localPopulationMode] <;>
    ring

/-!
## P0b & P0c: Full 16-Kraus Two-Qubit Channel, Spectral Flow Identity, GKSL ODE, and Convergence
-/

/-- The 16 two-qubit Kraus operators `K_{(a,b)}(t) = K^{(1)}_a(t) ⊗ K^{(2)}_b(t)`. -/
noncomputable def twoQubitKraus (t : ℝ) (p : Fin 4 × Fin 4) :
    Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker (localKraus1 t p.1) (localKraus2 t p.2)

/-- The 16-operator two-qubit Kraus channel `Φ_t(X) = ∑_{p : Fin 4 × Fin 4} K_p(t) X K_p(t)†`
acting on arbitrary `4 × 4` complex matrices `X`. -/
noncomputable def twoQubitKrausChannel (t : ℝ)
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  finiteKrausChannel (twoQubitKraus t) X

/-- The 16 two-qubit Kraus shape matrices `S_{(a,b)}(t) = S^{(1)}_a(t) ⊗ S^{(2)}_b(t)`. -/
noncomputable def twoQubitKrausShape (t : ℝ) (p : Fin 4 × Fin 4) :
    Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  Matrix.kronecker
    (gadShape (localDampingR (1 / 5) (3 / 7) t) p.1)
    (gadShape (localDampingR (2 / 9) (4 / 11) t) p.2)

/-- The 16 two-qubit Kraus weights `W_{(a,b)}(t) = w^{(1)}_a(t) * w^{(2)}_b(t)`. -/
noncomputable def twoQubitKrausWeight (t : ℝ) (p : Fin 4 × Fin 4) : ℝ :=
  gadWeight (localEqProb (1 / 5) (3 / 7)) (localDampingR (1 / 5) (3 / 7) t) p.1 *
    gadWeight (localEqProb (2 / 9) (4 / 11)) (localDampingR (2 / 9) (4 / 11) t) p.2

/-- Polynomial weighted 16-term two-qubit channel defined for all `t : ℝ`. -/
noncomputable def twoQubitWeightedKrausChannel (t : ℝ)
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Matrix TwoQubitIndex TwoQubitIndex ℂ :=
  ∑ p : Fin 4 × Fin 4,
    ((twoQubitKrausWeight t p : ℝ) : ℂ) •
      (twoQubitKrausShape t p * X * (twoQubitKrausShape t p).conjTranspose)

/-- For `t ≥ 0`, each two-qubit Kraus operator `twoQubitKraus t p` equals
`√(twoQubitKrausWeight t p) • twoQubitKrausShape t p`. -/
theorem twoQubitKraus_eq_sqrt_weight_smul_shape
    (t : ℝ) (ht : 0 ≤ t) (p : Fin 4 × Fin 4) :
    twoQubitKraus t p =
      ((Real.sqrt (twoQubitKrausWeight t p) : ℝ) : ℂ) • twoQubitKrausShape t p := by
  rcases p with ⟨a, b⟩
  have hw1 : 0 ≤ gadWeight (localEqProb (1 / 5) (3 / 7)) (localDampingR (1 / 5) (3 / 7) t) a :=
    gadWeight_nonneg _ _ (localEqProb_bounds (1 / 5) (3 / 7) (by norm_num) (by norm_num))
      (localDampingR_bounds (1 / 5) (3 / 7) t (by norm_num) (by norm_num) ht) a
  unfold twoQubitKraus localKraus1 localKraus2 localKraus gadKraus
    twoQubitKrausWeight twoQubitKrausShape
  rw [Real.sqrt_mul hw1]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.smul_apply, Matrix.kronecker, Matrix.kroneckerMap_apply,
    Complex.ofReal_mul, smul_eq_mul]
  ring

/-- Exact 16-operator Kraus completeness `∑_{p : Fin 4 × Fin 4} K_p(t)† K_p(t) = I₄`
for every `t ≥ 0`. -/
theorem twoQubitKraus_completeness (t : ℝ) (ht : 0 ≤ t) :
    ∑ p : Fin 4 × Fin 4, (twoQubitKraus t p).conjTranspose * twoQubitKraus t p =
      (1 : Matrix TwoQubitIndex TwoQubitIndex ℂ) := by
  have h1 := localKraus_completeness (1 / 5) (3 / 7) t (by norm_num) (by norm_num) ht
  have h2 := localKraus_completeness (2 / 9) (4 / 11) t (by norm_num) (by norm_num) ht
  have hterm (p : Fin 4 × Fin 4) :
      (twoQubitKraus t p).conjTranspose * twoQubitKraus t p =
        Matrix.kronecker
          ((localKraus1 t p.1).conjTranspose * localKraus1 t p.1)
          ((localKraus2 t p.2).conjTranspose * localKraus2 t p.2) := by
    unfold twoQubitKraus
    rw [kronecker_conjTranspose_v419]
    exact (Matrix.mul_kronecker_mul
      (localKraus1 t p.1).conjTranspose (localKraus1 t p.1)
      (localKraus2 t p.2).conjTranspose (localKraus2 t p.2)).symm
  simp_rw [hterm]
  rw [Fintype.sum_prod_type]
  have hkr :
      (∑ a : Fin 4, ∑ b : Fin 4,
        Matrix.kronecker
          ((localKraus1 t a).conjTranspose * localKraus1 t a)
          ((localKraus2 t b).conjTranspose * localKraus2 t b)) =
      Matrix.kronecker
        (∑ a : Fin 4, (localKraus1 t a).conjTranspose * localKraus1 t a)
        (∑ b : Fin 4, (localKraus2 t b).conjTranspose * localKraus2 t b) := by
    ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
    simp only [Matrix.sum_apply, Matrix.kronecker, Matrix.kroneckerMap_apply]
    rw [Finset.sum_mul]
    refine Finset.sum_congr rfl fun a _ => ?_
    rw [Finset.mul_sum]
  rw [hkr]
  unfold localKraus1 localKraus2
  rw [h1, h2]
  exact Matrix.one_kronecker_one

/-- Exact trace preservation of the 16-Kraus two-qubit channel for all `t ≥ 0`
and all `X ∈ M₄(ℂ)`. -/
theorem twoQubitKrausChannel_trace_preserving
    (t : ℝ) (ht : 0 ≤ t) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Matrix.trace (twoQubitKrausChannel t X) = Matrix.trace X :=
  finiteKrausChannel_trace_preserving (twoQubitKraus t) (twoQubitKraus_completeness t ht) X

/-- Positive-semidefinite preservation of `twoQubitKrausChannel t` on all PSD `4 × 4` matrices
(including entangled density matrices). -/
theorem twoQubitKrausChannel_posSemidef
    (t : ℝ) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (hX : X.PosSemidef) :
    (twoQubitKrausChannel t X).PosSemidef :=
  finiteKrausChannel_posSemidef (twoQubitKraus t) X hX

/-- Hermiticity preservation of `twoQubitKrausChannel t` on all Hermitian `4 × 4` matrices. -/
theorem twoQubitKrausChannel_isHermitian
    (t : ℝ) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (hX : X.IsHermitian) :
    (twoQubitKrausChannel t X).IsHermitian := by
  unfold Matrix.IsHermitian twoQubitKrausChannel finiteKrausChannel
  rw [Matrix.conjTranspose_sum]
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [Matrix.conjTranspose_mul, Matrix.conjTranspose_mul,
      Matrix.conjTranspose_conjTranspose, hX.eq, mul_assoc]

/-- Complete positivity of the 16-Kraus two-qubit channel for any finite ancilla type `a`. -/
theorem twoQubitKrausChannel_ancilla_posSemidef
    {a : Type*} [Fintype a] [DecidableEq a]
    (t : ℝ) (M : Matrix (a × TwoQubitIndex) (a × TwoQubitIndex) ℂ) (hM : M.PosSemidef) :
    (finiteKrausChannel
      (fun p : Fin 4 × Fin 4 =>
        Matrix.kronecker (1 : Matrix a a ℂ) (twoQubitKraus t p)) M).PosSemidef :=
  finiteKrausChannel_ancilla_posSemidef (twoQubitKraus t) M hM

/-- Complete positivity of the 16-Kraus two-qubit channel for any `Fin n` ancilla (`n : ℕ`),
both with left-ancilla `1_n ⊗ K_p(t)` and right-ancilla `K_p(t) ⊗ 1_n`. -/
theorem twoQubitKrausChannel_finAncilla_posSemidef
    (n : ℕ) (t : ℝ)
    (M₁ : Matrix (Fin n × TwoQubitIndex) (Fin n × TwoQubitIndex) ℂ) (hM₁ : M₁.PosSemidef)
    (M₂ : Matrix (TwoQubitIndex × Fin n) (TwoQubitIndex × Fin n) ℂ) (hM₂ : M₂.PosSemidef) :
    (finiteKrausChannel
      (fun p : Fin 4 × Fin 4 =>
        Matrix.kronecker (1 : Matrix (Fin n) (Fin n) ℂ) (twoQubitKraus t p)) M₁).PosSemidef ∧
    (finiteKrausChannel
      (fun p : Fin 4 × Fin 4 =>
        Matrix.kronecker (twoQubitKraus t p) (1 : Matrix (Fin n) (Fin n) ℂ)) M₂).PosSemidef :=
  ⟨finiteKrausChannel_posSemidef _ M₁ hM₁, finiteKrausChannel_posSemidef _ M₂ hM₂⟩

/-- For `t ≥ 0`, the 16-operator square-root Kraus channel `twoQubitKrausChannel t X`
equals the polynomial weighted channel `twoQubitWeightedKrausChannel t X` for all `X ∈ M₄(ℂ)`. -/
theorem twoQubitKrausChannel_eq_weighted
    (t : ℝ) (ht : 0 ≤ t) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitKrausChannel t X = twoQubitWeightedKrausChannel t X := by
  unfold twoQubitKrausChannel finiteKrausChannel twoQubitWeightedKrausChannel
  refine Finset.sum_congr rfl fun p _ => ?_
  have hw1 : 0 ≤ gadWeight (localEqProb (1 / 5) (3 / 7)) (localDampingR (1 / 5) (3 / 7) t) p.1 :=
    gadWeight_nonneg _ _ (localEqProb_bounds (1 / 5) (3 / 7) (by norm_num) (by norm_num))
      (localDampingR_bounds (1 / 5) (3 / 7) t (by norm_num) (by norm_num) ht) p.1
  have hw2 : 0 ≤ gadWeight (localEqProb (2 / 9) (4 / 11)) (localDampingR (2 / 9) (4 / 11) t) p.2 :=
    gadWeight_nonneg _ _ (localEqProb_bounds (2 / 9) (4 / 11) (by norm_num) (by norm_num))
      (localDampingR_bounds (2 / 9) (4 / 11) t (by norm_num) (by norm_num) ht) p.2
  have hw : 0 ≤ twoQubitKrausWeight t p := mul_nonneg hw1 hw2
  rw [twoQubitKraus_eq_sqrt_weight_smul_shape t ht p]
  rw [Matrix.conjTranspose_smul, Complex.star_def, Complex.conj_ofReal,
      Matrix.smul_mul, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  congr 1
  norm_cast
  exact Real.mul_self_sqrt hw

/-- Action of `twoQubitWeightedKrausChannel t` on any Kronecker product `A ⊗ B`:
`twoQubitWeightedKrausChannel t (A ⊗ B) = localChannel1 t A ⊗ localChannel2 t B`. -/
theorem twoQubitWeightedKrausChannel_kronecker
    (t : ℝ) (A B : Matrix QubitIndex QubitIndex ℂ) :
    twoQubitWeightedKrausChannel t (Matrix.kronecker A B) =
      Matrix.kronecker (localChannel1 t A) (localChannel2 t B) := by
  have hterm (p : Fin 4 × Fin 4) :
      twoQubitKrausShape t p * Matrix.kronecker A B * (twoQubitKrausShape t p).conjTranspose =
        Matrix.kronecker
          (gadShape (localDampingR (1 / 5) (3 / 7) t) p.1 * A *
            (gadShape (localDampingR (1 / 5) (3 / 7) t) p.1).conjTranspose)
          (gadShape (localDampingR (2 / 9) (4 / 11) t) p.2 * B *
            (gadShape (localDampingR (2 / 9) (4 / 11) t) p.2).conjTranspose) := by
    unfold twoQubitKrausShape
    rw [kronecker_conjTranspose_v419]
    have hm1 := (Matrix.mul_kronecker_mul
      (gadShape (localDampingR (1 / 5) (3 / 7) t) p.1) A
      (gadShape (localDampingR (2 / 9) (4 / 11) t) p.2) B).symm
    have hm2 := (Matrix.mul_kronecker_mul
      (gadShape (localDampingR (1 / 5) (3 / 7) t) p.1 * A)
      (gadShape (localDampingR (1 / 5) (3 / 7) t) p.1).conjTranspose
      (gadShape (localDampingR (2 / 9) (4 / 11) t) p.2 * B)
      (gadShape (localDampingR (2 / 9) (4 / 11) t) p.2).conjTranspose).symm
    dsimp only [Matrix.kronecker]
    rw [hm1, hm2]
  unfold twoQubitWeightedKrausChannel
  simp_rw [hterm]
  rw [Fintype.sum_prod_type]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.sum_apply, Matrix.smul_apply, Matrix.kronecker,
    Matrix.kroneckerMap_apply, twoQubitKrausWeight, localChannel1, localChannel2,
    localChannel, gadWeightedChannel, Complex.ofReal_mul, smul_eq_mul]
  rw [Finset.sum_mul]
  refine Finset.sum_congr rfl fun a _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun b _ => ?_
  ring

/-- Action of `twoQubitWeightedKrausChannel t` on each of the 16 two-qubit eigenmatrices:
`twoQubitWeightedKrausChannel t (twoQubitEigenMatrix p) = exp(twoQubitEigenvalue p * t) • twoQubitEigenMatrix p`. -/
theorem twoQubitWeightedKrausChannel_eigenMatrix
    (t : ℝ) (p : Fin 4 × Fin 4) :
    twoQubitWeightedKrausChannel t (twoQubitEigenMatrix p) =
      (Real.exp (twoQubitEigenvalue p * t) : ℂ) • twoQubitEigenMatrix p := by
  rcases p with ⟨a, b⟩
  unfold twoQubitEigenMatrix twoQubitEigenvalue
  rw [twoQubitWeightedKrausChannel_kronecker, localChannel1_eigen t a, localChannel2_eigen t b]
  ext ⟨i₁, i₂⟩ ⟨j₁, j₂⟩
  simp only [Matrix.smul_apply, Matrix.kronecker, Matrix.kroneckerMap_apply,
    add_mul, Real.exp_add, Complex.ofReal_mul, smul_eq_mul]
  ring

/-- Linearity of `twoQubitWeightedKrausChannel t` over finite sums of matrices. -/
theorem twoQubitWeightedKrausChannel_sum
    {ι : Type*} (s : Finset ι) (t : ℝ)
    (f : ι → Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitWeightedKrausChannel t (∑ q ∈ s, f q) =
      ∑ q ∈ s, twoQubitWeightedKrausChannel t (f q) := by
  unfold twoQubitWeightedKrausChannel
  simp_rw [Matrix.mul_sum, Matrix.sum_mul, Finset.smul_sum]
  exact Finset.sum_comm

/-- Linearity of `twoQubitWeightedKrausChannel t` with respect to complex scalar multiplication. -/
theorem twoQubitWeightedKrausChannel_smul
    (t : ℝ) (c : ℂ) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitWeightedKrausChannel t (c • X) =
      c • twoQubitWeightedKrausChannel t X := by
  unfold twoQubitWeightedKrausChannel
  rw [Finset.smul_sum]
  refine Finset.sum_congr rfl fun p _ => ?_
  ext i j
  simp only [Matrix.smul_apply, Matrix.mul_apply, smul_eq_mul,
    Finset.mul_sum, Finset.sum_mul]
  refine Finset.sum_congr rfl fun x _ => ?_
  refine Finset.sum_congr rfl fun y _ => ?_
  ring

/-- Exact equality of `twoQubitWeightedKrausChannel t X` and `twoQubitSpectralFlow t X`
for ALL `t ∈ ℝ` and ALL `4 × 4` complex matrices `X` (including coherent and entangled states). -/
theorem twoQubitWeightedKrausChannel_eq_spectralFlow
    (t : ℝ) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitWeightedKrausChannel t X = twoQubitSpectralFlow t X := by
  conv_lhs => rw [twoQubit_matrix_spectral_expansion X]
  rw [twoQubitWeightedKrausChannel_sum]
  unfold twoQubitSpectralFlow
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [twoQubitWeightedKrausChannel_smul, twoQubitWeightedKrausChannel_eigenMatrix,
      smul_smul, mul_comm]

/-- Exact equality of the 16-operator Kraus channel `twoQubitKrausChannel t X` and the
16-mode spectral propagator `twoQubitSpectralFlow t X` for all `t ≥ 0` and all `X ∈ M₄(ℂ)`. -/
theorem twoQubitKrausChannel_eq_spectralFlow
    (t : ℝ) (ht : 0 ≤ t) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitKrausChannel t X = twoQubitSpectralFlow t X := by
  rw [twoQubitKrausChannel_eq_weighted t ht X,
      twoQubitWeightedKrausChannel_eq_spectralFlow t X]

/-- At `t = 0`, the 16-Kraus channel is the identity on all `X ∈ M₄(ℂ)`. -/
theorem twoQubitKrausChannel_zero
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitKrausChannel 0 X = X := by
  rw [twoQubitKrausChannel_eq_spectralFlow 0 (le_refl 0) X,
      twoQubitSpectralFlow_zero]

/-- Exact semigroup composition law `Φ_{t+s}(X) = Φ_t(Φ_s(X))` for the 16-Kraus channel
on `s, t ≥ 0` and any `X ∈ M₄(ℂ)`. -/
theorem twoQubitKrausChannel_semigroup
    (s t : ℝ) (hs : 0 ≤ s) (ht : 0 ≤ t)
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitKrausChannel (t + s) X =
      twoQubitKrausChannel t (twoQubitKrausChannel s X) := by
  rw [twoQubitKrausChannel_eq_spectralFlow (t + s) (add_nonneg ht hs) X,
      twoQubitKrausChannel_eq_spectralFlow s hs X,
      twoQubitKrausChannel_eq_spectralFlow t ht (twoQubitSpectralFlow s X),
      twoQubitSpectralFlow_semigroup s t X]

/-!
## Arbitrary-Input GKSL Master Equation and ODE Uniqueness
-/

/-- Linearity of `dissipatorSchrodinger L` over finite sums. -/
theorem dissipatorSchrodinger_sum
    {n ι : Type*} [Fintype n] [DecidableEq n]
    (L : Matrix n n ℂ) (s : Finset ι) (f : ι → Matrix n n ℂ) :
    dissipatorSchrodinger L (∑ q ∈ s, f q) =
      ∑ q ∈ s, dissipatorSchrodinger L (f q) := by
  unfold dissipatorSchrodinger
  simp only [Matrix.mul_sum, Matrix.sum_mul, ← Finset.sum_add_distrib,
    Finset.smul_sum, ← Finset.sum_sub_distrib]

/-- Linearity of `dissipatorSchrodinger L` with respect to complex scalar multiplication. -/
theorem dissipatorSchrodinger_smul
    {n : Type*} [Fintype n] [DecidableEq n]
    (L : Matrix n n ℂ) (c : ℂ) (X : Matrix n n ℂ) :
    dissipatorSchrodinger L (c • X) = c • dissipatorSchrodinger L X := by
  unfold dissipatorSchrodinger
  rw [Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_smul, Matrix.smul_mul,
      ← smul_add, smul_comm (1 / 2 : ℂ) c, smul_sub]

/-- Linearity of `fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate` over finite sums. -/
theorem twoQubit_fullGKSLSchrodinger_sum
    {ι : Type*} (s : Finset ι)
    (f : ι → Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (∑ q ∈ s, f q) =
      ∑ q ∈ s, fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (f q) := by
  unfold fullGKSLSchrodinger twoQubitH
  simp only [Matrix.zero_mul, Matrix.mul_zero, sub_self, smul_zero, zero_add,
    dissipatorSchrodinger_sum, Finset.smul_sum]
  exact Finset.sum_comm

/-- Linearity of `fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate` with respect to
complex scalar multiplication. -/
theorem twoQubit_fullGKSLSchrodinger_smul
    (c : ℂ) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (c • X) =
      c • fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate X := by
  unfold fullGKSLSchrodinger twoQubitH
  simp only [Matrix.zero_mul, Matrix.mul_zero, sub_self, smul_zero, zero_add,
    dissipatorSchrodinger_smul, Finset.smul_sum]
  refine Finset.sum_congr rfl fun a _ => smul_comm _ c _

/-- Exact entrywise GKSL master equation for `twoQubitSpectralFlow` on ANY `4 × 4` complex matrix `X`
(including coherent and entangled states) at every `t ∈ ℝ`:
`d/dt (twoQubitSpectralFlow t X)_{i,j} = (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (twoQubitSpectralFlow t X))_{i,j}`. -/
theorem twoQubitSpectralFlow_hasDerivAt_GKSL
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ)
    (i j : TwoQubitIndex) :
    HasDerivAt (fun s : ℝ => twoQubitSpectralFlow s X i j)
      (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (twoQubitSpectralFlow t X) i j) t := by
  have hterm :
      ∀ p : Fin 4 × Fin 4,
        HasDerivAt
          (fun s : ℝ =>
            ((Real.exp (twoQubitEigenvalue p * s) : ℂ) *
              Matrix.trace (twoQubitDualMatrix p * X)) *
              twoQubitEigenMatrix p i j)
          (((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
              Matrix.trace (twoQubitDualMatrix p * X)) *
            ((twoQubitEigenvalue p : ℂ) * twoQubitEigenMatrix p i j)) t := by
    intro p
    have hlin : HasDerivAt (fun s : ℝ => twoQubitEigenvalue p * s)
        (twoQubitEigenvalue p) t := by
      simpa using (hasDerivAt_id t).const_mul (twoQubitEigenvalue p)
    have hexp : HasDerivAt (fun s : ℝ => Real.exp (twoQubitEigenvalue p * s))
        (Real.exp (twoQubitEigenvalue p * t) * twoQubitEigenvalue p) t :=
      (Real.hasDerivAt_exp _).comp t hlin
    have hcexp : HasDerivAt (fun s : ℝ => (Real.exp (twoQubitEigenvalue p * s) : ℂ))
        (((Real.exp (twoQubitEigenvalue p * t) * twoQubitEigenvalue p : ℝ) : ℂ)) t := by
      simpa using hexp.ofReal_comp
    have hmul := (hcexp.mul_const (Matrix.trace (twoQubitDualMatrix p * X))).mul_const
      (twoQubitEigenMatrix p i j)
    convert hmul using 1
    push_cast
    ring
  have hsum := HasDerivAt.sum (u := Finset.univ) (fun p _ => hterm p)
  have hfun :
      (fun s : ℝ => twoQubitSpectralFlow s X i j) =
        (fun s : ℝ =>
          ∑ p : Fin 4 × Fin 4,
            ((Real.exp (twoQubitEigenvalue p * s) : ℂ) *
              Matrix.trace (twoQubitDualMatrix p * X)) *
              twoQubitEigenMatrix p i j) := by
    ext s
    simp only [twoQubitSpectralFlow, Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul]
  rw [hfun]
  have hrhs :
      fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
          (twoQubitSpectralFlow t X) i j =
        ∑ p : Fin 4 × Fin 4,
          (((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
              Matrix.trace (twoQubitDualMatrix p * X)) *
            ((twoQubitEigenvalue p : ℂ) * twoQubitEigenMatrix p i j)) := by
    unfold twoQubitSpectralFlow
    rw [twoQubit_fullGKSLSchrodinger_sum]
    simp only [Matrix.sum_apply]
    refine Finset.sum_congr rfl fun p _ => ?_
    rw [twoQubit_fullGKSLSchrodinger_smul, twoQubit_fullGKSLSchrodinger_eigenMatrix]
    simp only [Matrix.smul_apply, smul_eq_mul]
  rw [hrhs]
  exact hsum

/-- Matrix-level derivative identity for `twoQubitSpectralFlow` on any `X ∈ M₄(ℂ)`. -/
theorem twoQubitSpectralFlow_matrix_deriv_eq_GKSL
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) :
    Matrix.of (fun i j => deriv (fun s : ℝ => twoQubitSpectralFlow s X i j) t) =
      fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (twoQubitSpectralFlow t X) := by
  ext i j
  exact (twoQubitSpectralFlow_hasDerivAt_GKSL X t i j).deriv

/-- Exact entrywise GKSL master equation for `twoQubitWeightedKrausChannel` on any `X ∈ M₄(ℂ)`
at every `t ∈ ℝ`. -/
theorem twoQubitWeightedKrausChannel_hasDerivAt_GKSL
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ)
    (i j : TwoQubitIndex) :
    HasDerivAt (fun s : ℝ => twoQubitWeightedKrausChannel s X i j)
      (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (twoQubitWeightedKrausChannel t X) i j) t := by
  simp_rw [twoQubitWeightedKrausChannel_eq_spectralFlow]
  exact twoQubitSpectralFlow_hasDerivAt_GKSL X t i j

/-- Right-derivative (`HasDerivWithinAt` on `[0, ∞)`) of `twoQubitKrausChannel` for every `t ≥ 0`
and every `X ∈ M₄(ℂ)`. -/
theorem twoQubitKrausChannel_hasDerivWithinAt_GKSL
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) (ht : 0 ≤ t)
    (i j : TwoQubitIndex) :
    HasDerivWithinAt (fun s : ℝ => twoQubitKrausChannel s X i j)
      (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (twoQubitKrausChannel t X) i j) (Set.Ici 0) t := by
  rw [twoQubitKrausChannel_eq_spectralFlow t ht X]
  have hd := (twoQubitSpectralFlow_hasDerivAt_GKSL X t i j).hasDerivWithinAt (s := Set.Ici 0)
  refine hd.congr (fun s hs => ?_) (by rw [twoQubitKrausChannel_eq_spectralFlow t ht X])
  exact twoQubitKrausChannel_eq_spectralFlow s hs X ▸ rfl

/-- Full two-sided `HasDerivAt` of `twoQubitKrausChannel` for every `t > 0` and every `X ∈ M₄(ℂ)`. -/
theorem twoQubitKrausChannel_hasDerivAt_GKSL_of_pos
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) (ht : 0 < t)
    (i j : TwoQubitIndex) :
    HasDerivAt (fun s : ℝ => twoQubitKrausChannel s X i j)
      (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate
        (twoQubitKrausChannel t X) i j) t := by
  have hd := twoQubitKrausChannel_hasDerivWithinAt_GKSL X t (le_of_lt ht) i j
  exact hd.hasDerivAt (Ici_mem_nhds ht)

/-- Arbitrary-input matrix ODE uniqueness theorem:
For ANY initial matrix `X ∈ M₄(ℂ)` (with no positivity, trace, or vacuum assumption) and ANY path
`ρ : ℝ → M₄(ℂ)` satisfying `ρ 0 = X` and entrywise `HasDerivAt` with the four-channel GKSL
generator on `[0, ∞)`, `ρ t = twoQubitSpectralFlow t X = twoQubitKrausChannel t X` for all `t ≥ 0`. -/
theorem twoQubit_arbitrary_initial_ode_unique
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (ρ : ℝ → Matrix TwoQubitIndex TwoQubitIndex ℂ)
    (h0 : ρ 0 = X)
    (hderiv : ∀ s : ℝ, 0 ≤ s → ∀ i j : TwoQubitIndex,
      HasDerivAt (fun u => ρ u i j)
        (fullGKSLSchrodinger twoQubitH twoQubitJump twoQubitRate (ρ s) i j) s)
    (t : ℝ) (ht : 0 ≤ t) :
    ρ t = twoQubitSpectralFlow t X ∧ ρ t = twoQubitKrausChannel t X := by
  have hspec : ρ t = twoQubitSpectralFlow t X := by
    have hmode :
        ∀ q : Fin 4 × Fin 4,
          Matrix.trace (twoQubitDualMatrix q * ρ t) =
            Matrix.trace (twoQubitDualMatrix q * twoQubitSpectralFlow t X) := by
      intro q
      let z : ℝ → ℂ := fun u =>
        Matrix.trace (twoQubitDualMatrix q * ρ u) -
          Matrix.trace (twoQubitDualMatrix q * twoQubitSpectralFlow u X)
      have hz0 : z 0 = 0 := by
        dsimp [z]
        rw [h0, twoQubitSpectralFlow_zero, sub_self]
      have hz : ∀ s : ℝ, 0 ≤ s → HasDerivAt z ((twoQubitEigenvalue q : ℂ) * z s) s := by
        intro s hs
        have h1 :=
          fullGKSL_expectation_hasDerivAt twoQubitH twoQubitJump twoQubitRate
            (twoQubitDualMatrix q) ρ s (hderiv s hs)
        have h2 :=
          fullGKSL_expectation_hasDerivAt twoQubitH twoQubitJump twoQubitRate
            (twoQubitDualMatrix q) (fun u => twoQubitSpectralFlow u X) s
            (twoQubitSpectralFlow_hasDerivAt_GKSL X s)
        rw [twoQubit_heisenbergGenerator_dualMatrix q, Matrix.smul_mul,
            Matrix.trace_smul, smul_eq_mul] at h1 h2
        have hsub := h1.sub h2
        convert hsub using 1
        dsimp [z]
        ring
      have hzt := complex_linear_ode_zero_nonneg (twoQubitEigenvalue q) z hz (hz0) t ht
      exact sub_eq_zero.mp hzt
    rw [twoQubit_matrix_spectral_expansion (ρ t),
        twoQubit_matrix_spectral_expansion (twoQubitSpectralFlow t X)]
    refine Finset.sum_congr rfl fun q _ => ?_
    rw [hmode q]
  refine ⟨hspec, ?_⟩
  rw [hspec, ← twoQubitKrausChannel_eq_spectralFlow t ht X]

/-- Agreement of the arbitrary-input 16-Kraus channel and spectral flow with the previously
verified `twoQubitVacuumTrajectory` when evaluated at `X = twoQubitVacuum`:
`twoQubitKrausChannel t twoQubitVacuum = twoQubitSpectralFlow t twoQubitVacuum = twoQubitVacuumTrajectory t`
for all `t ≥ 0`. -/
theorem twoQubitKrausChannel_vacuum_eq_trajectory
    (t : ℝ) (ht : 0 ≤ t) :
    twoQubitKrausChannel t twoQubitVacuum = twoQubitVacuumTrajectory t ∧
    twoQubitSpectralFlow t twoQubitVacuum = twoQubitVacuumTrajectory t := by
  have huniq :=
    twoQubit_arbitrary_initial_ode_unique twoQubitVacuum twoQubitVacuumTrajectory
      twoQubitVacuumTrajectory_zero
      (fun s _ i j => twoQubitVacuumTrajectory_hasDerivAt_GKSL s i j)
      t ht
  exact ⟨huniq.2.symm, huniq.1.symm⟩

/-!
## P0c: Stationary Projection, Global Convergence for Arbitrary Inputs, and `29/99` Decay Bounds
-/

/-- Decomposition of `twoQubitSpectralFlow t X` into the stationary projection
`Tr(X) • twoQubitEquilibrium` and the 15 decaying nonstationary modes `p ≠ (0, 0)`. -/
theorem twoQubitSpectralFlow_sub_stationary_projection
    (t : ℝ) (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    twoQubitSpectralFlow t X - Matrix.trace X • twoQubitEquilibrium =
      ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
        ((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
          Matrix.trace (twoQubitDualMatrix p * X)) • twoQubitEigenMatrix p := by
  unfold twoQubitSpectralFlow
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ ((0 : Fin 4), (0 : Fin 4)))]
  simp only [twoQubitEigenvalue_zero_zero, zero_mul, Real.exp_zero, Complex.ofReal_one,
    one_mul, twoQubitDualMatrix_zero_zero, Matrix.one_mul, twoQubitEigenMatrix_zero_zero,
    add_sub_cancel_left]

/-- For every nonstationary mode `p ≠ (0, 0)`, `Real.exp (twoQubitEigenvalue p * t) → 0`
as `t → +∞`. -/
theorem twoQubit_nonstationary_mode_exp_tendsto_zero
    (p : Fin 4 × Fin 4) (hp : p ≠ ((0 : Fin 4), (0 : Fin 4))) :
    Tendsto (fun t : ℝ => Real.exp (twoQubitEigenvalue p * t)) atTop (nhds 0) := by
  have hgap := twoQubitEigenvalue_gap_bound p hp
  have hneg : twoQubitEigenvalue p < 0 := by linarith
  exact Real.tendsto_exp_atBot.comp
    (Filter.Tendsto.const_mul_atTop_of_neg hneg tendsto_id)

/-- Global convergence of `twoQubitSpectralFlow t X` to `Tr(X) • twoQubitEquilibrium`
as `t → +∞` for EVERY `4 × 4` complex matrix `X`. -/
theorem twoQubitSpectralFlow_tendsto_atTop
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Tendsto (fun t : ℝ => twoQubitSpectralFlow t X)
      atTop (nhds (Matrix.trace X • twoQubitEquilibrium)) := by
  rw [tendsto_pi_nhds]
  intro i
  rw [tendsto_pi_nhds]
  intro j
  have hdecomp :
      (fun t : ℝ => twoQubitSpectralFlow t X i j) =
        (fun t : ℝ =>
          (Matrix.trace X • twoQubitEquilibrium) i j +
            ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
              ((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
                Matrix.trace (twoQubitDualMatrix p * X)) *
                twoQubitEigenMatrix p i j) := by
    ext t
    have hsub := congr_fun (congr_fun (twoQubitSpectralFlow_sub_stationary_projection t X) i) j
    simp only [Matrix.sub_apply, Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul] at hsub ⊢
    linear_combination hsub
  rw [hdecomp]
  suffices hzero :
      Tendsto
        (fun t : ℝ =>
          ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
            ((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
              Matrix.trace (twoQubitDualMatrix p * X)) *
              twoQubitEigenMatrix p i j)
        atTop (nhds 0) by
    simpa using tendsto_const_nhds.add hzero
  have hsum0 :
      Tendsto
        (fun t : ℝ =>
          ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
            ((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
              Matrix.trace (twoQubitDualMatrix p * X)) *
              twoQubitEigenMatrix p i j)
        atTop (nhds (∑ _p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)), (0 : ℂ))) :=
    tendsto_finset_sum (Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)))
      fun p hp => by
        have hpne : p ≠ ((0 : Fin 4), (0 : Fin 4)) := (Finset.mem_erase.mp hp).1
        have hexp := twoQubit_nonstationary_mode_exp_tendsto_zero p hpne
        have hcexp : Tendsto (fun t : ℝ => (Real.exp (twoQubitEigenvalue p * t) : ℂ))
            atTop (nhds (0 : ℂ)) :=
          (Complex.continuous_ofReal.tendsto' 0 0 Complex.ofReal_zero).comp hexp
        have hterm := (hcexp.mul_const (Matrix.trace (twoQubitDualMatrix p * X))).mul_const
          (twoQubitEigenMatrix p i j)
        simpa only [zero_mul] using hterm
  simpa only [Finset.sum_const, nsmul_zero] using hsum0

/-- Global convergence of the 16-Kraus CPTP channel `twoQubitKrausChannel t X` to
`Tr(X) • twoQubitEquilibrium` as `t → +∞` for EVERY `4 × 4` complex matrix `X`. -/
theorem twoQubitKrausChannel_tendsto_atTop
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) :
    Tendsto (fun t : ℝ => twoQubitKrausChannel t X)
      atTop (nhds (Matrix.trace X • twoQubitEquilibrium)) := by
  refine (twoQubitSpectralFlow_tendsto_atTop X).congr' ?_
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
  exact (twoQubitKrausChannel_eq_spectralFlow t ht X).symm

/-- Global convergence of `twoQubitKrausChannel t X` to `twoQubitEquilibrium` as `t → +∞`
for EVERY trace-one `4 × 4` matrix `X` (including all initial density matrices with
coherences or entanglement). -/
theorem twoQubitKrausChannel_tendsto_equilibrium_of_trace_one
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (htr : Matrix.trace X = 1) :
    Tendsto (fun t : ℝ => twoQubitKrausChannel t X)
      atTop (nhds twoQubitEquilibrium) := by
  simpa [htr, one_smul] using twoQubitKrausChannel_tendsto_atTop X

/-!
## Quantitative Exponential Decay Bounds at Rate `29/99` and Mode-Weight Sum `24`
-/

/-- Local right-eigenmode trace-norm weights `(1, 1, 1, 2)`. -/
def localModeWeight : Fin 4 → ℝ
  | ⟨0, _⟩ => 1
  | ⟨1, _⟩ => 1
  | ⟨2, _⟩ => 1
  | ⟨3, _⟩ => 2

/-- Two-qubit product eigenmode weights `w_{(a,b)} = w_a * w_b`. -/
def twoQubitModeWeight (p : Fin 4 × Fin 4) : ℝ :=
  localModeWeight p.1 * localModeWeight p.2

/-- The sum of the 15 nonstationary two-qubit mode weights equals `24 = 5² - 1`. -/
theorem twoQubitModeWeight_sum_nonstationary :
    ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
      twoQubitModeWeight p = 24 := by
  have htot :
      (∑ p : Fin 4 × Fin 4, twoQubitModeWeight p) = 25 := by
    rw [Fintype.sum_prod_type]
    simp [Fin.sum_univ_four, twoQubitModeWeight, localModeWeight]
    norm_num
  have h0 : twoQubitModeWeight ((0 : Fin 4), (0 : Fin 4)) = 1 := by
    simp [twoQubitModeWeight, localModeWeight]
  have hadd := Finset.add_sum_erase Finset.univ twoQubitModeWeight
    (Finset.mem_univ ((0 : Fin 4), (0 : Fin 4)))
  linarith

/-- For every nonstationary mode `p ≠ (0, 0)` and every `t ≥ 0`,
`0 ≤ Real.exp (twoQubitEigenvalue p * t) ≤ Real.exp (-(29 / 99) * t)`. -/
theorem twoQubit_nonstationary_exp_le_gap
    (p : Fin 4 × Fin 4) (hp : p ≠ ((0 : Fin 4), (0 : Fin 4)))
    (t : ℝ) (ht : 0 ≤ t) :
    Real.exp (twoQubitEigenvalue p * t) ≤ Real.exp (-(29 / 99 : ℝ) * t) := by
  apply Real.exp_le_exp.mpr
  have hgap := twoQubitEigenvalue_gap_bound p hp
  have hle : twoQubitEigenvalue p ≤ -(29 / 99 : ℝ) := by linarith
  exact mul_le_mul_of_nonneg_right hle ht

/-- Quantitative entrywise exponential decay bound at rate `29/99` for arbitrary `X ∈ M₄(ℂ)`
and all `t ≥ 0`:
`‖(twoQubitKrausChannel t X - Tr(X) • twoQubitEquilibrium) i j‖ ≤ exp(-(29/99)*t) * ∑_{p ≠ (0,0)} ‖Tr(D_p * X)‖ * ‖E_p i j‖`. -/
theorem twoQubitKrausChannel_entrywise_decay_bound
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) (ht : 0 ≤ t)
    (i j : TwoQubitIndex) :
    ‖(twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium) i j‖ ≤
      Real.exp (-(29 / 99 : ℝ) * t) *
        ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
          ‖Matrix.trace (twoQubitDualMatrix p * X)‖ * ‖twoQubitEigenMatrix p i j‖ := by
  rw [twoQubitKrausChannel_eq_spectralFlow t ht X,
      twoQubitSpectralFlow_sub_stationary_projection t X]
  simp only [Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul]
  calc
    ‖∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
        (Real.exp (twoQubitEigenvalue p * t) : ℂ) *
          Matrix.trace (twoQubitDualMatrix p * X) * twoQubitEigenMatrix p i j‖
      ≤ ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
          ‖(Real.exp (twoQubitEigenvalue p * t) : ℂ) *
            Matrix.trace (twoQubitDualMatrix p * X) * twoQubitEigenMatrix p i j‖ :=
        norm_sum_le _ _
    _ ≤ ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
          Real.exp (-(29 / 99 : ℝ) * t) *
            (‖Matrix.trace (twoQubitDualMatrix p * X)‖ * ‖twoQubitEigenMatrix p i j‖) := by
        refine Finset.sum_le_sum fun p hp => ?_
        have hpne : p ≠ ((0 : Fin 4), (0 : Fin 4)) := (Finset.mem_erase.mp hp).1
        rw [norm_mul, norm_mul, Complex.norm_real,
            Real.norm_of_nonneg (le_of_lt (Real.exp_pos _)), mul_assoc]
        exact mul_le_mul_of_nonneg_right
          (twoQubit_nonstationary_exp_le_gap p hpne t ht)
          (mul_nonneg (norm_nonneg _) (norm_nonneg _))
    _ = Real.exp (-(29 / 99 : ℝ) * t) *
          ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
            ‖Matrix.trace (twoQubitDualMatrix p * X)‖ * ‖twoQubitEigenMatrix p i j‖ := by
        rw [← Finset.mul_sum]

/-- Conditional Schatten-1 trace-norm decay theorem with explicit prefactor `24` and rate `29/99`:
Given any matrix seminorm `N1 : Matrix TwoQubitIndex TwoQubitIndex ℂ → ℝ` satisfying nonnegativity,
subadditivity over finite sums, complex scalar homogeneity, the eigenmatrix norm bounds
`N1 (twoQubitEigenMatrix p) ≤ twoQubitModeWeight p`, and the dual trace Hölder bound
`‖Matrix.trace (twoQubitDualMatrix p * X)‖ ≤ N1 X` for all `p ≠ (0, 0)`,
`N1 (twoQubitKrausChannel t X - Tr(X) • twoQubitEquilibrium) ≤ 24 * exp(-(29/99)*t) * N1 X`
for all `t ≥ 0` and all `X ∈ M₄(ℂ)`. -/
theorem twoQubit_abstract_schatten1_decay_24
    (N1 : Matrix TwoQubitIndex TwoQubitIndex ℂ → ℝ)
    (hN1_nonneg : ∀ A, 0 ≤ N1 A)
    (hN1_sum : ∀ (s : Finset (Fin 4 × Fin 4))
      (f : (Fin 4 × Fin 4) → Matrix TwoQubitIndex TwoQubitIndex ℂ),
      N1 (∑ p ∈ s, f p) ≤ ∑ p ∈ s, N1 (f p))
    (hN1_smul : ∀ (c : ℂ) (A : Matrix TwoQubitIndex TwoQubitIndex ℂ),
      N1 (c • A) = ‖c‖ * N1 A)
    (hN1_eigen : ∀ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
      N1 (twoQubitEigenMatrix p) ≤ twoQubitModeWeight p)
    (hN1_holder : ∀ (X : Matrix TwoQubitIndex TwoQubitIndex ℂ)
      (p : Fin 4 × Fin 4), p ≠ ((0 : Fin 4), (0 : Fin 4)) →
      ‖Matrix.trace (twoQubitDualMatrix p * X)‖ ≤ N1 X)
    (X : Matrix TwoQubitIndex TwoQubitIndex ℂ) (t : ℝ) (ht : 0 ≤ t) :
    N1 (twoQubitKrausChannel t X - Matrix.trace X • twoQubitEquilibrium) ≤
      24 * Real.exp (-(29 / 99 : ℝ) * t) * N1 X := by
  have hX_nonneg : 0 ≤ N1 X := hN1_nonneg X
  rw [twoQubitKrausChannel_eq_spectralFlow t ht X,
      twoQubitSpectralFlow_sub_stationary_projection t X]
  calc
    N1 (∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
        ((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
          Matrix.trace (twoQubitDualMatrix p * X)) • twoQubitEigenMatrix p)
      ≤ ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
          N1 (((Real.exp (twoQubitEigenvalue p * t) : ℂ) *
            Matrix.trace (twoQubitDualMatrix p * X)) • twoQubitEigenMatrix p) :=
        hN1_sum _ _
    _ ≤ ∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)),
          twoQubitModeWeight p * (Real.exp (-(29 / 99 : ℝ) * t) * N1 X) := by
        refine Finset.sum_le_sum fun p hp => ?_
        have hpne : p ≠ ((0 : Fin 4), (0 : Fin 4)) := (Finset.mem_erase.mp hp).1
        rw [hN1_smul, norm_mul, Complex.norm_real,
            Real.norm_of_nonneg (le_of_lt (Real.exp_pos _))]
        have hexp := twoQubit_nonstationary_exp_le_gap p hpne t ht
        have htr := hN1_holder X p hpne
        have heig := hN1_eigen p hp
        have hprod1 :
            Real.exp (twoQubitEigenvalue p * t) * ‖Matrix.trace (twoQubitDualMatrix p * X)‖ ≤
              Real.exp (-(29 / 99 : ℝ) * t) * N1 X :=
          mul_le_mul hexp htr (norm_nonneg _) (le_of_lt (Real.exp_pos _))
        have hprod2 :
            (Real.exp (twoQubitEigenvalue p * t) * ‖Matrix.trace (twoQubitDualMatrix p * X)‖) *
              N1 (twoQubitEigenMatrix p) ≤
            (Real.exp (-(29 / 99 : ℝ) * t) * N1 X) * twoQubitModeWeight p :=
          mul_le_mul hprod1 heig (hN1_nonneg _)
            (mul_nonneg (le_of_lt (Real.exp_pos _)) hX_nonneg)
        linarith
    _ = (∑ p ∈ Finset.univ.erase ((0 : Fin 4), (0 : Fin 4)), twoQubitModeWeight p) *
          (Real.exp (-(29 / 99 : ℝ) * t) * N1 X) := by
        rw [← Finset.sum_mul]
    _ = 24 * Real.exp (-(29 / 99 : ℝ) * t) * N1 X := by
        rw [twoQubitModeWeight_sum_nonstationary]
        ring

end BinduEventInterface
