import BinduEventInterface.Adjoint

/-!
# Conditional tensor-local GKSL identity, candidate pending Lean compilation.

This file deliberately does NOT assert that an arbitrary JSON clause has the
commutation properties supplied as hypotheses.  Its claims are genuinely about
arbitrary finite-dimensional matrices, including tensor-embedded operators.
The missing step for a fully kernel-certified physical model is proving these
hypotheses for the concrete embedding and formalizing the continuous ODE.
No `sorry` / `admit` / new axioms are introduced here.
-/

namespace BinduEventInterface
open Matrix

/-- If R commutes with a jump L and its adjoint, the GKSL dissipator of Q*R
    factors on the right. This is valid for arbitrary finite matrix dimensions. -/
theorem dissipator_right_factor
    {n : Type*} [Fintype n] [DecidableEq n]
    (L Q R : Matrix n n ℂ)
    (hL : R * L = L * R)
    (hLa : R * L.conjTranspose = L.conjTranspose * R) :
    dissipatorAdjoint L (Q * R) = (dissipatorAdjoint L Q) * R := by
  have hc : R * (L.conjTranspose * L) = (L.conjTranspose * L) * R := by
    calc
      R * (L.conjTranspose * L) = (R * L.conjTranspose) * L := by rw [← mul_assoc]
      _ = (L.conjTranspose * R) * L := by rw [hLa]
      _ = L.conjTranspose * (R * L) := by rw [mul_assoc]
      _ = L.conjTranspose * (L * R) := by rw [hL]
      _ = (L.conjTranspose * L) * R := by rw [← mul_assoc]
  have hfirst : L.conjTranspose * (Q * R) * L = (L.conjTranspose * Q * L) * R := by
    calc
      L.conjTranspose * (Q * R) * L = (L.conjTranspose * Q) * (R * L) := by simp only [mul_assoc]
      _ = (L.conjTranspose * Q) * (L * R) := by rw [hL]
      _ = (L.conjTranspose * Q * L) * R := by simp only [mul_assoc]
  have hsecond : (L.conjTranspose * L) * (Q * R) = ((L.conjTranspose * L) * Q) * R := by
    simp only [mul_assoc]
  have hthird : (Q * R) * (L.conjTranspose * L) = (Q * (L.conjTranspose * L)) * R := by
    calc
      (Q * R) * (L.conjTranspose * L) = Q * (R * (L.conjTranspose * L)) := by rw [mul_assoc]
      _ = Q * ((L.conjTranspose * L) * R) := by rw [hc]
      _ = (Q * (L.conjTranspose * L)) * R := by rw [← mul_assoc]
  unfold dissipatorAdjoint
  simp only [mul_assoc, hL, hc, add_mul, sub_mul, smul_mul_assoc]

/-- A pump identity on a site occupation n extends to the joint event n*R,
    if its local raising operator leaves the remainder R untouched. -/
theorem embedded_pump_event
    {n : Type*} [Fintype n] [DecidableEq n]
    (P N R : Matrix n n ℂ)
    (hP : dissipatorAdjoint P N = 1 - N)
    (hR : R * P = P * R)
    (hRa : R * P.conjTranspose = P.conjTranspose * R) :
    dissipatorAdjoint P (N * R) = (1 - N) * R := by
  rw [dissipator_right_factor P N R hR hRa, hP]

/-- Loss on a site occupation n extends to the joint occupation n*R. -/
theorem embedded_loss_event
    {n : Type*} [Fintype n] [DecidableEq n]
    (D N R : Matrix n n ℂ)
    (hD : dissipatorAdjoint D N = -N)
    (hR : R * D = D * R)
    (hRa : R * D.conjTranspose = D.conjTranspose * R) :
    dissipatorAdjoint D (N * R) = (-N) * R := by
  rw [dissipator_right_factor D N R hR hRa, hD]

end BinduEventInterface
