import Mathlib.Tactic
import BinduEventInterface.TwoQubitCPTPSemigroupCandidate
import BinduEventInterface.NQubitDiamondExponentialMixingCandidate
import BinduEventInterface.FiniteKrausTraceCandidate
import Mathlib
import BinduEventInterface.CPTPDiamondContractivity
import BinduEventInterface.SchattenOneDecomposition
import BinduEventInterface.KrausEnergyBridge




/-!
# BINDU GAD: square-root-free auxiliary channel certificate

Original physics and p-convention are those of
`BinduEventInterface.gadClosedChannel`.

The weighted shapes form a CP numerator of weight `s`, not yet a
**normalized** Kraus family. This module proves the non-tautological
matrix identities required for the later normalized CPTP construction.

No sorry/admit/axiom, no definition of a diamond norm by its target.
The file must be compiled on the user's Lean 4.19/Mathlib installation.
-/

namespace BinduGADAuxWeighted

open BinduEventInterface Matrix
open scoped BigOperators Matrix

private def h (r : ℝ) : ℝ := 2-r
private def s (p r : ℝ) : ℝ := 1-p*(1-p)*r^2
private def u (p r : ℝ) : ℝ := 1-p*r
private def v (p r : ℝ) : ℝ := 1-(1-p)*r

/-- Physical auxiliary shapes, *before* square-root normalization. -/
noncomputable def auxShape (p r : ℝ) : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ
  | 0 => !![(u p r : ℂ), 0; 0, -((v p r : ℝ) : ℂ)]
  | 1 => raising
  | 2 => lowering

/-- Unnormalized nonnegative auxiliary Kraus weights. -/
noncomputable def auxWeight (p r : ℝ) : Fin 3 → ℝ
  | 0 => 1
  | 1 => p*r*h r
  | 2 => (1-p)*r*h r

/-- The weights are nonnegative on the physical parameter cube. -/
theorem auxWeight_nonneg (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (j : Fin 3) : 0 ≤ auxWeight p r j := by
  have hh : 0 ≤ h r := by dsimp [h]; linarith [hr.2]
  fin_cases j
  · simp [auxWeight]
  · simpa only [auxWeight] using
      (mul_nonneg (mul_nonneg hp.1 hr.1) hh)
  · simpa only [auxWeight] using
      (mul_nonneg (mul_nonneg (by linarith [hp.2] : 0 ≤ 1-p) hr.1) hh)

/-- The exact *scaled* Kraus completeness identity, with no square roots. -/
theorem auxiliary_weighted_completeness_scaled (p r : ℝ) :
    ∑ j : Fin 3, ((auxWeight p r j : ℝ) : ℂ) •
       ((auxShape p r j)ᴴ * auxShape p r j) =
      ((s p r : ℝ) : ℂ) • (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Fin.sum_univ_three, auxShape, auxWeight, s, h, u, v,
      Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply,
      Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply, raising, lowering,
      Complex.conj_ofReal, Complex.ofReal_sub,
      Complex.ofReal_mul, Complex.ofReal_pow] <;> ring

/-- Genuine weighted auxiliary numerator (not yet normalized CPTP). -/
noncomputable def auxWeightedChannel (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) : Matrix (Fin 2) (Fin 2) ℂ :=
  ∑ j : Fin 3, (auxWeight p r j : ℂ) •
    (auxShape p r j * M * (auxShape p r j)ᴴ)

/-- An exact component formula valid for *every complex matrix*. -/
theorem auxWeightedChannel_eq_numerator (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    auxWeightedChannel p r M =
      !![(((u p r)^2 : ℝ) : ℂ) * M 0 0 + (((1-p)*r*h r : ℝ) : ℂ) * M 1 1,
          -((u p r*v p r : ℝ) : ℂ)*M 0 1;
         -((u p r*v p r : ℝ) : ℂ)*M 1 0,
          (((v p r)^2 : ℝ) : ℂ) * M 1 1 + ((p*r*h r : ℝ) : ℂ) * M 0 0] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Fin.sum_univ_three, auxWeightedChannel, auxShape, auxWeight,
      h, s, u, v, Matrix.mul_apply, Fin.sum_univ_two,
      Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply, raising, lowering,
      Complex.conj_ofReal, Complex.ofReal_sub,
      Complex.ofReal_mul, Complex.ofReal_pow,
      Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.vecMul, dotProduct] <;> ring

/-- Key real physical bridge: the actual GAD channel minus replacer
    is the scaled difference of identity and the auxiliary numerator.
    No hypotheses or circular definitions of channel norms are used. -/
theorem gadClosed_diff_via_auxWeighted (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    ((h r : ℝ) : ℂ) • (gadClosedChannel p r M - gadClosedChannel p 0 M) =
      ((r : ℝ) : ℂ) •
        (((s p r : ℝ) : ℂ) • M - auxWeightedChannel p r M) := by
  rw [auxWeightedChannel_eq_numerator]
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [gadClosedChannel, h, s, u, v,
      Matrix.smul_apply, Matrix.sub_apply,
      Matrix.cons_val_zero, Matrix.cons_val_one,
      Complex.ofReal_sub, Complex.ofReal_mul,
      Complex.ofReal_pow] <;> ring

#print axioms BinduGADAuxWeighted.auxWeight_nonneg
#print axioms BinduGADAuxWeighted.auxiliary_weighted_completeness_scaled
#print axioms BinduGADAuxWeighted.auxWeightedChannel_eq_numerator
#print axioms BinduGADAuxWeighted.gadClosed_diff_via_auxWeighted

end BinduGADAuxWeighted


/-!
# A non-circular arbitrary finite ancilla bridge for the physical GAD difference

Target: a pointwise equality on every complex entry of the true BINDU
`ancillaRightChannel (gadKraus p r) - ancillaRightChannel (gadKraus p 0)`.
No arbitrary diamond norm is defined by its hoped-for value.
This file is an independent Lean compilation candidate, not yet certified.
-/

namespace BinduGADAuxAncilla

open BinduEventInterface Matrix

private def h (r : ℝ) : ℝ := 2-r
private def s (p r : ℝ) : ℝ := 1-p*(1-p)*r^2
private def u (p r : ℝ) : ℝ := 1-p*r
private def v (p r : ℝ) : ℝ := 1-(1-p)*r

/-- Unnormalized three-branch auxiliary map, evaluated on 2x2 slices. -/
noncomputable def numerator (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) : Matrix (Fin 2) (Fin 2) ℂ :=
  !![((((u p r)^2 : ℝ) : ℂ))*M 0 0 + (((1-p)*r*h r : ℝ) : ℂ)*M 1 1,
      -((u p r*v p r : ℝ) : ℂ)*M 0 1;
     -((u p r*v p r : ℝ) : ℂ)*M 1 0,
      ((((v p r)^2 : ℝ) : ℂ))*M 1 1 + ((p*r*h r : ℝ) : ℂ)*M 0 0]

/-- The numerator map on the system + arbitrary finite ancilla, defined
    by its explicit action on each 2x2 system slice. -/
noncomputable def numeratorAncilla {a : Type*} [Fintype a]
    (p r : ℝ) (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    Matrix (Fin 2 × a) (Fin 2 × a) ℂ :=
  fun (i, α) (j, β) =>
    numerator p r (Matrix.of fun k l => X (k, α) (l, β)) i j

/-- Explicit physical matrix identity, valid for all complex 2x2 matrices.
    This is not just an identity on density operators. -/
theorem closed_scaled_difference (p r : ℝ)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    ((h r : ℝ) : ℂ) • (gadClosedChannel p r M - gadClosedChannel p 0 M) =
      ((r : ℝ) : ℂ) •
        (((s p r : ℝ) : ℂ) • M - numerator p r M) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [numerator, gadClosedChannel, h, s, u, v,
      Matrix.smul_apply, Matrix.sub_apply,
      Matrix.cons_val_zero, Matrix.cons_val_one,
      Complex.ofReal_sub, Complex.ofReal_mul, Complex.ofReal_pow] <;> ring

/-- This extends the true GAD Kraus-channel difference by identity to EVERY
    finite ancilla, with exact *unnormalized* auxiliary map on each slice. -/
theorem physical_ancilla_scaled_difference
    {a : Type*} [Fintype a] [DecidableEq a]
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    ((h r : ℝ) : ℂ) •
      (ancillaRightChannel (gadKraus p r) X -
        ancillaRightChannel (gadKraus p 0) X) =
      ((r : ℝ) : ℂ) •
        (((s p r : ℝ) : ℂ) • X - numeratorAncilla p r X) := by
  ext ⟨i, α⟩ ⟨j, β⟩
  let M : Matrix (Fin 2) (Fin 2) ℂ :=
    Matrix.of fun k l => X (k, α) (l, β)
  have hz : (0 ≤ (0 : ℝ)) ∧ (0 : ℝ) ≤ 1 := by constructor <;> norm_num
  have hA : ancillaRightChannel (gadKraus p r) X (i,α) (j,β) =
      gadClosedChannel p r M i j := by
    rw [ancillaRightChannel_apply (gadKraus p r)]
    exact congrArg (fun T : Matrix (Fin 2) (Fin 2) ℂ => T i j)
      (finiteKrausChannel_gadKraus_eq_closed p r hp hr M)
  have hB : ancillaRightChannel (gadKraus p 0) X (i,α) (j,β) =
      gadClosedChannel p 0 M i j := by
    rw [ancillaRightChannel_apply (gadKraus p 0)]
    exact congrArg (fun T : Matrix (Fin 2) (Fin 2) ℂ => T i j)
      (finiteKrausChannel_gadKraus_eq_closed p 0 hp hz M)
  have hC := congrArg (fun T : Matrix (Fin 2) (Fin 2) ℂ => T i j)
      (closed_scaled_difference p r M)
  simpa only [Matrix.smul_apply, Matrix.sub_apply,
    numeratorAncilla, Matrix.of_apply, hA, hB, M] using hC

#print axioms BinduGADAuxAncilla.closed_scaled_difference
#print axioms BinduGADAuxAncilla.physical_ancilla_scaled_difference

end BinduGADAuxAncilla


/-!
# Auxiliary GAD Kraus normalization: research Lean candidate

This is deliberately a separate standalone file from the weighted and
arbitrary-ancilla stages. The weights/square roots are real and physical;
all 3 Kraus operators are genuine complex 2x2 matrices.

No theorem here claims the full diamond norm. Must be compiled on Mac.
-/

namespace BinduGADAuxCPTP

open BinduEventInterface Matrix
open scoped Matrix BigOperators

private def h (r : ℝ) : ℝ := 2-r
private def s (p r : ℝ) : ℝ := 1-p*(1-p)*r^2
private def u (p r : ℝ) : ℝ := 1-p*r
private def v (p r : ℝ) : ℝ := 1-(1-p)*r

private theorem s_pos (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    0 < s p r := by
  have hpq : p*(1-p) ≤ (1/4:ℝ) := by
    nlinarith [sq_nonneg (p-(1/2:ℝ))]
  have hrr : r^2 ≤ 1 := by
    nlinarith [mul_nonneg (by linarith [hr.2] : 0 ≤ 1-r)
      (by linarith [hr.1] : 0 ≤ 1+r)]
  have hpqr : p*(1-p)*r^2 ≤ 1/4 := by
    calc
      p*(1-p)*r^2 ≤ (1/4:ℝ)*r^2 :=
        mul_le_mul_of_nonneg_right hpq (sq_nonneg r)
      _ ≤ (1/4:ℝ)*1 :=
        mul_le_mul_of_nonneg_left hrr (by norm_num)
      _ = 1/4 := by ring
  dsimp [s]
  linarith

/-- Three unnormalized Kraus shapes. -/
noncomputable def auxShape (p r : ℝ) : Fin 3 → Matrix (Fin 2) (Fin 2) ℂ
  | 0 => !![(u p r : ℂ), 0; 0, -((v p r : ℝ) : ℂ)]
  | 1 => raising
  | 2 => lowering

/-- Three unnormalized weights. -/
noncomputable def auxWeight (p r : ℝ) : Fin 3 → ℝ
  | 0 => 1
  | 1 => p*r*h r
  | 2 => (1-p)*r*h r

theorem auxWeight_nonneg (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (j : Fin 3) : 0 ≤ auxWeight p r j := by
  have hh : 0 ≤ h r := by dsimp [h]; linarith [hr.2]
  fin_cases j
  · simp [auxWeight]
  · simpa only [auxWeight] using (mul_nonneg (mul_nonneg hp.1 hr.1) hh)
  · simpa only [auxWeight] using
      (mul_nonneg (mul_nonneg (by linarith [hp.2] : 0 ≤ 1-p) hr.1) hh)

/-- Algebraic weighted completeness before taking square roots. -/
theorem scaled_weighted_completeness (p r : ℝ) :
    ∑ j : Fin 3, ((auxWeight p r j : ℝ) : ℂ) •
       ((auxShape p r j)ᴴ * auxShape p r j) =
      ((s p r : ℝ) : ℂ) • (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [Fin.sum_univ_three, auxShape, auxWeight, s, h, u, v,
      Matrix.mul_apply, Fin.sum_univ_two, Matrix.one_apply,
      Matrix.conjTranspose_apply, Matrix.transpose_apply,
      Matrix.smul_apply, raising, lowering,
      Complex.conj_ofReal, Complex.ofReal_sub,
      Complex.ofReal_mul, Complex.ofReal_pow] <;> ring

/-- The exact normalized Kraus family for the auxiliary CPTP channel. -/
noncomputable def normalizedKraus (p r : ℝ) (j : Fin 3) :
    Matrix (Fin 2) (Fin 2) ℂ :=
  ((Real.sqrt (auxWeight p r j / s p r) : ℝ) : ℂ) • auxShape p r j

/-- Each normalized effect equals the scaled weighted shape effect. -/
theorem normalizedKraus_effect (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (j : Fin 3) :
    (normalizedKraus p r j)ᴴ * normalizedKraus p r j =
      (((auxWeight p r j / s p r : ℝ) : ℂ)) •
        ((auxShape p r j)ᴴ * auxShape p r j) := by
  have hw : 0 ≤ auxWeight p r j / s p r :=
    div_nonneg (auxWeight_nonneg p r hp hr j) (le_of_lt (s_pos p r hp hr))
  unfold normalizedKraus
  rw [Matrix.conjTranspose_smul, Complex.star_def, Complex.conj_ofReal,
      Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  congr 1
  norm_cast
  exact Real.mul_self_sqrt hw

/-- Genuine trace-preservation certificate for the three normalized Kraus
    operators. This is the next substantive Lean gate after the weighted proof. -/
theorem normalizedKraus_completeness (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    ∑ j : Fin 3, (normalizedKraus p r j)ᴴ * normalizedKraus p r j =
      (1 : Matrix (Fin 2) (Fin 2) ℂ) := by
  simp_rw [normalizedKraus_effect p r hp hr]
  have hs : (s p r : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (s_pos p r hp hr))
  have hn :
      (∑ j : Fin 3, (((auxWeight p r j / s p r : ℝ) : ℂ)) •
        ((auxShape p r j)ᴴ * auxShape p r j)) =
      (((s p r : ℝ) : ℂ)⁻¹) •
        (∑ j : Fin 3, ((auxWeight p r j : ℝ) : ℂ) •
          ((auxShape p r j)ᴴ * auxShape p r j)) := by
    rw [Finset.smul_sum]
    apply Finset.sum_congr rfl
    intro j _
    have hcoeff :
        ((auxWeight p r j / s p r : ℝ) : ℂ) =
          (((s p r : ℝ) : ℂ)⁻¹) * ((auxWeight p r j : ℝ) : ℂ) := by
      rw [Complex.ofReal_div]
      ring
    rw [hcoeff, smul_smul]
  rw [hn, scaled_weighted_completeness]
  rw [smul_smul]
  simp [hs]

/-- Auxiliary physical Kraus sandwich equals weighted shape sandwich. -/
theorem normalizedKraus_sandwich (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (M : Matrix (Fin 2) (Fin 2) ℂ) (j : Fin 3) :
    normalizedKraus p r j * M * (normalizedKraus p r j)ᴴ =
      (((auxWeight p r j / s p r : ℝ) : ℂ)) •
        (auxShape p r j * M * (auxShape p r j)ᴴ) := by
  have hw : 0 ≤ auxWeight p r j / s p r :=
    div_nonneg (auxWeight_nonneg p r hp hr j) (le_of_lt (s_pos p r hp hr))
  unfold normalizedKraus
  rw [Matrix.conjTranspose_smul, Complex.star_def, Complex.conj_ofReal,
      Matrix.smul_mul, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  congr 1
  norm_cast
  exact Real.mul_self_sqrt hw

/-- Genuine Kraus action is the weighted auxiliary numerator / s.
    No physical identity or diamond-norm circularity is hidden here. -/
theorem normalizedKraus_channel_eq_weighted (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    finiteKrausChannel (normalizedKraus p r) M =
      (((s p r : ℝ) : ℂ)⁻¹) •
      (∑ j : Fin 3, (auxWeight p r j : ℂ) •
        (auxShape p r j * M * (auxShape p r j)ᴴ)) := by
  unfold finiteKrausChannel
  simp_rw [normalizedKraus_sandwich p r hp hr M]
  rw [Finset.smul_sum]
  apply Finset.sum_congr rfl
  intro j _
  have hcoeff :
      ((auxWeight p r j / s p r : ℝ) : ℂ) =
        (((s p r : ℝ) : ℂ)⁻¹) * ((auxWeight p r j : ℝ) : ℂ) := by
    rw [Complex.ofReal_div]
    ring
  rw [hcoeff, smul_smul]

#print axioms BinduGADAuxCPTP.auxWeight_nonneg
#print axioms BinduGADAuxCPTP.scaled_weighted_completeness
#print axioms BinduGADAuxCPTP.normalizedKraus_effect
#print axioms BinduGADAuxCPTP.normalizedKraus_completeness
#print axioms BinduGADAuxCPTP.normalizedKraus_sandwich
#print axioms BinduGADAuxCPTP.normalizedKraus_channel_eq_weighted

end BinduGADAuxCPTP


/-!
The sources above are the exact original Lean modules independently verified
on the user's Mac with standard axioms. This NEW section is experimental.
-/
namespace BinduGADAuxCPTP

/-- A genuinely normalized CPTP channel, scaled back by s, equals the
unnormalized explicit auxiliary numerator for every complex 2x2 matrix. -/
theorem normalized_channel_scaled_eq_numerator (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (M : Matrix (Fin 2) (Fin 2) ℂ) :
    ((s p r : ℝ) : ℂ) •
        BinduEventInterface.finiteKrausChannel (normalizedKraus p r) M =
      BinduGADAuxAncilla.numerator p r M := by
  have hs : ((s p r : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (s_pos p r hp hr))
  have hw := normalizedKraus_channel_eq_weighted p r hp hr M
  rw [hw]
  rw [smul_smul]
  rw [mul_inv_cancel₀ hs, one_smul]
  change BinduGADAuxWeighted.auxWeightedChannel p r M =
    BinduGADAuxAncilla.numerator p r M
  exact BinduGADAuxWeighted.auxWeightedChannel_eq_numerator p r M

#print axioms BinduGADAuxCPTP.normalized_channel_scaled_eq_numerator
end BinduGADAuxCPTP

namespace BinduGADUpperBridge
open BinduEventInterface Matrix

/-- The normalized three-operator CPTP channel has exactly the auxiliary
numerator action on any complex matrix and any finite ancillary dimension. -/
theorem normalized_auxiliary_ancilla_scaled_eq_numerator
    {a : Type*} [Fintype a] [DecidableEq a]
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    (((1-p*(1-p)*r^2 : ℝ) : ℂ)) •
       ancillaRightChannel (BinduGADAuxCPTP.normalizedKraus p r) X =
       BinduGADAuxAncilla.numeratorAncilla p r X := by
  ext ⟨i, α⟩ ⟨j, β⟩
  let M : Matrix (Fin 2) (Fin 2) ℂ :=
    Matrix.of fun k l => X (k, α) (l, β)
  have hA : (ancillaRightChannel
      (BinduGADAuxCPTP.normalizedKraus p r) X) (i,α) (j,β) =
        (finiteKrausChannel (BinduGADAuxCPTP.normalizedKraus p r) M) i j := by
    rw [ancillaRightChannel_apply (BinduGADAuxCPTP.normalizedKraus p r)]
  have hB := congrArg (fun T : Matrix (Fin 2) (Fin 2) ℂ => T i j)
     (BinduGADAuxCPTP.normalized_channel_scaled_eq_numerator p r hp hr M)
  simpa only [Matrix.smul_apply, BinduGADAuxAncilla.numeratorAncilla,
    Matrix.of_apply, hA, M] using hB

#print axioms BinduGADUpperBridge.normalized_auxiliary_ancilla_scaled_eq_numerator
end BinduGADUpperBridge


/-!
BINDU finite-ancilla stabilized Schatten-one norm.

This is a REAL, mathematically meaningful definition: the infimum of all
nonnegative uniform operator bounds over *every* finite ancilla dimension
and *every* complex matrix on the system plus ancilla. It does not define
the norm by the desired GAD formula and it does not reduce the test domain
to density operators. No new axioms and no `sorry` are used here.

The mathematical equivalence with the conventional completely bounded
trace norm follows from finite-dimensional Hilbert-space reindexing; a
separate project-level Lean bridge should explicitly connect this to any
external definition of the diamond norm.
-/

namespace BinduFiniteDiamond

open BinduEventInterface

/-- An arbitrary collection of superoperators on a 2-state system with a
finite-dimensional ancilla, expressed as a family indexed by dimension. -/
abbrev AncillaMap :=
  (m : ℕ) → Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ →
    Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ

/-- A true uniform stabilized Schatten-one operator bound. The range of the
quantifier includes all complex matrices, not only Hermitian/density matrices. -/
def UniformBound (F : AncillaMap) (C : ℝ) : Prop :=
  0 ≤ C ∧ ∀ (m : ℕ) (X : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ),
    schattenOneSpectralNorm (F m X) ≤ C * schattenOneSpectralNorm X

/-- A non-circular, finite-ancilla definition of the stabilized operator norm.
The coefficients must be uniform over every dimension m. -/
noncomputable def finiteAncillaDiamond (F : AncillaMap) : ℝ :=
  sInf {C : ℝ | UniformBound F C}

/-- Every proven uniform estimate genuinely bounds this infimum. -/
theorem diamond_le_of_uniform (F : AncillaMap) (C : ℝ)
    (hC : UniformBound F C) : finiteAncillaDiamond F ≤ C := by
  unfold finiteAncillaDiamond
  have hbelow : BddBelow {c : ℝ | UniformBound F c} := by
    refine ⟨0, ?_⟩
    intro c hc
    exact hc.1
  exact csInf_le hbelow hC

/-- When at least one uniform bound exists, the stabilized norm is nonnegative. -/
theorem diamond_nonneg (F : AncillaMap)
    (h : ∃ C : ℝ, UniformBound F C) :
    0 ≤ finiteAncillaDiamond F := by
  unfold finiteAncillaDiamond
  apply le_csInf
  · rcases h with ⟨C, hC⟩
    exact ⟨C, hC⟩
  · intro C hC
    exact hC.1

/-- Any normalized input gives a rigorous LOWER bound on the stabilized norm.
This is the missing side of older formula-only / `rfl` candidates. -/
theorem witness_le_diamond (F : AncillaMap) (C : ℝ)
    (hC : UniformBound F C)
    (m : ℕ) (X : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ)
    (hX : schattenOneSpectralNorm X = 1) :
    schattenOneSpectralNorm (F m X) ≤ finiteAncillaDiamond F := by
  unfold finiteAncillaDiamond
  apply le_csInf
  · exact ⟨C, hC⟩
  · intro c hc
    have h := hc.2 m X
    rw [hX, mul_one] at h
    exact h

/-- Exactness criterion for the GENUINE stabilized operator norm, not a
predefined target formula: one uniform bound and one saturating input. -/
theorem diamond_eq_of_upper_and_saturation
    (F : AncillaMap) (d : ℝ)
    (hupper : UniformBound F d)
    (m : ℕ) (X : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ)
    (hX : schattenOneSpectralNorm X = 1)
    (hout : schattenOneSpectralNorm (F m X) = d) :
    finiteAncillaDiamond F = d := by
  apply le_antisymm (diamond_le_of_uniform F d hupper)
  calc
    d = schattenOneSpectralNorm (F m X) := hout.symm
    _ ≤ finiteAncillaDiamond F := witness_le_diamond F d hupper m X hX

#print axioms BinduFiniteDiamond.diamond_le_of_uniform
#print axioms BinduFiniteDiamond.diamond_nonneg
#print axioms BinduFiniteDiamond.witness_le_diamond
#print axioms BinduFiniteDiamond.diamond_eq_of_upper_and_saturation

end BinduFiniteDiamond

/-!
Physical GAD one-qubit channel, genuinely extended to all finite ancillas.
This file proves the unconditional universal bound 2 on a non-circular norm;
it deliberately does NOT claim the exact formula has been Lean-proven.
-/

namespace BinduFiniteDiamond

open BinduEventInterface

/-- The actual four-Kraus physical GAD channel minus the same GAD channel
at r=0 (the stationary replacer), each extended by identity on Fin m. -/
noncomputable def gadDifference (p r : ℝ) : AncillaMap :=
  fun m X =>
    ancillaRightChannel (gadKraus p r) X -
      ancillaRightChannel (gadKraus p 0) X

/-- No SDP placeholder: an existing CPTP contraction theorem gives the
uniform bound for ALL complex inputs and ALL finite ancilla dimensions. -/
theorem gadDifference_uniform_two (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    UniformBound (gadDifference p r) 2 := by
  constructor
  · norm_num
  · intro m X
    change schattenOneSpectralNorm
      (ancillaRightChannel (gadKraus p r) X -
        ancillaRightChannel (gadKraus p 0) X) ≤
      2 * schattenOneSpectralNorm X
    have hz : 0 ≤ (0 : ℝ) ∧ (0 : ℝ) ≤ 1 := by constructor <;> norm_num
    exact cptp_channel_sub_le
      (gadKraus p r) (gadKraus_completeness p r hp hr)
      (gadKraus p 0) (gadKraus_completeness p 0 hp hz) X

/-- An unconditional bound on an actual stabilized operator norm,
not merely a statement for each fixed ancilla. -/
theorem gadDifference_diamond_le_two (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    finiteAncillaDiamond (gadDifference p r) ≤ 2 := by
  exact diamond_le_of_uniform _ _ (gadDifference_uniform_two p r hp hr)

/-- The real stabilized norm is nonnegative. -/
theorem gadDifference_diamond_nonneg (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    0 ≤ finiteAncillaDiamond (gadDifference p r) := by
  apply diamond_nonneg
  exact ⟨2, gadDifference_uniform_two p r hp hr⟩

#print axioms BinduFiniteDiamond.gadDifference_uniform_two
#print axioms BinduFiniteDiamond.gadDifference_diamond_le_two
#print axioms BinduFiniteDiamond.gadDifference_diamond_nonneg

end BinduFiniteDiamond

namespace BinduFiniteDiamond

open BinduEventInterface
open Matrix

/-- The proposed exact physical GAD-to-replacer distance (a scalar formula). -/
noncomputable def gadExactValue (p r : ℝ) : ℝ :=
  2*r*(1-p*(1-p)*r^2)/(2-r)

/-- The explicitly proposed optimal Schmidt vector on system and one-qubit ancilla.
The ordering is (system, ancilla), with support on |00> and |11>. -/
noncomputable def optimalSchmidtVector (p r : ℝ) : Fin 2 × Fin 2 → ℂ :=
  fun i => if i = (0, 0) then
    ((Real.sqrt ((1-(1-p)*r)/(2-r)) : ℝ) : ℂ)
  else if i = (1, 1) then
    ((Real.sqrt ((1-p*r)/(2-r)) : ℝ) : ℂ)
  else 0

/-- A concrete rank-one density matrix, not a nominal witness parameter. -/
noncomputable def optimalSchmidtInput (p r : ℝ) :
    Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ :=
  Matrix.vecMulVec (optimalSchmidtVector p r)
    (star (optimalSchmidtVector p r))

/-- The missing universal upper estimate: quantifies over ALL complex matrices
on ALL finite ancilla dimensions, with the actual physical Kraus difference. -/
def GADUpperObligation (p r : ℝ) : Prop :=
  ∀ (m : ℕ) (X : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ),
    schattenOneSpectralNorm (gadDifference p r m X) ≤
      gadExactValue p r * schattenOneSpectralNorm X

/-- The missing explicit primal normalization, not `True`. -/
def GADInputObligation (p r : ℝ) : Prop :=
  schattenOneSpectralNorm (optimalSchmidtInput p r) = 1

/-- The missing explicit output equality for the physical GAD difference. -/
def GADOutputObligation (p r : ℝ) : Prop :=
  schattenOneSpectralNorm (gadDifference p r 2 (optimalSchmidtInput p r)) =
    gadExactValue p r

/-- Nonnegativity of the proposed exact formula on the physical parameter box. -/
theorem gadExactValue_nonneg (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    0 ≤ gadExactValue p r := by
  have hpq : p * (1-p) ≤ (1/4 : ℝ) := by
    nlinarith [sq_nonneg (p-(1/2:ℝ))]
  have hpq0 : 0 ≤ p*(1-p) := mul_nonneg hp.1 (by linarith [hp.2])
  have hr2 : r^2 ≤ 1 := by nlinarith [mul_nonneg (by linarith [hr.2] : 0 ≤ 1-r) (by linarith [hr.1] : 0 ≤ 1+r)]
  have hr20 : 0 ≤ r^2 := sq_nonneg r
  have hq : p*(1-p)*r^2 ≤ 1 := by
    calc
      p*(1-p)*r^2 ≤ (1/4:ℝ)*r^2 := mul_le_mul_of_nonneg_right hpq hr20
      _ ≤ (1/4:ℝ)*1 := mul_le_mul_of_nonneg_left hr2 (by norm_num)
      _ ≤ 1 := by norm_num
  have hd : 0 < 2-r := by linarith [hr.2]
  unfold gadExactValue
  exact div_nonneg (mul_nonneg (by nlinarith [hr.1]) (by linarith [hq]))
    (le_of_lt hd)

/-- A rigorous completion theorem with no hidden tautologies. The real
remaining work is **exactly** the three explicit, physical GAD obligations.
The theorem does NOT claim these premises were proven here. -/
theorem gadExactValue_of_three_certificates (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (hUpper : GADUpperObligation p r)
    (hInput : GADInputObligation p r)
    (hOutput : GADOutputObligation p r) :
    finiteAncillaDiamond (gadDifference p r) = gadExactValue p r := by
  apply diamond_eq_of_upper_and_saturation
    (F := gadDifference p r) (d := gadExactValue p r)
    (m := 2) (X := optimalSchmidtInput p r)
  · exact ⟨gadExactValue_nonneg p r hp hr, hUpper⟩
  · exact hInput
  · exact hOutput

#print axioms BinduFiniteDiamond.gadExactValue_nonneg
#print axioms BinduFiniteDiamond.gadExactValue_of_three_certificates

end BinduFiniteDiamond


/-!
Theorem is independent of GAD: every CPTP map Lambda and the identity obey
‖c (Id - Lambda) ⊗ Id_a (X)‖₁ ≤ 2 c ‖X‖₁ for every complex matrix X,
finite ancilla a and c ≥ 0.  It uses pre-existing BINDU Schatten-1 theorems.
No diamond-norm formula is assumed or defined here.
-/

namespace BinduGADUpper
open BinduEventInterface Matrix
open scoped BigOperators Matrix

theorem scalar_cptp_difference_le
    {k a : Type*} [Fintype k] [Fintype a] [DecidableEq a]
    (K : k → Matrix (Fin 2) (Fin 2) ℂ)
    (hK : ∑ j, (K j)ᴴ * K j = (1 : Matrix (Fin 2) (Fin 2) ℂ))
    (c : ℝ) (hc : 0 ≤ c)
    (X : Matrix (Fin 2 × a) (Fin 2 × a) ℂ) :
    schattenOneSpectralNorm
      (((c : ℝ) : ℂ) • (X - ancillaRightChannel K X)) ≤
      (2 * c) * schattenOneSpectralNorm X := by
  have hcontract := schattenOne_ancillaRightChannel_le K hK X
  have htriangle := schattenOne_sub_le X (ancillaRightChannel K X)
  have htwo : schattenOneSpectralNorm (X - ancillaRightChannel K X) ≤
      2 * schattenOneSpectralNorm X := by
    linarith
  have hcNorm : ‖((c : ℝ) : ℂ)‖ = c := Complex.norm_of_nonneg hc
  calc
    schattenOneSpectralNorm (((c : ℝ) : ℂ) • (X - ancillaRightChannel K X))
        ≤ ‖((c : ℝ) : ℂ)‖ * schattenOneSpectralNorm (X - ancillaRightChannel K X) :=
          schattenOne_smul_le _ _
    _ = c * schattenOneSpectralNorm (X - ancillaRightChannel K X) := by rw [hcNorm]
    _ ≤ c * (2 * schattenOneSpectralNorm X) :=
          mul_le_mul_of_nonneg_left htwo hc
    _ = (2 * c) * schattenOneSpectralNorm X := by ring

#print axioms BinduGADUpper.scalar_cptp_difference_le
end BinduGADUpper

/-!
# Physical exact GAD upper bound: no assumptions about norm saturation

This section uses the *actual* Kraus GAD difference and the genuine
uniform finite-ancilla Schatten-one operator norm from BinduFiniteDiamond.
It does not define the norm by the desired formula.

All required source modules are concatenated before this section by the
fail-closed Mac generator.  The proofs below are source candidates until
`lake env lean` returns EXIT=0 and the axiom audit succeeds.
-/

namespace BinduGADUpperClosure

open BinduEventInterface Matrix

/-- Cancel a nonzero scalar on both sides of an equality of complex matrices. -/
theorem complex_matrix_smul_cancel
    {n : Type*} (z : ℂ) (hz : z ≠ 0)
    (A B : Matrix n n ℂ) (heq : z • A = z • B) : A = B := by
  ext i j
  have hij := congrArg (fun M : Matrix n n ℂ => M i j) heq
  apply (mul_left_cancel₀ hz)
  simpa only [Matrix.smul_apply, smul_eq_mul] using hij

/-- A general ring-theoretic reduction: h⋅A=r⋅(s⋅X−s⋅B) implies
A=(r*s/h)⋅(X−B) after checking h*c=r*s. -/
theorem abstract_factor_of_scaled
    {n : Type*} (z k t c : ℂ) (hz : z ≠ 0)
    (A X B : Matrix n n ℂ)
    (hscaled : z • A = k • (t • X - t • B))
    (hcoeff : z * c = k * t) :
    A = c • (X - B) := by
  apply complex_matrix_smul_cancel z hz A (c • (X - B))
  calc
    z • A = k • (t • X - t • B) := hscaled
    _ = (k * t) • (X - B) := by rw [← smul_sub, smul_smul]
    _ = (z * c) • (X - B) := by rw [hcoeff]
    _ = z • (c • (X - B)) := by rw [smul_smul]

/-- PHYSICAL factorization for every finite ancilla and arbitrary complex input.
The LHS uses the physical four-Kraus BINDU GAD channel, not a proxy channel. -/
theorem physical_difference_factor
    (p r : ℝ) (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (m : ℕ) (X : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ) :
    BinduFiniteDiamond.gadDifference p r m X =
      (((BinduFiniteDiamond.gadExactValue p r / 2 : ℝ) : ℂ)) •
        (X - ancillaRightChannel (BinduGADAuxCPTP.normalizedKraus p r) X) := by
  let h : ℝ := 2-r
  let s : ℝ := 1-p*(1-p)*r^2
  let c : ℝ := BinduFiniteDiamond.gadExactValue p r / 2
  have hh : h ≠ 0 := by
    dsimp [h]
    linarith [hr.2]
  have hz : ((h : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast hh
  have hphysical :=
    BinduGADAuxAncilla.physical_ancilla_scaled_difference p r hp hr X
  have hnum :=
    BinduGADUpperBridge.normalized_auxiliary_ancilla_scaled_eq_numerator p r hp hr X
  rw [← hnum] at hphysical
  have hscaled :
      ((h : ℝ) : ℂ) • (BinduFiniteDiamond.gadDifference p r m X) =
      ((r : ℝ) : ℂ) •
        (((s : ℝ) : ℂ) • X -
          ((s : ℝ) : ℂ) •
            ancillaRightChannel (BinduGADAuxCPTP.normalizedKraus p r) X) := by
    simpa only [BinduFiniteDiamond.gadDifference, h, s] using hphysical
  have hrsc : h * c = r * s := by
    dsimp [h, c, s, BinduFiniteDiamond.gadExactValue]
    field_simp [show (2-r : ℝ) ≠ 0 by linarith [hr.2]]
    ring
  have hcoeff : ((h : ℝ) : ℂ) * ((c : ℝ) : ℂ) =
      ((r : ℝ) : ℂ) * ((s : ℝ) : ℂ) := by
    calc
      ((h : ℝ) : ℂ) * ((c : ℝ) : ℂ) = ((h*c : ℝ) : ℂ) :=
        (Complex.ofReal_mul h c).symm
      _ = ((r*s : ℝ) : ℂ) := congrArg Complex.ofReal hrsc
      _ = ((r : ℝ) : ℂ) * ((s : ℝ) : ℂ) := Complex.ofReal_mul r s
  have hresult := abstract_factor_of_scaled
      (((h : ℝ) : ℂ)) (((r : ℝ) : ℂ)) (((s : ℝ) : ℂ))
      (((c : ℝ) : ℂ)) hz
      (BinduFiniteDiamond.gadDifference p r m X) X
      (ancillaRightChannel (BinduGADAuxCPTP.normalizedKraus p r) X)
      hscaled hcoeff
  simpa only [c] using hresult

/-- The exact uniform bound, for every finite ancilla and every complex X.
NO GADUpperObligation is passed as a premise; it is proved here. -/
theorem gad_upper_obligation_proved (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    BinduFiniteDiamond.GADUpperObligation p r := by
  intro m X
  let c : ℝ := BinduFiniteDiamond.gadExactValue p r / 2
  have hc : 0 ≤ c := by
    dsimp [c]
    have h := BinduFiniteDiamond.gadExactValue_nonneg p r hp hr
    linarith
  have hK := BinduGADAuxCPTP.normalizedKraus_completeness p r hp hr
  have hbound := BinduGADUpper.scalar_cptp_difference_le
    (K := BinduGADAuxCPTP.normalizedKraus p r) hK c hc X
  have heq := physical_difference_factor p r hp hr m X
  calc
    schattenOneSpectralNorm (BinduFiniteDiamond.gadDifference p r m X) =
      schattenOneSpectralNorm
        (((c : ℝ) : ℂ) •
          (X - ancillaRightChannel (BinduGADAuxCPTP.normalizedKraus p r) X)) := by
            rw [heq]
    _ ≤ (2 * c) * schattenOneSpectralNorm X := hbound
    _ = BinduFiniteDiamond.gadExactValue p r * schattenOneSpectralNorm X := by
      dsimp [c]
      ring

/-- UNCONDITIONAL rigorous exact-formula upper bound on the actual
non-circular stabilized operator norm of the physical GAD difference. -/
theorem physical_gad_diamond_le_exact (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    BinduFiniteDiamond.finiteAncillaDiamond
      (BinduFiniteDiamond.gadDifference p r) ≤
        BinduFiniteDiamond.gadExactValue p r := by
  apply BinduFiniteDiamond.diamond_le_of_uniform
  exact ⟨BinduFiniteDiamond.gadExactValue_nonneg p r hp hr,
    gad_upper_obligation_proved p r hp hr⟩

/-- The earlier three-obligation completion now needs ONLY the physical
normalization and output-saturation certificates. The upper premise is
constructed above, so it is no longer an external hypothesis. -/
theorem exact_diamond_of_witness_certificates (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (hInput : BinduFiniteDiamond.GADInputObligation p r)
    (hOutput : BinduFiniteDiamond.GADOutputObligation p r) :
    BinduFiniteDiamond.finiteAncillaDiamond
      (BinduFiniteDiamond.gadDifference p r) =
        BinduFiniteDiamond.gadExactValue p r := by
  exact BinduFiniteDiamond.gadExactValue_of_three_certificates p r hp hr
    (gad_upper_obligation_proved p r hp hr) hInput hOutput

#print axioms BinduGADUpperClosure.complex_matrix_smul_cancel
#print axioms BinduGADUpperClosure.abstract_factor_of_scaled
#print axioms BinduGADUpperClosure.physical_difference_factor
#print axioms BinduGADUpperClosure.gad_upper_obligation_proved
#print axioms BinduGADUpperClosure.physical_gad_diamond_le_exact
#print axioms BinduGADUpperClosure.exact_diamond_of_witness_certificates

end BinduGADUpperClosure


/-!
# Lower trace-norm bound by pairing with a unitary

For finite n, this file proves from EXISTING BINDU singular-vector and Kraus
energy lemmas the true trace-norm duality inequality

  ‖trace(U * X)‖ ≤ schattenOneSpectralNorm X

when Uᴴ * U = 1. It does not introduce a new norm, or claim that GAD
witness normalization/physical-output equality has been formalized.

This research file is a *candidate* until compiled on the user's Lean 4.19/Mathlib.
No `sorry`, `admit`, `axiom`, `opaque`, `constant` or fake `True` proof is used.
-/

namespace BinduGADTraceDuality

open Matrix
open BinduEventInterface
open BinduFiniteKrausCS (eucLength)

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- Trace of a left-multiplied rank-one matrix is a vector dot product. -/
theorem trace_mul_rankOne (U : Matrix n n ℂ) (a b : n → ℂ) :
    Matrix.trace (U * Matrix.vecMulVec a (star b)) =
      star b ⬝ᵥ (U *ᵥ a) := by
  change (∑ i : n, ∑ j : n, U i j * (a j * star (b i))) =
    ∑ i : n, star (b i) * (∑ j : n, U i j * a j)
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j _
  ring

/-- Existing BINDU SVD makes the trace pairing a sum of n vector pairings. -/
theorem trace_mul_svd (U X : Matrix n n ℂ) :
    Matrix.trace (U * X) =
      ∑ i : n, star (rv X i) ⬝ᵥ (U *ᵥ (X *ᵥ rv X i)) := by
  conv_lhs => rw [svd_decomp X]
  rw [Matrix.mul_sum, Matrix.trace_sum]
  apply Finset.sum_congr rfl
  intro i _
  exact trace_mul_rankOne U (X *ᵥ rv X i) (rv X i)

/-- A unitary, viewed as a one-member Kraus family, preserves vector energy. -/
theorem unitary_eucLength_mulVec_eq (U : Matrix n n ℂ)
    (hU : Uᴴ * U = (1 : Matrix n n ℂ)) (w : n → ℂ) :
    eucLength (U *ᵥ w) = eucLength w := by
  let K : Unit → Matrix n n ℂ := fun _ => U
  have hK : ∑ j : Unit, (K j)ᴴ * K j = (1 : Matrix n n ℂ) := by
    simpa [K] using hU
  have hsum := BinduKrausEnergyBridge.kraus_energy_preserved K hK w
  have hsum' : (∑ i : n, ‖(U *ᵥ w) i‖ ^ 2) = (∑ i : n, ‖w i‖ ^ 2) := by
    simpa [K] using hsum
  unfold eucLength
  rw [hsum']

/-- True finite-dimensional trace/nuclear-norm duality for a unitary test.
The RHS is the project's SVD-based Schatten-one norm, not an assumed formula.
-/
theorem trace_pairing_unitary_le_schattenOne (U X : Matrix n n ℂ)
    (hU : Uᴴ * U = (1 : Matrix n n ℂ)) :
    ‖Matrix.trace (U * X)‖ ≤ schattenOneSpectralNorm X := by
  have hterm (i : n) :
      ‖star (rv X i) ⬝ᵥ (U *ᵥ (X *ᵥ rv X i))‖ ≤ sv X i := by
    have hdot :
        star (rv X i) ⬝ᵥ (U *ᵥ (X *ᵥ rv X i)) =
          (inner (toE (rv X i))
            (toE (U *ᵥ (X *ᵥ rv X i))) : ℂ) := by
      rw [inner_toE]
      exact dotProduct_comm _ _
    calc
      ‖star (rv X i) ⬝ᵥ (U *ᵥ (X *ᵥ rv X i))‖ =
        ‖(inner (toE (rv X i))
            (toE (U *ᵥ (X *ᵥ rv X i))) : ℂ)‖ := congrArg norm hdot
      _ ≤ ‖toE (rv X i)‖ * ‖toE (U *ᵥ (X *ᵥ rv X i))‖ :=
        norm_inner_le_norm _ _
      _ = eucLength (rv X i) * eucLength (U *ᵥ (X *ᵥ rv X i)) := by
        rw [norm_toE, norm_toE]
      _ = sv X i := by
        rw [unitary_eucLength_mulVec_eq U hU,
          eucLength_rv, eucLength_X_rv, one_mul]
  calc
    ‖Matrix.trace (U * X)‖ =
        ‖∑ i : n, star (rv X i) ⬝ᵥ (U *ᵥ (X *ᵥ rv X i))‖ := by
      rw [trace_mul_svd]
    _ ≤ ∑ i : n, ‖star (rv X i) ⬝ᵥ (U *ᵥ (X *ᵥ rv X i))‖ :=
      norm_sum_le _ _
    _ ≤ ∑ i : n, sv X i := Finset.sum_le_sum (fun i _ => hterm i)
    _ = schattenOneSpectralNorm X := (schattenOne_eq_sum_sv X).symm

/-- The familiar special case with the identity test operator. -/
theorem trace_le_schattenOne (X : Matrix n n ℂ) :
    ‖Matrix.trace X‖ ≤ schattenOneSpectralNorm X := by
  have hI : (1 : Matrix n n ℂ)ᴴ * 1 = 1 := by simp
  simpa using trace_pairing_unitary_le_schattenOne (1 : Matrix n n ℂ) X hI

#print axioms BinduGADTraceDuality.trace_mul_rankOne
#print axioms BinduGADTraceDuality.trace_mul_svd
#print axioms BinduGADTraceDuality.unitary_eucLength_mulVec_eq
#print axioms BinduGADTraceDuality.trace_pairing_unitary_le_schattenOne
#print axioms BinduGADTraceDuality.trace_le_schattenOne

end BinduGADTraceDuality

/-!
# A unitary trace test gives a lower bound on the ACTUAL stabilized norm.

This theorem is completely independent of GAD. It proves the stronger
certificate using input Schatten norm <= 1 rather than an assumed equality.
No `sorry`, `axiom`, circular definitions, or unproven norm formula.
-/
namespace BinduGADLower

open Matrix BinduEventInterface BinduFiniteDiamond

/-- Any unitary trace test on an input of Schatten-one norm at most one
produces a lower bound on the genuine uniform finite-ancilla stabilized norm.
The parameter `C` witnesses nonemptiness of the family of uniform bounds. -/
theorem diamond_ge_of_unitary_trace_test
    (F : BinduFiniteDiamond.AncillaMap) (C d : ℝ)
    (hC : BinduFiniteDiamond.UniformBound F C)
    (m : ℕ)
    (X U : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ)
    (hX : schattenOneSpectralNorm X ≤ 1)
    (hU : Uᴴ * U = (1 : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ))
    (hpair : d ≤ ‖Matrix.trace (U * F m X)‖) :
    d ≤ BinduFiniteDiamond.finiteAncillaDiamond F := by
  unfold BinduFiniteDiamond.finiteAncillaDiamond
  apply le_csInf
  · exact ⟨C, hC⟩
  · intro c hc
    calc
      d ≤ ‖Matrix.trace (U * F m X)‖ := hpair
      _ ≤ schattenOneSpectralNorm (F m X) :=
        BinduGADTraceDuality.trace_pairing_unitary_le_schattenOne U (F m X) hU
      _ ≤ c * schattenOneSpectralNorm X := hc.2 m X
      _ ≤ c * 1 := mul_le_mul_of_nonneg_left hX hc.1
      _ = c := mul_one _

/-- Once a uniform bound d and a saturating unitary pairing are known, the
actual stabilized operator norm equals d. No `GADOutputObligation` is assumed. -/
theorem diamond_eq_of_upper_and_trace_test
    (F : BinduFiniteDiamond.AncillaMap) (d : ℝ)
    (hupper : BinduFiniteDiamond.UniformBound F d)
    (m : ℕ)
    (X U : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ)
    (hX : schattenOneSpectralNorm X ≤ 1)
    (hU : Uᴴ * U = (1 : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ))
    (hpair : d ≤ ‖Matrix.trace (U * F m X)‖) :
    BinduFiniteDiamond.finiteAncillaDiamond F = d := by
  apply le_antisymm
  · exact BinduFiniteDiamond.diamond_le_of_uniform F d hupper
  · exact diamond_ge_of_unitary_trace_test F d d hupper m X U hX hU hpair

/-- The last physical result can be reduced to a UNITARY TRACE TEST on the
concrete optimal Schmidt input: a strictly weaker obligation than evaluating
all singular values of the output. -/
theorem physical_gad_exact_of_trace_test (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (U : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ)
    (hX : schattenOneSpectralNorm (BinduFiniteDiamond.optimalSchmidtInput p r) ≤ 1)
    (hU : Uᴴ * U = (1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ))
    (hpair : BinduFiniteDiamond.gadExactValue p r ≤
      ‖Matrix.trace (U *
        BinduFiniteDiamond.gadDifference p r 2
          (BinduFiniteDiamond.optimalSchmidtInput p r))‖) :
    BinduFiniteDiamond.finiteAncillaDiamond (BinduFiniteDiamond.gadDifference p r) =
      BinduFiniteDiamond.gadExactValue p r := by
  apply diamond_eq_of_upper_and_trace_test
    (F := BinduFiniteDiamond.gadDifference p r)
    (d := BinduFiniteDiamond.gadExactValue p r)
    (m := 2) (X := BinduFiniteDiamond.optimalSchmidtInput p r) (U := U)
  · exact ⟨BinduFiniteDiamond.gadExactValue_nonneg p r hp hr,
      BinduGADUpperClosure.gad_upper_obligation_proved p r hp hr⟩
  · exact hX
  · exact hU
  · exact hpair

#print axioms BinduGADLower.diamond_ge_of_unitary_trace_test
#print axioms BinduGADLower.diamond_eq_of_upper_and_trace_test
#print axioms BinduGADLower.physical_gad_exact_of_trace_test

end BinduGADLower

/-!
# Actual optimal Schmidt input normalization for physical GAD

This goes beyond the generic trace test by proving the old
`GADInputObligation` from the actual two-qubit amplitudes.
-/
namespace BinduGADLower
open BinduEventInterface BinduFiniteDiamond Matrix
open BinduFiniteKrausCS (eucLength)

private theorem physical_weights_nonneg (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    0 ≤ (1-(1-p)*r)/(2-r) ∧ 0 ≤ (1-p*r)/(2-r) := by
  have hu : 0 ≤ 1-p*r := by
    have hpr : p*r ≤ 1 := by
      calc
        p*r ≤ 1*r := mul_le_mul_of_nonneg_right hp.2 hr.1
        _ = r := one_mul r
        _ ≤ 1 := hr.2
    linarith
  have hv : 0 ≤ 1-(1-p)*r := by
    have hpr : (1-p)*r ≤ 1 := by
      calc
        (1-p)*r ≤ 1*r :=
          mul_le_mul_of_nonneg_right (by linarith [hp.1] : (1-p) ≤ 1) hr.1
        _ = r := one_mul r
        _ ≤ 1 := hr.2
    linarith
  have hh : 0 ≤ 2-r := by linarith [hr.2]
  exact ⟨div_nonneg hv hh, div_nonneg hu hh⟩

/-- Exactly normalized amplitudes: sum of FOUR complex squared norms = 1. -/
theorem optimalSchmidtVector_unit_energy (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    (∑ ij : Fin 2 × Fin 2,
      ‖BinduFiniteDiamond.optimalSchmidtVector p r ij‖ ^ 2) = 1 := by
  obtain ⟨hv, hu⟩ := physical_weights_nonneg p r hp hr
  have hh : (2-r : ℝ) ≠ 0 := by linarith [hr.2]
  have hvroot :
      ‖(((Real.sqrt ((1-(1-p)*r)/(2-r)) : ℝ) : ℂ))‖^2 =
        (1-(1-p)*r)/(2-r) := by
    rw [Complex.norm_real, Real.norm_of_nonneg (Real.sqrt_nonneg _), Real.sq_sqrt hv]
  have huroot :
      ‖(((Real.sqrt ((1-p*r)/(2-r)) : ℝ) : ℂ))‖^2 =
        (1-p*r)/(2-r) := by
    rw [Complex.norm_real, Real.norm_of_nonneg (Real.sqrt_nonneg _), Real.sq_sqrt hu]
  have hsum :
      (∑ ij : Fin 2 × Fin 2,
        ‖BinduFiniteDiamond.optimalSchmidtVector p r ij‖ ^ 2) =
      (1-(1-p)*r)/(2-r)+(1-p*r)/(2-r) := by
    simp [Fintype.sum_prod_type, Fin.sum_univ_two,
      BinduFiniteDiamond.optimalSchmidtVector,
      Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (Real.sqrt_nonneg _), Real.sq_sqrt hv, Real.sq_sqrt hu]
  rw [hsum]
  field_simp [hh]
  ring

/-- The actual system+ancilla Schmidt vector has Euclidean norm 1. -/
theorem optimalSchmidtVector_eucLength_one (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    eucLength (BinduFiniteDiamond.optimalSchmidtVector p r) = 1 := by
  unfold eucLength
  rw [optimalSchmidtVector_unit_energy p r hp hr, Real.sqrt_one]

/-- Projective density input has Schatten-one norm <= 1, proved with the
nontrivial BINDU rank-one nuclear-norm lemma, not by definition. -/
theorem optimalSchmidtInput_schattenOne_le_one (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    schattenOneSpectralNorm (BinduFiniteDiamond.optimalSchmidtInput p r) ≤ 1 := by
  let w := BinduFiniteDiamond.optimalSchmidtVector p r
  let f : Unit → (Fin 2 × Fin 2 → ℂ) := fun _ => w
  have he : eucLength w = 1 := optimalSchmidtVector_eucLength_one p r hp hr
  have hdecomp : BinduFiniteDiamond.optimalSchmidtInput p r =
      ∑ k : Unit, Matrix.vecMulVec (f k) (star (f k)) := by
    simp [BinduFiniteDiamond.optimalSchmidtInput, f, w]
  have hb := BinduEventInterface.schattenOne_le_cost
    (BinduFiniteDiamond.optimalSchmidtInput p r) f f hdecomp
  simpa [f, he] using hb

/-- Exact trace normalization of the true rank-one GAD input. -/
theorem optimalSchmidtInput_trace_one (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    Matrix.trace (BinduFiniteDiamond.optimalSchmidtInput p r) = 1 := by
  have henergy := optimalSchmidtVector_unit_energy p r hp hr
  change Matrix.trace
    (BinduKrausEnergyBridge.rankOne (BinduFiniteDiamond.optimalSchmidtVector p r)) = 1
  rw [BinduKrausEnergyBridge.trace_rankOne, henergy]
  norm_num

/-- The previously open physical GADInputObligation is now a direct target,
with no hypothetical trace-norm evaluation. -/
theorem gad_input_obligation_unconditional (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    BinduFiniteDiamond.GADInputObligation p r := by
  unfold BinduFiniteDiamond.GADInputObligation
  apply le_antisymm
  · exact optimalSchmidtInput_schattenOne_le_one p r hp hr
  · have hlow := BinduGADTraceDuality.trace_le_schattenOne
      (BinduFiniteDiamond.optimalSchmidtInput p r)
    rw [optimalSchmidtInput_trace_one p r hp hr] at hlow
    simpa using hlow

#print axioms BinduGADLower.optimalSchmidtVector_unit_energy
#print axioms BinduGADLower.optimalSchmidtVector_eucLength_one
#print axioms BinduGADLower.optimalSchmidtInput_schattenOne_le_one
#print axioms BinduGADLower.optimalSchmidtInput_trace_one
#print axioms BinduGADLower.gad_input_obligation_unconditional

end BinduGADLower


/-!
A direct 4x4 polynomial certificate for the physical GAD trace-reflection
pairing. This deliberately does not define the diamond norm. It uses the
basis ordering |00>, |01>, |10>, |11> = system × ancilla.

The matrix `physicalDifferenceOnSchmidt` is the explicit expected output;
separately prove that it equals the ACTUAL Kraus difference acting on the
true complex `optimalSchmidtInput` before claiming the final theorem.

Lean compilation is not available in the assistant environment; each theorem
below is an uncompiled Lean candidate, not a certified statement.
-/
namespace BinduGADDirectTrace
open Matrix

/-- Generic rank-one input numerator with real amplitudes α,β and z=αβ.
Parameter x=α², y=β², z=αβ. -/
def schmidtInput (x y z : ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  !![x, 0, 0, z;
     0, 0, 0, 0;
     0, 0, 0, 0;
     z, 0, 0, y]

/-- Reflecting observable 2ρ−I (unitary when x+y=1 and z²=xy). -/
def reflection (x y z : ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  2 • schmidtInput x y z - 1

/-- Matrix of the PHYSICAL channel difference on the Schmidt input,
with system-first ordering (00,01,10,11). This is an explicit matrix target,
not yet a theorem equating it with a Kraus action. -/
def physicalDifferenceOnSchmidt (p r x y z : ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  !![p*r^2*x, 0, 0, r*z;
     0, -((1-p)*r^2*y), 0, 0;
     0, 0, -(p*r^2*x), 0;
     r*z, 0, 0, (1-p)*r^2*y]

/-- Exact trace pairing, without dividing by any parameter or invoking
any SDP axiom. This reduces the last lower bound to a scalar identity. -/
theorem physical_trace_pairing_polynomial (p r x y z : ℝ) :
    Matrix.trace
      (reflection x y z * physicalDifferenceOnSchmidt p r x y z) =
        2*r^2*(p*x^2 + (1-p)*y^2) + 4*r*z^2 := by
  simp [reflection, schmidtInput, physicalDifferenceOnSchmidt,
    Matrix.trace, Matrix.mul_apply, Fin.sum_univ_four,
    Matrix.smul_apply, Matrix.sub_apply, Matrix.one_apply] <;> ring

/-- The exact GAD scalar identity in polynomial form. -/
theorem physical_scalar_identity (p r : ℝ) :
    r^2*(p*(1-(1-p)*r)^2 + (1-p)*(1-p*r)^2) +
        2*r*(1-p*r)*(1-(1-p)*r) =
      r*(1-p*(1-p)*r^2)*(2-r) := by
  ring

/-- Formal denominator-clearing step for the exact GAD trace value.
The three assumptions are actual, nontrivial Schmidt-weight identities. -/
theorem trace_pairing_exact_of_schmidt_weights
    (p r x y z : ℝ) (h : 2-r ≠ 0)
    (hx : x = (1-(1-p)*r)/(2-r))
    (hy : y = (1-p*r)/(2-r))
    (hz : z^2 = x*y) :
    Matrix.trace
      (reflection x y z * physicalDifferenceOnSchmidt p r x y z) =
      2*r*(1-p*(1-p)*r^2)/(2-r) := by
  rw [physical_trace_pairing_polynomial, hz, hx, hy]
  field_simp [h] <;> ring

#print axioms BinduGADDirectTrace.physical_trace_pairing_polynomial
#print axioms BinduGADDirectTrace.physical_scalar_identity
#print axioms BinduGADDirectTrace.trace_pairing_exact_of_schmidt_weights
end BinduGADDirectTrace


/-!
An independent structural lemma for the last exact-GAD diamond-norm step.
It is NOT the physical GAD theorem: the actual output-state orthogonality must
still be proved using the physical Kraus action.  This source has not been
compiled in this assistant environment, where Lean/Lake are unavailable.
No sorry/admit/axiom/True shortcut is present.
-/

namespace BinduGADRankOneReflection
open Matrix
open BinduKrausEnergyBridge

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- A normalized rank-one matrix is an algebraic orthogonal projection. -/
theorem normalized_rankOne_sq (w : n → ℂ)
    (htr : Matrix.trace (rankOne w) = 1) :
    rankOne w * rankOne w = rankOne w := by
  classical
  have hn : (∑ k : n, star (w k) * w k) = 1 := by
    calc
      (∑ k : n, star (w k) * w k) =
          ∑ k : n, w k * star (w k) := by
            apply Finset.sum_congr rfl
            intro k _
            ring
      _ = Matrix.trace (rankOne w) := rfl
      _ = 1 := htr
  ext i j
  change (∑ k : n, (w i * star (w k)) * (w k * star (w j))) =
    w i * star (w j)
  calc
    (∑ k : n, (w i * star (w k)) * (w k * star (w j))) =
        (w i * star (w j)) * (∑ k : n, star (w k) * w k) := by
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro k _
          ring
    _ = w i * star (w j) := by rw [hn]; ring

/-- A rank-one matrix of the form `w w†` is self-adjoint. -/
theorem rankOne_self_adjoint (w : n → ℂ) :
    (rankOne w)ᴴ = rankOne w := by
  ext i j
  change star (w j * star (w i)) = w i * star (w j)
  exact star_mul_star (w j) (w i)

/-- Reflection across a one-dimensional pure-state support. -/
noncomputable def reflection (w : n → ℂ) : Matrix n n ℂ :=
  rankOne w + rankOne w - 1

/-- This reflection is self-adjoint. -/
theorem reflection_self_adjoint (w : n → ℂ) :
    (reflection w)ᴴ = reflection w := by
  simp [reflection, rankOne_self_adjoint]

/-- Involutivity/unitarity follows only from projector normalization. -/
theorem reflection_unitary (w : n → ℂ)
    (htr : Matrix.trace (rankOne w) = 1) :
    (reflection w)ᴴ * reflection w = (1 : Matrix n n ℂ) := by
  rw [reflection_self_adjoint]
  let R := rankOne w
  have hproj : R * R = R := normalized_rankOne_sq w htr
  change (R + R - 1) * (R + R - 1) = 1
  calc
    (R + R - 1) * (R + R - 1) =
        (R * R + R * R + R * R + R * R) -
          (R + R + R + R) + 1 := by
            noncomm_ring
    _ = 1 := by rw [hproj]; abel

/-- Orthogonal normalized outputs saturate the trace-reflection test. -/
theorem reflection_trace_saturation (w : n → ℂ) (S : Matrix n n ℂ)
    (htr : Matrix.trace (rankOne w) = 1)
    (hS : Matrix.trace S = 1)
    (horth : rankOne w * S = 0) :
    Matrix.trace (reflection w * (rankOne w - S)) = (2 : ℂ) := by
  let R := rankOne w
  have hproj : R * R = R := normalized_rankOne_sq w htr
  have hmat : (R + R - 1) * (R - S) = R + S := by
    calc
      (R + R - 1) * (R - S) =
          (R * R + R * R - R) - (R * S + R * S - S) := by
            noncomm_ring
      _ = R + S := by rw [hproj, horth]; abel
  calc
    Matrix.trace (reflection w * (rankOne w - S)) =
        Matrix.trace (R + S) := by
          change Matrix.trace ((R + R - 1) * (R - S)) = _
          rw [hmat]
    _ = Matrix.trace R + Matrix.trace S := Matrix.trace_add R S
    _ = 2 := by rw [htr, hS]; ring

#print axioms BinduGADRankOneReflection.normalized_rankOne_sq
#print axioms BinduGADRankOneReflection.rankOne_self_adjoint
#print axioms BinduGADRankOneReflection.reflection_unitary
#print axioms BinduGADRankOneReflection.reflection_trace_saturation

end BinduGADRankOneReflection

/-!
# Native physical matrix bridge — real GAD difference, no formula-defined norm.

The proof is carried in the native `(Fin 2 × Fin 2)` basis (system, ancilla),
without introducing an external SDP axiom. This file is an EXPERIMENTAL
candidate. The genuine Lean kernel on the user's Mac must verify it.
-/
namespace BinduGADNativePhysical
open Matrix BinduEventInterface BinduFiniteDiamond

private def flat : Fin 2 × Fin 2 → Fin 4 := fun i =>
  if i.1 = 0 then (if i.2 = 0 then 0 else 1)
  else (if i.2 = 0 then 2 else 3)

/-- The explicit real 4x4 density numerator, reindexed in the *actual*
`Fin 2 × Fin 2` basis and embedded into complex matrices. -/
noncomputable def nativeInput (a b : ℝ) :
    Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ :=
  fun i j => ((BinduGADDirectTrace.schmidtInput
    (a^2) (b^2) (a*b) (flat i) (flat j) : ℝ) : ℂ)

/-- The exact *physical* GAD output in the native basis. This is a target
matrix only; the next theorem establishes equality with the real Kraus map. -/
noncomputable def nativeOutput (p r a b : ℝ) :
    Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ :=
  fun i j => ((BinduGADDirectTrace.physicalDifferenceOnSchmidt
    p r (a^2) (b^2) (a*b) (flat i) (flat j) : ℝ) : ℂ)

/-- Trace pairing of native complex reindexing of the explicit physical
output. No normalization assumption: the formula is polynomial. -/
theorem native_trace_polynomial (p r a b : ℝ) :
    Matrix.trace ((2 • nativeInput a b - 1) * nativeOutput p r a b) =
      ((2*r^2*(p*(a^2)^2+(1-p)*(b^2)^2)+4*r*(a*b)^2 : ℝ) : ℂ) := by
  classical
  simp [nativeInput, nativeOutput, flat, Matrix.trace, Matrix.mul_apply,
    Fintype.sum_prod_type, Fin.sum_univ_two,
    BinduGADDirectTrace.schmidtInput,
    BinduGADDirectTrace.physicalDifferenceOnSchmidt,
    Matrix.smul_apply, Matrix.sub_apply, Matrix.one_apply,
    Matrix.of_apply, Complex.ofReal_add, Complex.ofReal_neg, Complex.ofReal_mul, Complex.ofReal_sub, Complex.ofReal_pow, two_smul] <;> ring

/-- An exact *entrywise* reduction from the four physical Kraus operators
on an arbitrary matrix to the already verified closed GAD formula on each
system slice. This uses the genuine `gadDifference`, not a target matrix. -/
theorem physical_difference_slice (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1)
    (m : ℕ) (X : Matrix (Fin 2 × Fin m) (Fin 2 × Fin m) ℂ)
    (i j : Fin 2) (α β : Fin m) :
    BinduFiniteDiamond.gadDifference p r m X (i,α) (j,β) =
      (gadClosedChannel p r
        (Matrix.of fun k l => X (k,α) (l,β)) -
       gadClosedChannel p 0
        (Matrix.of fun k l => X (k,α) (l,β))) i j := by
  let M : Matrix (Fin 2) (Fin 2) ℂ :=
    Matrix.of fun k l => X (k,α) (l,β)
  have hz : (0 ≤ (0:ℝ)) ∧ (0:ℝ) ≤ 1 := by constructor <;> norm_num
  have ha : (ancillaRightChannel (gadKraus p r) X) (i,α) (j,β) =
      gadClosedChannel p r M i j := by
    rw [ancillaRightChannel_apply (gadKraus p r)]
    exact congrArg (fun T : Matrix (Fin 2) (Fin 2) ℂ => T i j)
      (finiteKrausChannel_gadKraus_eq_closed p r hp hr M)
  have hb : (ancillaRightChannel (gadKraus p 0) X) (i,α) (j,β) =
      gadClosedChannel p 0 M i j := by
    rw [ancillaRightChannel_apply (gadKraus p 0)]
    exact congrArg (fun T : Matrix (Fin 2) (Fin 2) ℂ => T i j)
      (finiteKrausChannel_gadKraus_eq_closed p 0 hp hz M)
  simpa only [BinduFiniteDiamond.gadDifference, Matrix.sub_apply,
    ha, hb, M] using (show
      (ancillaRightChannel (gadKraus p r) X) (i,α) (j,β) -
      (ancillaRightChannel (gadKraus p 0) X) (i,α) (j,β) =
      gadClosedChannel p r M i j - gadClosedChannel p 0 M i j from
        congrArg₂ (· - ·) ha hb)

/-- The actual optimal Schmidt input is the reindexed exact matrix. -/
theorem actual_input_eq_native (p r : ℝ) :
    BinduFiniteDiamond.optimalSchmidtInput p r =
      nativeInput
        (Real.sqrt ((1-(1-p)*r)/(2-r)))
        (Real.sqrt ((1-p*r)/(2-r))) := by
  ext ⟨i,α⟩ ⟨j,β⟩
  fin_cases i <;> fin_cases α <;> fin_cases j <;> fin_cases β <;>
    simp [nativeInput, flat, BinduFiniteDiamond.optimalSchmidtInput,
      BinduFiniteDiamond.optimalSchmidtVector,
      BinduGADDirectTrace.schmidtInput,
      Matrix.vecMulVec_apply, Complex.star_def, Complex.conj_ofReal,
      Complex.ofReal_mul, Complex.ofReal_pow] <;> ring

/-- The target 4x4 output IS the physical four-Kraus difference evaluated
on the normalized two-qubit Schmidt input. -/
theorem actual_output_eq_native (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    BinduFiniteDiamond.gadDifference p r 2
      (BinduFiniteDiamond.optimalSchmidtInput p r) =
      nativeOutput p r
        (Real.sqrt ((1-(1-p)*r)/(2-r)))
        (Real.sqrt ((1-p*r)/(2-r))) := by
  classical
  ext ⟨i,α⟩ ⟨j,β⟩
  rw [physical_difference_slice p r hp hr 2
    (BinduFiniteDiamond.optimalSchmidtInput p r) i j α β]
  fin_cases i <;> fin_cases α <;> fin_cases j <;> fin_cases β <;>
    norm_num [nativeOutput, flat,
      BinduGADDirectTrace.physicalDifferenceOnSchmidt,
      BinduFiniteDiamond.optimalSchmidtInput,
      BinduFiniteDiamond.optimalSchmidtVector,
      gadClosedChannel, Matrix.of_apply,
      Matrix.vecMulVec_apply, Complex.star_def, Complex.conj_ofReal,
      Complex.ofReal_mul, Complex.ofReal_sub,
      Complex.ofReal_pow] <;> push_cast <;> ring

#print axioms BinduGADNativePhysical.native_trace_polynomial
#print axioms BinduGADNativePhysical.physical_difference_slice
#print axioms BinduGADNativePhysical.actual_input_eq_native
#print axioms BinduGADNativePhysical.actual_output_eq_native
end BinduGADNativePhysical

/-!
# Formal endgame (experimental until tested by Lean)

A final theorem must mention the real `finiteAncillaDiamond` applied to the
actual `gadDifference`, with no output/input/trace-test premises. The kernel
will accept this file only after all native physical matrix identities hold.
-/
namespace BinduGADFinal
open Matrix BinduEventInterface BinduFiniteDiamond

/-- The normalized Schmidt vector induces the self-adjoint unitary reflector
used in the trace-duality lower bound. -/
theorem optimal_reflection_unitary (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    (BinduGADRankOneReflection.reflection
      (BinduFiniteDiamond.optimalSchmidtVector p r))ᴴ *
      BinduGADRankOneReflection.reflection
      (BinduFiniteDiamond.optimalSchmidtVector p r) =
      (1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) := by
  apply BinduGADRankOneReflection.reflection_unitary
  change Matrix.trace (BinduFiniteDiamond.optimalSchmidtInput p r) = 1
  exact BinduGADLower.optimalSchmidtInput_trace_one p r hp hr

/-- The actual physical four-Kraus difference attains the claimed exact
trace pairing with the unitary reflection on the optimal Schmidt input. -/
theorem physical_unitary_trace_pairing (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    Matrix.trace
      ((BinduGADRankOneReflection.reflection
        (BinduFiniteDiamond.optimalSchmidtVector p r)) *
        BinduFiniteDiamond.gadDifference p r 2
          (BinduFiniteDiamond.optimalSchmidtInput p r)) =
      ((BinduFiniteDiamond.gadExactValue p r : ℝ) : ℂ) := by
  let a := Real.sqrt ((1-(1-p)*r)/(2-r))
  let b := Real.sqrt ((1-p*r)/(2-r))
  have hhpos : 0 ≤ 2-r := by linarith [hr.2]
  have hpr : p*r ≤ 1 := by
    calc
      p*r ≤ 1*r := mul_le_mul_of_nonneg_right hp.2 hr.1
      _ = r := one_mul r
      _ ≤ 1 := hr.2
  have hqr : (1-p)*r ≤ 1 := by
    calc
      (1-p)*r ≤ 1*r :=
        mul_le_mul_of_nonneg_right (by linarith [hp.1] : (1-p) ≤ 1) hr.1
      _ = r := one_mul r
      _ ≤ 1 := hr.2
  have hv : 0 ≤ (1-(1-p)*r)/(2-r) :=
    div_nonneg (by linarith [hqr]) hhpos
  have hu : 0 ≤ (1-p*r)/(2-r) :=
    div_nonneg (by linarith [hpr]) hhpos
  have ha : a^2 = (1-(1-p)*r)/(2-r) := by
    exact Real.sq_sqrt hv
  have hb : b^2 = (1-p*r)/(2-r) := by
    exact Real.sq_sqrt hu
  have hh : (2-r : ℝ) ≠ 0 := by linarith [hr.2]
  have hs : (a*b)^2 = a^2*b^2 := by ring
  have hreal :
      2*r^2*(p*(a^2)^2+(1-p)*(b^2)^2)+4*r*(a*b)^2 =
        BinduFiniteDiamond.gadExactValue p r := by
    rw [hs, ha, hb]
    unfold BinduFiniteDiamond.gadExactValue
    field_simp [hh]
    ring
  have hi := BinduGADNativePhysical.actual_input_eq_native p r
  have ho := BinduGADNativePhysical.actual_output_eq_native p r hp hr
  have hreflection :
      BinduGADRankOneReflection.reflection
        (BinduFiniteDiamond.optimalSchmidtVector p r) =
      2 • BinduFiniteDiamond.optimalSchmidtInput p r - 1 := by
    unfold BinduGADRankOneReflection.reflection
    change BinduFiniteDiamond.optimalSchmidtInput p r +
      BinduFiniteDiamond.optimalSchmidtInput p r - 1 = _
    rw [two_smul]
  calc
    Matrix.trace
      ((BinduGADRankOneReflection.reflection
        (BinduFiniteDiamond.optimalSchmidtVector p r)) *
        BinduFiniteDiamond.gadDifference p r 2
          (BinduFiniteDiamond.optimalSchmidtInput p r)) =
      Matrix.trace ((2 • BinduGADNativePhysical.nativeInput a b - 1) *
        BinduGADNativePhysical.nativeOutput p r a b) := by
          rw [hreflection, ho, hi]
    _ = ((2*r^2*(p*(a^2)^2+(1-p)*(b^2)^2)+4*r*(a*b)^2 : ℝ) : ℂ) :=
      BinduGADNativePhysical.native_trace_polynomial p r a b
    _ = ((BinduFiniteDiamond.gadExactValue p r : ℝ) : ℂ) :=
      congrArg Complex.ofReal hreal

/-- A genuine lower bound for the stabilised operator norm of the PHYSICAL
GAD difference, independent of numerical SDP conventions. -/
theorem physical_gad_diamond_ge_exact (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    BinduFiniteDiamond.gadExactValue p r ≤
      BinduFiniteDiamond.finiteAncillaDiamond
        (BinduFiniteDiamond.gadDifference p r) := by
  let U := BinduGADRankOneReflection.reflection
    (BinduFiniteDiamond.optimalSchmidtVector p r)
  have hX : schattenOneSpectralNorm
      (BinduFiniteDiamond.optimalSchmidtInput p r) ≤ 1 :=
    BinduGADLower.optimalSchmidtInput_schattenOne_le_one p r hp hr
  have hU : Uᴴ * U = (1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) :=
    optimal_reflection_unitary p r hp hr
  have htr := physical_unitary_trace_pairing p r hp hr
  have hpair : BinduFiniteDiamond.gadExactValue p r ≤
      ‖Matrix.trace (U * BinduFiniteDiamond.gadDifference p r 2
        (BinduFiniteDiamond.optimalSchmidtInput p r))‖ := by
    change BinduFiniteDiamond.gadExactValue p r ≤
      ‖Matrix.trace ((BinduGADRankOneReflection.reflection
        (BinduFiniteDiamond.optimalSchmidtVector p r)) *
        BinduFiniteDiamond.gadDifference p r 2
          (BinduFiniteDiamond.optimalSchmidtInput p r))‖
    rw [htr, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (BinduFiniteDiamond.gadExactValue_nonneg p r hp hr)]
  have hUpper : BinduFiniteDiamond.UniformBound
      (BinduFiniteDiamond.gadDifference p r)
      (BinduFiniteDiamond.gadExactValue p r) :=
    ⟨BinduFiniteDiamond.gadExactValue_nonneg p r hp hr,
      BinduGADUpperClosure.gad_upper_obligation_proved p r hp hr⟩
  exact BinduGADLower.diamond_ge_of_unitary_trace_test
    (BinduFiniteDiamond.gadDifference p r)
    (BinduFiniteDiamond.gadExactValue p r)
    (BinduFiniteDiamond.gadExactValue p r)
    hUpper 2 (BinduFiniteDiamond.optimalSchmidtInput p r) U hX hU hpair

/-- REQUIRED FINAL CLAIM: the infimum of all physical finite-ancilla
Schatten-one uniform bounds equals the exact closed expression. -/
theorem physical_gad_exact_diamond (p r : ℝ)
    (hp : 0 ≤ p ∧ p ≤ 1) (hr : 0 ≤ r ∧ r ≤ 1) :
    BinduFiniteDiamond.finiteAncillaDiamond
      (BinduFiniteDiamond.gadDifference p r) =
        BinduFiniteDiamond.gadExactValue p r := by
  apply le_antisymm
  · exact BinduGADUpperClosure.physical_gad_diamond_le_exact p r hp hr
  · exact physical_gad_diamond_ge_exact p r hp hr

#print BinduGADFinal.physical_gad_exact_diamond
#print axioms BinduGADFinal.optimal_reflection_unitary
#print axioms BinduGADFinal.physical_unitary_trace_pairing
#print axioms BinduGADFinal.physical_gad_diamond_ge_exact
#print axioms BinduGADFinal.physical_gad_exact_diamond
end BinduGADFinal
