# BINDU–VECTRA: Machine-Checked Ancilla-Uniform Mixing Bounds for Independent Generalized Amplitude-Damping Channels

Independent research package; archive directory label: 9 November 2026. The supplied primary manuscript files use the filename date prefix `2026_11_10`.

## Primary paper

- `PAPER/2026_11_10_BINDU_VECTRA_Machine_Checked_Ancilla_Uniform_Mixing_Bounds_for_Independent_Generalized_Amplitude_Damping_Channels.pdf`
- `PAPER/2026_11_10_BINDU_VECTRA_Machine_Checked_Ancilla_Uniform_Mixing_Bounds_for_Independent_Generalized_Amplitude_Damping_Channels.tex`

Original, unedited 2-page manuscript by Andrei Preece and Boris Batenin.
The document filename matches the scientific title (with spaces and punctuation
normalized to underscores), using the supplied primary-file date prefix `2026_11_10`.

## Parent / foundational research

- `PARENT_RESEARCH/2026_11_09_Quantum_event_reachability_certificates_dissipative_mixing_and_formally_verified_coherence_benchmarks.pdf`
- `PARENT_RESEARCH/2026_11_09_Quantum_event_reachability_certificates_dissipative_mixing_and_formally_verified_coherence_benchmarks.tex`

Title: **Quantum-event reachability certificates, dissipative mixing, and formally verified coherence benchmarks**; 34 pages; Andrei Preece and Boris Batenin.
This is the same separately supplied foundational PDF and TeX as in the
companion Exact Diamond Distance archive, included for scientific context and
traceability. Its presence is not a formal certificate for all parent claims.
No DOI is assumed or invented.

## Proof sources and integrity

- `PROOFS/BinduEventInterface/`: all **53 source-identical historical Lean modules**
  from the supplied release. In particular the VECTRA targets named by the
  two-page article are in `BinduSiteLocalFamilyBridgeCandidate.lean` and
  `BinduUnconditionalHybridCandidate.lean`. The exact source filenames are
  retained because local Lean imports depend on them.
- `AUDIT/VECTRA_PROOF_MAP.md`: the eight claim/declaration identifiers and
  their precise source-file locations.
- `CERTIFICATION/DEPENDENCY_SHA256.csv`: the original author-supplied SHA-256
  inventory for those 53 modules (its external-project paths are checked
  against local `PROOFS/` locations).
- `LEAN/PhysicalExactDiamond.LEAN_VERIFIED.lean` and the other material in
  `CERTIFICATION/`: retained **historical companion exact-GAD evidence** only.
  These do NOT supply the eight VECTRA build/axiom results, and are not presented
  as if they did. The original replay runner `TOOLS/REPLAY_EXACT_GAD_MAC.py`
  relates to that companion exact-GAD source, not to a VECTRA kernel replay.
- `TOOLS/VERIFY_PACKAGE.py`: checks every file hash, original 53 dependency
  hashes, local Lean import existence, and the source-level presence of the
  eight stated VECTRA theorem declarations and axiom-inspection commands.
  **It does not compile Lean or validate proof statements.**

From inside the extracted top-level package directory:

```sh
python3 TOOLS/VERIFY_PACKAGE.py
```

## Verification status / limitations

The two-page article reports a historical author-performed Lean 4.19.0
verification of eight VECTRA statements. Their corresponding theorem sources
and `#print axioms` commands are present and hash-matched in this archive.
However, the specific VECTRA build logs, axiom **outputs**, the referenced
`VERIFY_CERTIFIED_ONLY_MAC.py` script, and exact standalone Lake project
configuration (`lean-toolchain`, `lakefile.lean` and `lake-manifest.json`) were
**not supplied** in the source ZIP. An independent Lean kernel replay was not
performed during this assembly. Therefore the phrase 'Machine-Checked' in the
scientific title is retained verbatim as part of the original manuscript, not
upgraded here into a new independent verification claim. See
`AUDIT/PACKAGE_COMPLETENESS.md` and `AUDIT/VECTRA_PROOF_MAP.md`.

The six-page **Exact Diamond Distance** article is intentionally **not**
included in this ZIP; it has its own separate archival package. Its historical
Lean source and matching receipts are retained only as source-provenance and
related-work artifacts. Neither the ancillary mixing bound nor the parent
research is claimed to establish the exact diamond norm result.

Original PDF/TeX, all 54 copied Lean source files, original historical receipts,
and author-supplied historical replay runner have been retained byte-for-byte.
The README, VECTRA-focused audit, proof map, provenance record, verification
script and package manifest were created for this release.
