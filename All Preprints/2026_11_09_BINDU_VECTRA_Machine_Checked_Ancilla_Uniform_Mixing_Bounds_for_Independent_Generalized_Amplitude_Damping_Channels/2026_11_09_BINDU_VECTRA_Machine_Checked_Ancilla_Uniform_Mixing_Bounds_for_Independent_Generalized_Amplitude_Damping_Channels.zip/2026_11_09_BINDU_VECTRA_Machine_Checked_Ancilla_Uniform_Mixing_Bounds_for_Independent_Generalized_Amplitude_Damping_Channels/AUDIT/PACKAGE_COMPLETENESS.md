# Scope and completeness — BINDU–VECTRA package

Review date: 9 November 2026. **Not independently kernel replayed.**

## Present

1. Entire unedited two-page **BINDU–VECTRA: Machine-Checked Ancilla-Uniform Mixing Bounds for Independent Generalized Amplitude-Damping Channels** article: PDF and LaTeX.
2. The complete separately supplied 34-page foundational research: PDF and LaTeX.
3. The full 53-module historical Lean source tree; all 53 original SHA-256
   dependency hashes. The eight VECTRA theorem declarations and `#print axioms`
   commands were located in two original project modules.
4. Related but *distinct* first-paper exact-GAD Lean source, historical terminal
   summary, final-success extract, original manifests and historical replay
   runner, preserved as provenance rather than as evidence of VECTRA replay.
5. Fresh SHA-256 manifest covering this package, a package verification script
   checking its actual structure and a source-level theorem map.

## Confirmed by this packaging review

- Original PDF, TeX, Lean sources and historical receipts were byte-copied
  without editing scientific claims or proofs. Only document filenames were
  renamed to match their title and the agreed publication date prefix.
- Integrity checker can match the supplied SHA-256 inventory of all 53 Lean
  dependencies and resolve all local `BinduEventInterface` import references.
- The theorem identifiers listed by the manuscript occur as source declarations,
  and source-side axiom inspection commands are present for all eight.

## Open verification and reproducibility requirements

1. VECTRA-specific successful Lean build transcript and raw compiler output
   were **not** supplied in the provided ZIP. The historical exact-GAD terminal
   report is **not** such a VECTRA report.
2. The specific tool `VERIFY_CERTIFIED_ONLY_MAC.py`, the earlier 58-file
   verification inventory and historical 65-entry source inventory cited by
   the paper are not present in the supplied source archive. They have not
   been silently recreated or asserted to exist.
3. The matching original `lean-toolchain`, `lakefile.lean`, and
   `lake-manifest.json` for Lean/Mathlib are absent; recovering exact dependency
   versions and independent kernel replay remains outstanding.
4. The source check does not execute Lean, inspect compiled theorem types,
   or reproduce axiom reports; it is an integrity/declaration map only.
5. No DOI or public permanent code link is present in the supplied materials.
6. The parent compendium contains many statements outside the eight VECTRA
   theorems, which are not certified by the present archival review.

## Scientific scope of VECTRA article

The short paper presents an ancilla-uniform trace-norm estimate for finite
products of independent generalized-amplitude-damping channels, with an
explicit sum-of-site-coefficients envelope. It does not assert an exactly
computed diamond norm, results for interacting Lindbladians, an optimal
mixing rate, or full verification of the 34-page parent research.

The article's use of 'machine-checked' and descriptions of historical receipts
are author statements preserved verbatim. The independent auditor must
recover the missing records and rerun Lean before declaring independent
reproducibility. This packaging review does not decide the mathematical truth
of the claims.
