# BINDU–VECTRA: target-to-source map

Review date: 9 November 2026. This maps theorem **declarations** in the
provided source archive. It does not assert a new Lean kernel build or replay.

| Target theorem stated in two-page manuscript | Original supplied source |
| --- | --- |
| `bindu_site_local_family_bridge` | `PROOFS/BinduEventInterface/BinduSiteLocalFamilyBridgeCandidate.lean` |
| `bindu_site_replacer_kernel_bridge` | `PROOFS/BinduEventInterface/BinduSiteLocalFamilyBridgeCandidate.lean` |
| `bindu_site_pauli_z_kernel_bridge` | `PROOFS/BinduEventInterface/BinduSiteLocalFamilyBridgeCandidate.lean` |
| `bindu_local_dephasing_half_Z` | `PROOFS/BinduEventInterface/BinduUnconditionalHybridCandidate.lean` |
| `bindu_site_dephasing_kernel_bridge` | `PROOFS/BinduEventInterface/BinduUnconditionalHybridCandidate.lean` |
| `bindu_global_site_identity_unconditional` | `PROOFS/BinduEventInterface/BinduUnconditionalHybridCandidate.lean` |
| `bindu_global_hybrid_rplusr2_unconditional` | `PROOFS/BinduEventInterface/BinduUnconditionalHybridCandidate.lean` |
| `bindu_nQubit_diamond_envelope_unconditional` | `PROOFS/BinduEventInterface/BinduUnconditionalHybridCandidate.lean` |

The source files also include `#print axioms` directives for these declarations.
The output of those directives and a matching compiler success log for these
eight targets were not present in the supplied combined release. Hash matching
and source presence cannot substitute for running the actual compiler/kernel.

The `Candidate` suffix is an historical filename and must not be silently
interpreted as either proof of success or proof of failure.
