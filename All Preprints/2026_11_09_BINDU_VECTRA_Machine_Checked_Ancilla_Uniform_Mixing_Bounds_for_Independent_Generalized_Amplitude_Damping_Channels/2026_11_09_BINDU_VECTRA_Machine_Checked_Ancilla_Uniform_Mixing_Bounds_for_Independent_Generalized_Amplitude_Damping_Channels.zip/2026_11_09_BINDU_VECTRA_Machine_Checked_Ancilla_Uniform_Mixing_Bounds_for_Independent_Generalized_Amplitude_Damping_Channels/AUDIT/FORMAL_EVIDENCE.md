# Formal evidence: exact GAD theorem

This English review replaces the supplied Russian audit and internal
handoff instructions. It reports historical evidence; it is not a new
Lean certificate.

## Exact source identity

The supplied source has 1,573 lines and SHA-256
`6586b54bd2588357b580bd21c5444f19e6dd36c5fb2a7d87fe22c4a8d21456f2`.
That hash matches the `FINAL_SHA256` reported in the supplied transcript.
All 53 supplied dependency files match their original dependency inventory.
All 66 entries of the original overall manifest matched the original
uploaded files before cleanup.

## Reported final statement

The final source declaration is `BinduGADFinal.physical_gad_exact_diamond`.
For real `p` and `r` with `0 <= p <= 1` and `0 <= r <= 1`, its conclusion is
`finiteAncillaDiamond (gadDifference p r) = gadExactValue p r`.
The declared exact value is `2*r*(1-p*(1-p)*r^2)/(2-r)`.
The source defines the norm through nonnegative uniform bounds for all
finite ancillary dimensions and arbitrary complex input matrices, and
defines the physical difference using the four-Kraus channel at `r` and
at `0`. The theorem is not simply a reflexive scalar equality.

## Author-supplied terminal record

The transcript reports a successful final `lake env lean` run and eight
axiom summaries limited to `propext`, `Classical.choice`, and `Quot.sound`.
It also records successful `native_two_smul` and `norm_num_push_cast`
closure attempts after earlier failures. The accepted final source is
preserved unchanged; earlier source drafts are not substituted for it.

The transcript refers to a separate `LOGS/FINAL/PhysicalExactDiamond.log`.
That raw compiler log is not present. No independent kernel replay was
performed during this cleanup because Lean and Lake are unavailable here.
The recorded pass and source identity are different evidence from a new
successful execution in an independent environment.

## Scope

The reported certificate concerns the exact single-qubit physical
finite-ancilla norm equality. It does not automatically certify the
separate analytic SDP argument, an 8-by-8 PSD formalization, multiqubit
corollaries, or equivalence with another library's named diamond norm.
The old `GAD_Exact_Diamond_Complete.lean` is neither supplied nor imported.
The two-page core manuscript has eight different targets; its historical
verification evidence must be assessed separately.

## Independent acceptance requirements

Recover the exact original toolchain and dependency pins, build the
supplied imports, replay the byte-identical final source, retain the raw
compiler output, and inspect the final theorem type and all eight axiom
reports. Preserve the accepted source and record any later changes under
new hashes. These requirements do not imply that the missing inputs or
the independent replay have already been supplied.
