#!/usr/bin/env python3
"""Read-only replay of the BINDU physical GAD theorem using current Mac Lean.

The source is fixed by SHA-256 and project source roots are not modified.
Compiler logs and a machine-readable report are written only to the output
folder chosen by --output or to the release's CERTIFICATION/REPLAY_RESULTS.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, pathlib, re, shutil, subprocess, sys, time
ROOTKIT=pathlib.Path(__file__).resolve().parent.parent
SRC=ROOTKIT/'LEAN/PhysicalExactDiamond.LEAN_VERIFIED.lean'
EXPECTED='6586b54bd2588357b580bd21c5444f19e6dd36c5fb2a7d87fe22c4a8d21456f2'
ALLOWED={'propext','Classical.choice','Quot.sound'}
THEOREMS=[
 'BinduGADNativePhysical.native_trace_polynomial',
 'BinduGADNativePhysical.physical_difference_slice',
 'BinduGADNativePhysical.actual_input_eq_native',
 'BinduGADNativePhysical.actual_output_eq_native',
 'BinduGADFinal.optimal_reflection_unitary',
 'BinduGADFinal.physical_unitary_trace_pairing',
 'BinduGADFinal.physical_gad_diamond_ge_exact',
 'BinduGADFinal.physical_gad_exact_diamond',
]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args):
    project=pathlib.Path(args.current).resolve(strict=True)
    if not (project/'lakefile.lean').exists() or not (project/'lean-toolchain').exists():
        raise ValueError('CURRENT must be a valid Lake project')
    if not SRC.is_file() or sha(SRC)!=EXPECTED:
        raise ValueError('Exact accepted Lean proof source hash mismatch')
    with (ROOTKIT/'CERTIFICATION/DEPENDENCY_SHA256.csv').open(newline='') as file:
        dep_rows=list(csv.DictReader(file))
    for row in dep_rows:
        dep=project/row['current_relative_path']
        if not dep.is_file() or sha(dep)!=row['sha256']:
            raise ValueError('Protected dependency SHA mismatch: '+str(dep))
    print('DEPENDENCIES_SHA256_MATCHED='+str(len(dep_rows)))
    lk=shutil.which('lake')
    if not lk:raise ValueError('lake missing; nothing certified')
    for rel in ['BinduEventInterface/TwoQubitCPTPSemigroupCandidate.lean',
                'BinduEventInterface/NQubitDiamondExponentialMixingCandidate.lean',
                'BinduEventInterface/FiniteKrausTraceCandidate.lean',
                'BinduEventInterface/CPTPDiamondContractivity.lean',
                'BinduEventInterface/SchattenOneDecomposition.lean',
                'BinduEventInterface/KrausEnergyBridge.lean']:
        if not (project/rel).is_file():raise ValueError('Missing dependency: '+rel)
    out=pathlib.Path(args.output).resolve() if args.output else ROOTKIT/'CERTIFICATION/REPLAY_RESULTS'
    out.mkdir(parents=True, exist_ok=True)
    try:
        version=subprocess.run([lk,'env','lean','--version'],cwd=project,capture_output=True,text=True,timeout=60)
        version_txt=(version.stdout+'\n'+version.stderr).strip()
    except Exception as exc:
        version_txt='UNKNOWN: '+str(exc)
    cp=subprocess.run([lk,'env','lean',str(SRC)],cwd=project,
      capture_output=True,text=True,errors='replace',timeout=args.timeout)
    log=cp.stdout+'\n'+cp.stderr
    (out/'LEAN_KERNEL_FULL.log').write_text(log,encoding='utf8')
    print('LEAN_EXIT='+str(cp.returncode))
    print('SOURCE_SHA256='+EXPECTED)
    found={}
    for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",log,re.S):
        found[m.group(1)]={x.strip() for x in m.group(2).split(',') if x.strip()}
    for m in re.finditer(r"'([^']+)' does not depend on any axioms",log):found[m.group(1)]=set()
    a_ok=all(k in found and found[k] <= ALLOWED for k in THEOREMS)
    match=re.search(r'theorem\s+BinduGADFinal\.physical_gad_exact_diamond\b([\s\S]{0,2200}?)\s*:=',log)
    type_txt=match.group(0) if match else ''
    type_ok=all(x in type_txt for x in ('finiteAncillaDiamond','gadDifference','gadExactValue','0 ≤ p','0 ≤ r')) and '=' in type_txt
    ok=cp.returncode==0 and a_ok and type_ok and 'sorryAx' not in log
    report={'verdict':'GAD_EXACT_LEAN_KERNEL_REPLAY_PASSED' if ok else 'GAD_REPLAY_NOT_CERTIFIED',
            'lean_exit':cp.returncode, 'lean_version':version_txt, 'source_sha256':EXPECTED, 'dependencies_sha_verified':len(dep_rows),
            'axioms':{k:sorted(found.get(k,set())) if k in found else None for k in THEOREMS},
            'type_check':type_ok,'source':'LEAN/PhysicalExactDiamond.LEAN_VERIFIED.lean',
            'proof_target':type_txt, 'current_project':str(project)}
    (out/'LEAN_CERTIFICATE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print('AXIOMS_OK='+str(a_ok),'PHYSICAL_TYPE_OK='+str(type_ok))
    print('VERDICT='+report['verdict'])
    return 0 if ok else 1
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('current');p.add_argument('--output');p.add_argument('--timeout',type=int,default=1200)
    x=p.parse_args()
    try:sys.exit(run(x))
    except (ValueError,FileNotFoundError,subprocess.TimeoutExpired) as e:
        print('VERDICT=GAD_REPLAY_NOT_CERTIFIED ERROR='+str(e),file=sys.stderr);sys.exit(2)
