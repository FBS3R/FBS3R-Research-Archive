#!/usr/bin/env python3
"""Verify this ZIP's hashes, VECTRA declaration presence, and local Lean imports.
Not a Lean kernel run, verification of theorem bodies, or scientific peer review.
"""
from pathlib import Path
import csv,hashlib,re,sys

ROOT=Path(__file__).resolve().parent.parent
EXACT_GAD_HASH='6586b54bd2588357b580bd21c5444f19e6dd36c5fb2a7d87fe22c4a8d21456f2'
TARGETS=(
 'bindu_site_local_family_bridge',
 'bindu_site_replacer_kernel_bridge',
 'bindu_site_pauli_z_kernel_bridge',
 'bindu_local_dephasing_half_Z',
 'bindu_site_dephasing_kernel_bridge',
 'bindu_global_site_identity_unconditional',
 'bindu_global_hybrid_rplusr2_unconditional',
 'bindu_nQubit_diamond_envelope_unconditional',
)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(rel):
 p=(ROOT/rel).resolve()
 if not p.is_relative_to(ROOT) or p==ROOT:raise ValueError('Unsafe path: '+rel)
 return p

def main():
 failures=[]
 with (ROOT/'MANIFEST_SHA256.csv').open(newline='',encoding='utf8') as f:
  rows=list(csv.DictReader(f))
 names=[r['relative_path'] for r in rows]
 if len(names)!=len(set(names)):failures.append('Duplicate manifest paths')
 for row in rows:
  p=safe(row['relative_path'])
  if not p.is_file() or sha(p)!=row['sha256']:
   failures.append('Manifest mismatch: '+row['relative_path'])
 excluded=lambda p: ('__pycache__' in p.parts or
                       str(p).startswith('CERTIFICATION/REPLAY_RESULTS/'))
 actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
         and p.name!='MANIFEST_SHA256.csv' and not excluded(p.relative_to(ROOT))}
 for n in sorted(actual-set(names)):failures.append('Unlisted file: '+n)
 for n in sorted(set(names)-actual):failures.append('Missing listed file: '+n)
 with (ROOT/'CERTIFICATION/DEPENDENCY_SHA256.csv').open(newline='',encoding='utf8') as f:
  deps=list(csv.DictReader(f))
 if len(deps)!=53:failures.append('Expected 53 original dependency hashes')
 for row in deps:
  p=safe('PROOFS/'+row['current_relative_path'])
  if not p.is_file() or sha(p)!=row['sha256']:
   failures.append('Original dependency mismatch: '+row['current_relative_path'])
 historical=ROOT/'LEAN/PhysicalExactDiamond.LEAN_VERIFIED.lean'
 if not historical.is_file() or sha(historical)!=EXACT_GAD_HASH:
  failures.append('Historical exact-GAD source hash mismatch')
 modules=list((ROOT/'PROOFS/BinduEventInterface').glob('*.lean'))
 if len(modules)!=53:failures.append('Expected 53 project modules')
 texts={p:p.read_text(encoding='utf8') for p in modules}
 mapped={}
 axiom_cmd=0
 for name in TARGETS:
  occurrences=[p.relative_to(ROOT).as_posix() for p,s in texts.items()
               if re.search(r'\btheorem\s+'+re.escape(name)+r'\b',s)]
  if len(occurrences)!=1:failures.append('VECTRA theorem declaration not unique/present: '+name)
  mapped[name]=occurrences
  if not any(re.search(r'#print\s+axioms\s+(?:\S+\.)?'+re.escape(name)+r'\b',s)
             for s in texts.values()):
   failures.append('Missing historical axiom inspection command: '+name)
  else:axiom_cmd+=1
 external=set(); imports=0
 for p,s in {**texts,historical:historical.read_text(encoding='utf8') if historical.exists() else ''}.items():
  for mod in re.findall(r'^import\s+(\S+)',s,re.M):
   if mod.startswith('BinduEventInterface.'):
    imports+=1
    if not (ROOT/'PROOFS'/ (mod.replace('.','/')+'.lean')).is_file():
     failures.append('Missing local import: '+mod)
   else: external.add(mod)
 if failures:
  for f in failures:print('FAIL:',f,file=sys.stderr)
  print('PACKAGE_INTEGRITY=FAILED',file=sys.stderr)
  return 1
 print('PACKAGE_INTEGRITY=PASSED')
 print('MANIFEST_FILES='+str(len(rows)))
 print('ORIGINAL_DEPENDENCY_HASHES_MATCHED='+str(len(deps)))
 print('VECTRA_TARGET_DECLARATIONS_PRESENT='+str(len(mapped)))
 print('VECTRA_AXIOM_INSPECTION_COMMANDS_PRESENT='+str(axiom_cmd))
 print('LOCAL_PROJECT_IMPORTS_RESOLVED='+str(imports))
 print('EXTERNAL_MODULES='+', '.join(sorted(external)))
 print('HISTORICAL_EXACT_GAD_SOURCE_HASH_MATCHED=True')
 print('VECTRA_KERNEL_REPLAY=NOT_PERFORMED')
 print('VECTRA_HISTORICAL_BUILD_LOG=NOT_INCLUDED')
 print('PUBLICATION_COMPLETENESS=UNRESOLVED; see AUDIT/PACKAGE_COMPLETENESS.md')
 return 0

if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,KeyError,csv.Error,UnicodeError) as exc:
  print('PACKAGE_INTEGRITY=FAILED: '+str(exc),file=sys.stderr)
  sys.exit(2)
